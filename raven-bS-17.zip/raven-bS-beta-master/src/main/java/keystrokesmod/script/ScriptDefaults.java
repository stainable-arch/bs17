package keystrokesmod.script;

import keystrokesmod.Raven;
import keystrokesmod.clickgui.ClickGui;
import keystrokesmod.clickgui.components.impl.CategoryComponent;
import keystrokesmod.clickgui.components.impl.ModuleComponent;
import keystrokesmod.helper.RotationHelper;
import keystrokesmod.mixin.impl.accessor.*;
import keystrokesmod.module.Module;
import keystrokesmod.module.ModuleManager;
import keystrokesmod.module.impl.combat.AimAssist;
import keystrokesmod.module.impl.combat.KillAura;
import keystrokesmod.module.impl.network.Backtrack;
import keystrokesmod.module.impl.network.LagRange;
import keystrokesmod.module.setting.Setting;
import keystrokesmod.module.setting.impl.*;
import keystrokesmod.script.model.*;
import keystrokesmod.script.model.Vec3;
import keystrokesmod.script.packet.clientbound.SPacket;
import keystrokesmod.script.packet.serverbound.CPacket;
import keystrokesmod.script.packet.serverbound.PacketHandler;
import keystrokesmod.utility.*;
import keystrokesmod.utility.shader.BlurUtils;
import keystrokesmod.utility.shader.RoundedUtils;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.*;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.gui.inventory.GuiContainerCreative;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.resources.ResourcePackRepository;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.inventory.ContainerWorkbench;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemBlock;
import net.minecraft.network.Packet;
import net.minecraft.realms.RealmsBridge;
import net.minecraft.scoreboard.Team;
import net.minecraft.util.*;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ScriptDefaults {
    private static ExecutorService cachedExecutor;
    private static final Minecraft mc = Minecraft.getMinecraft();
    public static final Bridge bridge = new Bridge();
    private static final LinkedHashMap<String, Module> modulesMap = new LinkedHashMap<>();

    public static void reloadModules() {
        modulesMap.clear();
        for (Module module : Raven.getModuleManager().getModules()) {
            modulesMap.put(module.getName(), module);
        }
        for (Module module : Raven.scriptManager.scripts.values()) {
            modulesMap.put(module.getName(), module);
        }
    }

    public static class client {
        public static boolean allowFlying() {
            return mc.thePlayer.capabilities.allowFlying;
        }

        public static void setItemInUse(boolean inUse) {
            ReflectionUtils.setItemInUse(inUse);
        }

        public static void setTabName(String name, String displayName) {
            if (name == null || displayName == null || mc.getNetHandler() == null) {
                return;
            }

            for (NetworkPlayerInfo info : mc.getNetHandler().getPlayerInfoMap()) {
                if (info.getGameProfile() != null && name.equalsIgnoreCase(info.getGameProfile().getName())) {
                    info.setDisplayName(new ChatComponentText(displayName));
                    return;
                }
            }
        }

        public static long nanoTime() {
            return System.nanoTime();
        }

        public static void removePotionEffect(int id) {
            if (mc.thePlayer == null) {
                return;
            }
            mc.thePlayer.removePotionEffectClient(id);
        }

        public static int getUID() {
            return 4;
        }

        public static String getUser() {
            return mc.thePlayer.getName();
        }

        public static void addEnemy(String username) {
            Utils.addEnemy(username);
        }

        public static void addFriend(String username) {
            Utils.addFriend(username);
        }

        public static void async(final Runnable method) {
            if (cachedExecutor == null) {
                cachedExecutor = Executors.newCachedThreadPool();
            }
            cachedExecutor.execute(method);
        }

        public static int getFPS() {
            return Minecraft.getDebugFPS();
        }

        public static void chat(String message) {
            mc.thePlayer.sendChatMessage(message);
        }

        public static void print(String string) {
            Utils.sendRawMessage(string);
        }

        public static void print(Message component) {
            mc.thePlayer.addChatMessage(component.component);
        }

        public static void print(Object object) {
            String s = String.valueOf(object);
            Utils.sendRawMessage(s);
        }

        public static boolean isDiagonal() {
            return Utils.isDiagonal(false);
        }

        public static void setTimer(float timer) {
            ((IAccessorMinecraft) mc).getTimer().timerSpeed = timer;
        }

        public static void setTimer(double timer) {
            ((IAccessorMinecraft) mc).getTimer().timerSpeed = (float) timer;
        }

        public static boolean isCreative() {
            return mc.thePlayer.capabilities.isCreativeMode;
        }

        public static void processPacket(SPacket packet) {
            packet.packet.processPacket((((IAccessorNetworkManager) (mc.getNetHandler().getNetworkManager())).getPacketListener()));
        }

        public static void multiplyMotion(double factor) {
            mc.thePlayer.motionZ *= factor;
            mc.thePlayer.motionX *= factor;
        }

        public static void processPacketNoEvent(SPacket packet) {
            PacketUtils.receivePacketNoEvent(packet.packet);
        }

        public static String getTitle() {
            return ((IAccessorGuiIngame) mc.ingameGUI).getDisplayedTitle();
        }

        public static String getSubTitle() {
            return ((IAccessorGuiIngame) mc.ingameGUI).getDisplayedSubTitle();
        }

        public static String getRecordPlaying() {
            return ((IAccessorGuiIngame) mc.ingameGUI).getRecordPlaying();
        }

        public static boolean isFlying() {
            return mc.thePlayer.capabilities.isFlying;
        }

        public static void attack(Entity entity) {
            Utils.attackEntity(entity.entity, true, true);
        }

        public static boolean isSinglePlayer() {
            return mc.isSingleplayer();
        }

        public static boolean isSpectator() {
            return mc.thePlayer.isSpectator();
        }

        public static void setFlying(boolean flying) {
            mc.thePlayer.capabilities.isFlying = flying;
        }

        public static void setJump(boolean jump) {
            mc.thePlayer.movementInput.jump = jump;
        }

        public static void setJumping(boolean jump) {
            mc.thePlayer.setJumping(jump);
        }

        public static void setRenderArmPitch(float pitch) {
            mc.thePlayer.prevRenderArmPitch = pitch;
            mc.thePlayer.renderArmPitch = pitch;
        }

        public static float getEquippedProgress() {
            return ((IAccessorItemRenderer) mc.getItemRenderer()).getEquippedProgress();
        }

        public static void disconnect() {
            boolean isLocal = mc.isIntegratedServerRunning();
            boolean isRealms = mc.isConnectedToRealms();
            mc.theWorld.sendQuittingDisconnectingPacket();
            mc.loadWorld(null);
            if (isLocal) {
                mc.displayGuiScreen(new GuiMainMenu());
                return;
            }
            if (isRealms) {
                new RealmsBridge().switchToRealms(new GuiMainMenu());
                return;
            }
            mc.displayGuiScreen(new GuiMultiplayer(new GuiMainMenu()));
        }

        public static float getRenderArmPitch() {
            return mc.thePlayer.renderArmPitch;
        }

        public static void setRenderArmYaw(float yaw) {
            mc.thePlayer.prevRenderArmYaw = yaw;
            mc.thePlayer.renderArmYaw = yaw;
        }

        public static float getRenderArmYaw() {
            return mc.thePlayer.renderArmYaw;
        }

        public static long getTotalMemory() {
            return Runtime.getRuntime().totalMemory();
        }

        public static long getFreeMemory() {
            return Runtime.getRuntime().freeMemory();
        }

        public static long getMaxMemory() {
            return Runtime.getRuntime().maxMemory();
        }

        public static List<String[]> getResourcePacks() {
            List<String[]> packs = new ArrayList<>();
            if (mc.getResourcePackRepository().getRepositoryEntries() == null || mc.getResourcePackRepository().getRepositoryEntries().isEmpty()) {
                packs.add(new String[] { mc.mcDefaultResourcePack.getPackName(), "" } );
            }
            else {
                for (ResourcePackRepository.Entry entry : mc.getResourcePackRepository().getRepositoryEntries()) {
                    packs.add(new String[] { entry.getResourcePackName(), entry.getTexturePackDescription() } );
                }
            }
            Collections.reverse(packs); // reverse it to match the correct order
            return packs;
        }

        public static void jump() {
            mc.thePlayer.jump();
        }

        public static boolean allowEditing() {
            if (mc.thePlayer == null || mc.thePlayer.capabilities == null) {
                return false;
            }
            return mc.thePlayer.capabilities.allowEdit;
        }

        public static void setItemInUseCount(int count) {
            ((IAccessorEntityPlayer) mc.thePlayer).setItemInUseCount(count);
        }

        public static int getItemInUseCount() {
            return mc.thePlayer.getItemInUseCount();
        }

        public static int getItemInUseDuration() {
            return mc.thePlayer.getItemInUseDuration();
        }

        public static void log(final Object obj) {
            Utils.log.info(obj);
        }

        public static void setSneaking(boolean sneak) {
            mc.thePlayer.setSneaking(sneak);
        }

        public static void setSneak(boolean sneak) {
            mc.thePlayer.movementInput.sneak = sneak;
        }

        public static boolean isSneak() {
            return mc.thePlayer.movementInput.sneak;
        }

        public static Entity getPlayer() {
            if (mc == null || mc.thePlayer == null) {
                return null;
            }
            return Entity.convert(mc.thePlayer);
        }

        public static void removeEnemy(String username) {
            Utils.removeEnemy(username);
        }

        public static void removeFriend(String username) {
            Utils.removeFriend(username);
        }

        public static boolean isRiding() {
            return mc.thePlayer.isRiding();
        }

        public static void setRidingEntity(Entity entity) {
            if (entity == null) {
                mc.thePlayer.ridingEntity = null;
                return;
            }
            mc.thePlayer.ridingEntity = entity.entity;
        }

        public static Vec3 getMotion() {
            return new Vec3(mc.thePlayer.motionX, mc.thePlayer.motionY, mc.thePlayer.motionZ);
        }

        public static void sleep(long ms) {
            try {
                Thread.sleep(ms);
            }
            catch (InterruptedException ignored) {}
        }

        public static void ping() {
            mc.thePlayer.playSound("note.pling", 1.0f, 1.0f);
        }

        public static void playSound(String name, float volume, float pitch) {
            mc.thePlayer.playSound(name, volume, pitch);
        }

        public static boolean isMoving() {
            return Utils.isMoving();
        }

        public static boolean isJump() {
            return mc.thePlayer.movementInput.jump;
        }

        public static float getStrafe() {
            return mc.thePlayer.movementInput.moveStrafe;
        }

        public static void sleep(int ms) {
            try {
                Thread.sleep(ms);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }

        public static float getForward() {
            return mc.thePlayer.movementInput.moveForward;
        }

        public static void closeScreen() {
            if (mc.currentScreen instanceof ClickGui) {
                mc.displayGuiScreen(null);
                return;
            }
            mc.thePlayer.closeScreen();
        }

        public static String getScreen() {
            return mc.currentScreen == null ? "" : mc.currentScreen.getClass().getSimpleName();
        }

        public static float[] getRotationsToEntity(Entity entity) {
            return RotationUtils.getRotations(entity.entity);
        }

        public static void sendPacket(CPacket packet) {
            Packet packet1 = PacketHandler.convertCPacket(packet);
            if (packet1 == null) {
                return;
            }
            mc.thePlayer.sendQueue.addToSendQueue(packet1);
        }

        public static void sendPacketNoEvent(CPacket packet) {
            Packet packet1 = PacketHandler.convertCPacket(packet);
            if (packet1 == null) {
                return;
            }
            PacketUtils.sendPacketNoEvent(packet1);
        }

        public static boolean inFocus() {
            return mc.inGameHasFocus;
        }

        public static void dropItem(boolean dropStack) {
            mc.thePlayer.dropOneItem(dropStack);
        }

        public static void setMotion(double x, double y, double z) {
            mc.thePlayer.motionX = x;
            mc.thePlayer.motionY = y;
            mc.thePlayer.motionZ = z;
        }

        public static void setSpeed(double speed) {
            Utils.setSpeed(speed);
        }

        public static void setForward(float forward) {
            mc.thePlayer.movementInput.moveForward = forward;
        }

        public static void setStrafe(float strafe) {
            mc.thePlayer.movementInput.moveStrafe = strafe;
        }

        public static String getServerIP() {
            if (mc.getCurrentServerData() == null || mc.isSingleplayer()) {
                return "";
            }
            return mc.getCurrentServerData().serverIP;
        }

        public static int[] getDisplaySize() {
            final ScaledResolution scaledResolution = new ScaledResolution(mc);
            return new int[]{scaledResolution.getScaledWidth(), scaledResolution.getScaledHeight(), scaledResolution.getScaleFactor()};
        }

        public static float getServerDirection(PlayerState state) {
            return state.yaw;
        }

        public static Object[] raycastBlock(final double distance) {
            return raycastBlock(distance, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch);
        }

        public static Object[] raycastBlock(final double distance, final float yaw, final float pitch) {
            final net.minecraft.util.Vec3 eyeVec = mc.thePlayer.getPositionEyes(1.0f);
            final net.minecraft.util.Vec3 lookVec = Utils.getLookVec(yaw, pitch);
            final net.minecraft.util.Vec3 sumVec = eyeVec.addVector(lookVec.xCoord * distance, lookVec.yCoord * distance, lookVec.zCoord * distance);
            final MovingObjectPosition mop = mc.theWorld.rayTraceBlocks(eyeVec, sumVec, false, false, false);
            if (mop == null || mop.typeOfHit != MovingObjectPosition.MovingObjectType.BLOCK) {
                return null;
            }
            final Vec3 pos = new Vec3(mop.getBlockPos());
            final Vec3 offset = new Vec3(mop.hitVec.xCoord - pos.x, mop.hitVec.yCoord - pos.y, mop.hitVec.zCoord - pos.z);
            return new Object[] { pos, offset, mop.sideHit.name() };
        }

        public static Object[] raycastEntity(final double distance) {
            return raycastEntity(distance, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch);
        }

        public static Object[] raycastEntity(final double distance, final float yaw, final float pitch) {
            net.minecraft.entity.Entity pointedEntity = null;
            MovingObjectPosition mop = mc.thePlayer.rayTrace(distance, 1.0f);
            final net.minecraft.util.Vec3 eyeVec = mc.thePlayer.getPositionEyes(1.0f);
            final net.minecraft.util.Vec3 lookVec = Utils.getLookVec(yaw, pitch);
            final net.minecraft.util.Vec3 vec32 = eyeVec.addVector(lookVec.xCoord * distance, lookVec.yCoord * distance, lookVec.zCoord * distance);
            net.minecraft.util.Vec3 vec33 = null;
            final List list = mc.theWorld.getEntitiesWithinAABBExcludingEntity(mc.getRenderViewEntity(), mc.getRenderViewEntity().getEntityBoundingBox().addCoord(lookVec.xCoord * distance, lookVec.yCoord * distance, lookVec.zCoord * distance).expand(1.0, 1.0, 1.0));
            double d2 = distance;
            for (int i = 0; i < list.size(); ++i) {
                final net.minecraft.entity.Entity entity = (net.minecraft.entity.Entity) list.get(i);
                if (entity instanceof EntityLivingBase && entity.canBeCollidedWith()) {
                    if (((EntityLivingBase)entity).deathTime == 0) {
                        final float cbs = entity.getCollisionBorderSize();
                        final AxisAlignedBB axisalignedbb = entity.getEntityBoundingBox().expand((double)cbs, (double)cbs, (double)cbs);
                        final MovingObjectPosition movingobjectposition = axisalignedbb.calculateIntercept(eyeVec, vec32);
                        if (axisalignedbb.isVecInside(eyeVec)) {
                            if (0.0 < d2 || d2 == 0.0) {
                                pointedEntity = entity;
                                vec33 = ((movingobjectposition == null) ? eyeVec : movingobjectposition.hitVec);
                                d2 = 0.0;
                            }
                        }
                        else if (movingobjectposition != null) {
                            final double d3 = eyeVec.distanceTo(movingobjectposition.hitVec);
                            if (d3 < d2 || d2 == 0.0) {
                                if (entity == mc.getRenderViewEntity().ridingEntity && !entity.canRiderInteract()) {
                                    if (d2 == 0.0) {
                                        pointedEntity = entity;
                                        vec33 = movingobjectposition.hitVec;
                                    }
                                }
                                else {
                                    pointedEntity = entity;
                                    vec33 = movingobjectposition.hitVec;
                                    d2 = d3;
                                }
                            }
                        }
                    }
                }
            }
            if (pointedEntity != null && (d2 < distance || mop == null)) {
                mop = new MovingObjectPosition(pointedEntity, vec33);
                final Vec3 offset = new Vec3(mop.hitVec.xCoord - pointedEntity.posX, mop.hitVec.yCoord - pointedEntity.posY, mop.hitVec.zCoord - pointedEntity.posZ);
                return new Object[] { new Entity(mop.entityHit), offset, eyeVec.squareDistanceTo(mop.hitVec) };
            }
            return null;
        }

        public static boolean canPlaceBlock(ItemStack stack, Vec3 pos, String side) {
            if (stack == null || stack.itemStack == null || stack.itemStack.getItem() == null || !stack.isBlock) {
                return false;
            }
            return ((ItemBlock) stack.itemStack.getItem()).canPlaceBlockOnSide(mc.theWorld, Vec3.getBlockPos(pos), Utils.getEnum(EnumFacing.class, side), mc.thePlayer, stack.itemStack);
        }

        public static boolean placeBlock(Vec3 targetPos, String side, Vec3 hitVec) {
            return mc.playerController.onPlayerRightClick(mc.thePlayer, mc.theWorld, mc.thePlayer.getHeldItem(), Vec3.getBlockPos(targetPos), Utils.getEnum(EnumFacing.class, side), Vec3.getVec3(hitVec));
        }

        public static void clickBlock(Vec3 blockpos, String side) {
            mc.playerController.clickBlock(Vec3.getBlockPos(blockpos), Utils.getEnum(EnumFacing.class, side));
        }

        public static void enableMovementFix() {
            RotationHelper.get().forceMovementFix = true;
        }

        public static void disableMovementFix() {
            RotationHelper.get().forceMovementFix = false;
        }

        public static boolean isMovementFixActive() {
            return RotationHelper.get().fixMovement();
        }

        public static boolean isRotationActive() {
            return RotationHelper.get().isActive();
        }

        public static void setRotations(float yaw, float pitch) {
            RotationHelper.get().setRotations(yaw, pitch);
        }

        public static void setYaw(float yaw) {
            RotationHelper.get().setYaw(yaw);
        }

        public static void setPitch(float pitch) {
            RotationHelper.get().setPitch(pitch);
        }

        public static Float getServerYaw() {
            return RotationHelper.get().getServerYaw();
        }

        public static Float getServerPitch() {
            return RotationHelper.get().getServerPitch();
        }

        public static float[] getRotationsToBlock(Vec3 position) {
            return RotationUtils.getRotations(new BlockPos(position.x, position.y, position.z));
        }

        public static void setSprinting(boolean sprinting) {
            mc.thePlayer.setSprinting(sprinting);
        }

        public static void swing() {
            mc.thePlayer.swingItem();
        }

        public static void swingReset() {
            mc.thePlayer.swingItem();
            mc.getItemRenderer().resetEquippedProgress();
        }

        public static long time() {
            return System.currentTimeMillis();
        }

        public static boolean isFriend(String username) {
            return Utils.isFriended(username);
        }

        public static boolean isEnemy(String username) {
            return Utils.isEnemy(username);
        }
    }

    public static class world {
        public static boolean exists() {
            return mc.theWorld != null;
        }

        public static Entity spawnMob(String type, double x, double y, double z) {
            return ClientEntityManager.spawnMob(type, x, y, z);
        }

        public static Entity spawnMob(String type, Vec3 position) {
            if (position == null) {
                return null;
            }
            return spawnMob(type, position.x, position.y, position.z);
        }

        public static boolean removeClientEntity(Entity entity) {
            return ClientEntityManager.removeClientEntity(entity);
        }

        public static void clearClientEntities() {
            ClientEntityManager.clearClientEntities();
        }

        public static void playSound(String name, float volume, float pitch, double x, double y, double z) {
            mc.theWorld.playSound(x, y, z, name, volume, pitch, false);
        }

        public static boolean isValidEntity(Entity entity) {
            return mc.theWorld != null && mc.theWorld.loadedEntityList.contains(entity);
        }

        public static Block getBlockAt(int x, int y, int z) {
            IBlockState state = BlockUtils.getBlockState(new BlockPos(x, y, z));
            if (state == null) {
                return new Block(Blocks.air, new BlockPos(x, y, z));
            }
            return new Block(state, new BlockPos(x, y, z));
        }

        public static String getTitleText() {
            return client.getTitle();
        }

        public static void setTitleText(String title, String subTitle, int timeFadeIn, int displayTime, int timeFadeOut) {
            mc.ingameGUI.displayTitle(title, subTitle, timeFadeIn, displayTime, timeFadeOut);
        }

        public static void clearTitleText() {
            mc.ingameGUI.displayTitle(null, null, -1, -1, -1);
        }

        public static Block getBlockAt(Vec3 pos) {
            IBlockState state = BlockUtils.getBlockState(new BlockPos(pos.x, pos.y, pos.z));
            if (state == null) {
                return new Block(Blocks.air, new BlockPos(pos.x, pos.y, pos.z));
            }
            return new Block(state, new BlockPos(pos.x, pos.y, pos.z));
        }

        public static String getDimension() {
            if (mc.theWorld == null) {
                return "";
            }
            return mc.theWorld.provider.getDimensionName();
        }

        public static List<Entity> getEntities() {
            List<Entity> entities = new ArrayList<>();
            if (mc.theWorld == null) {
                return entities;
            }
            for (net.minecraft.entity.Entity entity : mc.theWorld.loadedEntityList) {
                entities.add(Entity.convert(entity));
            }
            return entities;
        }

        public static Entity getEntityById(int entityId) {
            if (mc.theWorld == null) {
                return null;
            }
            return Entity.convert(mc.theWorld.getEntityByID(entityId));
        }

        public static List<NetworkPlayer> getNetworkPlayers() {
            List<NetworkPlayer> entities = new ArrayList<>();
            for (NetworkPlayerInfo networkPlayerInfo : Utils.getTablist(false)) {
                entities.add(NetworkPlayer.convert(networkPlayerInfo));
            }
            return entities;
        }

        public static List<Entity> getPlayerEntities() {
            List<Entity> entities = new ArrayList<>();
            for (net.minecraft.entity.Entity entity : mc.theWorld.playerEntities) {
                entities.add(Entity.convert(entity));
            }
            return entities;
        }

        public static List<String> getScoreboard() {
            List<String> sidebarLines = Utils.getSidebarLines();
            if (sidebarLines.isEmpty()) {
                return null;
            }
            return sidebarLines;
        }

        public static String getTabHeader() {
            if (mc == null || mc.ingameGUI == null || mc.ingameGUI.getTabList() == null) {
                return "";
            }
            IChatComponent header = ((IAccessorGuiPlayerTabOverlay) mc.ingameGUI.getTabList()).getHeader();
            if (header != null) {
                return header.getUnformattedText();
            }
            return "";
        }

        public static String getTabFooter() {
            if (mc == null || mc.ingameGUI == null || mc.ingameGUI.getTabList() == null) {
                return "";
            }
            IChatComponent footer = ((IAccessorGuiPlayerTabOverlay) mc.ingameGUI.getTabList()).getFooter();
            if (footer != null) {
                return footer.getUnformattedText();
            }
            return "";
        }

        public static Map<String, List<String>> getTeams() {
            Map<String, List<String>> teams = new HashMap<>();
            for (Team team : mc.theWorld.getScoreboard().getTeams()) {
                List<String> members = new ArrayList<>();
                for (String member : team.getMembershipCollection()) {
                    members.add(member);
                }
                teams.put(team.getRegisteredName(), members);
            }
            return teams;
        }

        public static List<TileEntity> getTileEntities() {
            List<TileEntity> tileEntities = new ArrayList<>();
            for (net.minecraft.tileentity.TileEntity entity : mc.theWorld.loadedTileEntityList) {
                tileEntities.add(new TileEntity(entity));
            }
            return tileEntities;
        }
    }

    public static class modules {
        private String superName;

        public modules(String superName) {
            this.superName = superName;
        }

        private static Module getModule(String moduleName) {
            return modulesMap.get(moduleName);
        }

        private static Module getScript(String name) {
            return modulesMap.get(name);
        }

        private static Setting getSetting(Module module, String settingName) {
            if (module == null) {
                return null;
            }
            for (Setting setting : module.getSettings()) {
                if (setting.getName().equals(settingName)) {
                    return setting;
                }
            }
            return null;
        }

        private GroupSetting getGroupForString(String group) {
            if (group.isEmpty()) {
                return null;
            }
            List<Setting> settings = getScript(this.superName).getSettings();
            for (Setting setting : settings) {
                if (!(setting instanceof GroupSetting)) {
                    continue;
                }
                if (setting.getName().equals(group)) {
                    return (GroupSetting) setting;
                }
            }
            return null;
        }

        public void enable(String moduleName) {
            if (getModule(moduleName) == null) {
                return;
            }
            getModule(moduleName).enable();
        }

        public void disable(String moduleName) {
            if (getModule(moduleName) == null) {
                return;
            }
            getModule(moduleName).disable();
        }

        public boolean isEnabled(String moduleName) {
            if (getModule(moduleName) == null) {
                return false;
            }
            return getModule(moduleName).isEnabled();
        }

        public Entity getKillAuraTarget() {
            if (KillAura.target == null) {
                return null;
            }
            return Entity.convert(KillAura.target);
        }

        public Entity getAimAssistTarget() {
            AimAssist aimAssist = (AimAssist) ModuleManager.getModule(AimAssist.class);
            if (aimAssist == null || !aimAssist.isEnabled()) {
                return null;
            }
            return Entity.convert(aimAssist.getAimAssistTarget());
        }

        public Entity getLagRangeTarget() {
            LagRange lagRange = (LagRange) ModuleManager.getModule(LagRange.class);
            if (lagRange == null || !lagRange.isEnabled()) {
                return null;
            }
            return Entity.convert(lagRange.getLagRangeTarget());
        }

        public Entity getBacktrackTarget() {
            Backtrack backtrack = ModuleManager.backtrack;
            if (backtrack == null || !backtrack.isEnabled()) {
                return null;
            }
            return Entity.convert(backtrack.getBacktrackTarget());
        }

        public Vec3 getLagRangePosition() {
            LagRange lagRange = (LagRange) ModuleManager.getModule(LagRange.class);
            if (lagRange == null || !lagRange.isEnabled()) {
                return null;
            }
            net.minecraft.util.Vec3 position = lagRange.getLagRangePosition();
            return position == null ? null : new Vec3(position);
        }

        public Vec3 getBacktrackPosition() {
            Backtrack backtrack = ModuleManager.backtrack;
            if (backtrack == null || !backtrack.isEnabled()) {
                return null;
            }
            net.minecraft.util.Vec3 position = backtrack.getBacktrackPosition();
            return position == null ? null : new Vec3(position);
        }

        public Map<String, Object> getSettings(String name) {
            Map<String, Object> settings = new HashMap<>();
            Module module = getModule(name);
            if (module == null) {
                return settings;
            }
            for (Setting setting : module.getSettings()) {
                if (setting instanceof SliderSetting) {
                    settings.put(setting.getName(), ((SliderSetting) setting).getInput());
                }
                else if (setting instanceof ButtonSetting) {
                    settings.put(setting.getName(), ((ButtonSetting) setting).isToggled());
                }
                else if (setting instanceof ColorSetting) {
                    settings.put(setting.getName(), ((ColorSetting) setting).getColor());
                }
            }
            return settings;
        }

        public Map<String, List<String>> getCategories() {
            Map<String, List<String>> categories = new HashMap<>();
            for (CategoryComponent categoryComponent : ClickGui.categories) {
                List<String> modules = new ArrayList<>();
                for (ModuleComponent module : categoryComponent.modules) {
                    modules.add(module.mod.getName());
                }
                categories.put(categoryComponent.category.name(), modules);
            }
            return categories;
        }

        public Vec3 getBedAuraPosition() {
            if (ModuleManager.bedAura == null || !ModuleManager.bedAura.isEnabled()) {
                return null;
            }
            BlockPos p = ModuleManager.bedAura.getAuraTargetPos();
            if (p == null) {
                return null;
            }
            return new Vec3(p.getX(), p.getY(), p.getZ());
        }

        public float[] getBedAuraProgress() {
            if (ModuleManager.bedAura == null || !ModuleManager.bedAura.isEnabled()) {
                return new float[]{0, 0};
            }
            float d = ModuleManager.bedAura.getAuraBreakProgress();
            return new float[]{d, 0};
        }

        public boolean isScaffolding() {
            return false;
        }

        public boolean isTowering() {
            return false;
        }

        public boolean isHidden(String moduleName) {
            Module module = getModule(moduleName);
            if (module != null) {
                return module.isHidden();
            }
            return false;
        }

        public void registerGroup(String name) {
            getScript(this.superName).registerSetting(new GroupSetting(name));
        }

        public void registerButton(String name, boolean defaultValue) {
            getScript(this.superName).registerSetting(new ButtonSetting(name, defaultValue));
        }

        public void registerButton(String group, String name, boolean defaultValue) {
            getScript(this.superName).registerSetting(new ButtonSetting(getGroupForString(group), name, defaultValue));
        }

        public void registerKey(String group, String name, int defaultKey) {
            getScript(this.superName).registerSetting(new KeySetting(getGroupForString(group), name, defaultKey));
        }

        public void registerKey(String name, int defaultKey) {
            getScript(this.superName).registerSetting(new KeySetting(name, defaultKey));
        }

        // main slider constructors

        public void registerSlider(String group, String name, String suffix, double defaultValue, double minimum, double maximum, double interval) {
            getScript(this.superName).registerSetting(new SliderSetting(getGroupForString(group), name, suffix, defaultValue, minimum, maximum, interval));
        }

        public void registerSlider(String group, String name, String suffix, int defaultValue, String[] stringArray) {
            getScript(this.superName).registerSetting(new SliderSetting(getGroupForString(group), name, suffix, defaultValue, stringArray));
        }

        // rest

        public void registerSlider(String name, double defaultValue, double minimum, double maximum, double interval) {
            this.registerSlider("", name, "", defaultValue, minimum, maximum, interval);
        }

        public void registerSlider(String name,  int defaultValue, String[] stringArray) {
            this.registerSlider("", name, "", defaultValue, stringArray);
        }

        public void registerSlider(String name, String suffix, double defaultValue, double minimum, double maximum, double interval) {
            this.registerSlider("", name, suffix, defaultValue, minimum, maximum, interval);
        }

        public void registerSlider(String name, String suffix, int defaultValue, String[] stringArray) {
            this.registerSlider("", name, suffix, defaultValue, stringArray);
        }

        public void registerDescription(String description) {
            getScript(this.superName).registerSetting(new DescriptionSetting(description));
        }

        public void registerColor(String name, int red, int green, int blue) {
            getScript(this.superName).registerSetting(new ColorSetting(name, red, green, blue));
        }

        public void registerColor(String name, int red, int green, int blue, int alpha) {
            getScript(this.superName).registerSetting(new ColorSetting(name, red, green, blue, alpha));
        }

        public void registerColor(String group, String name, int red, int green, int blue) {
            getScript(this.superName).registerSetting(new ColorSetting(getGroupForString(group), name, red, green, blue));
        }

        public void registerColor(String group, String name, int red, int green, int blue, int alpha) {
            getScript(this.superName).registerSetting(new ColorSetting(getGroupForString(group), name, red, green, blue, alpha));
        }

        public int getColor(String moduleName, String name) {
            ColorSetting setting = (ColorSetting) getSetting(getModule(moduleName), name);
            if (setting == null) {
                return 0;
            }
            return setting.getColor();
        }

        public void setColor(String moduleName, String name, int red, int green, int blue) {
            ColorSetting setting = (ColorSetting) getSetting(getModule(moduleName), name);
            if (setting == null) {
                return;
            }
            setting.setColor(red, green, blue);
        }

        public void setColor(String moduleName, String name, int red, int green, int blue, int alpha) {
            ColorSetting setting = (ColorSetting) getSetting(getModule(moduleName), name);
            if (setting == null) {
                return;
            }
            setting.setColor(red, green, blue, alpha);
        }

        public boolean getButton(String moduleName, String name) {
            ButtonSetting setting = (ButtonSetting) getSetting(getModule(moduleName), name);
            if (setting == null) {
                return false;
            }
            boolean buttonState = setting.isToggled();
            return buttonState;
        }

        public double getSlider(String moduleName, String name) {
            SliderSetting setting = ((SliderSetting) getSetting(getModule(moduleName), name));
            if (setting == null) {
                return 0;
            }
            double sliderValue = setting.getInput();
            return sliderValue;
        }

        public double getSliderMin(String moduleName, String name) {
            SliderSetting setting = ((SliderSetting) getSetting(getModule(moduleName), name));
            if (setting == null) {
                return 0;
            }
            return setting.getMin();
        }

        public double getSliderMax(String moduleName, String name) {
            SliderSetting setting = ((SliderSetting) getSetting(getModule(moduleName), name));
            if (setting == null) {
                return 0;
            }
            return setting.getMax();
        }

        public String getSliderString(String moduleName, String name) {
            SliderSetting setting = ((SliderSetting) getSetting(getModule(moduleName), name));
            if (setting == null || !setting.isString) {
                return "";
            }
            int idx = (int) Math.round(setting.getInput());
            idx = Math.max(0, Math.min(idx, setting.getOptions().length - 1));
            return setting.getOptions()[idx];
        }

        public boolean getKeyPressed(String moduleName, String name) {
            KeySetting setting = ((KeySetting) getSetting(getModule(moduleName), name));
            if (setting == null) {
                return false;
            }
            return setting.isPressed();
        }

        public void setButton(String moduleName, String name, boolean value) {
            ButtonSetting setting = (ButtonSetting) getSetting(getModule(moduleName), name);
            if (setting == null) {
                return;
            }
            setting.setEnabled(value);
        }

        public void setSlider(String moduleName, String name, double value) {
            SliderSetting setting = ((SliderSetting) getSetting(getModule(moduleName), name));
            if (setting == null) {
                return;
            }
            setting.setValueRawWithEvent(value);
        }

        public void setKey(String moduleName, String name, int code) {
            KeySetting setting = ((KeySetting) getSetting(getModule(moduleName), name));
            if (setting == null) {
                return;
            }
            setting.setKey(code);
        }
    }

    public static class gl {
        public static void alpha(boolean alpha) {
            if (alpha) {
                GlStateManager.enableAlpha();
            }
            else {
                GlStateManager.disableAlpha();
            }
        }

        public static void begin(int mode) {
            GL11.glBegin(mode);
        }

        public static void blend(boolean blend) {
            if (blend) {
                GlStateManager.enableBlend();
            }
            else {
                GlStateManager.disableBlend();
            }
        }

        public static void color(float r, float g, float b, float a) {
            GlStateManager.color(r, g, b, a);
        }

        public static void color(double r, double g, double b, double a) {
            GlStateManager.color((float) r, (float) g, (float) b, (float) a);
        }

        public static void color(int r, int g, int b, int a) {
            if (r <= 1 && g <= 1 && b <= 1 && a <= 1) {
                GlStateManager.color(r, g, b, a);
                return;
            }
            GlStateManager.color(r / 255.0F, g / 255.0F, b / 255.0F, a / 255.0F);
        }

        public static void depthFunc(int func) {
            GL11.glDepthFunc(func);
        }

        public static void colorMask(boolean red, boolean green, boolean blue, boolean alpha) {
            GlStateManager.colorMask(red, green, blue, alpha);
        }

        public static void polygonOffset(float factor, float units) {
            GL11.glPolygonOffset(factor, units);
        }

        public static void texCoord2(double u, double v) {
            GL11.glTexCoord2d(u, v);
        }

        public static void texCoord2(float u, float v) {
            GL11.glTexCoord2f(u, v);
        }

        public static void bindTexture(String resource) {
            ResourceLocation resLoc = new ResourceLocation(resource);
            mc.getTextureManager().bindTexture(resLoc);
        }

        public static void bindTextureId(int textureId) {
            GlStateManager.bindTexture(textureId);
        }

        public static int getBoundTexture() {
            return GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);
        }

        public static void polygonOffset(boolean enabled) {
            if (enabled) {
                GlStateManager.enablePolygonOffset();
            }
            else {
                GlStateManager.disablePolygonOffset();
            }
        }

        public static void cull(boolean cull) {
            if (cull) {
                GlStateManager.enableCull();
            }
            else {
                GlStateManager.disableCull();
            }
        }

        public static void depth(boolean depth) {
            if (depth) {
                GlStateManager.enableDepth();
            }
            else {
                GlStateManager.disableDepth();
            }
        }

        public static void depthMask(boolean depthMask) {
            GlStateManager.depthMask(depthMask);
        }

        public static void disable(int cap) {
            setCapability(cap, false);
        }

        public static void disableItemLighting() {
            RenderHelper.disableStandardItemLighting();
        }

        public static void enable(int cap) {
            setCapability(cap, true);
        }

        public static void enableItemLighting(boolean gui) {
            if (gui) {
                RenderHelper.enableGUIStandardItemLighting();
            }
            else {
                RenderHelper.enableStandardItemLighting();
            }
        }

        public static void resetColor() {
            GlStateManager.resetColor();
            GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
        }

        public static void end() {
            GL11.glEnd();
        }

        public static void lighting(boolean lighting) {
            if (lighting) {
                GlStateManager.enableLighting();
            }
            else {
                GlStateManager.disableLighting();
            }
        }

        public static void lineSmooth(boolean lineSmooth) {
            setGLEnable(GL11.GL_LINE_SMOOTH, lineSmooth);
        }

        public static void lineWidth(float width) {
            GL11.glLineWidth(width);
        }

        public static void lineWidth(double width) {
            GL11.glLineWidth((float) width);
        }

        public static void normal(float x, float y, float z) {
            GL11.glNormal3f(x, y, z);
        }

        public static void normal(double x, double y, double z) {
            GL11.glNormal3d(x, y, z);
        }

        public static void pop() {
            GL11.glPopMatrix();
        }

        public static void push() {
            GL11.glPushMatrix();
        }

        public static void rotate(float angle, float x, float y, float z) {
            GL11.glRotatef(angle, x, y, z);
        }

        public static void rotate(double angle, double x, double y, double z) {
            GL11.glRotated(angle, x, y, z);
        }

        public static void scale(float x, float y, float z) {
            GL11.glScalef(x, y, z);
        }

        public static void scissor(int x, int y, int width, int height) {
            GL11.glScissor(x, y, width, height);
        }

        public static void scissor(boolean scissor) {
            setGLEnable(GL11.GL_SCISSOR_TEST, scissor);
        }

        public static void texture2d(boolean texture2d) {
            if (texture2d) {
                GlStateManager.enableTexture2D();
            }
            else {
                GlStateManager.disableTexture2D();
            }
        }

        public static void translate(float x, float y, float z) {
            GL11.glTranslatef(x, y, z);
        }

        public static void translate(double x, double y, double z) {
            GL11.glTranslated(x, y, z);
        }

        public static void vertex2(float x, float y) {
            GL11.glVertex2f(x, y);
        }

        public static void vertex3(float x, float y, float z) {
            GL11.glVertex3f(x, y, z);
        }

        public static void vertex3(double x, double y, double z) {
            GL11.glVertex3d(x, y, z);
        }

        private static void setGLEnable(int cap, boolean enable) {
            if (enable) {
                GL11.glEnable(cap);
            }
            else {
                GL11.glDisable(cap);
            }
        }

        private static void setCapability(int cap, boolean enable) {
            switch (cap) {
                case GL11.GL_ALPHA_TEST:
                    alpha(enable);
                    break;
                case GL11.GL_BLEND:
                    blend(enable);
                    break;
                case GL11.GL_CULL_FACE:
                    cull(enable);
                    break;
                case GL11.GL_DEPTH_TEST:
                    depth(enable);
                    break;
                case GL11.GL_FOG:
                    if (enable) {
                        GlStateManager.enableFog();
                    }
                    else {
                        GlStateManager.disableFog();
                    }
                    break;
                case GL11.GL_LIGHTING:
                    lighting(enable);
                    break;
                case GL11.GL_COLOR_LOGIC_OP:
                    if (enable) {
                        GlStateManager.enableColorLogic();
                    }
                    else {
                        GlStateManager.disableColorLogic();
                    }
                    break;
                case GL11.GL_NORMALIZE:
                    if (enable) {
                        GlStateManager.enableNormalize();
                    }
                    else {
                        GlStateManager.disableNormalize();
                    }
                    break;
                case GL11.GL_POLYGON_OFFSET_FILL:
                    if (enable) {
                        GlStateManager.enablePolygonOffset();
                    }
                    else {
                        GlStateManager.disablePolygonOffset();
                    }
                    break;
                case 32826:
                    if (enable) {
                        GlStateManager.enableRescaleNormal();
                    }
                    else {
                        GlStateManager.disableRescaleNormal();
                    }
                    break;
                case GL11.GL_TEXTURE_2D:
                    texture2d(enable);
                    break;
                default:
                    setGLEnable(cap, enable);
                    break;
            }
        }
    }

    public static class config {
        private static String CONFIG_DIR = mc.mcDataDir + File.separator + "keystrokes" + File.separator + "script_config.txt";
        private static String SEPARATOR = ":";
        private static String SEPARATOR_FULL = SEPARATOR + " ";

        private static void ensureConfigFileExists() throws IOException {
            final Path configPath = Paths.get(config.CONFIG_DIR);
            if (Files.notExists(configPath)) {
                Files.createDirectories(configPath.getParent());
                Files.createFile(configPath);
            }
        }

        public static boolean set(String key, final String value) {
            if (key == null || key.isEmpty()) {
                return false;
            }
            key = key.replace(SEPARATOR, "");
            final String entry = key + config.SEPARATOR_FULL + value;
            try {
                ensureConfigFileExists();
                final Path configPath = new File(config.CONFIG_DIR).toPath();
                final List<String> lines = new ArrayList<>(Files.readAllLines(configPath));
                boolean keyExists = false;
                for (int i = 0; i < lines.size(); ++i) {
                    final String line = lines.get(i);
                    if (line.startsWith(key + config.SEPARATOR_FULL)) {
                        lines.set(i, entry);
                        keyExists = true;
                        break;
                    }
                }
                if (!keyExists) {
                    lines.add(entry);
                }
                Files.write(configPath, lines);
                return true;
            }
            catch (IOException ex) {
                return false;
            }
        }

        public static String get(final String key) {
            if (key == null || key.isEmpty()) {
                return null;
            }
            try {
                ensureConfigFileExists();
                final Path configPath = new File(config.CONFIG_DIR).toPath();
                final List<String> lines = Files.readAllLines(configPath);
                for (final String line : lines) {
                    if (line.startsWith(key + config.SEPARATOR_FULL)) {
                        return line.substring((key + config.SEPARATOR_FULL).length());
                    }
                }
            }
            catch (IOException ex) {}
            return null;
        }
    }

    public static class render {
        private static final double[] WORLD_TO_SCREEN_COORDS = new double[3];
        private static RenderUtils.ProjectionContext worldToScreenContext;
        private static boolean worldToScreenContextActive;

        static void beginWorldToScreen(int scaleFactor) {
            worldToScreenContext = RenderUtils.captureProjectionContext(worldToScreenContext, scaleFactor);
            worldToScreenContextActive = true;
        }

        static void endWorldToScreen() {
            worldToScreenContextActive = false;
        }

        public static void block(Vec3 position, int color, boolean outline, boolean shade) {
            RenderUtils.renderBlock(new BlockPos(position.x, position.y, position.z), color, outline, shade);
        }

        public static void beam(Vec3 position, double height, double width, int color, float alpha) {
            beam(position.x, position.y, position.z, height, width, color, alpha);
        }

        public static void beam(double x, double y, double z, double height, double width, int color, float alpha) {
            RenderUtils.drawBeam(x, y, z, height, width, color, alpha);
        }

        public static int getThemeRGB(String theme) {
            return Theme.getGradient(Utils.getEnum(Theme.class, theme).ordinal(), 0);
        }

        public static void block(int x, int y, int z, int color, boolean outline, boolean shade) {
            RenderUtils.renderBlock(new BlockPos(x, y, z), color, outline, shade);
        }

        public static void entity(Entity en, int color, float partialTicks, boolean outline, boolean shade) {
            net.minecraft.entity.Entity e = en.entity;
            double x = e.lastTickPosX + (e.posX - e.lastTickPosX) * partialTicks - mc.getRenderManager().viewerPosX;
            double y = e.lastTickPosY + (e.posY - e.lastTickPosY) * partialTicks - mc.getRenderManager().viewerPosY;
            double z = e.lastTickPosZ + (e.posZ - e.lastTickPosZ) * partialTicks - mc.getRenderManager().viewerPosZ;
            AxisAlignedBB bbox = e.getEntityBoundingBox().expand(0.1, 0.1, 0.1);
            AxisAlignedBB axis = new AxisAlignedBB(bbox.minX - e.posX + x, bbox.minY - e.posY + y, bbox.minZ - e.posZ + z, bbox.maxX - e.posX + x, bbox.maxY - e.posY + y, bbox.maxZ - e.posZ + z);
            GL11.glPushMatrix();
            GL11.glBlendFunc(770, 771);
            GL11.glEnable(3042);
            GL11.glDisable(3553);
            GL11.glDisable(2929);
            GL11.glDepthMask(false);
            GL11.glLineWidth(2.0f);
            float a = (color >> 24 & 0xFF) / 255.0f;
            float r = (color >> 16 & 0xFF) / 255.0f;
            float g = (color >> 8 & 0xFF) / 255.0f;
            float b = (color & 0xFF) / 255.0f;
            GL11.glColor4f(r, g, b, a);
            if (outline) {
                RenderGlobal.drawSelectionBoundingBox(axis);
            }
            if (shade) {
                RenderUtils.drawBoundingBox(axis, r, g, b);
            }
            GL11.glEnable(3553);
            GL11.glEnable(2929);
            GL11.glDepthMask(true);
            GL11.glDisable(3042);
            GL11.glPopMatrix();
        }

        public static void entityGui(Entity en, int x, int y, float mouseX, float mouseY, int scale) {
            if (!en.isLiving) {
                return;
            }
            GL11.glPushMatrix();
            GuiInventory.drawEntityOnScreen(x, y, scale, mouseX, mouseY, (EntityLivingBase) en.entity);
            GL11.glPopMatrix();
        }

        public static void resetEquippedProgress() {
            mc.getItemRenderer().resetEquippedProgress();
        }

        public static void tracer(Entity entity, float lineWidth, int color, float partialTicks) {
            RenderUtils.drawTracerLine(entity.entity, color, lineWidth, partialTicks);
        }

        public static void showGui() {
            mc.displayGuiScreen(new EmptyGuiScreen());
        }

        private static class EmptyGuiScreen extends GuiScreen {
        }

        public static void item(ItemStack item, float x, float y, float scale) {
            GlStateManager.pushMatrix();
            mc.entityRenderer.setupOverlayRendering();
            if (scale != 1.0f) {
                GlStateManager.scale(scale, scale, scale);
            }
            RenderHelper.enableGUIStandardItemLighting();
            GlStateManager.disableBlend();
            GlStateManager.translate(x / scale, y / scale, 0);
            mc.getRenderItem().renderItemIntoGUI(item.itemStack, 0, 0);
            GlStateManager.enableBlend();
            RenderHelper.disableStandardItemLighting();
            if (scale != 1.0f) {
                GlStateManager.scale(scale, scale, scale);
            }
            GlStateManager.popMatrix();
        }

        public static void image(Image image, float x, float y, float width, float height) {
            if (image == null || !image.isLoaded()) {
                return;
            }
            if (image.textureId == -1) {
                final DynamicTexture dynamicTexture = new DynamicTexture(image.bufferedImage);
                GL11.glTexParameteri(3553, 10240, 9728);
                dynamicTexture.updateDynamicTexture();
                image.textureId = dynamicTexture.getGlTextureId();
            }
            GlStateManager.pushMatrix();
            GlStateManager.enableTexture2D();
            GlStateManager.bindTexture(image.textureId);
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            GL11.glTexParameteri(3553, 10240, 9728);
            Tessellator tessellator = Tessellator.getInstance();
            WorldRenderer worldrenderer = tessellator.getWorldRenderer();
            worldrenderer.begin(7, DefaultVertexFormats.POSITION_TEX_COLOR);
            worldrenderer.pos(x, (y + height), 0.0).tex(0.0, 1.0).color(255, 255, 255, 255).endVertex();
            worldrenderer.pos((x + width), (y + height), 0.0).tex(1.0, 1.0).color(255, 255, 255, 255).endVertex();
            worldrenderer.pos((x + width), y, 0.0).tex(1.0, 0.0).color(255, 255, 255, 255).endVertex();
            worldrenderer.pos(x, y, 0.0).tex(0.0, 0.0).color(255, 255, 255, 255).endVertex();
            tessellator.draw();
            GlStateManager.popMatrix();
        }

        public static Vec3 worldToScreen(double x, double y, double z, int scaleFactor, float partialTicks) {
            boolean temporaryContext = !worldToScreenContextActive;
            if (temporaryContext) {
                ((IAccessorEntityRenderer) mc.entityRenderer).callSetupCameraTransform(partialTicks, 0);
                beginWorldToScreen(scaleFactor);
            }

            x -= mc.getRenderManager().viewerPosX;
            y -= mc.getRenderManager().viewerPosY;
            z -= mc.getRenderManager().viewerPosZ;

            boolean projected = RenderUtils.projectTo2D(worldToScreenContext, x, y, z, scaleFactor, WORLD_TO_SCREEN_COORDS);
            mc.entityRenderer.setupOverlayRendering();
            if (temporaryContext) {
                endWorldToScreen();
            }
            if (!projected) {
                return null;
            }
            return new Vec3(WORLD_TO_SCREEN_COORDS[0], WORLD_TO_SCREEN_COORDS[1], WORLD_TO_SCREEN_COORDS[2]);
        }

        public static void roundedRect(float startX, float startY, float endX, float endY, float radius, int color) {
            RoundedUtils.drawRoundedRectRise(startX, startY, Math.abs(startX - endX), Math.abs(startY - endY), radius, color);
        }

        public static void gradientRect(float startX, float startY, float endX, float endY, int leftColor, int rightColor) {
            gradientRect(startX, startY, endX, endY, leftColor, leftColor, rightColor, rightColor);
        }

        public static void gradientRect(float startX, float startY, float endX, float endY, int topLeftColor, int bottomLeftColor, int topRightColor, int bottomRightColor) {
            RenderUtils.drawRoundedGradientRect(startX, startY, endX, endY, 0, topLeftColor, bottomLeftColor, topRightColor, bottomRightColor);
        }

        public static double[] getRotations() {
            return new double[] { mc.getRenderManager().playerViewY, mc.getRenderManager().playerViewX };
        }

        public static double[] getCameraRotations() {
            return new double[] { Utils.getCameraYaw(), Utils.getCameraPitch() };
        }

        public static int getFontWidth(String text) {
            return mc.fontRendererObj.getStringWidth(text) + Utils.getBoldWidth(text);
        }

        public static int getFontHeight() {
            return mc.fontRendererObj.FONT_HEIGHT;
        }

        public static Vec3 getPosition() {
            return new Vec3(mc.getRenderManager().viewerPosX,  mc.getRenderManager().viewerPosY, mc.getRenderManager().viewerPosZ);
        }

        public static void text(String text, float x, float y, float scale, int color, boolean shadow) {
            text2d(text, x, y, scale, color, shadow);
        }

        public static void text2d(String text, float x, float y, float scale, int color, boolean shadow) {
            GlStateManager.pushMatrix();
            if (scale != 1.0f) {
                GlStateManager.scale(scale, scale, scale);
            }
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            mc.fontRendererObj.drawString(text, x / scale, y / scale, color, shadow);
            GlStateManager.disableBlend();
            if (scale != 1.0f) {
                GlStateManager.scale(1.0f, 1.0f, 1.0f);
            }
            GlStateManager.popMatrix();
        }

        public static void text3d(String text, Vec3 position, float scale, boolean shadow, boolean depth, boolean background, int color) {
            ((IAccessorEntityRenderer) mc.entityRenderer).callSetupCameraTransform(((IAccessorMinecraft) mc).getTimer().renderPartialTicks, 0);
            GlStateManager.pushMatrix();
            float partialTicks = ((IAccessorMinecraft) mc).getTimer().renderPartialTicks;
            double px = mc.thePlayer.prevPosX + (mc.thePlayer.posX - mc.thePlayer.prevPosX) * partialTicks;
            double py = mc.thePlayer.prevPosY + (mc.thePlayer.posY - mc.thePlayer.prevPosY) * partialTicks;
            double pz = mc.thePlayer.prevPosZ + (mc.thePlayer.posZ - mc.thePlayer.prevPosZ) * partialTicks;
            GlStateManager.translate((float)position.x - px, (float)position.y - py, (float)position.z - pz);
            GL11.glNormal3f(0.0F, 1.0F, 0.0F);
            GlStateManager.rotate(-mc.getRenderManager().playerViewY, 0.0F, 1.0F, 0.0F);
            GlStateManager.rotate(mc.getRenderManager().playerViewX, 1.0f, 0.0f, 0.0f);
            float f1 = 0.02666667F;
            GlStateManager.scale(-f1, -f1, f1);
            if (depth) {
                GlStateManager.depthMask(false);
                GlStateManager.disableDepth();
            }
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            if (background) {
                GlStateManager.disableTexture2D();
                int width = mc.fontRendererObj.getStringWidth(text);
                Tessellator tessellator = Tessellator.getInstance();
                WorldRenderer worldrenderer = tessellator.getWorldRenderer();
                worldrenderer.begin(7, DefaultVertexFormats.POSITION_COLOR);
                worldrenderer.pos(-1, -1.0, 0.0).color(0.0f, 0.0f, 0.0f, 0.25f).endVertex();
                worldrenderer.pos(-1, 7.0, 0.0).color(0.0f, 0.0f, 0.0f, 0.25f).endVertex();
                worldrenderer.pos(width + 1, 7.0, 0.0).color(0.0f, 0.0f, 0.0f, 0.25f).endVertex();
                worldrenderer.pos(width + 1, -1.0, 0.0).color(0.0f, 0.0f, 0.0f, 0.25f).endVertex();
                tessellator.draw();
                GlStateManager.enableTexture2D();
            }
            if (scale != 1) {
                GlStateManager.scale(scale, scale, scale);
            }
            mc.fontRendererObj.drawString(text, 0, 0, color, shadow);
            if (scale != 1) {
                GlStateManager.scale(1, 1, 1);
            }
            if (depth) {
                GlStateManager.enableDepth();
                GlStateManager.depthMask(true);
            }
            GlStateManager.disableBlend();
            GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
            GlStateManager.popMatrix();
        }

        public static void rect(float startX, float startY, float endX, float endY, final int color) {
            if (startX < endX) {
                final float i = startX;
                startX = endX;
                endX = i;
            }
            if (startY < endY) {
                final float j = startY;
                startY = endY;
                endY = j;
            }
            final float f3 = (color >> 24 & 0xFF) / 255.0f;
            final float f4 = (color >> 16 & 0xFF) / 255.0f;
            final float f5 = (color >> 8 & 0xFF) / 255.0f;
            final float f6 = (color & 0xFF) / 255.0f;
            final Tessellator tessellator = Tessellator.getInstance();
            final WorldRenderer worldrenderer = tessellator.getWorldRenderer();
            GL11.glPushMatrix();
            GlStateManager.enableBlend();
            GlStateManager.disableTexture2D();
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            GlStateManager.color(f4, f5, f6, f3);
            worldrenderer.begin(7, DefaultVertexFormats.POSITION);
            worldrenderer.pos((double)startX, (double)endY, 0.0).endVertex();
            worldrenderer.pos((double)endX, (double)endY, 0.0).endVertex();
            worldrenderer.pos((double)endX, (double)startY, 0.0).endVertex();
            worldrenderer.pos((double)startX, (double)startY, 0.0).endVertex();
            tessellator.draw();
            GlStateManager.enableTexture2D();
            GlStateManager.disableBlend();
            GL11.glPopMatrix();
        }

        public static void line2D(double startX, double startY, double endX, double endY, float lineWidth, int color) {
            GL11.glPushMatrix();
            GL11.glEnable(GL11.GL_LINE_SMOOTH);
            GL11.glDisable(GL11.GL_TEXTURE_2D);
            GL11.glEnable(GL11.GL_BLEND);
            RenderUtils.glColor(color);
            GL11.glLineWidth(lineWidth);
            GL11.glBegin(GL11.GL_LINES);
            GL11.glVertex2d(startX, startY);
            GL11.glVertex2d(endX, endY);
            GL11.glEnd();
            GL11.glDisable(GL11.GL_BLEND);
            GL11.glEnable(GL11.GL_TEXTURE_2D);
            GL11.glDisable(GL11.GL_LINE_SMOOTH);
            GL11.glPopMatrix();
        }

        public static void line3D(Vec3 pos1, Vec3 pos2, float lineWidth, int color) {
            line3D(pos1.x, pos1.y, pos1.z, pos2.x, pos2.y, pos2.z, lineWidth, color);
        }

        public static void line3D(final double startX, final double startY, final double startZ, double endX, double endY, double endZ, final float lineWidth, final int color) {
            final double vx = mc.getRenderManager().viewerPosX;
            final double vy = mc.getRenderManager().viewerPosY;
            final double vz = mc.getRenderManager().viewerPosZ;
            final double sx = startX - vx;
            final double sy = startY - vy;
            final double sz = startZ - vz;
            endX -= vx;
            endY -= vy;
            endZ -= vz;
            final float a = (color >> 24 & 0xFF) / 255.0f;
            final float r = (color >> 16 & 0xFF) / 255.0f;
            final float g = (color >> 8 & 0xFF) / 255.0f;
            final float b = (color & 0xFF) / 255.0f;
            GL11.glPushMatrix();
            GL11.glEnable(3042);
            GL11.glEnable(2848);
            GL11.glDisable(2929);
            GL11.glDisable(3553);
            GL11.glBlendFunc(770, 771);
            GL11.glLineWidth(lineWidth);
            GlStateManager.color(r, g, b, a);
            GL11.glBegin(2);
            GL11.glVertex3d(sx, sy, sz);
            GL11.glVertex3d(endX, endY, endZ);
            GL11.glEnd();
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            GL11.glEnable(3553);
            GL11.glEnable(2929);
            GL11.glDisable(2848);
            GL11.glDisable(3042);
            GL11.glPopMatrix();
        }

        public static boolean isInView(Entity en) {
            return RenderUtils.isInViewFrustum(en.entity);
        }

        public static class blur {
            public static void prepare() {
                BlurUtils.prepareBlur();
            }

            public static void apply(final int passes, final float radius) {
                BlurUtils.blurEnd(passes, radius);
            }
        }

        public static class bloom {
            public static void prepare() {
                BlurUtils.prepareBloom();
            }

            public static void apply(final int passes, final float radius) {
                BlurUtils.bloomEnd(passes, radius);
            }
        }
    }

    public static class inventory {
        public static int getSlot() {
            return mc.thePlayer.inventory.currentItem;
        }

        public static int getHoveringSlot() {
            if (!(mc.currentScreen instanceof GuiContainer)) {
                return -1;
            }
            Slot slot = ((GuiContainer) mc.currentScreen).getSlotUnderMouse();
            return slot == null ? -1 : slot.slotNumber;
        }

        public static void setSlot(int slot) {
            mc.thePlayer.inventory.currentItem = slot;
        }

        public static void click(int slot, int button, int mode) {
            mc.playerController.windowClick(mc.thePlayer.openContainer.windowId, slot, button, mode, mc.thePlayer);
        }

        public static List<String> getBookContents() {
            if (mc.currentScreen instanceof GuiScreenBook) {
                List<String> contents = new ArrayList<>();
                List<IChatComponent> bookContents = ((IAccessorGuiScreenBook) mc.currentScreen).getBookContents();
                if (bookContents == null) {
                    return contents;
                }
                int max = Math.min(128 / mc.fontRendererObj.FONT_HEIGHT, bookContents.size());
                for (int line = 0; line < max; ++line) {
                    IChatComponent lineStr = bookContents.get(line);
                    contents.add(lineStr.getUnformattedText());
                }
                if (!contents.isEmpty()) {
                    return contents;
                }
            }
            return null;
        }

        public static String getChest() {
            if (mc.thePlayer.openContainer instanceof ContainerChest) {
                ContainerChest chest = (ContainerChest) mc.thePlayer.openContainer;
                if (chest == null) {
                    return "";
                }
                return chest.getLowerChestInventory().getDisplayName().getUnformattedText();
            }
            return "";
        }

        public static String getContainer() {
            if (mc.currentScreen instanceof GuiContainerCreative) {
                CreativeTabs creativetabs = CreativeTabs.creativeTabArray[((GuiContainerCreative) mc.currentScreen).getSelectedTabIndex()];
                if (creativetabs != null) {
                    return I18n.format(creativetabs.getTranslatedTabLabel());
                }
            }
            else if (mc.currentScreen != null) {
                try {
                    return ((IInventory) ReflectionUtils.containerInventoryPlayer.get(mc.currentScreen.getClass()).get(mc.currentScreen)).getDisplayName().getUnformattedText();
                } catch (Exception e) {
                }
            }
            return "";
        }

        public static int getSize() {
            return mc.thePlayer.inventory.getSizeInventory();
        }

        public static int getChestSize() {
            if (mc.thePlayer.openContainer instanceof ContainerChest) {
                ContainerChest chest = (ContainerChest) mc.thePlayer.openContainer;
                if (chest == null) {
                    return -1;
                }
                return chest.getLowerChestInventory().getSizeInventory();
            }
            return -1;
        }

        public static ItemStack getStackInSlot(int slot) {
            if (mc.thePlayer.inventory.getStackInSlot(slot) == null) {
                return null;
            }
            return new ItemStack(mc.thePlayer.inventory.getStackInSlot(slot), (byte) 0);
        }

        public static ItemStack getStackInChestSlot(int slot) {
            if (mc.thePlayer.openContainer instanceof ContainerChest) {
                ContainerChest chest = (ContainerChest) mc.thePlayer.openContainer;
                if (chest.getLowerChestInventory().getStackInSlot(slot) == null) {
                    return null;
                }
                return new ItemStack(chest.getLowerChestInventory().getStackInSlot(slot), (byte) 0);
            }
            return null;
        }

        public static ItemStack getStackInCraftingSlot(int slot) {
            if (mc.thePlayer.openContainer instanceof ContainerWorkbench) {
                InventoryCrafting craftMatrix = ((ContainerWorkbench) mc.thePlayer.openContainer).craftMatrix;
                if (craftMatrix.getStackInSlot(slot) == null) {
                    return null;
                }
                return new ItemStack(craftMatrix.getStackInSlot(slot), (byte) 0);
            }
            return null;
        }

        public static ItemStack getCraftResult() {
            if (mc.thePlayer.openContainer instanceof ContainerWorkbench) {
                IInventory craftResult = ((ContainerWorkbench) mc.thePlayer.openContainer).craftResult;
                if (craftResult.getStackInSlot(0) == null) {
                    return null;
                }
                return new ItemStack(craftResult.getStackInSlot(0), (byte) 0);
            }
            return null;
        }

        public static void open() {
            KeyBinding inventoryKey = mc.gameSettings.keyBindInventory;
            int originalKeyCode = inventoryKey.getKeyCode();

            if (originalKeyCode == 0) {
                inventoryKey.setKeyCode(13);
                KeyBinding.resetKeyBindingArrayAndHash();
            }

            KeyBinding.setKeyBindState(inventoryKey.getKeyCode(), true);
            KeyBinding.onTick(inventoryKey.getKeyCode());
            KeyBinding.setKeyBindState(inventoryKey.getKeyCode(), false);

            if (originalKeyCode == 0) {
                inventoryKey.setKeyCode(0);
                KeyBinding.resetKeyBindingArrayAndHash();
            }
        }
    }

    public static class keybinds {
        public static int[] getMousePosition() {
            return new int[] { Mouse.getX(), Mouse.getY() };
        }

        public static boolean isPressed(final String key) {
            KeyBinding keyBind = ReflectionUtils.keybinds.get(key);
            return keyBind != null && keyBind.isKeyDown();
        }

        public static void setPressed(final String key, final boolean pressed) {
            KeyBinding keyBind = ReflectionUtils.keybinds.get(key);
            if (keyBind != null) {
                KeyBinding.setKeyBindState(keyBind.getKeyCode(), pressed);
            }
        }

        public static void onTick(final String key) {
            KeyBinding keyBind = ReflectionUtils.keybinds.get(key);
            if (keyBind != null) {
                KeyBinding.onTick(keyBind.getKeyCode());
            }
        }

        public static int getKeyCode(final String key) {
            final KeyBinding keyBind = ReflectionUtils.keybinds.get(key);
            if (keyBind != null) {
                return keyBind.getKeyCode();
            }
            return -1;
        }

        public static int getKeycode(final String key) {
            return getKeyCode(key);
        }

        public static int getKeyIndex(String key) {
            return Keyboard.getKeyIndex(key);
        }

        public static boolean isMouseDown(int mouseButton) {
            return Mouse.isButtonDown(mouseButton);
        }

        public static boolean isKeyDown(int key) {
            return Keyboard.isKeyDown(key);
        }

        public static void rightClick() {
            ((IAccessorMinecraft) mc).callRightClickMouse();
        }

        public static void leftClick() {
            ((IAccessorMinecraft) mc).callClickMouse();
        }

        public static int getScroll() {
            return Mouse.getDWheel();
        }
    }

    public static class util {
        public static final String colorSymbol = "§";

        public static String color(String message) {
            return Utils.formatColor(message);
        }

        public static String strip(String string) {
            return Utils.stripColor(string);
        }

        public static double round(double value, int decimals) {
            return Utils.round(value, decimals);
        }

        public static int randomInt(int min, int max) {
            return Utils.randomizeInt(min, max);
        }

        public static double randomDouble(double min, double max) {
            return Utils.randomizeDouble(min, max);
        }
    }
}
