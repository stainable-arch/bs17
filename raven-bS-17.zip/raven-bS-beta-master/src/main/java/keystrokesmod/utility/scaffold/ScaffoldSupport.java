package keystrokesmod.utility.scaffold;

import keystrokesmod.helper.RotationHelper;
import keystrokesmod.mixin.impl.accessor.IAccessorPlayerControllerMP;
import keystrokesmod.utility.IMinecraftInstance;
import net.minecraft.block.*;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.*;
import net.minecraftforge.event.ForgeEventFactory;

public final class ScaffoldSupport implements IMinecraftInstance {
    private static volatile long lastSetback;
    private static EntityPlayerSP tickPlayer;

    private ScaffoldSupport() {
    }

    public static void recordSetback() {
        lastSetback = System.currentTimeMillis();
    }

    public static boolean sinceSetback(long duration) {
        return lastSetback != 0L && System.currentTimeMillis() - lastSetback < duration;
    }

    public static void resetTicks() {
        tickPlayer = null;
        PlayerUtils.groundTicks = 0;
        PlayerUtils.airTicks = 0;
    }

    public static void updateTicks() {
        if (mc.thePlayer == null) {
            resetTicks();
            return;
        }
        if (tickPlayer != mc.thePlayer) {
            resetTicks();
            tickPlayer = mc.thePlayer;
        }
        if (mc.thePlayer.onGround) {
            ++PlayerUtils.groundTicks;
            PlayerUtils.airTicks = 0;
        } else {
            PlayerUtils.groundTicks = 0;
            ++PlayerUtils.airTicks;
        }
    }

    public enum MoveDirection {
        NONE(false, false, false),
        FORWARD(true, false, false),
        FORWARD_LEFT(true, true, false),
        FORWARD_RIGHT(true, true, false),
        BACK(false, false, true),
        BACK_LEFT(false, true, true),
        BACK_RIGHT(false, true, true),
        LEFT(false, false, false),
        RIGHT(false, false, false);
    
        public final boolean forward;
        public final boolean diagonal;
        public final boolean backward;
    
        MoveDirection(boolean forward, boolean diagonal, boolean backward) {
            this.forward = forward;
            this.diagonal = diagonal;
            this.backward = backward;
        }
    }

    public enum FakeRotation {
        None,
        Smooth,
        Forward,
        Spin
    }

    public static final class PlayerUtils {
        public static long groundTicks;
        public static long airTicks;

        public static boolean isAirBelow(double x, double y, double z) {
            BlockPos pos = new BlockPos(x, y - (double) (y % 1.0 == 0.0 ? 1 : 0), z);
            return mc.theWorld.isAirBlock(pos);
        }

        public static boolean isAirBelow() {
            return isAirBelow(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ);
        }

        public static boolean nearEdge(double margin) {
            int x = MathHelper.floor_double(mc.thePlayer.posX);
            int y = MathHelper.floor_double(mc.thePlayer.posY - 0.01);
            int z = MathHelper.floor_double(mc.thePlayer.posZ);
            BlockPos pos = new BlockPos(x, y, z);
            if (mc.theWorld.isAirBlock(pos)) {
                return true;
            }
            double fx = mc.thePlayer.posX - (double) x;
            double fz = mc.thePlayer.posZ - (double) z;
            return fx < margin && mc.theWorld.isAirBlock(new BlockPos(x - 1, y, z)) || fx > 1.0 - margin && mc.theWorld.isAirBlock(new BlockPos(x + 1, y, z)) || fz < margin && mc.theWorld.isAirBlock(new BlockPos(x, y, z - 1)) || fz > 1.0 - margin && mc.theWorld.isAirBlock(new BlockPos(x, y, z + 1));
        }

        public static boolean inLiquid() {
            return mc.thePlayer.isInWater() || mc.thePlayer.isInLava();
        }

        public static Vec3 eyes(double x, double y, double z) {
            return new Vec3(x, y + (double) mc.thePlayer.getEyeHeight(), z);
        }

        public static int idOffset() {
            int id = Math.abs(mc.thePlayer.getEntityId());
            return id > 999 ? id + 213 : id * 99;
        }

        public static int decimals(double d) {
            return (int) Math.round(d % 1.0 * 10000.0);
        }

        public static int posYDecimals() {
            return decimals(mc.thePlayer.posY);
        }

        public static int motionYDecimals() {
            return (int) Math.round(mc.thePlayer.motionY % 10.0 * 10000.0);
        }

        public static float forwardInput() {
            float f = 0.0f;
            if (mc.gameSettings.keyBindForward.isKeyDown()) {
                f += 1.0f;
            }
            if (mc.gameSettings.keyBindBack.isKeyDown()) {
                f -= 1.0f;
            }
            return f;
        }

        public static float strafeInput() {
            float f = 0.0f;
            if (mc.gameSettings.keyBindLeft.isKeyDown()) {
                f += 1.0f;
            }
            if (mc.gameSettings.keyBindRight.isKeyDown()) {
                f -= 1.0f;
            }
            return f;
        }

        public static boolean isMoving() {
            return mc.thePlayer.movementInput.moveForward != 0.0f || mc.thePlayer.movementInput.moveStrafe != 0.0f;
        }

        public static boolean jumpKeyDown() {
            return GameSettings.isKeyDown(mc.gameSettings.keyBindJump);
        }

        public static void setJump(boolean jump) {
            mc.thePlayer.movementInput.jump = jump;
        }

        public static void setSneak(boolean sneak) {
            boolean was = mc.thePlayer.movementInput.sneak;
            mc.thePlayer.movementInput.sneak = sneak;
            if (!was && sneak) {
                setForward((float) ((double) getForward() * 0.3));
                setStrafe((float) ((double) getStrafe() * 0.3));
            }
        }

        public static float getForward() {
            return mc.thePlayer.movementInput.moveForward;
        }

        public static float getStrafe() {
            return mc.thePlayer.movementInput.moveStrafe;
        }

        public static void setForward(float f) {
            mc.thePlayer.movementInput.moveForward = f;
        }

        public static void setStrafe(float f) {
            mc.thePlayer.movementInput.moveStrafe = f;
        }

        public static MoveDirection direction(double forward, double strafe) {
            MoveDirection d = null;
            if (forward == 0.0) {
                if (strafe == 0.0) {
                    d = MoveDirection.NONE;
                } else if (strafe > 0.0) {
                    d = MoveDirection.LEFT;
                } else if (strafe < 0.0) {
                    d = MoveDirection.RIGHT;
                }
            } else if (forward > 0.0) {
                if (strafe == 0.0) {
                    d = MoveDirection.FORWARD;
                } else if (strafe > 0.0) {
                    d = MoveDirection.FORWARD_LEFT;
                } else if (strafe < 0.0) {
                    d = MoveDirection.FORWARD_RIGHT;
                }
            } else if (forward < 0.0) {
                if (strafe == 0.0) {
                    d = MoveDirection.BACK;
                } else if (strafe > 0.0) {
                    d = MoveDirection.BACK_LEFT;
                } else if (strafe < 0.0) {
                    d = MoveDirection.BACK_RIGHT;
                }
            }
            return d;
        }

        public static MoveDirection direction() {
            return direction(forwardInput(), strafeInput());
        }

        public static boolean diagonalYaw() {
            float f = Math.abs(mc.thePlayer.rotationYaw % 90.0f);
            return f > 10.0f && f < 80.0f;
        }

        public static boolean isDiagonal() {
            return diagonalYaw() || direction().diagonal;
        }

        public static float movementAngle() {
            return mc.thePlayer.rotationYaw + (float) RotationUtils.inputAngle();
        }

        public static void jump() {
            mc.thePlayer.jump();
        }

        public static void jump(double speed) {
            MoveUtils.strafe(speed);
            jump();
        }

        public static void multiplyMotion(double d) {
            mc.thePlayer.motionX *= d;
            mc.thePlayer.motionZ *= d;
        }

        public static int potionLevel(Potion potion) {
            PotionEffect effect = mc.thePlayer.getActivePotionEffect(potion);
            return effect == null ? 0 : effect.getAmplifier() + 1;
        }

        public static int speedLevel() {
            return potionLevel(Potion.moveSpeed);
        }

        public static double perSpeedLevel(double d) {
            return (double) speedLevel() * d;
        }

        public static void syncCurrentPlayItem() {
            ((IAccessorPlayerControllerMP) mc.playerController).callSyncCurrentPlayItem();
        }

        public static void swing(boolean packetOnly, boolean resetEquip) {
            if (packetOnly) {
                mc.thePlayer.sendQueue.addToSendQueue(new C0APacketAnimation());
            } else {
                mc.thePlayer.swingItem();
                if (resetEquip) {
                    mc.getItemRenderer().resetEquippedProgress();
                }
            }
        }

        public static void place(MovingObjectPosition hit, ItemStack itemStack) {
            float fx = (float) (hit.hitVec.xCoord - (double) hit.getBlockPos().getX());
            float fy = (float) (hit.hitVec.yCoord - (double) hit.getBlockPos().getY());
            float fz = (float) (hit.hitVec.zCoord - (double) hit.getBlockPos().getZ());
            mc.thePlayer.sendQueue.addToSendQueue(new C08PacketPlayerBlockPlacement(hit.getBlockPos(), hit.sideHit.getIndex(), itemStack, fx, fy, fz));
            if (!isCreative()) {
                itemStack.onItemUse(mc.thePlayer, mc.theWorld, hit.getBlockPos(), hit.sideHit, fx, fy, fz);
                if (itemStack.stackSize <= 0) {
                    ForgeEventFactory.onPlayerDestroyItem(mc.thePlayer, itemStack);
                }
            }
        }

        public static boolean isCreative() {
            return mc.thePlayer.capabilities.isCreativeMode;
        }

        public static boolean isAdventure() {
            return !mc.thePlayer.capabilities.allowEdit;
        }

        public static EnumFacing facing() {
            return mc.thePlayer.getHorizontalFacing();
        }

        public static MovingObjectPosition rayTraceFrom(double range, double x, double y, double z, float yaw, float pitch) {
            Vec3 from = eyes(x, y, z);
            Vec3 dir = RotationUtils.getVectorForRotation(yaw, pitch);
            Vec3 to = from.addVector(dir.xCoord * range, dir.yCoord * range, dir.zCoord * range);
            return mc.theWorld.rayTraceBlocks(from, to, false, false, false);
        }

        public static MovingObjectPosition rayTraceBlocks(double range, float yaw, float pitch) {
            return rayTraceFrom(range, mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, yaw, pitch);
        }

        public static MovingObjectPosition rayTraceBlock(BlockPos pos, EnumFacing facing, double range, float yaw, float pitch) {
            MovingObjectPosition hit = rayTraceBlocks(range, yaw, pitch);
            if (hit == null || hit.typeOfHit != MovingObjectPosition.MovingObjectType.BLOCK) {
                return null;
            }
            if (!BlockUtils.samePos(hit.getBlockPos(), pos) || facing != null && hit.sideHit != facing) {
                return null;
            }
            return hit;
        }
    }

    public static final class MoveUtils {
        public static float moveYaw(float yaw, float forward, float strafe) {
            float f4 = 1.0f;
            if (forward < 0.0f) {
                yaw += 180.0f;
                f4 = -0.5f;
            } else if (forward > 0.0f) {
                f4 = 0.5f;
            }
            if (strafe > 0.0f) {
                yaw -= 90.0f * f4;
            } else if (strafe < 0.0f) {
                yaw += 90.0f * f4;
            }
            return yaw;
        }

        public static float moveYaw(float yaw) {
            return moveYaw(yaw, mc.thePlayer.movementInput.moveForward, mc.thePlayer.movementInput.moveStrafe);
        }

        public static void setSpeed(double speed, float yaw) {
            if (speed == 0.0) {
                mc.thePlayer.motionZ = 0.0;
                mc.thePlayer.motionX = 0.0;
                return;
            }
            mc.thePlayer.motionX = -Math.sin(yaw *= (float) Math.PI / 180) * speed;
            mc.thePlayer.motionZ = Math.cos(yaw) * speed;
        }

        public static void setSpeed(double speed) {
            float yaw = mc.thePlayer.rotationYaw;
            if (mc.thePlayer.movementInput.moveForward < 0.0f) {
                yaw += 180.0f;
            }
            setSpeed(speed, yaw);
        }

        public static void strafe(double speed) {
            setSpeed(speed, moveYaw((RotationHelper.get().fixMovement() && RotationHelper.get().getServerYaw() != null ? RotationHelper.get().getServerYaw() : mc.thePlayer.rotationYaw)));
        }

        public static double speed() {
            return Math.sqrt(mc.thePlayer.motionX * mc.thePlayer.motionX + mc.thePlayer.motionZ * mc.thePlayer.motionZ);
        }
    }

    public static final class RotationUtils {
        public enum Precision {
            Low(40.0f),
            Medium(20.0f),
            High(5.0f),
            Very_high(1.5f);

            public final float offsetYaw;

            Precision(float offsetYaw) {
                this.offsetYaw = offsetYaw;
            }

            public float getOffsetYaw() {
                return this.offsetYaw;
            }

            public float getOffsetPitch(float pitch) {
                if (pitch > 75.0f) {
                    return 1.0f;
                }
                if (pitch > 60.0f) {
                    return 2.0f;
                }
                return 5.0f;
            }
        }

        public static float clampPitch(float pitch) {
            return MathHelper.clamp_float(pitch, -90.0f, 90.0f);
        }

        public static float[] fixSensitivity(float yaw, float pitch, float lastYaw, float lastPitch, boolean jitter) {
            float f5 = yaw - lastYaw;
            float f7 = pitch - lastPitch;
            float f8 = mc.gameSettings.mouseSensitivity * 0.6f + 0.2f;
            double d = (double) (f8 * f8 * f8) * 1.2;
            float f9 = (float) ((double) Math.round((double) f5 / d) * d);
            float f10 = (float) ((double) Math.round((double) f7 / d) * d);
            yaw = lastYaw + f9;
            pitch = lastPitch + f10;
            return new float[]{yaw, clampPitch(pitch)};
        }

        public static float randomOffset() {
            return (float) (Math.random() - 0.5);
        }

        public static double inputAngle() {
            double d = Math.toDegrees(Math.atan2(PlayerUtils.strafeInput(), -PlayerUtils.forwardInput()));
            d = (d + 360.0) % 360.0;
            return d;
        }

        public static double inputAngleSigned() {
            double d = Math.toDegrees(Math.atan2(-PlayerUtils.strafeInput(), PlayerUtils.forwardInput()));
            return d == 0.0 ? 0.0 : d;
        }

        public static Vec3 getVectorForRotation(float yaw, float pitch) {
            float f3 = MathHelper.cos((yaw *= -((float) Math.PI / 180)) - (float) Math.PI);
            float f4 = MathHelper.sin(yaw - (float) Math.PI);
            float f5 = -MathHelper.cos(pitch *= -((float) Math.PI / 180));
            float f6 = MathHelper.sin(pitch);
            return new Vec3(f4 * f5, f6, f3 * f5);
        }

        public static float[] searchBlockRotation(BlockPos pos, EnumFacing facing, float offset, Precision precision, float airYaw, boolean playerYaw) {
            float bestYaw = 0.0f;
            float bestPitch = 0.0f;
            float base = playerYaw ? mc.thePlayer.rotationYaw : (mc.thePlayer.onGround ? PlayerUtils.movementAngle() : airYaw);
            float from = base + offset;
            float to = base + 170.0f;
            float reach = mc.playerController.getBlockReachDistance();
            float best = 360.0f;
            for (float yaw = from; yaw <= to; yaw += precision.getOffsetYaw()) {
                float y = (float) ((double) yaw + (Math.random() - 0.5));
                for (float pitch = 90.0f; pitch > 30.0f; pitch -= precision.getOffsetPitch(pitch)) {
                    float diff;
                    BlockPos hitPos;
                    float p = MathHelper.clamp_float((float) ((double) pitch + (Math.random() - 0.5)), -90.0f, 90.0f);
                    MovingObjectPosition hit = WorldUtils.rayTraceBlocks(reach, y, p);
                    if (hit == null || hit.typeOfHit != MovingObjectPosition.MovingObjectType.BLOCK || facing != null && hit.sideHit != facing || !BlockUtils.samePos(hitPos = hit.getBlockPos(), pos) || !awayFromEdge((float) (hit.hitVec.yCoord - (double) hitPos.getY())) || !awayFromEdge((float) (hit.hitVec.xCoord - (double) hitPos.getX())) || !awayFromEdge((float) (hit.hitVec.zCoord - (double) hitPos.getZ())) || !((diff = Math.abs(base - y)) < best)) continue;
                    best = diff;
                    bestYaw = y;
                    bestPitch = p;
                }
            }
            if (best == 360.0f) {
                return null;
            }
            if (playerYaw && best > (float) 70) {
                return null;
            }
            return new float[]{bestYaw, bestPitch};
        }

        public static boolean awayFromEdge(float f) {
            return f == 0.0f || f == 1.0f || (double) f > 0.06 && (double) f < 0.94;
        }
    }

    public static final class BlockUtils {
        public static BlockPos below(double d) {
            return new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY - d, mc.thePlayer.posZ);
        }

        public static boolean isReplaceable(BlockPos pos) {
            Block block = getBlock(pos);
            return block == Blocks.air || block == Blocks.fire || block instanceof BlockLiquid || block.getMaterial().isReplaceable();
        }

        public static boolean isPlaceable(Block block) {
            return block == Blocks.glass || block.isFullBlock() && block != Blocks.gravel && block != Blocks.sand && block != Blocks.soul_sand && block != Blocks.tnt && block != Blocks.crafting_table && block != Blocks.furnace && block != Blocks.dispenser && block != Blocks.dropper && block != Blocks.noteblock && block != Blocks.command_block;
        }

        public static boolean isBlockItem(ItemStack itemStack) {
            return itemStack != null && itemStack.getItem() instanceof ItemBlock;
        }

        public static boolean isContainer(Block block) {
            return block instanceof BlockContainer || block == Blocks.crafting_table || block == Blocks.anvil;
        }

        public static boolean isInteractable(Block block) {
            if (isContainer(block) || block == Blocks.bed || block == Blocks.lever) {
                return true;
            }
            if (block instanceof BlockTrapDoor || block instanceof BlockFence || block instanceof BlockFenceGate) {
                return true;
            }
            if (!(block instanceof BlockDoor)) {
                return false;
            }
            return block != Blocks.iron_door;
        }

        public static BlockPos placedPos(MovingObjectPosition hit) {
            return hit.getBlockPos().offset(hit.sideHit);
        }

        public static Vec3 hitVec(BlockPos pos, net.minecraft.util.EnumFacing facing) {
            double lo = 0.1, hi = 0.9, ylo = 0.05, yhi = 0.95, top = 1.0;
            double x = (double) pos.getX() + randomBetween(lo, hi);
            double y = (double) pos.getY() + randomBetween(ylo, yhi);
            double z = (double) pos.getZ() + randomBetween(lo, hi);
            IBlockState state = getState(pos);
            Block block = state.getBlock();
            if (!block.isFullBlock() && block instanceof net.minecraft.block.BlockSlab) {
                if (state.getValue(net.minecraft.block.BlockSlab.HALF) == net.minecraft.block.BlockSlab.EnumBlockHalf.TOP) {
                    ylo = 0.505;
                } else if (facing == net.minecraft.util.EnumFacing.UP) {
                    top = 0.5;
                } else {
                    yhi = 0.495;
                }
                y = (double) pos.getY() + randomBetween(ylo, yhi);
            }
            switch (facing) {
                case EAST: x = pos.getX() + 1; break;
                case WEST: x = pos.getX(); break;
                case NORTH: z = pos.getZ(); break;
                case SOUTH: z = pos.getZ() + 1; break;
                case UP: y = (double) pos.getY() + top; break;
                case DOWN: y = pos.getY(); break;
            }
            return new Vec3(x, y, z);
        }

        public static Block getBlock(BlockPos pos) {
            return mc.theWorld.getBlockState(pos).getBlock();
        }

        public static IBlockState getState(BlockPos pos) {
            return mc.theWorld.getBlockState(pos);
        }

        public static boolean samePos(BlockPos a, BlockPos b) {
            return a.equals(b);
        }
    }

    public static final class ItemUtils {
        public static boolean isScaffoldBlock(ItemStack itemStack) {
            if (BlockUtils.isBlockItem(itemStack) && itemStack.stackSize > 0) {
                Block block = ((ItemBlock) itemStack.getItem()).getBlock();
                return BlockUtils.isPlaceable(block) && block != Blocks.pumpkin;
            }
            return false;
        }
    }

    public static final class WorldUtils {
        public static MovingObjectPosition rayTraceBlocks(double range, float yaw, float pitch) {
            Vec3 eyes = new Vec3(mc.thePlayer.posX, mc.thePlayer.posY + (double) mc.thePlayer.getEyeHeight(), mc.thePlayer.posZ);
            float f3 = MathHelper.cos((yaw *= -((float) Math.PI / 180)) - (float) Math.PI);
            float f4 = MathHelper.sin(yaw - (float) Math.PI);
            float f5 = -MathHelper.cos(pitch *= -((float) Math.PI / 180));
            float f6 = MathHelper.sin(pitch);
            Vec3 dir = new Vec3(f4 * f5, f6, f3 * f5);
            Vec3 end = eyes.addVector(dir.xCoord * range, dir.yCoord * range, dir.zCoord * range);
            return mc.theWorld.rayTraceBlocks(eyes, end, false, false, false);
        }

        public static double distanceSq(double x, double y, double z, Vec3 p) {
            double d4 = x - p.xCoord;
            double d5 = y - p.yCoord;
            double d6 = z - p.zCoord;
            return d4 * d4 + d5 * d5 + d6 * d6;
        }

        public static double behind(double x, double z, double dirX, double dirZ, Vec3 p) {
            double d5 = p.xCoord - x;
            double d6 = p.zCoord - z;
            return -(d5 * dirX + d6 * dirZ);
        }
    }

    public static double randomBetween(double min, double max) {
        return min + Math.random() * (max - min);
    }
}
