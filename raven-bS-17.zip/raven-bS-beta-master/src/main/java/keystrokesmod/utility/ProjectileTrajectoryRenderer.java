package keystrokesmod.utility;

import keystrokesmod.mixin.impl.accessor.IAccessorEntityArrow;
import keystrokesmod.module.impl.world.AntiBot;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.item.EntityEnderPearl;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityLargeFireball;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import org.lwjgl.opengl.GL11;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class ProjectileTrajectoryRenderer {
    private static final Minecraft mc = Minecraft.getMinecraft();
    private static final Color FIREBALL_COLOR = new Color(255, 150, 0);
    private static final Color PEARL_COLOR = new Color(210, 0, 255);

    private static final class ProjectileTrajectoryProps {
        final double gravity;
        final double drag;
        final double dragInWater;
        final double hitboxRadius;
        final double width;
        final double height;
        final boolean ignoreBlockWithoutBoundingBox;
        final int ignoreOwnerTicks;

        private ProjectileTrajectoryProps(double gravity, double drag, double dragInWater, double hitboxRadius,
                                         double width, double height, boolean ignoreBlockWithoutBoundingBox,
                                         int ignoreOwnerTicks) {
            this.gravity = gravity;
            this.drag = drag;
            this.dragInWater = dragInWater;
            this.hitboxRadius = hitboxRadius;
            this.width = width;
            this.height = height;
            this.ignoreBlockWithoutBoundingBox = ignoreBlockWithoutBoundingBox;
            this.ignoreOwnerTicks = ignoreOwnerTicks;
        }
    }

    private static final class FluidState {
        final boolean inWater;
        final Vec3 flowDirection;

        private FluidState(boolean inWater, Vec3 flowDirection) {
            this.inWater = inWater;
            this.flowDirection = flowDirection;
        }
    }

    private static final class BlockCollisionResult {
        final MovingObjectPosition hit;
        final double distanceSq;

        private BlockCollisionResult(MovingObjectPosition hit, double distanceSq) {
            this.hit = hit;
            this.distanceSq = distanceSq;
        }
    }

    private static final class TrajectoryPrediction {
        final List<Vec3> points;
        final Vec3 impactPosition;
        final BlockPos hitBlockPos;
        final EnumFacing hitFace;
        final double width;
        final double height;

        private TrajectoryPrediction(List<Vec3> points, Vec3 impactPosition, BlockPos hitBlockPos, EnumFacing hitFace,
                                     double width, double height) {
            this.points = points;
            this.impactPosition = impactPosition;
            this.hitBlockPos = hitBlockPos;
            this.hitFace = hitFace;
            this.width = width;
            this.height = height;
        }
    }

    private static final float FIREBALL_TRAJECTORY_LINE_WIDTH = 2.0F;
    private static final float FIREBALL_TRAJECTORY_SHADE_ALPHA = 0.18F;
    private static final double FIREBALL_ACCELERATION = 0.1D;
    private static final double FIRST_PERSON_RENDER_CLIP_DISTANCE = 0.5D;
    private static final double ARROW_GRAVITY = 0.05D;
    private static final double THROWABLE_GRAVITY = 0.03D;
    private static final double PROJECTILE_DRAG = 0.99D;
    private static final double ARROW_WATER_DRAG = 0.6D;
    private static final double THROWABLE_WATER_DRAG = 0.8D;
    private static final double WATER_FLOW_ACCELERATION = 0.014D;
    private static final double WATER_CHECK_EXPAND_Y = -0.4000000059604645D;
    private static final double WATER_CHECK_CONTRACT = 0.001D;
    private static final double COLLISION_EPSILON_SQ = 1.0E-7D;
    private static final double ENTITY_HIT_EXPANSION = 0.3D;
    private static final int PROJECTILE_TRAJECTORY_MAX_TICKS = 120;
    private static final int PROJECTILE_TRAJECTORY_SUBDIVISIONS = 4;
    private static final int PROJECTILE_IGNORE_OWNER_TICKS = 5;
    private static final double ARROW_TRAJECTORY_MARKER_BACK_OFFSET = 0.12D;
    private static final double ARROW_TRAJECTORY_MARKER_INNER_RADIUS = 0.02D;
    private static final double ARROW_TRAJECTORY_MARKER_OUTER_RADIUS = 0.15D;
    private static final float ARROW_TRAJECTORY_MARKER_LINE_WIDTH = 2.0F;
    private static final float ARROW_TRAJECTORY_MARKER_ALPHA = 1.0F;
    private static final double ARROW_TRAJECTORY_MARKER_SPIN_SPEED = 0.35D;
    private static final double ARROW_TRAJECTORY_MARKER_INNER_BACK_SWEEP = 0.01D;
    private static final double ARROW_TRAJECTORY_MARKER_OUTER_BACK_SWEEP = 0.05D;

    private final Map<EntityLargeFireball, Vec3> fireballAccelerationOverrides = new ConcurrentHashMap<>();
    private World world;
    private EntityArrow arrowPreview;
    private EntityEnderPearl pearlPreview;
    private EntityLargeFireball fireballPreview;
    private boolean crossTarget;
    private boolean autoScale;
    private float targetLineWidth = FIREBALL_TRAJECTORY_LINE_WIDTH;

    public void configureTarget(boolean crossTarget, boolean autoScale, float targetLineWidth) {
        this.crossTarget = crossTarget;
        this.autoScale = autoScale;
        this.targetLineWidth = targetLineWidth;
    }

    public void clear() {
        fireballAccelerationOverrides.clear();
        arrowPreview = null;
        pearlPreview = null;
        fireballPreview = null;
        world = null;
    }

    public void updateWorld() {
        if (world != mc.theWorld) {
            clear();
            world = mc.theWorld;
        }
        fireballAccelerationOverrides.keySet().removeIf(fireball -> fireball.isDead
                || fireball.worldObj != world || world == null
                || world.getEntityByID(fireball.getEntityId()) != fireball);
    }

    public void onVelocityPacket(S12PacketEntityVelocity packet) {
        if (mc.theWorld == null) {
            return;
        }
        Entity entity = mc.theWorld.getEntityByID(packet.getEntityID());
        if (!(entity instanceof EntityLargeFireball)) {
            return;
        }

        Vec3 motion = new Vec3(packet.getMotionX() / 8000.0D, packet.getMotionY() / 8000.0D,
                packet.getMotionZ() / 8000.0D);
        double length = motion.lengthVector();
        if (length > 0.0D) {
            double scale = FIREBALL_ACCELERATION / length;
            fireballAccelerationOverrides.put((EntityLargeFireball) entity,
                    new Vec3(motion.xCoord * scale, motion.yCoord * scale, motion.zCoord * scale));
        }
    }

    public void renderThrown(Entity entity, float partialTicks) {
        if (entity.isDead) {
            return;
        }
        if (entity instanceof EntityLargeFireball) {
            renderFireballTrajectory((EntityLargeFireball) entity, partialTicks);
        } else if (entity instanceof EntityArrow && !((IAccessorEntityArrow) entity).getInGround()) {
            renderArrowTrajectory((EntityArrow) entity, partialTicks);
        } else if (entity instanceof EntityEnderPearl) {
            EntityEnderPearl pearl = (EntityEnderPearl) entity;
            renderPearlTrajectory(pearl, pearl.getThrower(), partialTicks);
        }
    }

    public void renderHeld(EntityPlayer player, float partialTicks) {
        ItemStack heldStack = player.getHeldItem();
        if (heldStack == null) {
            return;
        }

        Item item = heldStack.getItem();
        double velocity = 1.5D;
        if (item == Items.bow) {
            if (!player.isUsingItem() || player.getItemInUse().getItem() != Items.bow) {
                return;
            }
            float charge = (player.getItemInUseDuration() + partialTicks) / 20.0F;
            charge = Math.min(1.0F, (charge * charge + charge * 2.0F) / 3.0F);
            if (charge < 0.1F) {
                return;
            }
            velocity = charge * 3.0D;
        } else if (item != Items.ender_pearl && item != Items.fire_charge) {
            return;
        }

        float previousYaw = player == mc.thePlayer ? player.prevRotationYaw : player.prevRotationYawHead;
        float currentYaw = player == mc.thePlayer ? player.rotationYaw : player.rotationYawHead;
        float yaw = (float) Math.toRadians(previousYaw
                + MathHelper.wrapAngleTo180_float(currentYaw - previousYaw) * partialTicks);
        float pitch = (float) Math.toRadians(player.prevRotationPitch
                + (player.rotationPitch - player.prevRotationPitch) * partialTicks);
        Vec3 direction = new Vec3(-MathHelper.sin(yaw) * MathHelper.cos(pitch),
                -MathHelper.sin(pitch), MathHelper.cos(yaw) * MathHelper.cos(pitch)).normalize();
        double posX = player.lastTickPosX + (player.posX - player.lastTickPosX) * partialTicks;
        double posY = player.lastTickPosY + (player.posY - player.lastTickPosY) * partialTicks + player.getEyeHeight();
        double posZ = player.lastTickPosZ + (player.posZ - player.lastTickPosZ) * partialTicks;
        posX -= MathHelper.cos(yaw) * 0.16F;
        posY -= 0.10000000149011612D;
        posZ -= MathHelper.sin(yaw) * 0.16F;

        if (item == Items.fire_charge) {
            if (fireballPreview == null) {
                fireballPreview = new EntityLargeFireball(mc.theWorld);
            }
            fireballPreview.shootingEntity = player;
            fireballPreview.accelerationX = direction.xCoord * FIREBALL_ACCELERATION;
            fireballPreview.accelerationY = direction.yCoord * FIREBALL_ACCELERATION;
            fireballPreview.accelerationZ = direction.zCoord * FIREBALL_ACCELERATION;
            positionPreview(fireballPreview, posX, posY - fireballPreview.height * 0.5D, posZ, direction, 0.0D);
            renderFireballTrajectory(fireballPreview, partialTicks);
            return;
        }

        if (item == Items.bow) {
            if (arrowPreview == null) {
                arrowPreview = new EntityArrow(mc.theWorld);
            }
            arrowPreview.shootingEntity = player;
            positionPreview(arrowPreview, posX, posY, posZ, direction, velocity);
            renderArrowTrajectory(arrowPreview, partialTicks);
        } else {
            if (pearlPreview == null) {
                pearlPreview = new EntityEnderPearl(mc.theWorld);
            }
            positionPreview(pearlPreview, posX, posY, posZ, direction, velocity);
            renderPearlTrajectory(pearlPreview, player, partialTicks);
        }
    }

    private void positionPreview(Entity projectile, double posX, double posY, double posZ, Vec3 direction, double velocity) {
        projectile.setPosition(posX, posY, posZ);
        projectile.lastTickPosX = posX;
        projectile.lastTickPosY = posY;
        projectile.lastTickPosZ = posZ;
        projectile.motionX = direction.xCoord * velocity;
        projectile.motionY = direction.yCoord * velocity;
        projectile.motionZ = direction.zCoord * velocity;
        projectile.ticksExisted = 0;
    }

    private void renderFireballTrajectory(EntityLargeFireball fireball, float partialTicks) {
        Vec3 accelerationOverride = fireballAccelerationOverrides.get(fireball);
        FireballSImulator.Result result = crossTarget
                ? FireballSImulator.simulateCenterLine(fireball, accelerationOverride)
                : FireballSImulator.simulate(fireball, accelerationOverride);
        Vec3 impactPosition = result.getImpactPosition();

        if (impactPosition == null) {
            return;
        }

        double viewerX = mc.getRenderManager().viewerPosX;
        double viewerY = mc.getRenderManager().viewerPosY;
        double viewerZ = mc.getRenderManager().viewerPosZ;
        double startX = fireball.lastTickPosX + (fireball.posX - fireball.lastTickPosX) * partialTicks;
        double startY = fireball.lastTickPosY + (fireball.posY - fireball.lastTickPosY) * partialTicks + fireball.height * 0.5D;
        double startZ = fireball.lastTickPosZ + (fireball.posZ - fireball.lastTickPosZ) * partialTicks;
        Vec3 targetPosition = crossTarget && result.hitBlock() ? result.getHitPosition()
                : impactPosition.addVector(0.0D, fireball.height * 0.5D, 0.0D);
        if (fireball == fireballPreview && fireball.shootingEntity == mc.thePlayer && mc.gameSettings.thirdPersonView == 0) {
            Vec3 segment = new Vec3(targetPosition.xCoord - startX, targetPosition.yCoord - startY, targetPosition.zCoord - startZ);
            double length = segment.lengthVector();
            if (length > 0.0D) {
                double clipScale = Math.min(FIRST_PERSON_RENDER_CLIP_DISTANCE, length) / length;
                startX += segment.xCoord * clipScale;
                startY += segment.yCoord * clipScale;
                startZ += segment.zCoord * clipScale;
            }
        }
        Color fireballColor = FIREBALL_COLOR;
        float red = fireballColor.getRed() / 255.0F;
        float green = fireballColor.getGreen() / 255.0F;
        float blue = fireballColor.getBlue() / 255.0F;

        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glDepthMask(false);

        GL11.glLineWidth(FIREBALL_TRAJECTORY_LINE_WIDTH);
        GL11.glColor4f(red, green, blue, 1.0F);
        GL11.glBegin(GL11.GL_LINES);
        GL11.glVertex3d(startX - viewerX, startY - viewerY, startZ - viewerZ);
        GL11.glVertex3d(targetPosition.xCoord - viewerX, targetPosition.yCoord - viewerY, targetPosition.zCoord - viewerZ);
        GL11.glEnd();

        if (crossTarget) {
            MovingObjectPosition collision = result.getCollision();
            renderCrossIndicator(targetPosition,
                    collision != null ? collision.sideHit : null, viewerX, viewerY, viewerZ,
                    red, green, blue, autoScale, targetLineWidth);
        } else {
            AxisAlignedBB impactBox = getImpactBox(fireball, impactPosition);
            RenderUtils.drawOutlinedBox(impactBox, viewerX, viewerY, viewerZ);
            RenderUtils.drawBoundingBox(impactBox.offset(-viewerX, -viewerY, -viewerZ), red, green, blue, FIREBALL_TRAJECTORY_SHADE_ALPHA);
        }

        GL11.glLineWidth(1.0F);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        GL11.glDepthMask(true);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glPopMatrix();
    }

    private void renderArrowTrajectory(EntityArrow arrowEntity, float partialTicks) {
        ProjectileTrajectoryProps props = new ProjectileTrajectoryProps(
                ARROW_GRAVITY,
                PROJECTILE_DRAG,
                ARROW_WATER_DRAG,
                Math.max(arrowEntity.width * 0.5D, 0.25D),
                arrowEntity.width,
                arrowEntity.height,
                true,
                PROJECTILE_IGNORE_OWNER_TICKS
        );
        renderPredictedTrajectory(
                arrowEntity,
                partialTicks,
                predictProjectileTrajectory(arrowEntity, props, arrowEntity.shootingEntity),
                Color.WHITE
        );
    }

    private void renderPearlTrajectory(EntityEnderPearl pearlEntity, Entity owner, float partialTicks) {
        ProjectileTrajectoryProps props = new ProjectileTrajectoryProps(
                THROWABLE_GRAVITY,
                PROJECTILE_DRAG,
                THROWABLE_WATER_DRAG,
                Math.max(pearlEntity.width * 0.5D, 0.125D),
                pearlEntity.width,
                pearlEntity.height,
                false,
                PROJECTILE_IGNORE_OWNER_TICKS
        );
        Color pearlColor = PEARL_COLOR;
        renderPredictedTrajectory(
                pearlEntity,
                partialTicks,
                predictProjectileTrajectory(pearlEntity, props, owner),
                pearlColor
        );
    }

    private TrajectoryPrediction predictProjectileTrajectory(Entity projectile, ProjectileTrajectoryProps props, Entity owner) {
        double posX = projectile.posX;
        double posY = projectile.posY;
        double posZ = projectile.posZ;
        double motionX = projectile.motionX;
        double motionY = projectile.motionY;
        double motionZ = projectile.motionZ;
        int ticksInAir = Math.max(0, projectile.ticksExisted);

        List<Vec3> points = new ArrayList<>();
        points.add(new Vec3(posX, posY, posZ));

        for (int tick = 0; tick < PROJECTILE_TRAJECTORY_MAX_TICKS; tick++) {
            FluidState fluidState = sampleFluidState(posX, posY, posZ, props.width, props.height, projectile);
            double[] motion = new double[] { motionX, motionY, motionZ };
            applyWaterFlowAcceleration(fluidState, motion);
            motionX = motion[0];
            motionY = motion[1];
            motionZ = motion[2];

            double nextX = posX + motionX;
            double nextY = posY + motionY;
            double nextZ = posZ + motionZ;

            Vec3 start = new Vec3(posX, posY, posZ);
            Vec3 end = new Vec3(nextX, nextY, nextZ);
            BlockCollisionResult blockCollision = getNearestBlockCollision(start, end, props);
            MovingObjectPosition blockHit = blockCollision.hit;
            double bestDistanceSq = blockCollision.distanceSq;
            Vec3 clampedEnd = blockHit != null ? blockHit.hitVec : end;

            AxisAlignedBB broadBox = new AxisAlignedBB(
                    posX - props.hitboxRadius,
                    posY - props.hitboxRadius,
                    posZ - props.hitboxRadius,
                    posX + props.hitboxRadius,
                    posY + props.hitboxRadius,
                    posZ + props.hitboxRadius
            ).addCoord(motionX, motionY, motionZ).expand(1.0D, 1.0D, 1.0D);

            Vec3 bestEntityHit = null;
            EnumFacing bestEntityHitFace = null;
            for (Entity entity : mc.theWorld.getEntitiesWithinAABBExcludingEntity(projectile, broadBox)) {
                if (!(entity instanceof EntityLivingBase)) {
                    continue;
                }
                if (entity instanceof EntityArmorStand) {
                    continue;
                }
                if (!entity.canBeCollidedWith()) {
                    continue;
                }
                if (((EntityLivingBase) entity).deathTime != 0) {
                    continue;
                }
                if (entity instanceof EntityPlayer && AntiBot.isBot(entity)) {
                    continue;
                }
                if (owner != null && entity.isEntityEqual(owner) && ticksInAir < props.ignoreOwnerTicks) {
                    continue;
                }

                AxisAlignedBB expandedBox = entity.getEntityBoundingBox().expand(
                        ENTITY_HIT_EXPANSION,
                        ENTITY_HIT_EXPANSION,
                        ENTITY_HIT_EXPANSION
                );
                MovingObjectPosition entityHit = expandedBox.calculateIntercept(start, clampedEnd);
                if (entityHit == null) {
                    continue;
                }

                double distanceSq = start.squareDistanceTo(entityHit.hitVec);
                if (distanceSq + COLLISION_EPSILON_SQ < bestDistanceSq) {
                    bestDistanceSq = distanceSq;
                    bestEntityHit = entityHit.hitVec;
                    bestEntityHitFace = entityHit.sideHit;
                }
            }

            if (bestEntityHit != null) {
                addHitSegmentPoints(points, posX, posY, posZ, motionX, motionY, motionZ, bestEntityHit);
                return new TrajectoryPrediction(points, bestEntityHit, null, bestEntityHitFace, props.width, props.height);
            }

            if (blockHit != null) {
                addHitSegmentPoints(points, posX, posY, posZ, motionX, motionY, motionZ, blockHit.hitVec);
                return new TrajectoryPrediction(points, blockHit.hitVec, blockHit.getBlockPos(), blockHit.sideHit, props.width, props.height);
            }

            addFullSegmentPoints(points, posX, posY, posZ, motionX, motionY, motionZ);
            posX = nextX;
            posY = nextY;
            posZ = nextZ;

            motionX *= fluidState.inWater ? props.dragInWater : props.drag;
            motionY *= fluidState.inWater ? props.dragInWater : props.drag;
            motionZ *= fluidState.inWater ? props.dragInWater : props.drag;
            motionY -= props.gravity;
            ticksInAir++;

            if (posY < -64.0D) {
                break;
            }
        }

        return new TrajectoryPrediction(points, null, null, null, props.width, props.height);
    }

    private void addFullSegmentPoints(List<Vec3> points, double posX, double posY, double posZ,
                                      double motionX, double motionY, double motionZ) {
        for (int step = 1; step <= PROJECTILE_TRAJECTORY_SUBDIVISIONS; step++) {
            double t = (double) step / (double) PROJECTILE_TRAJECTORY_SUBDIVISIONS;
            points.add(new Vec3(
                    posX + motionX * t,
                    posY + motionY * t,
                    posZ + motionZ * t
            ));
        }
    }

    private void addHitSegmentPoints(List<Vec3> points, double posX, double posY, double posZ,
                                     double motionX, double motionY, double motionZ, Vec3 hitVec) {
        double segmentLengthSq = motionX * motionX + motionY * motionY + motionZ * motionZ;
        double hitDx = hitVec.xCoord - posX;
        double hitDy = hitVec.yCoord - posY;
        double hitDz = hitVec.zCoord - posZ;
        double hitDistanceSq = hitDx * hitDx + hitDy * hitDy + hitDz * hitDz;
        double hitT = segmentLengthSq > 0.0D ? Math.sqrt(hitDistanceSq / segmentLengthSq) : 0.0D;
        hitT = Math.max(0.0D, Math.min(1.0D, hitT));
        int subCount = (int) Math.ceil(hitT * PROJECTILE_TRAJECTORY_SUBDIVISIONS);

        for (int step = 1; step < subCount; step++) {
            double t = (double) step / (double) PROJECTILE_TRAJECTORY_SUBDIVISIONS;
            points.add(new Vec3(
                    posX + motionX * t,
                    posY + motionY * t,
                    posZ + motionZ * t
            ));
        }

        points.add(hitVec);
    }

    private void renderPredictedTrajectory(Entity projectile, float partialTicks, TrajectoryPrediction prediction, Color color) {
        if (prediction.points.size() < 2) {
            return;
        }

        double viewerX = mc.getRenderManager().viewerPosX;
        double viewerY = mc.getRenderManager().viewerPosY;
        double viewerZ = mc.getRenderManager().viewerPosZ;
        double startX = projectile.lastTickPosX + (projectile.posX - projectile.lastTickPosX) * partialTicks;
        double startY = projectile.lastTickPosY + (projectile.posY - projectile.lastTickPosY) * partialTicks;
        double startZ = projectile.lastTickPosZ + (projectile.posZ - projectile.lastTickPosZ) * partialTicks;
        float red = color.getRed() / 255.0F;
        float green = color.getGreen() / 255.0F;
        float blue = color.getBlue() / 255.0F;

        GL11.glPushMatrix();
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glDepthMask(false);

        GL11.glLineWidth(FIREBALL_TRAJECTORY_LINE_WIDTH);
        GL11.glColor4f(red, green, blue, 1.0F);
        GL11.glBegin(GL11.GL_LINE_STRIP);
        GL11.glVertex3d(startX - viewerX, startY - viewerY, startZ - viewerZ);
        for (int i = 1; i < prediction.points.size(); i++) {
            Vec3 point = prediction.points.get(i);
            GL11.glVertex3d(point.xCoord - viewerX, point.yCoord - viewerY, point.zCoord - viewerZ);
        }
        GL11.glEnd();

        if (prediction.impactPosition != null) {
            if (crossTarget) {
                renderCrossIndicator(prediction.impactPosition, prediction.hitFace, viewerX, viewerY, viewerZ,
                        red, green, blue, autoScale, targetLineWidth);
            } else {
                AxisAlignedBB impactBox = getPredictedImpactBox(projectile, prediction);
                RenderUtils.drawOutlinedBox(impactBox, viewerX, viewerY, viewerZ);
                RenderUtils.drawBoundingBox(impactBox.offset(-viewerX, -viewerY, -viewerZ), red, green, blue, FIREBALL_TRAJECTORY_SHADE_ALPHA);
            }
        }

        if (projectile instanceof EntityArrow && projectile != arrowPreview) {
            renderArrowTrajectoryStartMarker(prediction, projectile, partialTicks, startX, startY, startZ, viewerX, viewerY, viewerZ, red, green, blue);
        }

        GL11.glLineWidth(1.0F);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        GL11.glDepthMask(true);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glPopMatrix();
    }

    public static void renderCrossIndicator(Vec3 hitPos, EnumFacing hitFace, double camX, double camY, double camZ,
                                            float r, float g, float b, boolean autoScale, float lineWidth) {
        double distanceSq = mc.thePlayer.getDistanceSq(hitPos.xCoord, hitPos.yCoord, hitPos.zCoord);
        double size = autoScale ? Math.min(0.1 * (1.0 + distanceSq / 500.0), 0.5) : 0.1;
        double x = hitPos.xCoord - camX;
        double y = hitPos.yCoord - camY;
        double z = hitPos.zCoord - camZ;
        GL11.glLineWidth(lineWidth);
        GL11.glColor4f(r, g, b, 1.0f);
        GL11.glBegin(GL11.GL_LINES);
        switch (hitFace != null ? hitFace : EnumFacing.UP) {
            case WEST:
            case EAST:
                GL11.glVertex3d(x, y - size, z - size);
                GL11.glVertex3d(x, y + size, z + size);
                GL11.glVertex3d(x, y - size, z + size);
                GL11.glVertex3d(x, y + size, z - size);
                break;
            case NORTH:
            case SOUTH:
                GL11.glVertex3d(x - size, y - size, z);
                GL11.glVertex3d(x + size, y + size, z);
                GL11.glVertex3d(x + size, y - size, z);
                GL11.glVertex3d(x - size, y + size, z);
                break;
            case DOWN:
            case UP:
                GL11.glVertex3d(x - size, y, z - size);
                GL11.glVertex3d(x + size, y, z + size);
                GL11.glVertex3d(x + size, y, z - size);
                GL11.glVertex3d(x - size, y, z + size);
                break;
        }
        GL11.glEnd();
    }

    private void renderArrowTrajectoryStartMarker(TrajectoryPrediction prediction, Entity projectile, float partialTicks,
                                                  double startX, double startY, double startZ,
                                                  double viewerX, double viewerY, double viewerZ,
                                                  float red, float green, float blue) {
        Vec3 direction = getArrowTrajectoryMarkerDirection(prediction, projectile, startX, startY, startZ);
        if (direction == null) {
            return;
        }

        Vec3 armAxisA = getPerpendicularUnitVector(direction);
        if (armAxisA == null) {
            return;
        }

        Vec3 armAxisB = normalizeVec3(cross(direction, armAxisA));
        if (armAxisB == null) {
            return;
        }

        double centerX = startX - direction.xCoord * ARROW_TRAJECTORY_MARKER_BACK_OFFSET;
        double centerY = startY - direction.yCoord * ARROW_TRAJECTORY_MARKER_BACK_OFFSET;
        double centerZ = startZ - direction.zCoord * ARROW_TRAJECTORY_MARKER_BACK_OFFSET;
        double spinAngle = (projectile.ticksExisted + partialTicks) * ARROW_TRAJECTORY_MARKER_SPIN_SPEED;
        double cosine = Math.cos(spinAngle);
        double sine = Math.sin(spinAngle);
        Vec3 rotatedArmAxisA = rotateMarkerAxis(armAxisA, armAxisB, cosine, sine);
        Vec3 rotatedArmAxisB = rotateMarkerAxis(armAxisB, armAxisA, cosine, -sine);

        GL11.glLineWidth(ARROW_TRAJECTORY_MARKER_LINE_WIDTH);
        GL11.glColor4f(red, green, blue, ARROW_TRAJECTORY_MARKER_ALPHA);
        GL11.glBegin(GL11.GL_LINES);
        addMarkerSegment(centerX, centerY, centerZ, rotatedArmAxisA, direction, viewerX, viewerY, viewerZ);
        addMarkerSegment(centerX, centerY, centerZ, new Vec3(-rotatedArmAxisA.xCoord, -rotatedArmAxisA.yCoord, -rotatedArmAxisA.zCoord), direction, viewerX, viewerY, viewerZ);
        addMarkerSegment(centerX, centerY, centerZ, rotatedArmAxisB, direction, viewerX, viewerY, viewerZ);
        addMarkerSegment(centerX, centerY, centerZ, new Vec3(-rotatedArmAxisB.xCoord, -rotatedArmAxisB.yCoord, -rotatedArmAxisB.zCoord), direction, viewerX, viewerY, viewerZ);
        GL11.glEnd();
    }

    private void addMarkerSegment(double centerX, double centerY, double centerZ, Vec3 axis, Vec3 direction,
                                  double viewerX, double viewerY, double viewerZ) {
        GL11.glVertex3d(
                centerX + axis.xCoord * ARROW_TRAJECTORY_MARKER_INNER_RADIUS - direction.xCoord * ARROW_TRAJECTORY_MARKER_INNER_BACK_SWEEP - viewerX,
                centerY + axis.yCoord * ARROW_TRAJECTORY_MARKER_INNER_RADIUS - direction.yCoord * ARROW_TRAJECTORY_MARKER_INNER_BACK_SWEEP - viewerY,
                centerZ + axis.zCoord * ARROW_TRAJECTORY_MARKER_INNER_RADIUS - direction.zCoord * ARROW_TRAJECTORY_MARKER_INNER_BACK_SWEEP - viewerZ
        );
        GL11.glVertex3d(
                centerX + axis.xCoord * ARROW_TRAJECTORY_MARKER_OUTER_RADIUS - direction.xCoord * ARROW_TRAJECTORY_MARKER_OUTER_BACK_SWEEP - viewerX,
                centerY + axis.yCoord * ARROW_TRAJECTORY_MARKER_OUTER_RADIUS - direction.yCoord * ARROW_TRAJECTORY_MARKER_OUTER_BACK_SWEEP - viewerY,
                centerZ + axis.zCoord * ARROW_TRAJECTORY_MARKER_OUTER_RADIUS - direction.zCoord * ARROW_TRAJECTORY_MARKER_OUTER_BACK_SWEEP - viewerZ
        );
    }

    private Vec3 getArrowTrajectoryMarkerDirection(TrajectoryPrediction prediction, Entity projectile,
                                                   double startX, double startY, double startZ) {
        Vec3 direction = normalizeVec3(new Vec3(projectile.motionX, projectile.motionY, projectile.motionZ));
        if (direction != null) {
            return direction;
        }

        if (prediction.points.size() < 2) {
            return null;
        }

        Vec3 nextPoint = prediction.points.get(1);
        return normalizeVec3(new Vec3(
                nextPoint.xCoord - startX,
                nextPoint.yCoord - startY,
                nextPoint.zCoord - startZ
        ));
    }

    private Vec3 getPerpendicularUnitVector(Vec3 direction) {
        Vec3 reference = Math.abs(direction.yCoord) < 0.9D
                ? new Vec3(0.0D, 1.0D, 0.0D)
                : new Vec3(1.0D, 0.0D, 0.0D);
        return normalizeVec3(cross(direction, reference));
    }

    private Vec3 rotateMarkerAxis(Vec3 primaryAxis, Vec3 secondaryAxis, double primaryWeight, double secondaryWeight) {
        return new Vec3(
                primaryAxis.xCoord * primaryWeight + secondaryAxis.xCoord * secondaryWeight,
                primaryAxis.yCoord * primaryWeight + secondaryAxis.yCoord * secondaryWeight,
                primaryAxis.zCoord * primaryWeight + secondaryAxis.zCoord * secondaryWeight
        );
    }

    private Vec3 cross(Vec3 a, Vec3 b) {
        return new Vec3(
                a.yCoord * b.zCoord - a.zCoord * b.yCoord,
                a.zCoord * b.xCoord - a.xCoord * b.zCoord,
                a.xCoord * b.yCoord - a.yCoord * b.xCoord
        );
    }

    private Vec3 normalizeVec3(Vec3 vector) {
        double lengthSq = vector.xCoord * vector.xCoord + vector.yCoord * vector.yCoord + vector.zCoord * vector.zCoord;
        if (lengthSq <= 1.0E-6D) {
            return null;
        }

        double invLength = 1.0D / Math.sqrt(lengthSq);
        return new Vec3(vector.xCoord * invLength, vector.yCoord * invLength, vector.zCoord * invLength);
    }

    private AxisAlignedBB getPredictedImpactBox(Entity projectile, TrajectoryPrediction prediction) {
        if (projectile instanceof EntityArrow) {
            return getProjectileImpactBox(prediction);
        }

        if (prediction.hitBlockPos != null) {
            AxisAlignedBB selectionBox = BlockUtils.getBlockSelectionBox(prediction.hitBlockPos);
            if (selectionBox != null) {
                return selectionBox;
            }

            return new AxisAlignedBB(
                    prediction.hitBlockPos.getX(),
                    prediction.hitBlockPos.getY(),
                    prediction.hitBlockPos.getZ(),
                    prediction.hitBlockPos.getX() + 1.0D,
                    prediction.hitBlockPos.getY() + 1.0D,
                    prediction.hitBlockPos.getZ() + 1.0D
            );
        }

        return getProjectileImpactBox(prediction);
    }

    private AxisAlignedBB getProjectileImpactBox(TrajectoryPrediction prediction) {
        double halfWidth = prediction.width * 0.5D;
        return new AxisAlignedBB(
                prediction.impactPosition.xCoord - halfWidth,
                prediction.impactPosition.yCoord,
                prediction.impactPosition.zCoord - halfWidth,
                prediction.impactPosition.xCoord + halfWidth,
                prediction.impactPosition.yCoord + prediction.height,
                prediction.impactPosition.zCoord + halfWidth
        );
    }

    private AxisAlignedBB getImpactBox(EntityLargeFireball fireball, Vec3 impactPosition) {
        double halfWidth = fireball.width * 0.5D;
        return new AxisAlignedBB(
                impactPosition.xCoord - halfWidth,
                impactPosition.yCoord,
                impactPosition.zCoord - halfWidth,
                impactPosition.xCoord + halfWidth,
                impactPosition.yCoord + fireball.height,
                impactPosition.zCoord + halfWidth
        );
    }

    private FluidState sampleFluidState(double posX, double posY, double posZ, double width, double height, Entity projectile) {
        AxisAlignedBB entityBox = new AxisAlignedBB(
                posX - width * 0.5D,
                posY,
                posZ - width * 0.5D,
                posX + width * 0.5D,
                posY + height,
                posZ + width * 0.5D
        );
        AxisAlignedBB waterCheckBox = entityBox.expand(0.0D, WATER_CHECK_EXPAND_Y, 0.0D)
                .contract(WATER_CHECK_CONTRACT, WATER_CHECK_CONTRACT, WATER_CHECK_CONTRACT);

        int minX = MathHelper.floor_double(waterCheckBox.minX);
        int maxX = MathHelper.floor_double(waterCheckBox.maxX + 1.0D);
        int minY = MathHelper.floor_double(waterCheckBox.minY);
        int maxY = MathHelper.floor_double(waterCheckBox.maxY + 1.0D);
        int minZ = MathHelper.floor_double(waterCheckBox.minZ);
        int maxZ = MathHelper.floor_double(waterCheckBox.maxZ + 1.0D);

        if (!mc.theWorld.isAreaLoaded(new BlockPos(minX, minY, minZ), new BlockPos(maxX, maxY, maxZ), true)) {
            return new FluidState(false, new Vec3(0.0D, 0.0D, 0.0D));
        }

        boolean inWater = false;
        Vec3 flowDirection = new Vec3(0.0D, 0.0D, 0.0D);
        BlockPos.MutableBlockPos mutablePos = new BlockPos.MutableBlockPos();

        for (int x = minX; x < maxX; ++x) {
            for (int y = minY; y < maxY; ++y) {
                for (int z = minZ; z < maxZ; ++z) {
                    mutablePos.set(x, y, z);
                    IBlockState blockState = mc.theWorld.getBlockState(mutablePos);

                    if (blockState.getBlock().getMaterial() != Material.water) {
                        continue;
                    }

                    double liquidSurfaceY = (double) ((float) (y + 1)
                            - BlockLiquid.getLiquidHeightPercent((Integer) blockState.getValue(BlockLiquid.LEVEL)));
                    if ((double) maxY >= liquidSurfaceY) {
                        inWater = true;
                        flowDirection = blockState.getBlock().modifyAcceleration(mc.theWorld, mutablePos, projectile, flowDirection);
                    }
                }
            }
        }

        if (flowDirection.lengthVector() > 0.0D) {
            flowDirection = flowDirection.normalize();
        }

        return new FluidState(inWater, flowDirection);
    }

    private void applyWaterFlowAcceleration(FluidState fluidState, double[] motion) {
        if (!fluidState.inWater || fluidState.flowDirection.lengthVector() <= 0.0D) {
            return;
        }

        motion[0] += fluidState.flowDirection.xCoord * WATER_FLOW_ACCELERATION;
        motion[1] += fluidState.flowDirection.yCoord * WATER_FLOW_ACCELERATION;
        motion[2] += fluidState.flowDirection.zCoord * WATER_FLOW_ACCELERATION;
    }

    private AxisAlignedBB getBlockSweepBounds(Vec3 start, Vec3 end) {
        return new AxisAlignedBB(
                Math.min(start.xCoord, end.xCoord),
                Math.min(start.yCoord, end.yCoord),
                Math.min(start.zCoord, end.zCoord),
                Math.max(start.xCoord, end.xCoord),
                Math.max(start.yCoord, end.yCoord),
                Math.max(start.zCoord, end.zCoord)
        );
    }

    private AxisAlignedBB getVanillaProjectileBounds(Block block, BlockPos pos) {
        block.setBlockBoundsBasedOnState(mc.theWorld, pos);
        return block.getSelectedBoundingBox(mc.theWorld, pos);
    }

    private AxisAlignedBB intersectBoxes(AxisAlignedBB first, AxisAlignedBB second) {
        double minX = Math.max(first.minX, second.minX);
        double minY = Math.max(first.minY, second.minY);
        double minZ = Math.max(first.minZ, second.minZ);
        double maxX = Math.min(first.maxX, second.maxX);
        double maxY = Math.min(first.maxY, second.maxY);
        double maxZ = Math.min(first.maxZ, second.maxZ);

        if (maxX - minX <= 1.0E-7D || maxY - minY <= 1.0E-7D || maxZ - minZ <= 1.0E-7D) {
            return null;
        }

        return new AxisAlignedBB(minX, minY, minZ, maxX, maxY, maxZ);
    }

    private BlockCollisionResult rayTraceBlockCollisionBoxes(Vec3 start, Vec3 end, ProjectileTrajectoryProps props) {
        AxisAlignedBB sweepBounds = getBlockSweepBounds(start, end);
        int minX = MathHelper.floor_double(sweepBounds.minX);
        int maxX = MathHelper.floor_double(sweepBounds.maxX + 1.0D);
        int minY = MathHelper.floor_double(sweepBounds.minY);
        int maxY = MathHelper.floor_double(sweepBounds.maxY + 1.0D);
        int minZ = MathHelper.floor_double(sweepBounds.minZ);
        int maxZ = MathHelper.floor_double(sweepBounds.maxZ + 1.0D);

        if (!mc.theWorld.isAreaLoaded(new BlockPos(minX, minY, minZ), new BlockPos(maxX, maxY, maxZ), true)) {
            return new BlockCollisionResult(null, Double.MAX_VALUE);
        }

        List<AxisAlignedBB> collisionBoxes = new ArrayList<>();
        BlockPos.MutableBlockPos mutablePos = new BlockPos.MutableBlockPos();
        MovingObjectPosition bestHit = null;
        double bestDistanceSq = Double.MAX_VALUE;

        for (int x = minX; x < maxX; ++x) {
            for (int y = minY; y < maxY; ++y) {
                for (int z = minZ; z < maxZ; ++z) {
                    mutablePos.set(x, y, z);
                    IBlockState blockState = mc.theWorld.getBlockState(mutablePos);
                    Block block = blockState.getBlock();

                    if ((!props.ignoreBlockWithoutBoundingBox
                            || block.getCollisionBoundingBox(mc.theWorld, mutablePos, blockState) != null)
                            && block.canCollideCheck(blockState, false)) {
                        collisionBoxes.clear();
                        AxisAlignedBB vanillaProjectileBounds = getVanillaProjectileBounds(block, mutablePos);
                        block.addCollisionBoxesToList(mc.theWorld, mutablePos, blockState, sweepBounds, collisionBoxes, null);

                        for (AxisAlignedBB collisionBox : collisionBoxes) {
                            AxisAlignedBB projectileCollisionBox = intersectBoxes(collisionBox, vanillaProjectileBounds);
                            if (projectileCollisionBox == null) {
                                continue;
                            }

                            MovingObjectPosition hit = projectileCollisionBox.calculateIntercept(start, end);
                            if (hit == null) {
                                continue;
                            }

                            double distanceSq = start.squareDistanceTo(hit.hitVec);
                            if (distanceSq + COLLISION_EPSILON_SQ < bestDistanceSq) {
                                bestDistanceSq = distanceSq;
                                bestHit = new MovingObjectPosition(hit.hitVec, hit.sideHit, new BlockPos(mutablePos));
                            }
                        }
                    }
                }
            }
        }

        return new BlockCollisionResult(bestHit, bestDistanceSq);
    }

    private BlockCollisionResult getNearestBlockCollision(Vec3 start, Vec3 end, ProjectileTrajectoryProps props) {
        MovingObjectPosition vanillaHit = mc.theWorld.rayTraceBlocks(start, end, false, props.ignoreBlockWithoutBoundingBox, false);
        double vanillaDistanceSq = vanillaHit != null ? start.squareDistanceTo(vanillaHit.hitVec) : Double.MAX_VALUE;

        BlockCollisionResult collisionBoxHit = rayTraceBlockCollisionBoxes(start, end, props);
        if (collisionBoxHit.hit != null && collisionBoxHit.distanceSq + COLLISION_EPSILON_SQ < vanillaDistanceSq) {
            return collisionBoxHit;
        }

        return new BlockCollisionResult(vanillaHit, vanillaDistanceSq);
    }

}
