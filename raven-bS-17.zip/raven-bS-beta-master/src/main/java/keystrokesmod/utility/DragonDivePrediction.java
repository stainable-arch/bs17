package keystrokesmod.utility;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.boss.EntityDragon;
import net.minecraft.init.Blocks;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public final class DragonDivePrediction {
    private static final double LOOK_AHEAD_TICKS = 40.0;
    private static final int MAX_HIGHLIGHTED_BLOCKS = 256;
    private static final int MAX_CHECKED_BLOCKS = 8192;
    private static final int MAX_STEPS = 256;
    private static final Result EMPTY = new Result(null, null, null, Collections.emptyList(), Collections.emptyList());

    private final EntityDragon dragon;
    private int lastTick = -1;
    private boolean lastBedWarsRules;
    private Vec3 lastPosition;
    private float lastYaw;
    private double velocityX;
    private double velocityY;
    private double velocityZ;
    private double verticalAcceleration;
    private double turnRate;
    private Result result = EMPTY;

    public DragonDivePrediction(EntityDragon dragon) {
        this.dragon = dragon;
    }

    public Result update(boolean bedWarsRules) {
        if (lastTick == dragon.ticksExisted && lastBedWarsRules == bedWarsRules) {
            return result;
        }
        lastBedWarsRules = bedWarsRules;
        Vec3 position = new Vec3(dragon.posX, dragon.posY, dragon.posZ);
        int elapsedTicks = dragon.ticksExisted - lastTick;
        if (lastPosition == null || elapsedTicks <= 0 || elapsedTicks > 5
                || position.squareDistanceTo(lastPosition) > elapsedTicks * elapsedTicks * 64.0) {
            velocityX = velocityY = velocityZ = verticalAcceleration = turnRate = 0.0;
            lastPosition = position;
            lastYaw = dragon.rotationYaw;
            lastTick = dragon.ticksExisted;
            result = EMPTY;
            return result;
        }

        double observedX = (position.xCoord - lastPosition.xCoord) / elapsedTicks;
        double observedY = (position.yCoord - lastPosition.yCoord) / elapsedTicks;
        double observedZ = (position.zCoord - lastPosition.zCoord) / elapsedTicks;
        verticalAcceleration = MathHelper.clamp_double((observedY - velocityY) / elapsedTicks, -0.04, 0.04);
        velocityX += (observedX - velocityX) * 0.65;
        velocityY += (observedY - velocityY) * 0.65;
        velocityZ += (observedZ - velocityZ) * 0.65;
        turnRate = MathHelper.clamp_double(
                MathHelper.wrapAngleTo180_float(dragon.rotationYaw - lastYaw) / elapsedTicks, -3.0, 3.0
        );
        lastPosition = position;
        lastYaw = dragon.rotationYaw;
        lastTick = dragon.ticksExisted;

        if (!dragon.isEntityAlive() || dragon.ticksExisted < 2) {
            result = EMPTY;
        }
        else {
            result = predict(bedWarsRules || canBreakBlocks(), bedWarsRules);
        }
        return result;
    }

    private boolean canBreakBlocks() {
        World rulesWorld = dragon.worldObj;
        Minecraft minecraft = Minecraft.getMinecraft();
        MinecraftServer server = minecraft.getIntegratedServer();
        if (server != null && server.worldServers != null && server.worldServers.length > 0) {
            WorldServer serverWorld = server.worldServerForDimension(
                    rulesWorld.provider.getDimensionId()
            );
            if (serverWorld != null) {
                rulesWorld = serverWorld;
            }
        }
        return rulesWorld.getGameRules().getBoolean("mobGriefing");
    }

    private Result predict(boolean canBreakBlocks, boolean ignoreBlockProtection) {
        AxisAlignedBB head = dragon.dragonPartHead.getEntityBoundingBox();
        AxisAlignedBB body = dragon.dragonPartBody.getEntityBoundingBox();
        Set<BlockPos> checked = new HashSet<>();
        Set<BlockPos> affected = new LinkedHashSet<>();
        Set<BlockPos> contacts = new LinkedHashSet<>();
        List<Vec3> path = new ArrayList<>();
        Vec3 impact = null;
        AxisAlignedBB impactSurface = null;
        EnumFacing impactFace = null;
        AxisAlignedBB previousHead = head;
        AxisAlignedBB previousBody = body;
        double x = dragon.posX;
        double y = dragon.posY;
        double z = dragon.posZ;
        double motionX = velocityX;
        double motionY = velocityY;
        double motionZ = velocityZ;
        double acceleration = verticalAcceleration;
        double yawVelocity = Math.toRadians(turnRate);
        double yawOffset = 0.0;
        double speed = Math.sqrt(motionX * motionX + motionY * motionY + motionZ * motionZ);
        double step = Math.max(LOOK_AHEAD_TICKS / MAX_STEPS, 0.5 / Math.max(1.0, speed));

        for (double tick = 0.0; tick <= LOOK_AHEAD_TICKS; tick += step) {
            AxisAlignedBB predictedHead = movePart(head, x, y, z, yawOffset);
            AxisAlignedBB predictedBody = movePart(body, x, y, z, yawOffset);
            Vec3 headCenter = new Vec3((predictedHead.minX + predictedHead.maxX) * 0.5,
                    (predictedHead.minY + predictedHead.maxY) * 0.5,
                    (predictedHead.minZ + predictedHead.maxZ) * 0.5);
            if (impact == null) {
                path.add(headCenter);
            }
            Set<BlockPos> futureContacts = tick > 0.0 ? contacts : null;
            collectBlocks(predictedHead, checked, affected, futureContacts, canBreakBlocks, ignoreBlockProtection);
            collectBlocks(predictedBody, checked, affected, futureContacts, canBreakBlocks, ignoreBlockProtection);
            if (impact == null && !contacts.isEmpty()) {
                Contact firstContact = null;
                for (BlockPos pos : contacts) {
                    Contact headContact = findContact(previousHead, predictedHead, pos);
                    Contact bodyContact = findContact(previousBody, predictedBody, pos);
                    if (headContact != null && (firstContact == null || headContact.fraction < firstContact.fraction)) {
                        firstContact = headContact;
                    }
                    if (bodyContact != null && (firstContact == null || bodyContact.fraction < firstContact.fraction)) {
                        firstContact = bodyContact;
                    }
                }
                if (firstContact != null) {
                    impact = firstContact.position;
                    impactSurface = firstContact.surface;
                    impactFace = firstContact.face;
                    path.add(impact);
                    contacts = null;
                }
                else {
                    contacts.clear();
                }
            }
            if (!canBreakBlocks && impact != null || affected.size() >= MAX_HIGHLIGHTED_BLOCKS
                    || checked.size() >= MAX_CHECKED_BLOCKS) {
                break;
            }

            previousHead = predictedHead;
            previousBody = predictedBody;
            double turn = yawVelocity * step;
            double cosine = Math.cos(turn);
            double sine = Math.sin(turn);
            double nextMotionX = motionX * cosine - motionZ * sine;
            motionZ = motionX * sine + motionZ * cosine;
            motionX = nextMotionX;
            yawOffset += turn;
            motionY = MathHelper.clamp_double(motionY + acceleration * step, -2.0, 2.0);
            x += motionX * step;
            y += motionY * step;
            z += motionZ * step;
            yawVelocity *= Math.pow(0.94, step);
            acceleration *= Math.pow(0.90, step);
        }
        if (impact == null && affected.isEmpty()) {
            return EMPTY;
        }
        return new Result(impact, impactSurface, impactFace, new ArrayList<>(affected),
                impact == null ? Collections.emptyList() : path);
    }

    private Contact findContact(AxisAlignedBB previous, AxisAlignedBB predicted, BlockPos pos) {
        Vec3 start = new Vec3((previous.minX + previous.maxX) * 0.5,
                (previous.minY + previous.maxY) * 0.5, (previous.minZ + previous.maxZ) * 0.5);
        Vec3 end = new Vec3((predicted.minX + predicted.maxX) * 0.5,
                (predicted.minY + predicted.maxY) * 0.5, (predicted.minZ + predicted.maxZ) * 0.5);
        double movementLengthSq = start.squareDistanceTo(end);
        if (movementLengthSq < 1.0E-10) {
            return null;
        }

        AxisAlignedBB blockBounds = new AxisAlignedBB(pos.getX(), pos.getY(), pos.getZ(),
                pos.getX() + 1.0, pos.getY() + 1.0, pos.getZ() + 1.0);
        AxisAlignedBB expanded = blockBounds.expand((predicted.maxX - predicted.minX) * 0.5,
                (predicted.maxY - predicted.minY) * 0.5, (predicted.maxZ - predicted.minZ) * 0.5);
        MovingObjectPosition hit = expanded.calculateIntercept(start, end);
        if (hit == null) {
            return null;
        }

        AxisAlignedBB surface = BlockUtils.getBlockSelectionBox(pos);
        if (surface == null) {
            surface = blockBounds;
        }
        double fraction = Math.sqrt(start.squareDistanceTo(hit.hitVec) / movementLengthSq);
        AxisAlignedBB touchingPart = previous.offset((end.xCoord - start.xCoord) * fraction,
                (end.yCoord - start.yCoord) * fraction, (end.zCoord - start.zCoord) * fraction);
        double minX = MathHelper.clamp_double(touchingPart.minX, surface.minX, surface.maxX);
        double minY = MathHelper.clamp_double(touchingPart.minY, surface.minY, surface.maxY);
        double minZ = MathHelper.clamp_double(touchingPart.minZ, surface.minZ, surface.maxZ);
        double maxX = MathHelper.clamp_double(touchingPart.maxX, surface.minX, surface.maxX);
        double maxY = MathHelper.clamp_double(touchingPart.maxY, surface.minY, surface.maxY);
        double maxZ = MathHelper.clamp_double(touchingPart.maxZ, surface.minZ, surface.maxZ);
        double x = MathHelper.clamp_double(hit.hitVec.xCoord, minX, maxX);
        double y = MathHelper.clamp_double(hit.hitVec.yCoord, minY, maxY);
        double z = MathHelper.clamp_double(hit.hitVec.zCoord, minZ, maxZ);
        switch (hit.sideHit) {
            case WEST:
                minX = maxX = surface.minX;
                x = surface.minX - 0.04;
                break;
            case EAST:
                minX = maxX = surface.maxX;
                x = surface.maxX + 0.04;
                break;
            case DOWN:
                minY = maxY = surface.minY;
                y = surface.minY - 0.04;
                break;
            case UP:
                minY = maxY = surface.maxY;
                y = surface.maxY + 0.04;
                break;
            case NORTH:
                minZ = maxZ = surface.minZ;
                z = surface.minZ - 0.04;
                break;
            case SOUTH:
                minZ = maxZ = surface.maxZ;
                z = surface.maxZ + 0.04;
                break;
        }
        AxisAlignedBB contactSurface = new AxisAlignedBB(minX, minY, minZ, maxX, maxY, maxZ);
        return new Contact(new Vec3(x, y, z), contactSurface, hit.sideHit, fraction);
    }

    private AxisAlignedBB movePart(AxisAlignedBB bounds, double x, double y, double z, double yawOffset) {
        double offsetX = (bounds.minX + bounds.maxX) * 0.5 - dragon.posX;
        double offsetZ = (bounds.minZ + bounds.maxZ) * 0.5 - dragon.posZ;
        double cosine = Math.cos(yawOffset);
        double sine = Math.sin(yawOffset);
        return bounds.offset(x - dragon.posX + offsetX * cosine - offsetZ * sine - offsetX,
                y - dragon.posY, z - dragon.posZ + offsetX * sine + offsetZ * cosine - offsetZ);
    }

    private void collectBlocks(AxisAlignedBB bounds, Set<BlockPos> checked, Set<BlockPos> affected,
                               Set<BlockPos> contacts, boolean canBreakBlocks, boolean ignoreBlockProtection) {
        int minY = Math.max(0, MathHelper.floor_double(bounds.minY));
        int maxY = Math.min(255, MathHelper.floor_double(bounds.maxY));
        for (int x = MathHelper.floor_double(bounds.minX); x <= MathHelper.floor_double(bounds.maxX); x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = MathHelper.floor_double(bounds.minZ); z <= MathHelper.floor_double(bounds.maxZ); z++) {
                    if (affected.size() >= MAX_HIGHLIGHTED_BLOCKS || checked.size() >= MAX_CHECKED_BLOCKS) {
                        return;
                    }
                    BlockPos pos = new BlockPos(x, y, z);
                    if (!checked.add(pos) || !dragon.worldObj.isBlockLoaded(pos)) {
                        continue;
                    }
                    Block block = dragon.worldObj.getBlockState(pos).getBlock();
                    if (block.getMaterial() == Material.air) {
                        continue;
                    }
                    if (contacts != null) {
                        contacts.add(pos);
                    }
                    if (canBreakBlocks && (ignoreBlockProtection || block != Blocks.barrier && block != Blocks.obsidian
                            && block != Blocks.end_stone && block != Blocks.bedrock && block != Blocks.command_block)) {
                        affected.add(pos);
                    }
                }
            }
        }
    }

    private static final class Contact {
        private final Vec3 position;
        private final AxisAlignedBB surface;
        private final EnumFacing face;
        private final double fraction;

        private Contact(Vec3 position, AxisAlignedBB surface, EnumFacing face, double fraction) {
            this.position = position;
            this.surface = surface;
            this.face = face;
            this.fraction = fraction;
        }
    }

    public static final class Result {
        public final Vec3 impact;
        public final AxisAlignedBB impactSurface;
        public final EnumFacing impactFace;
        public final List<BlockPos> blocks;
        public final List<Vec3> path;

        private Result(Vec3 impact, AxisAlignedBB impactSurface, EnumFacing impactFace,
                       List<BlockPos> blocks, List<Vec3> path) {
            this.impact = impact;
            this.impactSurface = impactSurface;
            this.impactFace = impactFace;
            this.blocks = blocks;
            this.path = path;
        }
    }
}
