package keystrokesmod.utility.shader;

import keystrokesmod.utility.RenderUtils;
import keystrokesmod.utility.shader.effects.GlowShader;
import net.minecraft.client.shader.Framebuffer;

public final class KawaseBloom {
    private static Framebuffer source;

    private KawaseBloom() {
    }

    public static void renderBlur(int texture, int iterations, float offset) {
        RenderUtils.updateResolution();
        if (source == null) {
            source = new Framebuffer(1, 1, false);
        }
        int saved = source.framebufferTexture;
        source.framebufferTexture = texture;
        try {
            GlowShader.get().render(source, iterations, offset);
        } finally {
            source.framebufferTexture = saved;
        }
    }
}
