package keystrokesmod.utility.shader;

import keystrokesmod.utility.RenderUtils;
import net.minecraft.client.shader.Framebuffer;
import org.lwjgl.opengl.GL20;

public final class HeavyGlowShader {
    private final MaskShader mask = new MaskShader();
    private final EdgeShader edge = new EdgeShader();

    public boolean isValid() {
        return mask.isValid() && edge.isValid();
    }

    public void useMask(int color) {
        mask.use();
        GL20.glUniform3f(mask.uniform("color"), (color >> 16 & 255) / 255.0f,
                (color >> 8 & 255) / 255.0f, (color & 255) / 255.0f);
    }

    public void stopMask() {
        mask.stop();
    }

    public void render(Framebuffer source) {
        KawaseBloom.renderBlur(source.framebufferTexture, 2, 6.5f);
        edge.use();
        try {
            GL20.glUniform2f(edge.uniform("texelSize"), 1.0f / source.framebufferWidth,
                    1.0f / source.framebufferHeight);
            RenderUtils.drawFramebufferFullscreen(source);
        } finally {
            edge.stop();
        }
    }

    private static final class MaskShader extends OutlineESPShader {
        private static final String VERTEX = "#version 120\n" +
                "varying float glint;\n" +
                "void main() {\n" +
                "  mat4 m = gl_TextureMatrix[0];\n" +
                "  float delta = abs(m[0][0] - 1.0) + abs(m[0][1]) + abs(m[1][0]) + abs(m[1][1] - 1.0) + abs(m[3][0]) + abs(m[3][1]);\n" +
                "  glint = step(0.001, delta);\n" +
                "  gl_TexCoord[0] = gl_MultiTexCoord0;\n" +
                "  gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;\n" +
                "}";
        private static final String FRAGMENT = "#version 120\n" +
                "uniform sampler2D tex;\n" +
                "uniform vec3 color;\n" +
                "varying float glint;\n" +
                "void main() {\n" +
                "  if (glint > 0.5 || texture2D(tex, gl_TexCoord[0].st).a <= 0.001) discard;\n" +
                "  gl_FragColor = vec4(color, 1.0);\n" +
                "}";

        private MaskShader() {
            super(FRAGMENT, VERTEX);
        }

        @Override
        public void onLink() {
            cacheUniform("tex");
            cacheUniform("color");
        }

        @Override
        public void onUse() {
            GL20.glUseProgram(programId);
            GL20.glUniform1i(uniform("tex"), 0);
        }
    }

    private static final class EdgeShader extends OutlineESPShader {
        private static final String FRAGMENT = "#version 120\n" +
                "uniform sampler2D tex;\n" +
                "uniform vec2 texelSize;\n" +
                "vec4 pick(vec2 uv, vec2 p) {\n" +
                "  vec4 c;\n" +
                "  c = texture2D(tex, uv + vec2(p.x, 0.0)); if (c.a > 0.1) return c;\n" +
                "  c = texture2D(tex, uv + vec2(-p.x, 0.0)); if (c.a > 0.1) return c;\n" +
                "  c = texture2D(tex, uv + vec2(0.0, p.y)); if (c.a > 0.1) return c;\n" +
                "  c = texture2D(tex, uv + vec2(0.0, -p.y)); if (c.a > 0.1) return c;\n" +
                "  c = texture2D(tex, uv + vec2(p.x, p.y)); if (c.a > 0.1) return c;\n" +
                "  c = texture2D(tex, uv + vec2(-p.x, p.y)); if (c.a > 0.1) return c;\n" +
                "  c = texture2D(tex, uv + vec2(p.x, -p.y)); if (c.a > 0.1) return c;\n" +
                "  c = texture2D(tex, uv + vec2(-p.x, -p.y)); if (c.a > 0.1) return c;\n" +
                "  return vec4(0.0);\n" +
                "}\n" +
                "void main() {\n" +
                "  vec2 uv = gl_TexCoord[0].st;\n" +
                "  if (texture2D(tex, uv).a > 0.1) discard;\n" +
                "  vec4 c = pick(uv, texelSize);\n" +
                "  if (c.a <= 0.1) c = pick(uv, texelSize * 2.0);\n" +
                "  if (c.a <= 0.1) discard;\n" +
                "  gl_FragColor = vec4(c.rgb, 1.0);\n" +
                "}";

        private EdgeShader() {
            super(FRAGMENT);
        }

        @Override
        public void onLink() {
            cacheUniform("tex");
            cacheUniform("texelSize");
        }

        @Override
        public void onUse() {
            GL20.glUseProgram(programId);
            GL20.glUniform1i(uniform("tex"), 0);
        }
    }
}
