package keystrokesmod.utility.shader.effects;

import keystrokesmod.module.impl.client.Settings;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.scoreboard.ScorePlayerTeam;

import java.util.Map;

public final class Strings {
    private static final Minecraft mc = Minecraft.getMinecraft();
    public static final char SECTION = '§';
    public static final char HEART = '❤';
    public static final String RED = "§c", GOLD = "§6", YELLOW = "§e", GREEN = "§a", DARK_GREEN = "§2";

    private Strings() {
    }

    public static float health(EntityLivingBase e) {
        return e.getHealth() + e.getAbsorptionAmount();
    }

    public static double round(double d, int n) {
        if (n == 0) {
            return Math.round(d);
        }
        double d2 = Math.pow(10.0, n);
        return (double) Math.round(d * d2) / d2;
    }

    public static void heart(StringBuilder sb) {
        sb.append(SECTION);
        sb.append('c');
        sb.append(HEART);
    }

    public static StringBuilder reset(StringBuilder sb) {
        sb.append(SECTION).append('r').append(' ');
        return sb;
    }

    public static String health(double d, double d2) {
        String prefix = d < 0.3 ? RED : (d < 0.5 ? GOLD : (d < 0.7 ? YELLOW : GREEN));
        if (Settings.showHealthAsHearts.isToggled()) {
            d2 /= 2.0;
        }
        String s = formatNumber(round(d2, 1));
        StringBuilder sb = new StringBuilder(16);
        sb.append(prefix);
        sb.append(s);
        if (Settings.showHeartSymbol.isToggled()) {
            heart(sb);
        }
        return sb.toString();
    }

    public static String health(EntityPlayer p) {
        float f = health((EntityLivingBase) p);
        return health(Math.min(f / p.getMaxHealth(), 1.0f), f);
    }

    public static String healthDifference(float f, boolean heart) {
        String prefix = f >= 8.0f ? DARK_GREEN : (f > 2.0f ? GREEN : (f > -2.0f ? YELLOW : (f > -6.0f ? GOLD : RED)));
        if (Settings.showHealthAsHearts.isToggled()) {
            f /= 2.0f;
        }
        String s = formatNumber(round(f, 1));
        StringBuilder sb = new StringBuilder(16);
        sb.append(prefix);
        if (f >= 0.0f) {
            sb.append('+');
        }
        sb.append(s);
        if (heart && Settings.showHeartSymbol.isToggled()) {
            heart(sb);
        }
        return sb.toString();
    }

    public static int healthColor(double d) {
        return d < 0.3 ? -55770 : (d < 0.5 ? -12250 : (d < 0.7 ? -218 : -14221530));
    }

    public static String formatNumber(double d) {
        return d == Math.floor(d) ? Long.toString((long) d) : Double.toString(d);
    }
}