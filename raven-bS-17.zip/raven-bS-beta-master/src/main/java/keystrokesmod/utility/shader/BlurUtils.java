package keystrokesmod.utility.shader;

import keystrokesmod.utility.RenderUtils;
import keystrokesmod.utility.shader.effects.Blur;
import keystrokesmod.utility.shader.effects.GlowShader;

public class BlurUtils {
    public static void prepareBlur() {
        RenderUtils.updateResolution();
        Blur.get().startStencil();
    }

    public static void prepareBloom() {
        RenderUtils.updateResolution();
        GlowShader.get().startCapture();
    }

    public static void blurEnd(int passes, float radius) {
        Blur.get().render(passes, radius);
    }

    public static void bloomEnd(int passes, float radius) {
        GlowShader.get().render(passes, radius);
    }
}
