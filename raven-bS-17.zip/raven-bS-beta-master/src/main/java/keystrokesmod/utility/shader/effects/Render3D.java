package keystrokesmod.utility.shader.effects;

import keystrokesmod.utility.RenderUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.AxisAlignedBB;
import org.lwjgl.opengl.GL11;

public final class Render3D {
    private static final Minecraft mc = Minecraft.getMinecraft();

    public static void filledBox(AxisAlignedBB a, float r, float g, float b, float alpha) {
        Tessellator t = Tessellator.getInstance();
        WorldRenderer w = t.getWorldRenderer();
        w.begin(7, DefaultVertexFormats.POSITION_COLOR);
        double[][] v = {
                {a.minX, a.minY, a.minZ}, {a.minX, a.maxY, a.minZ}, {a.maxX, a.maxY, a.minZ}, {a.maxX, a.minY, a.minZ},
                {a.minX, a.minY, a.maxZ}, {a.maxX, a.minY, a.maxZ}, {a.maxX, a.maxY, a.maxZ}, {a.minX, a.maxY, a.maxZ},
                {a.minX, a.minY, a.minZ}, {a.minX, a.minY, a.maxZ}, {a.minX, a.maxY, a.maxZ}, {a.minX, a.maxY, a.minZ},
                {a.maxX, a.minY, a.minZ}, {a.maxX, a.maxY, a.minZ}, {a.maxX, a.maxY, a.maxZ}, {a.maxX, a.minY, a.maxZ},
                {a.minX, a.minY, a.minZ}, {a.maxX, a.minY, a.minZ}, {a.maxX, a.minY, a.maxZ}, {a.minX, a.minY, a.maxZ},
                {a.minX, a.maxY, a.minZ}, {a.minX, a.maxY, a.maxZ}, {a.maxX, a.maxY, a.maxZ}, {a.maxX, a.maxY, a.minZ}};
        for (double[] p : v) {
            w.pos(p[0], p[1], p[2]).color(r, g, b, alpha).endVertex();
        }
        t.draw();
    }

    public static void entityBox(Entity entity, int n, int n2, float f) {
        if (!(entity instanceof EntityLivingBase)) {
            return;
        }
        RenderManager rm = mc.getRenderManager();
        double d4 = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * (double) f - rm.viewerPosX;
        double d5 = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * (double) f - rm.viewerPosY;
        double d6 = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * (double) f - rm.viewerPosZ;
        GlStateManager.pushMatrix();
        if (n == 3) {
            GL11.glTranslated(d4, d5 - 0.2, d6);
            GL11.glRotated(-rm.playerViewY, 0.0, 1.0, 0.0);
            GlStateManager.disableDepth();
            GL11.glScalef(0.03f, 0.03f, 0.03f);
            float f2 = 0.5f;
            RenderUtils.beginRect();
            RenderUtils.rawRect(-20.0f - f2, 75.0f, 20.0f + f2, 75.0f + f2, -15987700);
            RenderUtils.rawRect(-20.0f - f2, -1.0f - f2, 20.0f + f2, -1.0f, -15987700);
            RenderUtils.rawRect(-20.0f - f2, -1.0f, -20.0f, 75.0f, -15987700);
            RenderUtils.rawRect(20.0f + f2, -1.0f, 20.0f, 75.0f, -15987700);
            RenderUtils.endRect();
            f2 = 1.5f;
            if (n2 == 0) {
                int n4 = RenderUtils.rainbow(2L, 0L);
                int n5 = RenderUtils.rainbow(2L, 1000L);
                RenderUtils.gradientRect(-20.0f, -1.0f + f2, -20.0f + f2, 75.0f - f2, n4, n5);
                RenderUtils.gradientRect(20.0f, -1.0f + f2, 20.0f - f2, 75.0f - f2, n4, n5);
                RenderUtils.rect(-20.0f, 75.0f, 20.0f, 75.0f - f2, n4);
                RenderUtils.rect(-20.0f, -1.0f, 20.0f, -1.0f + f2, n5);
            } else {
                RenderUtils.rect(-20.0f, 75.0f, 20.0f, 75.0f - f2, n2);
                RenderUtils.rect(-20.0f, -1.0f, 20.0f, -1.0f + f2, n2);
                RenderUtils.rect(-20.0f, -1.0f + f2, -20.0f + f2, 75.0f - f2, n2);
                RenderUtils.rect(20.0f, -1.0f + f2, 20.0f - f2, 75.0f - f2, n2);
            }
            GlStateManager.enableDepth();
        } else if (n == 4) {
            RenderUtils.renderEntity(entity, 4, 0, 0, n2, false);
        } else if (n == 6) {
            RenderUtils.renderEntity(entity, 6, 0, 0, n2, false);
        } else {
            if (n2 == 0) {
                n2 = RenderUtils.rainbow(2L, 0L);
            }
            float a = (float) (n2 >> 24 & 0xFF) / 255.0f;
            float r = (float) (n2 >> 16 & 0xFF) / 255.0f;
            float g = (float) (n2 >> 8 & 0xFF) / 255.0f;
            float b = (float) (n2 & 0xFF) / 255.0f;
            {
                AxisAlignedBB bb = entity.getEntityBoundingBox().expand(0.1, 0.1, 0.1);
                AxisAlignedBB bb2 = new AxisAlignedBB(bb.minX - entity.posX + d4, bb.minY - entity.posY + d5, bb.minZ - entity.posZ + d6,
                        bb.maxX - entity.posX + d4, bb.maxY - entity.posY + d5, bb.maxZ - entity.posZ + d6);
                GL11.glBlendFunc(770, 771);
                GL11.glEnable(3042);
                GL11.glDisable(3553);
                GL11.glDisable(2929);
                GL11.glDepthMask(false);
                if (n == 1) {
                    GlStateManager.color(r, g, b, a);
                    GL11.glEnable(2848);
                    GL11.glLineWidth(2.0f);
                    RenderGlobal.drawSelectionBoundingBox(bb2);
                    GL11.glDisable(2848);
                } else if (n == 2) {
                    filledBox(bb2, r, g, b, 0.37f);
                }
                RenderUtils.resetColor();
                GL11.glEnable(3553);
                GL11.glEnable(2929);
                GL11.glDepthMask(true);
                GL11.glDisable(3042);
            }
        }
        GlStateManager.popMatrix();
    }

}
