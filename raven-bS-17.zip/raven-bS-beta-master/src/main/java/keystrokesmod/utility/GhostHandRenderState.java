package keystrokesmod.utility;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;

import java.nio.FloatBuffer;

public final class GhostHandRenderState {
    private static final FloatBuffer previousBlendColor = BufferUtils.createFloatBuffer(16);
    private static final FloatBuffer previousColor = BufferUtils.createFloatBuffer(16);
    private static boolean active;
    private static float opacity;
    private static boolean blendEnabled;
    private static boolean cullEnabled;
    private static int cullFace;
    private static boolean depthMask;
    private static int depthFunction;
    private static int sourceRgb;
    private static int destinationRgb;
    private static int sourceAlpha;
    private static int destinationAlpha;

    private GhostHandRenderState() {
    }

    public static boolean begin(float alpha) {
        if (active || alpha >= 1.0F) return false;

        previousBlendColor.clear();
        previousColor.clear();
        GL11.glGetFloat(GL14.GL_BLEND_COLOR, previousBlendColor);
        GL11.glGetFloat(GL11.GL_CURRENT_COLOR, previousColor);
        blendEnabled = GL11.glIsEnabled(GL11.GL_BLEND);
        cullEnabled = GL11.glIsEnabled(GL11.GL_CULL_FACE);
        cullFace = GL11.glGetInteger(GL11.GL_CULL_FACE_MODE);
        depthMask = GL11.glGetBoolean(GL11.GL_DEPTH_WRITEMASK);
        depthFunction = GL11.glGetInteger(GL11.GL_DEPTH_FUNC);
        sourceRgb = GL11.glGetInteger(GL14.GL_BLEND_SRC_RGB);
        destinationRgb = GL11.glGetInteger(GL14.GL_BLEND_DST_RGB);
        sourceAlpha = GL11.glGetInteger(GL14.GL_BLEND_SRC_ALPHA);
        destinationAlpha = GL11.glGetInteger(GL14.GL_BLEND_DST_ALPHA);

        opacity = alpha;
        active = true;
        setColorAlpha(previousColor.get(3));
        GlStateManager.enableBlend();
        GlStateManager.enableCull();
        GlStateManager.cullFace(GL11.GL_BACK);
        GlStateManager.tryBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ZERO);
        GlStateManager.depthMask(false);
        return true;
    }

    public static boolean isActive() {
        return active;
    }

    public static void setColorAlpha(float alpha) {
        if (active) {
            GL14.glBlendColor(0.0F, 0.0F, 0.0F, opacity * alpha);
        }
    }

    public static void end() {
        if (!active) return;
        active = false;

        GL14.glBlendColor(previousBlendColor.get(0), previousBlendColor.get(1), previousBlendColor.get(2), previousBlendColor.get(3));
        GlStateManager.tryBlendFuncSeparate(sourceRgb, destinationRgb, sourceAlpha, destinationAlpha);
        OpenGlHelper.glBlendFunc(sourceRgb, destinationRgb, sourceAlpha, destinationAlpha);
        if (blendEnabled) {
            GlStateManager.enableBlend();
        } else {
            GlStateManager.disableBlend();
        }
        GlStateManager.cullFace(cullFace);
        if (cullEnabled) {
            GlStateManager.enableCull();
        } else {
            GlStateManager.disableCull();
        }
        GlStateManager.depthMask(depthMask);
        GlStateManager.depthFunc(depthFunction);
        GlStateManager.resetColor();
        GlStateManager.color(previousColor.get(0), previousColor.get(1), previousColor.get(2), previousColor.get(3));
    }
}
