package keystrokesmod.module.impl.player;

import keystrokesmod.event.PrePlayerInteractEvent;
import keystrokesmod.event.ReceivePacketEvent;
import keystrokesmod.event.SendPacketEvent;
import keystrokesmod.mixin.impl.accessor.IAccessorPlayerControllerMP;
import keystrokesmod.module.Module;
import keystrokesmod.module.setting.impl.BlockListSetting;
import keystrokesmod.module.setting.impl.ButtonSetting;
import keystrokesmod.module.setting.impl.SliderSetting;
import keystrokesmod.utility.BlockUtils;
import keystrokesmod.utility.Utils;
import keystrokesmod.utility.scaffold.ScaffoldSupport.ItemUtils;
import net.minecraft.block.Block;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.server.S2FPacketSetSlot;
import net.minecraft.network.play.server.S30PacketWindowItems;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AutoSwap extends Module {
    private static final String[] ALLOWED_TYPES = { "Exact", "Variants", "Full", "Any" };
    private static final int EXACT = 0;
    private static final int VARIANTS = 1;
    private static final int FULL = 2;
    private static final int ANY = 3;

    private final SliderSetting allowedTypes;
    private final ButtonSetting swapOnRmb;
    private final ButtonSetting syncStackSize;
    private final ButtonSetting useBlockWhitelist;
    private final BlockListSetting blockWhitelist;

    private ItemStack trackedStack;
    private volatile int lastPlaceSlot = -1;
    private int lastSwapSlot = -1;
    private volatile int serverStackSize = -1;
    private long lastSwapTime;

    public AutoSwap() {
        super("Auto Swap", category.player);
        this.liteModule = true;
        this.registerSetting(allowedTypes = new SliderSetting("Allowed types", EXACT, ALLOWED_TYPES));
        this.registerSetting(swapOnRmb = new ButtonSetting("Swap on RMB", true));
        this.registerSetting(syncStackSize = new ButtonSetting("Sync stack size", true));
        this.registerSetting(useBlockWhitelist = new ButtonSetting("Use block whitelist", false));
        this.registerSetting(blockWhitelist = new BlockListSetting("Whitelisted blocks", "Blocks", "Blocks.Block whitelist", "Blocks.Whitelisted blocks"));
        blockWhitelist.visible = false;
        this.closetModule = true;
        this.alwaysOn = true;
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Override
    public void guiUpdate() {
        blockWhitelist.setVisible(useBlockWhitelist.isToggled(), this);
    }

    @Override
    public void onEnable() {
        if (!scaffoldSwapEnabled()) {
            resetState();
        }
    }

    @Override
    public void onDisable() {
        if (!scaffoldSwapEnabled()) {
            resetState();
        }
    }

    @SubscribeEvent
    public void onSendPacket(SendPacketEvent e) {
        if ((!isEnabled() && !scaffoldSwapEnabled()) || !Utils.nullCheck()
            || !(e.getPacket() instanceof C08PacketPlayerBlockPlacement)) {
            return;
        }

        C08PacketPlayerBlockPlacement packet = (C08PacketPlayerBlockPlacement) e.getPacket();
        if (packet.getPlacedBlockDirection() == 255) {
            return;
        }

        ItemStack stack = packet.getStack();
        if (stack == null || !(stack.getItem() instanceof ItemBlock)) {
            return;
        }

        trackStack(stack, mc.thePlayer.inventory.currentItem);
    }

    private void trackStack(ItemStack stack, int slot) {
        boolean continuingStack = lastPlaceSlot == slot && isSameStack(stack, trackedStack);
        if (!continuingStack) {
            serverStackSize = -1;
        }

        trackedStack = stack.copy();
        trackedStack.stackSize = 1;
        lastPlaceSlot = slot;
    }

    @SubscribeEvent
    public void onReceivePacket(ReceivePacketEvent e) {
        if (!isEnabled() && !scaffoldSwapEnabled()) {
            return;
        }
        int hotbarSlot = lastPlaceSlot;
        if (hotbarSlot == -1) {
            return;
        }

        int inventorySlot = 36 + hotbarSlot;
        if (e.getPacket() instanceof S2FPacketSetSlot) {
            S2FPacketSetSlot packet = (S2FPacketSetSlot) e.getPacket();
            if (packet.func_149175_c() == 0 && packet.func_149173_d() == inventorySlot) {
                updateServerStackSize(packet.func_149174_e());
            }
        }
        else if (e.getPacket() instanceof S30PacketWindowItems) {
            S30PacketWindowItems packet = (S30PacketWindowItems) e.getPacket();
            ItemStack[] stacks = packet.getItemStacks();
            if (packet.func_148911_c() == 0 && inventorySlot < stacks.length) {
                updateServerStackSize(stacks[inventorySlot]);
            }
        }
    }

    @SubscribeEvent
    public void onPrePlayerInteract(PrePlayerInteractEvent e) {
        if (isEnabled() && !scaffoldSwapEnabled()) {
            trySwap(false);
        }
    }

    public boolean swapForScaffold() {
        return scaffoldSwapEnabled() && trySwap(true);
    }

    private boolean scaffoldSwapEnabled() {
        return Scaffold.instance != null && Scaffold.instance.isEnabled()
            && Scaffold.autoSwap != null && Scaffold.autoSwap.isToggled();
    }

    @SubscribeEvent
    public void onWorldUnload(WorldEvent.Unload e) {
        if (e.world == mc.theWorld) {
            resetState();
        }
    }

    private boolean trySwap(boolean scaffold) {
        if (!Utils.nullCheck()) {
            resetState();
            return false;
        }

        if (!mc.inGameHasFocus || mc.currentScreen != null
            || (swapOnRmb.isToggled() && !Utils.isBindDown(mc.gameSettings.keyBindUseItem))) {
            return false;
        }

        int currentSlot = mc.thePlayer.inventory.currentItem;
        ItemStack held = mc.thePlayer.getHeldItem();
        ItemStack reference;
        if (scaffold) {
            reference = held != null && held.getItem() instanceof ItemBlock ? held
                : held == null && currentSlot == lastPlaceSlot ? trackedStack : null;
            if (ItemUtils.isScaffoldBlock(held)) {
                trackStack(held, currentSlot);
            }
        } else {
            if (trackedStack == null || currentSlot != lastPlaceSlot
                || held != null && !isSameStack(held, trackedStack)) {
                return false;
            }
            reference = trackedStack;
        }

        boolean clientStackEmpty = held == null || held.stackSize <= 0;
        boolean serverStackEmpty = syncStackSize.isToggled()
            && !mc.playerController.isInCreativeMode()
            && currentSlot == lastPlaceSlot
            && isSameStack(reference, trackedStack)
            && serverStackSize == 0;
        if (!clientStackEmpty && !serverStackEmpty
            && (!scaffold || ItemUtils.isScaffoldBlock(held))) {
            return false;
        }

        if (reference != null && !isWhitelistedBlock(reference)) {
            return false;
        }

        long now = System.currentTimeMillis();
        for (int slot = 8; slot >= 0; --slot) {
            if (slot == currentSlot) {
                continue;
            }
            if (slot == lastSwapSlot && now - lastSwapTime < 300L) {
                continue;
            }

            ItemStack candidate = mc.thePlayer.inventory.getStackInSlot(slot);
            if (!matchesStack(candidate, reference)
                || reference == null && !isWhitelistedBlock(candidate)
                || scaffold && !ItemUtils.isScaffoldBlock(candidate)) {
                continue;
            }

            swapToSlot(slot);
            if (scaffold) {
                trackStack(candidate, slot);
            }
            lastSwapSlot = slot;
            lastSwapTime = now;
            return true;
        }
        return false;
    }

    private boolean isWhitelistedBlock(ItemStack stack) {
        if (!useBlockWhitelist.isToggled()) {
            return true;
        }

        if (stack == null || !(stack.getItem() instanceof ItemBlock)) {
            return false;
        }

        Block block = ((ItemBlock) stack.getItem()).getBlock();
        Object registryName = Block.blockRegistry.getNameForObject(block);
        if (block == null || registryName == null) {
            return false;
        }

        String registryId = registryName.toString();
        int meta = stack.getMetadata();
        String storageId = meta != 0 ? registryId + ":" + meta : registryId;
        return blockWhitelist.contains(storageId) || blockWhitelist.contains(registryId);
    }

    private boolean isSameStack(ItemStack first, ItemStack second) {
        return first != null && second != null
            && first.getItem() == second.getItem()
            && first.getMetadata() == second.getMetadata()
            && ItemStack.areItemStackTagsEqual(first, second);
    }

    private void updateServerStackSize(ItemStack stack) {
        serverStackSize = stack == null ? 0 : stack.stackSize;
    }

    private boolean matchesStack(ItemStack stack, ItemStack reference) {
        if (stack == null || stack.stackSize <= 0 || !(stack.getItem() instanceof ItemBlock)) {
            return false;
        }

        int allowedType = (int) allowedTypes.getInput();
        if (allowedType == EXACT || allowedType == VARIANTS) {
            if (reference == null) {
                return true;
            }
            if (stack.getItem() != reference.getItem()) {
                return false;
            }
            if (allowedType == EXACT && stack.getMetadata() != reference.getMetadata()) {
                return false;
            }
            return ItemStack.areItemStackTagsEqual(stack, reference);
        }

        Block block = ((ItemBlock) stack.getItem()).getBlock();
        if (block == null) {
            return false;
        }

        if (allowedType == FULL) {
            return block.isFullBlock();
        }

        return allowedType == ANY && !BlockUtils.isInteractable(block);
    }

    private void swapToSlot(int slot) {
        if (slot == -1 || slot == mc.thePlayer.inventory.currentItem) {
            return;
        }

        mc.thePlayer.inventory.currentItem = slot;
        ((IAccessorPlayerControllerMP) mc.playerController).callSyncCurrentPlayItem();
    }

    private void resetState() {
        trackedStack = null;
        lastPlaceSlot = -1;
        lastSwapSlot = -1;
        serverStackSize = -1;
        lastSwapTime = 0L;
    }
}
