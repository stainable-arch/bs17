package keystrokesmod.module.impl.combat;

import keystrokesmod.event.PreEntityVelocityEvent;
import keystrokesmod.event.PreUpdateEvent;
import keystrokesmod.module.Module;
import keystrokesmod.module.impl.player.Scaffold;
import keystrokesmod.module.setting.impl.ButtonSetting;
import keystrokesmod.module.setting.impl.SliderSetting;
import keystrokesmod.utility.Utils;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemSword;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.ReflectionHelper;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.Random;

public class AutoClicker extends Module {
    public static AutoClicker instance;
    public static SliderSetting minCps, maxCps, inventoryCps, blockHit, jitter;
    public static ButtonSetting leftClick, clickOnDamage, breakBlocks, weaponOnly, rightClick, blocksOnly;

    private static final Random RANDOM = new Random();
    private static long nextPress, nextRelease;
    private static long phaseEnd, extraEnd;
    private static boolean slowPhase;
    private static double slowFactor;
    private static double slowMin = 1.1, slowMax = 1.25;
    private static int extraMin = 50, extraMax = 90;
    private static int blockHitAcc = 100;
    private static boolean blockHitDown;
    private static boolean breaking;
    private static boolean paused;
    private static boolean inventoryClick;
    private static long lastVelocity;
    public static boolean firing;

    public AutoClicker() {
        super("Auto Clicker", category.combat, 0);
        instance = this;
        this.liteModule = true;
        this.registerSetting(minCps = new SliderSetting("Min CPS", 9.0, 1.0, 20.0, 0.5));
        this.registerSetting(maxCps = new SliderSetting("Max CPS", 13.0, 1.0, 20.0, 0.5));
        this.registerSetting(inventoryCps = new SliderSetting("Inventory CPS", 0.0, 0.0, 20.0, 1.0));
        this.registerSetting(blockHit = new SliderSetting("Block hit", "%", 0.0, 0.0, 100.0, 5.0));
        this.registerSetting(jitter = new SliderSetting("Jitter", 0.0, 0.0, 3.0, 0.1));
        this.registerSetting(leftClick = new ButtonSetting("Left click", true));
        this.registerSetting(clickOnDamage = new ButtonSetting("^ Click on damage", false));
        this.registerSetting(breakBlocks = new ButtonSetting("^ Break blocks", true));
        this.registerSetting(weaponOnly = new ButtonSetting("^ Weapon only", false));
        this.registerSetting(rightClick = new ButtonSetting("Right click", false));
        this.registerSetting(blocksOnly = new ButtonSetting("^ Blocks only", true));
        this.closetModule = true;
    }

    public static boolean clicking() {
        return nextPress > 0L;
    }

    public static boolean clickingLeft() {
        return clicking() && leftClick.isToggled() && Mouse.isButtonDown(0);
    }

    private static int randomInt(int a, int b) {
        return a + (int) ((double) (b - a + 1) * Math.random());
    }

    private static double randomBetween(double a, double b) {
        return a + RANDOM.nextDouble() * (b - a);
    }

    private static boolean notDefault(SliderSetting setting) {
        return setting.getInput() != 0.0;
    }

    @SubscribeEvent
    public void onPreUpdate(PreUpdateEvent e) {
        if (inventoryClick) {
            inventoryClick = false;
            if (mc.currentScreen != null) {
                clickScreen(mc.currentScreen);
            }
        }
    }

    private static void schedule(boolean inventory) {
        double cps;
        if (!inventory) {
            cps = randomBetween(minCps.getInput(), maxCps.getInput()) + randomBetween(-0.3, 0.4);
        } else {
            cps = inventoryCps.getInput() + randomBetween(-0.6, 0.8);
        }
        long now = System.currentTimeMillis();
        long delay = (int) Math.round(1000.0 / cps);
        if (now > phaseEnd) {
            if (slowPhase) {
                slowPhase = false;
            } else if (RANDOM.nextInt(100) >= 80) {
                slowPhase = true;
                slowFactor = randomBetween(slowMin, slowMax);
            }
            phaseEnd = now + (long) randomInt(700, 2200);
        }
        if (slowPhase) {
            delay = (long) ((double) delay * slowFactor);
        }
        if (now > extraEnd) {
            if (RANDOM.nextInt(100) >= 75) {
                delay += (long) randomInt(extraMin, extraMax);
            }
            extraEnd = now + (long) randomInt(700, 2200);
        }
        nextPress = now + delay;
        nextRelease = now + delay / 2L - (long) RANDOM.nextInt(10);
    }

    public static boolean fakeMouse(int button, boolean down) {
        boolean ok = true;
        try {
            MouseEvent e = new MouseEvent();
            Field fb = ReflectionHelper.findField(MouseEvent.class, "button");
            Field fs = ReflectionHelper.findField(MouseEvent.class, "buttonstate");
            fb.set(e, button);
            fs.set(e, down);
            firing = true;
            ok = !MinecraftForge.EVENT_BUS.post(e);
            firing = false;
            if (ok) {
                Field f = ReflectionHelper.findField(Mouse.class, "buttons");
                ByteBuffer buf = (ByteBuffer) f.get(null);
                if (button >= 0 && button < buf.limit()) {
                    buf.put(button, (byte) (down ? 1 : 0));
                }
            }
        } catch (IllegalAccessException ignored) {
        }
        return ok;
    }

    private static void click(int key, int button) {
        BlockPos pos;
        if (breakBlocks.isToggled() && button == 0 && mc.objectMouseOver != null && (pos = mc.objectMouseOver.getBlockPos()) != null) {
            Block block = mc.theWorld.getBlockState(pos).getBlock();
            if (block != Blocks.air && !(block instanceof BlockLiquid)) {
                breaking = true;
                KeyBinding.setKeyBindState(key, true);
                return;
            }
            if (breaking) {
                breaking = false;
                KeyBinding.setKeyBindState(key, false);
            }
        }
        if (notDefault(jitter)) {
            double d = jitter.getInput() * 0.45;
            mc.thePlayer.rotationYaw = RANDOM.nextBoolean() ? (float) ((double) mc.thePlayer.rotationYaw + (double) RANDOM.nextFloat() * d)
                    : (float) ((double) mc.thePlayer.rotationYaw - (double) RANDOM.nextFloat() * d);
            mc.thePlayer.rotationPitch = RANDOM.nextBoolean() ? (float) ((double) mc.thePlayer.rotationPitch + (double) RANDOM.nextFloat() * (d * 0.45))
                    : (float) ((double) mc.thePlayer.rotationPitch - (double) RANDOM.nextFloat() * (d * 0.45));
        }
        if (nextPress > 0L && nextRelease > 0L) {
            long now = System.currentTimeMillis();
            if (now > nextPress) {
                if (fakeMouse(button, true)) {
                    KeyBinding.setKeyBindState(key, true);
                    KeyBinding.onTick(key);
                    double d = blockHit.getInput();
                    if (button == 0 && d > 0.0 && Mouse.isButtonDown(1) && holdingSword()) {
                        blockHitAcc = (int) ((double) blockHitAcc + d);
                        if (blockHitAcc >= 100) {
                            blockHitAcc -= 100;
                            blockHitDown = true;
                            if (fakeMouse(1, true)) {
                                int use = mc.gameSettings.keyBindUseItem.getKeyCode();
                                KeyBinding.setKeyBindState(use, true);
                                KeyBinding.onTick(use);
                            }
                        }
                    }
                }
                schedule(false);
            } else if (nextRelease != 1L && now > nextRelease) {
                fakeMouse(button, false);
                KeyBinding.setKeyBindState(key, false);
                if (button == 0 && blockHitDown && holdingSword()) {
                    fakeMouse(1, false);
                    KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
                }
                nextRelease = 1L;
            }
        } else {
            schedule(false);
        }
    }

    private static boolean holdingSword() {
        return mc.thePlayer.getHeldItem() != null && mc.thePlayer.getHeldItem().getItem() instanceof ItemSword;
    }

    @Override
    public void onDisable() {
        reset();
        inventoryClick = false;
        breaking = false;
    }

    private static int mode() {
        if (KillAura.target != null || Scaffold.instance != null && Scaffold.instance.isEnabled()) {
            return -1;
        }
        boolean weapon = Utils.holdingWeapon();
        if (!weapon && mc.thePlayer.isEating()) {
            return -1;
        }
        return weapon ? 1 : 0;
    }

    public static void reset() {
        nextRelease = 0L;
        nextPress = 0L;
        paused = false;
        blockHitDown = false;
        blockHitAcc = 100;
    }

    @SubscribeEvent
    public void onKnockback(PreEntityVelocityEvent e) {
        if (!Utils.nullCheck() || e.packet.getEntityID() != mc.thePlayer.getEntityId()) {
            return;
        }
        long now = System.currentTimeMillis();
        if (clickOnDamage.isToggled() && clickingLeft() && now - lastVelocity > 250L && mc.objectMouseOver != null
                && mc.objectMouseOver.typeOfHit == MovingObjectPosition.MovingObjectType.ENTITY) {
            if (now < nextRelease) {
                nextRelease = 2L;
                nextPress = now + 20L;
            } else {
                nextPress = 2L;
            }
        }
        lastVelocity = now;
    }

    @SubscribeEvent
    public void onRenderTick(TickEvent.RenderTickEvent e) {
        if (e.phase != TickEvent.Phase.START || !Utils.nullCheck()) {
            return;
        }
        if (mc.currentScreen == null && mc.inGameHasFocus) {
            int n = mode();
            if (n == -1) {
                paused = true;
                return;
            }
            if (leftClick.isToggled() && Mouse.isButtonDown(0)) {
                if (n == 0) {
                    if (weaponOnly.isToggled()) {
                        paused = true;
                        return;
                    }
                } else if (!notDefault(blockHit) && mc.thePlayer.isBlocking()) {
                    paused = true;
                    return;
                }
                if (paused) {
                    paused = false;
                    nextRelease = 2L;
                    nextPress = 2L;
                }
                click(mc.gameSettings.keyBindAttack.getKeyCode(), 0);
            } else if (rightClick.isToggled() && Mouse.isButtonDown(1)) {
                if (blocksOnly.isToggled() && !(mc.thePlayer.getHeldItem() != null && mc.thePlayer.getHeldItem().getItem() instanceof ItemBlock)) {
                    return;
                }
                click(mc.gameSettings.keyBindUseItem.getKeyCode(), 1);
            } else {
                reset();
            }
        } else if (notDefault(inventoryCps) && (mc.currentScreen instanceof GuiInventory || mc.currentScreen instanceof GuiChest)) {
            if (Mouse.isButtonDown(0) && (Keyboard.isKeyDown(42) || Keyboard.isKeyDown(54))) {
                if (nextRelease == 0L || nextPress == 0L) {
                    schedule(true);
                } else if (System.currentTimeMillis() > nextPress) {
                    schedule(true);
                    inventoryClick = true;
                }
            } else {
                reset();
            }
        }
    }

    @Override
    public void guiUpdate() {
        if (minCps.getInput() > maxCps.getInput()) {
            maxCps.setValueRaw(minCps.getInput());
        }
        clickOnDamage.setVisible(leftClick.isToggled(), this);
        breakBlocks.setVisible(leftClick.isToggled(), this);
        weaponOnly.setVisible(leftClick.isToggled(), this);
        blocksOnly.setVisible(rightClick.isToggled(), this);
    }

    private static void clickScreen(GuiScreen gui) {
        int x = Mouse.getX() * gui.width / mc.displayWidth;
        int y = gui.height - Mouse.getY() * gui.height / mc.displayHeight - 1;
        try {
            Method m = ReflectionHelper.findMethod(GuiScreen.class, gui, new String[]{"mouseClicked", "func_73864_a"}, int.class, int.class, int.class);
            m.invoke(gui, x, y, 0);
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onEnable() {
        slowMin = randomBetween(1.09, 1.12);
        slowMax = randomBetween(1.22, 1.25);
        extraMin = randomInt(40, 50);
        extraMax = randomInt(85, 95);
    }
}
