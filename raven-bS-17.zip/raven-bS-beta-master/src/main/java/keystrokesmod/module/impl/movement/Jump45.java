package keystrokesmod.module.impl.movement;

import keystrokesmod.event.ClientLookEvent;
import keystrokesmod.event.NoEventPacketEvent;
import keystrokesmod.event.PreUpdateEvent;
import keystrokesmod.event.SendPacketEvent;
import keystrokesmod.helper.RotationHelper;
import keystrokesmod.module.Module;
import keystrokesmod.module.ModuleManager;
import keystrokesmod.module.impl.combat.KillAura;
import keystrokesmod.module.setting.impl.ButtonSetting;
import keystrokesmod.module.setting.impl.DescriptionSetting;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.util.MovingObjectPosition;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Jump45 extends Module {
    private final ButtonSetting flying;
    private final ButtonSetting holdingBlocks;
    private final ButtonSetting holdingBow;
    private final ButtonSetting holdingThrowable;
    private final ButtonSetting holdingRod;
    private final ButtonSetting inLiquid;
    private final ButtonSetting targeting;

    private boolean rotating;
    private float offset;
    private boolean sentInteraction;
    private boolean tracingPlayerRotations;
    private float mouseYaw;
    private float mousePitch;

    public Jump45() {
        super("45 Jump", category.movement);
        this.registerSetting(new DescriptionSetting("Disable while..."));
        this.registerSetting(flying = new ButtonSetting("Flying", false));
        this.registerSetting(holdingBlocks = new ButtonSetting("Holding blocks", true));
        this.registerSetting(holdingBow = new ButtonSetting("Holding bow", true));
        this.registerSetting(holdingThrowable = new ButtonSetting("Holding throwable", true));
        this.registerSetting(holdingRod = new ButtonSetting("Holding rod", true));
        this.registerSetting(inLiquid = new ButtonSetting("In liquid", false));
        this.registerSetting(targeting = new ButtonSetting("Targeting", true));
    }

    @Override
    public void onEnable() {
        reset();
    }

    @Override
    public void onDisable() {
        reset();
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onPreUpdate(PreUpdateEvent event) {
        RotationHelper rotations = RotationHelper.get();
        if (rotations.isActive() || !shouldRotate()) {
            rotating = false;
            return;
        }
        if (!rotating) {
            rotating = true;
            offset = 45.0F + (float) (-0.3F + (double) (0.3F - -0.3F) * Math.random());
        }
        rotations.setRotations(mc.thePlayer.rotationYaw + offset, mc.thePlayer.rotationPitch);
    }

    private boolean shouldRotate() {
        if (mc.thePlayer == null || mc.theWorld == null || mc.thePlayer.onGround || !mc.thePlayer.isSprinting()
                || sentInteraction) {
            return false;
        }
        float strafe = 0.0F;
        if (mc.gameSettings.keyBindLeft.isKeyDown()) {
            strafe += 1.0F;
        }
        if (mc.gameSettings.keyBindRight.isKeyDown()) {
            strafe -= 1.0F;
        }
        if (strafe != 0.0F || flying.isToggled() && mc.thePlayer.capabilities.isFlying
                || inLiquid.isToggled() && (mc.thePlayer.isInWater() || mc.thePlayer.isInLava())) {
            return false;
        }
        ItemStack stack = mc.thePlayer.getHeldItem();
        Item item = stack == null ? null : stack.getItem();
        if (item != null) {
            if (holdingBlocks.isToggled() && isScaffoldBlock(stack)
                    || holdingBow.isToggled() && item == Items.bow
                    || holdingThrowable.isToggled() && isThrowable(stack)
                    || holdingRod.isToggled() && item == Items.fishing_rod) {
                return false;
            }
        }
        return !targeting.isToggled() || !isTargeting();
    }

    private boolean isScaffoldBlock(ItemStack stack) {
        if (!(stack.getItem() instanceof ItemBlock)) {
            return false;
        }
        Block block = ((ItemBlock) stack.getItem()).getBlock();
        return (block == Blocks.glass || block.isFullBlock() && block != Blocks.gravel
                && block != Blocks.sand && block != Blocks.soul_sand && block != Blocks.tnt
                && block != Blocks.crafting_table && block != Blocks.furnace && block != Blocks.dispenser
                && block != Blocks.dropper && block != Blocks.noteblock && block != Blocks.command_block)
                && block != Blocks.pumpkin;
    }

    private boolean isThrowable(ItemStack stack) {
        Item item = stack.getItem();
        return item == Items.fire_charge || item == Items.ender_pearl || item == Items.ender_eye
                || item == Items.snowball || item == Items.egg || item == Items.experience_bottle
                || item == Items.nether_star || item == Items.potionitem && ItemPotion.isSplash(item.getMetadata(stack));
    }

    private boolean isTargeting() {
        return KillAura.target != null
                || ModuleManager.aimAssist != null && ModuleManager.aimAssist.isEnabled()
                && "Silent".equals(ModuleManager.aimAssist.getInfo())
                && ModuleManager.aimAssist.getAimAssistTarget() != null
                || mc.objectMouseOver != null && mc.objectMouseOver.entityHit != null;
    }

    @SubscribeEvent(priority = EventPriority.LOWEST, receiveCanceled = true)
    public void onSendPacket(SendPacketEvent event) {
        trackPacket(event.getPacket());
    }

    @SubscribeEvent
    public void onNoEventPacket(NoEventPacketEvent event) {
        trackPacket(event.getPacket());
    }

    private void trackPacket(Packet<?> packet) {
        if (packet instanceof C03PacketPlayer) {
            sentInteraction = false;
        } else if (packet instanceof C02PacketUseEntity || packet instanceof C08PacketPlayerBlockPlacement) {
            sentInteraction = true;
        } else if (packet instanceof C07PacketPlayerDigging) {
            C07PacketPlayerDigging.Action action = ((C07PacketPlayerDigging) packet).getStatus();
            if (action == C07PacketPlayerDigging.Action.START_DESTROY_BLOCK
                    || action == C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK
                    || action == C07PacketPlayerDigging.Action.ABORT_DESTROY_BLOCK) {
                sentInteraction = true;
            }
        }
    }

    @SubscribeEvent
    public void onMouse(MouseEvent event) {
        if (!rotating || !event.buttonstate || event.button != 0 && event.button != 1
                || mc.thePlayer == null || mc.entityRenderer == null) {
            return;
        }
        float previousHeadYaw = mc.thePlayer.rotationYawHead;
        mouseYaw = mc.thePlayer.rotationYaw;
        mousePitch = mc.thePlayer.rotationPitch;
        mc.thePlayer.rotationYawHead = mouseYaw;
        tracingPlayerRotations = true;
        try {
            mc.entityRenderer.getMouseOver(1.0F);
        } finally {
            tracingPlayerRotations = false;
            if (mc.objectMouseOver == null || mc.objectMouseOver.typeOfHit == MovingObjectPosition.MovingObjectType.MISS) {
                mc.thePlayer.rotationYawHead = previousHeadYaw;
            }
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onClientLook(ClientLookEvent event) {
        if (tracingPlayerRotations) {
            event.yaw = mouseYaw;
            event.pitch = mousePitch;
        }
    }

    @SubscribeEvent
    public void onEntityJoinWorld(EntityJoinWorldEvent event) {
        if (event.entity == mc.thePlayer) {
            reset();
        }
    }

    private void reset() {
        rotating = false;
        offset = 0.0F;
        sentInteraction = false;
        tracingPlayerRotations = false;
    }
}
