package keystrokesmod.module.impl.player;

import keystrokesmod.event.ClientRotationEvent;
import keystrokesmod.event.PreUpdateEvent;
import keystrokesmod.helper.RotationHelper;
import keystrokesmod.module.Module;
import keystrokesmod.module.setting.impl.ButtonSetting;
import keystrokesmod.module.setting.impl.SliderSetting;
import keystrokesmod.utility.BlockUtils;
import keystrokesmod.utility.RotationUtils;
import keystrokesmod.utility.Timer;
import keystrokesmod.utility.Utils;
import net.minecraft.block.Block;
import net.minecraft.block.BlockBed;
import net.minecraft.block.BlockLadder;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Mouse;

import java.awt.Color;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Set;

public class AutoBlockin extends Module {
    public static AutoBlockin instance;
    public static SliderSetting delay;
    public static ButtonSetting disableInCreative, disableObsidian, disableWhenComplete, onlyWhileMiddleClicking, prioritizeStrongerBlocks,
            showPercentage, silentAim, silentSwing, skipNearBed;

    private static final class Node {
        final BlockPos pos;
        final int score;
        final int cost;

        Node(BlockPos pos, int score, int cost) {
            this.pos = pos;
            this.score = score;
            this.cost = cost;
        }
    }

    private static final EnumFacing[] ORDER = {EnumFacing.NORTH, EnumFacing.SOUTH, EnumFacing.WEST, EnumFacing.EAST, EnumFacing.UP, EnumFacing.DOWN};
    private static final EnumFacing[] ORDER_UP = {EnumFacing.UP, EnumFacing.NORTH, EnumFacing.SOUTH, EnumFacing.WEST, EnumFacing.EAST, EnumFacing.DOWN};
    private static final BlockPos.MutableBlockPos MUTABLE = new BlockPos.MutableBlockPos();

    private boolean active;
    private String percentText;
    private int percentColor;
    private float percentHalfWidth;
    private long startedAt, stoppedAt;
    private boolean middleHeld;
    private boolean waitRelease;
    private int previousSlot = -1, blockSlot = -1;
    private BlockPos against;
    private EnumFacing face;
    private BlockPos targetPos;
    private List<BlockPos> path;
    private final Deque<BlockPos> retry = new ArrayDeque<BlockPos>();
    private final Set<BlockPos> retrySet = new HashSet<BlockPos>();
    private final Set<BlockPos> failed = new HashSet<BlockPos>();
    private EnumFacing[] facings;
    private float aimYaw, aimPitch;
    private boolean hasAim;
    private BlockPos hitAt;
    private EnumFacing hitSide;
    private Vec3 placeAt;
    private boolean placeQueued;
    private float smYaw, smPitch;

    public AutoBlockin() {
        super("AutoBlockin", category.player);
        instance = this;
        this.liteModule = true;
        this.registerSetting(delay = new SliderSetting("Delay", " tick", 0.0, 0.0, 10.0, 1.0));
        this.registerSetting(disableInCreative = new ButtonSetting("Disable in creative", true));
        this.registerSetting(disableObsidian = new ButtonSetting("Disable obsidian", false));
        this.registerSetting(disableWhenComplete = new ButtonSetting("Disable when complete", false));
        this.registerSetting(onlyWhileMiddleClicking = new ButtonSetting("Only while middle clicking", false));
        this.registerSetting(prioritizeStrongerBlocks = new ButtonSetting("Prioritize stronger blocks", false));
        this.registerSetting(showPercentage = new ButtonSetting("Show percentage", true));
        this.registerSetting(silentAim = new ButtonSetting("Silent aim", false));
        this.registerSetting(silentSwing = new ButtonSetting("Silent swing", false));
        this.registerSetting(skipNearBed = new ButtonSetting("Skip near bed", true));
        this.closetModule = true;
    }

    @Override
    public void onDisable() {
        stop();
        waitRelease = false;
    }

    private boolean blocked() {
        if (!Utils.nullCheck() || !mc.inGameHasFocus) {
            return true;
        }
        if (mc.currentScreen != null) {
            return true;
        }
        if (disableInCreative.isToggled() && mc.thePlayer.capabilities.isCreativeMode) {
            return true;
        }
        Scaffold scaffold = Scaffold.instance;
        return scaffold != null && scaffold.isEnabled();
    }

    private void tick() {
        if (blocked()) {
            if (middleHeld) {
                stop();
            } else if (active) {
                reset();
            }
            hasAim = false;
            return;
        }
        if (onlyWhileMiddleClicking.isToggled() && waitRelease) {
            if (Mouse.isButtonDown(2)) {
                hasAim = false;
                return;
            }
            waitRelease = false;
        }
        boolean run = !onlyWhileMiddleClicking.isToggled() || Mouse.isButtonDown(2);
        if (!run && middleHeld) {
            stop();
        }
        middleHeld = run;
        if (!run) {
            hasAim = false;
            return;
        }
        if (!active) {
            blockSlot = findSlot();
            if (blockSlot == -1) {
                hasAim = false;
                return;
            }
            previousSlot = mc.thePlayer.inventory.currentItem;
            mc.thePlayer.inventory.currentItem = blockSlot;
            active = true;
            startedAt = System.currentTimeMillis();
            captureFacings();
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
        }
        ItemStack held = mc.thePlayer.inventory.getStackInSlot(mc.thePlayer.inventory.currentItem);
        if (!usable(held)) {
            int n = findSlot();
            if (n == -1) {
                stop();
                hasAim = false;
                return;
            }
            blockSlot = n;
            mc.thePlayer.inventory.currentItem = blockSlot;
            held = mc.thePlayer.inventory.getStackInSlot(blockSlot);
        }
        failed.clear();
        if (!(hasTarget() || findTarget() || retryTarget())) {
            clearTarget();
            hasAim = false;
            return;
        }
        Vec3 point = BlockUtils.getFaceCenter(against, face);
        Vec3 eye = mc.thePlayer.getPositionEyes(1.0f);
        float[] rot = RotationUtils.getRotationsFromEye(eye, point.xCoord, point.yCoord, point.zCoord);
        if (!BlockUtils.canPlaceBlockOnSide(held, against, face)) {
            markFailed();
            clearTarget();
            hasAim = false;
            return;
        }
        aimYaw = rot[0];
        aimPitch = rot[1];
        hasAim = true;
    }

    private void applyRotation(float baseYaw, float basePitch) {
        if (!hasAim) {
            return;
        }
        int ticks = Math.max(1, (int) delay.getInput());
        float[] sm = RotationUtils.smoothRotation(baseYaw, basePitch, aimYaw, aimPitch, ticks);
        smYaw = sm[0];
        smPitch = sm[1];
        double reach = mc.playerController.getBlockReachDistance();
        MovingObjectPosition hit = RotationUtils.rayCastBlock(reach, smYaw, smPitch);
        if (hit != null) {
            BlockPos hitBlock = hit.getBlockPos();
            EnumFacing side = hit.sideHit;
            if (hitBlock.equals(against) && side == face) {
                hitAt = hitBlock;
                hitSide = side;
                placeAt = hit.hitVec;
                placeQueued = true;
            }
        }
        if (silentAim.isToggled()) {
            RotationHelper.get().forceMovementFix = true;
        } else {
            mc.thePlayer.rotationYaw = smYaw;
            mc.thePlayer.rotationPitch = smPitch;
        }
    }

    @SubscribeEvent
    public void onClientRotation(ClientRotationEvent e) {
        if (!silentAim.isToggled()) {
            return;
        }
        tick();
        float baseYaw = e.yaw != null ? e.yaw : RotationUtils.serverRotations[0];
        float basePitch = e.pitch != null ? e.pitch : RotationUtils.serverRotations[1];
        applyRotation(baseYaw, basePitch);
        if (hasAim) {
            e.setYaw(smYaw);
            e.setPitch(smPitch);
        }
    }

    @Override
    public void onUpdate() {
        if (silentAim.isToggled()) {
            return;
        }
        tick();
        applyRotation(mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch);
        updatePercent();
    }

    @SubscribeEvent
    public void onPreUpdate(PreUpdateEvent e) {
        if (!Utils.nullCheck()) {
            return;
        }
        if (silentAim.isToggled()) {
            updatePercent();
        }
        if (!placeQueued) {
            return;
        }
        placeQueued = false;
        if (hitAt == null || hitSide == null || placeAt == null) {
            return;
        }
        BlockPos placementPos = hitAt.offset(hitSide);
        if (isNearBed(placementPos)) {
            return;
        }
        if (mc.playerController.onPlayerRightClick(mc.thePlayer, mc.theWorld, mc.thePlayer.getHeldItem(), hitAt, hitSide, placeAt)) {
            if (silentSwing.isToggled()) {
                Utils.setSwinging();
            } else {
                mc.thePlayer.swingItem();
            }
            if (path != null && !path.isEmpty() && path.get(0).equals(targetPos)) {
                path.remove(0);
            }
            clearTarget();
        }
    }

    private void updatePercent() {
        if (!active) {
            return;
        }
        int x = MathHelper.floor_double(mc.thePlayer.posX);
        int y = MathHelper.floor_double(mc.thePlayer.posY);
        int z = MathHelper.floor_double(mc.thePlayer.posZ);
        float enclosed = enclosure(x, y, z);
        int percent = Math.round(enclosed * 100.0f);
        percentText = percent + "%";
        percentColor = percent != 100 ? -1 : Color.green.getRGB();
        percentHalfWidth = (float) mc.fontRendererObj.getStringWidth(percentText) / 2.0f - 2.0f;
        if (percent == 100 && disableWhenComplete.isToggled()) {
            if (!onlyWhileMiddleClicking.isToggled()) {
                this.setEnabled(false);
            } else {
                stop();
                waitRelease = true;
            }
        }
    }

    @SubscribeEvent
    public void onMouse(MouseEvent e) {
        if (e.buttonstate && e.button != 0 && active) {
            e.setCanceled(true);
        }
    }

    @SubscribeEvent
    public void onRenderTick(TickEvent.RenderTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !Utils.nullCheck()) {
            return;
        }
        if (!showPercentage.isToggled() || percentText == null) {
            return;
        }
        long now = System.currentTimeMillis();
        int a;
        long age;
        if (!active) {
            age = now - stoppedAt;
            if (age >= 125L) {
                a = 0;
                percentText = null;
            } else {
                a = (int) (240.0f - (float) age / 125.0f * 240.0f);
            }
        } else {
            age = now - startedAt;
            a = age >= 125L ? 240 : (int) ((float) age / 125.0f * 240.0f);
        }
        if (a > 0) {
            ScaledResolution sr = new ScaledResolution(mc);
            float x = (float) sr.getScaledWidth() / 2.0f - percentHalfWidth;
            float y = (float) sr.getScaledHeight() / 2.0f + 11.0f;
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            mc.fontRendererObj.drawString(percentText, x, y, Utils.mergeAlpha(percentColor, Math.max(5, Math.min(255, a))), true);
            GlStateManager.disableBlend();
        }
    }

    private void stop() {
        if (previousSlot >= 0 && previousSlot < 9) {
            mc.thePlayer.inventory.currentItem = previousSlot;
        }
        reset();
    }

    private void reset() {
        if (active) {
            active = false;
            stoppedAt = System.currentTimeMillis();
        }
        middleHeld = false;
        previousSlot = -1;
        blockSlot = -1;
        path = null;
        retry.clear();
        retrySet.clear();
        failed.clear();
        clearTarget();
        facings = null;
    }

    private void clearTarget() {
        against = null;
        face = null;
        targetPos = null;
    }

    private void captureFacings() {
        EnumFacing f = mc.thePlayer.getHorizontalFacing();
        facings = new EnumFacing[]{f, f.rotateY(), f.getOpposite(), f.rotateYCCW()};
    }

    private EnumFacing[] facings() {
        return facings != null ? facings : new EnumFacing[]{EnumFacing.EAST, EnumFacing.WEST, EnumFacing.NORTH, EnumFacing.SOUTH};
    }

    private int findSlot() {
        int slot = -1;
        int most = 0;
        float best = -1.0f;
        for (int i = 0; i < 9; ++i) {
            ItemStack stack = mc.thePlayer.inventory.getStackInSlot(i);
            if (!usable(stack)) {
                continue;
            }
            Block block = ((ItemBlock) stack.getItem()).getBlock();
            int size = stack.stackSize;
            if (prioritizeStrongerBlocks.isToggled()) {
                float f = BlockUtils.getFistBreakTicks(block);
                if (f < 0.0f) {
                    continue;
                }
                if (!(f > best || f == best && size > most)) {
                    continue;
                }
                best = f;
                most = size;
                slot = i;
                continue;
            }
            if (size <= most) {
                continue;
            }
            most = size;
            slot = i;
        }
        return slot;
    }

    private boolean usable(ItemStack stack) {
        if (stack == null || !(stack.getItem() instanceof ItemBlock)) {
            return false;
        }
        Block block = ((ItemBlock) stack.getItem()).getBlock();
        if (block instanceof BlockLadder) {
            return false;
        }
        if (block == Blocks.pumpkin || disableObsidian.isToggled() && block == Blocks.obsidian) {
            return false;
        }
        return stack.stackSize > 0;
    }

    private boolean isSupport(Block block) {
        return BlockUtils.isNormalBlock(block);
    }

    private boolean isSupport(BlockPos pos) {
        return isSupport(BlockUtils.getBlock(pos));
    }

    private BlockPos playerPos() {
        return new BlockPos(MathHelper.floor_double(mc.thePlayer.posX), MathHelper.floor_double(mc.thePlayer.posY), MathHelper.floor_double(mc.thePlayer.posZ));
    }

    private boolean isPlayerBlock(BlockPos pos) {
        BlockPos own = playerPos();
        return pos.equals(own) || pos.equals(own.up());
    }

    private boolean hasSupport(BlockPos pos) {
        for (EnumFacing f : EnumFacing.VALUES) {
            if (isSupport(pos.offset(f))) {
                return true;
            }
        }
        return false;
    }

    private boolean skip(BlockPos pos) {
        return failed.contains(pos) || isPlayerBlock(pos) || skipNearBed.isToggled() && BlockUtils.isAdjacentToBed(pos);
    }

    private boolean isNearBed(BlockPos pos) {
        if (!skipNearBed.isToggled()) {
            return false;
        }
        return BlockUtils.getBlock(pos) instanceof BlockBed || BlockUtils.isAdjacentToBed(pos);
    }

    private boolean hasTarget() {
        return against != null && face != null && targetPos != null && !isPlayerBlock(targetPos) && BlockUtils.replaceable(targetPos);
    }

    private void markFailed() {
        if (targetPos == null) {
            return;
        }
        failed.add(targetPos);
        if (path != null && !path.isEmpty() && targetPos.equals(path.get(0))) {
            path = null;
        }
        if (!retrySet.contains(targetPos) && !isPlayerBlock(targetPos)) {
            addRetry(targetPos);
        }
    }

    private void addRetry(BlockPos pos) {
        if (retry.size() >= 3) {
            BlockPos old = retry.pollFirst();
            if (old != null) {
                retrySet.remove(old);
            }
        }
        retry.addLast(pos);
        retrySet.add(pos);
    }

    private boolean retryTarget() {
        int n = retry.size();
        while (n-- > 0 && !retry.isEmpty()) {
            BlockPos pos = retry.pollFirst();
            if (pos == null) {
                continue;
            }
            if (skip(pos) || !BlockUtils.replaceable(pos)) {
                retrySet.remove(pos);
                continue;
            }
            if (findSupport(pos)) {
                retrySet.remove(pos);
                return true;
            }
            retry.addLast(pos);
        }
        return false;
    }

    private boolean findTarget() {
        BlockPos own = playerPos();
        BlockPos roof = own.up(2);
        if (path != null && !path.isEmpty()) {
            while (!path.isEmpty() && (retrySet.contains(path.get(0)) || isPlayerBlock(path.get(0)))) {
                path.remove(0);
            }
            BlockPos next;
            if (!path.isEmpty() && !skip(next = path.get(0)) && findSupport(next)) {
                return true;
            }
        }
        if (BlockUtils.replaceable(roof) && hasSupport(roof) && !skip(roof) && findSupport(roof)) {
            return true;
        }
        List<BlockPos> list;
        BlockPos next;
        if (BlockUtils.replaceable(roof) && (list = findPath(roof, own, 8, -2, 6)) != null && !list.isEmpty()) {
            path = list;
            while (!path.isEmpty() && isPlayerBlock(path.get(0))) {
                path.remove(0);
            }
            if (!path.isEmpty() && !skip(next = path.get(0)) && findSupport(next)) {
                return true;
            }
        }
        for (EnumFacing facing : facings()) {
            BlockPos below = own.down().offset(facing);
            BlockPos feet = own.offset(facing);
            BlockPos head = feet.up();
            if (BlockUtils.replaceable(below)) {
                if (hasSupport(below)) {
                    if (!skip(below) && findSupportUp(below)) {
                        return true;
                    }
                } else {
                    list = findPath(below, own, 4, -6, 0);
                    if (list != null && !list.isEmpty()) {
                        path = list;
                        while (!path.isEmpty() && isPlayerBlock(path.get(0))) {
                            path.remove(0);
                        }
                        if (!path.isEmpty() && !skip(next = path.get(0)) && findSupport(next)) {
                            return true;
                        }
                    }
                }
            }
            if (BlockUtils.replaceable(feet)) {
                if (!skip(feet) && findSupportBeside(feet, own, facing)) {
                    return true;
                }
                if (!hasSupport(feet)) {
                    list = findPath(feet, own, 4, -3, 1);
                    if (list != null && !list.isEmpty()) {
                        path = list;
                        while (!path.isEmpty() && isPlayerBlock(path.get(0))) {
                            path.remove(0);
                        }
                        if (!path.isEmpty() && !skip(next = path.get(0)) && findSupport(next)) {
                            return true;
                        }
                    }
                } else if (!skip(feet) && findSupport(feet, ORDER)) {
                    return true;
                }
            }
            if (!BlockUtils.replaceable(head)) {
                continue;
            }
            if (hasSupport(head)) {
                if (skip(head) || !findSupport(head, ORDER)) {
                    continue;
                }
                return true;
            }
            list = findPath(head, own, 4, -2, 2);
            if (list == null || list.isEmpty()) {
                continue;
            }
            path = list;
            while (!path.isEmpty() && isPlayerBlock(path.get(0))) {
                path.remove(0);
            }
            if (path.isEmpty() || skip(next = path.get(0)) || !findSupport(next)) {
                continue;
            }
            return true;
        }
        return BlockUtils.replaceable(roof) && hasSupport(roof) && !skip(roof) && findSupport(roof);
    }

    private boolean findSupport(BlockPos pos) {
        BlockPos own = playerPos();
        if (pos.equals(own.north()) || pos.equals(own.south())) {
            return false;
        }
        BlockPos below = own.down();
        if (pos.equals(below.east()) || pos.equals(below.west()) || pos.equals(below.north()) || pos.equals(below.south())) {
            return findSupportUp(pos);
        }
        return findSupport(pos, ORDER);
    }

    private boolean findSupportUp(BlockPos pos) {
        return !isPlayerBlock(pos) && findSupport(pos, ORDER_UP);
    }

    private boolean findSupport(BlockPos pos, EnumFacing[] order) {
        if (isPlayerBlock(pos)) {
            return false;
        }
        for (EnumFacing f : order) {
            BlockPos n = pos.offset(f.getOpposite());
            if (isSupport(n)) {
                against = n;
                face = f;
                targetPos = pos;
                return true;
            }
        }
        return false;
    }

    private boolean findSupportBeside(BlockPos pos, BlockPos own, EnumFacing facing) {
        if (isPlayerBlock(pos)) {
            return false;
        }
        if (pos.getY() == own.getY()) {
            if (isSupport(own)) {
                against = own;
                face = facing;
                targetPos = pos;
                return true;
            }
            BlockPos below = pos.down();
            if (isSupport(below)) {
                against = below;
                face = EnumFacing.UP;
                targetPos = pos;
                return true;
            }
        }
        return findSupport(pos, ORDER);
    }

    private List<BlockPos> findPath(BlockPos pos, BlockPos own, int r, int minY, int maxY) {
        HashSet<BlockPos> solids = new HashSet<BlockPos>();
        HashSet<BlockPos> open = new HashSet<BlockPos>();
        for (int y = minY; y <= maxY; y++) {
            for (int x = -r; x <= r; x++) {
                for (int z = -r; z <= r; z++) {
                    BlockPos p = own.add(x, y, z);
                    if (isSupport(p)) {
                        solids.add(p);
                    } else if (BlockUtils.replaceable(p)) {
                        open.add(p);
                    }
                }
            }
        }
        if (open.isEmpty()) {
            return null;
        }
        for (EnumFacing f : EnumFacing.VALUES) {
            if (solids.contains(pos.offset(f.getOpposite()))) {
                return null;
            }
        }
        ArrayList<BlockPos> starts = new ArrayList<BlockPos>();
        for (EnumFacing f : EnumFacing.VALUES) {
            BlockPos n = own.offset(f);
            if (open.contains(n)) {
                starts.add(n);
            }
        }
        if (starts.isEmpty() && open.contains(own)) {
            starts.add(own);
        }
        if (starts.isEmpty()) {
            return null;
        }
        HashSet<BlockPos> goals = new HashSet<BlockPos>();
        for (EnumFacing f : EnumFacing.VALUES) {
            BlockPos p = pos.offset(f.getOpposite());
            if (open.contains(p) && !retrySet.contains(p)) {
                goals.add(p);
            }
        }
        if (goals.isEmpty()) {
            return null;
        }
        int size = open.size();
        int limit = Math.min(8000, Math.max(500, size * 2));
        PriorityQueue<Node> queue = new PriorityQueue<Node>(new Comparator<Node>() {
            public int compare(Node a, Node b) {
                return a.score - b.score;
            }
        });
        HashMap<BlockPos, Integer> cost = new HashMap<BlockPos, Integer>(size);
        HashMap<BlockPos, BlockPos> parent = new HashMap<BlockPos, BlockPos>(size);
        for (BlockPos p : starts) {
            int h = nearestDistance(p, goals);
            cost.put(p, 0);
            queue.add(new Node(p, h, 0));
            parent.put(p, null);
        }
        HashSet<BlockPos> closed = new HashSet<BlockPos>();
        int visited = 0;
        BlockPos found = null;
        while (!queue.isEmpty()) {
            Node node = queue.poll();
            BlockPos p = node.pos;
            if (closed.contains(p)) {
                continue;
            }
            closed.add(p);
            if (goals.contains(p)) {
                found = p;
                break;
            }
            if (++visited > limit) {
                break;
            }
            int c = cost.get(p);
            for (EnumFacing f : EnumFacing.VALUES) {
                BlockPos n = p.offset(f);
                if (!open.contains(n) || closed.contains(n)) {
                    continue;
                }
                int step = 1 + (p.getY() != n.getY() ? 1 : 0);
                int nc = c + step;
                Integer old = cost.get(n);
                if (old == null || nc < old) {
                    cost.put(n, nc);
                    parent.put(n, p);
                    int h = nearestDistance(n, goals);
                    queue.add(new Node(n, nc + h, nc));
                }
            }
        }
        if (found == null) {
            return null;
        }
        ArrayList<BlockPos> route = new ArrayList<BlockPos>();
        for (BlockPos p = found; p != null; p = parent.get(p)) {
            route.add(p);
        }
        Collections.reverse(route);
        ArrayList<BlockPos> out = new ArrayList<BlockPos>();
        for (BlockPos p : route) {
            if (!isSupport(p) && !isPlayerBlock(p)) {
                out.add(p);
            }
        }
        return out;
    }

    private int nearestDistance(BlockPos pos, Set<BlockPos> goals) {
        int best = Integer.MAX_VALUE;
        for (BlockPos g : goals) {
            int d = Math.abs(pos.getX() - g.getX()) + Math.abs(pos.getY() - g.getY()) + Math.abs(pos.getZ() - g.getZ());
            if (d < best) {
                best = d;
            }
        }
        return best;
    }

    private float enclosure(int x, int y, int z) {
        int n = 0;
        if (solid(x, y + 2, z)) ++n;
        if (solid(x + 1, y, z)) ++n;
        if (solid(x - 1, y, z)) ++n;
        if (solid(x, y, z + 1)) ++n;
        if (solid(x, y, z - 1)) ++n;
        if (solid(x + 1, y + 1, z)) ++n;
        if (solid(x - 1, y + 1, z)) ++n;
        if (solid(x, y + 1, z + 1)) ++n;
        if (solid(x, y + 1, z - 1)) ++n;
        return (float) n / 9.0f;
    }

    private boolean solid(int x, int y, int z) {
        MUTABLE.set(x, y, z);
        return isSupport(BlockUtils.getBlock(MUTABLE));
    }
}
