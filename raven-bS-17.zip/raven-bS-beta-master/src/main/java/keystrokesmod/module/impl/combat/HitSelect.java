package keystrokesmod.module.impl.combat;

import keystrokesmod.event.PreEntityVelocityEvent;
import keystrokesmod.event.ReceivePacketEvent;
import keystrokesmod.event.SendPacketEvent;
import keystrokesmod.module.Module;
import keystrokesmod.module.setting.impl.ButtonSetting;
import keystrokesmod.module.setting.impl.SliderSetting;
import keystrokesmod.utility.Utils;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.network.play.server.S19PacketEntityStatus;
import net.minecraft.potion.Potion;
import net.minecraft.util.MovingObjectPosition;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.HashMap;

public class HitSelect extends Module {
    public static HitSelect instance;
    public static SliderSetting pause, onlyInCombo;
    public static ButtonSetting disableOnLowHealth, fakeSwing, forceFirstHit, onlyCriticalHits, onlyWhileJumping, resetComboOnSwap,
            resetOnDamage, manual, autoClicker, killAura;
    private static int combo;
    private static int lastTarget;
    private static long lastAttack, damagedAt;
    private static final HashMap<Integer, Long> firstHits = new HashMap<Integer, Long>();
    private static final HashMap<Integer, Long> lastHitTimes = new HashMap<Integer, Long>();

    public HitSelect() {
        super("Hit Select", category.combat);
        instance = this;
        this.liteModule = true;
        this.registerSetting(pause = new SliderSetting("Pause", "ms", 300.0, 0.0, 500.0, 50.0));
        this.registerSetting(onlyInCombo = new SliderSetting("Only in combo", 0.0, 0.0, 10.0, 1.0));
        this.registerSetting(disableOnLowHealth = new ButtonSetting("Disable on low health", false));
        this.registerSetting(fakeSwing = new ButtonSetting("Fake swing", false));
        this.registerSetting(forceFirstHit = new ButtonSetting("Force first hit", false));
        this.registerSetting(onlyCriticalHits = new ButtonSetting("Only critical hits", false));
        this.registerSetting(onlyWhileJumping = new ButtonSetting("Only while jumping", false));
        this.registerSetting(resetComboOnSwap = new ButtonSetting("Reset combo on swap", false));
        this.registerSetting(resetOnDamage = new ButtonSetting("Reset on damage", false));
        this.registerSetting(manual = new ButtonSetting("Manual", true));
        this.registerSetting(autoClicker = new ButtonSetting("AutoClicker", true));
        this.registerSetting(killAura = new ButtonSetting("KillAura", false));
        this.closetModule = true;
    }

    public static boolean on() {
        return instance != null && instance.isEnabled();
    }

    private static boolean atMin(SliderSetting setting) {
        return setting.getInput() <= setting.getMin();
    }

    @SubscribeEvent
    public void onSendPacket(SendPacketEvent e) {
        if (e.getPacket() instanceof C09PacketHeldItemChange) {
            onHeldItemChange();
        } else if (e.getPacket() instanceof C02PacketUseEntity) {
            onUseEntity((C02PacketUseEntity) e.getPacket());
        }
    }

    public static void onUseEntity(C02PacketUseEntity p) {
        if (p.getAction() != C02PacketUseEntity.Action.ATTACK || !Utils.nullCheck()) {
            return;
        }
        Entity e = p.getEntityFromWorld(mc.theWorld);
        if (e == null) {
            return;
        }
        long now = System.currentTimeMillis();
        int id = e.getEntityId();
        boolean rapidSwing = lastTarget == id && lastAttack != 0L && now - lastAttack < 750L;
        if (!rapidSwing && !atMin(onlyInCombo) && lastTarget == id && lastAttack != 0L && now - lastAttack >= 400L && now - lastAttack < 1250L) {
            ++combo;
        }
        lastTarget = id;
        lastAttack = now;
        lastHitTimes.put(id, now);
    }

    @SubscribeEvent
    public void onMouse(MouseEvent e) {
        if (e.button != 0 || !e.buttonstate) {
            return;
        }
        if (!autoClicker.isToggled() && AutoClicker.clicking()) {
            return;
        }
        if (!manual.isToggled()) {
            return;
        }
        if (!Utils.nullCheck() || mc.objectMouseOver == null || mc.objectMouseOver.typeOfHit != MovingObjectPosition.MovingObjectType.ENTITY) {
            return;
        }
        if (hold(mc.objectMouseOver.entityHit)) {
            e.setCanceled(true);
        }
    }

    public static boolean holdForKillAura(Entity e) {
        return killAura != null && killAura.isToggled() && hold(e);
    }

    @SubscribeEvent
    public void onReceivePacket(ReceivePacketEvent e) {
        if (!(e.getPacket() instanceof S19PacketEntityStatus) || !Utils.nullCheck()) {
            return;
        }
        S19PacketEntityStatus p = (S19PacketEntityStatus) e.getPacket();
        Entity entity;
        if (!atMin(onlyInCombo) && p.getOpCode() == 2 && Math.abs(System.currentTimeMillis() - lastAttack) < 750L
                && (entity = p.getEntity(mc.theWorld)) != null && entity.getEntityId() == lastTarget) {
            ++combo;
            lastHitTimes.put(entity.getEntityId(), System.currentTimeMillis());
        }
    }

    public static boolean hold(Entity entity) {
        if (!(on() && entity instanceof EntityLivingBase) || !Utils.nullCheck()) {
            return false;
        }
        if (disableOnLowHealth.isToggled() && !mc.thePlayer.capabilities.isCreativeMode && mc.thePlayer.getHealth() <= 4.0f) {
            return false;
        }
        if (!atMin(onlyInCombo) && combo < (int) onlyInCombo.getInput()) {
            return false;
        }
        if (onlyWhileJumping.isToggled() && !GameSettings.isKeyDown(mc.gameSettings.keyBindJump)) {
            return false;
        }
        if (damagedAt != 0L && Math.abs(System.currentTimeMillis() - damagedAt) < 170L) {
            return false;
        }
        boolean hold = shouldHold((EntityLivingBase) entity);
        if (hold && forceFirstHit.isToggled()) {
            long now = System.currentTimeMillis();
            Long t = firstHits.get(entity.getEntityId());
            if (t == null || now - t > 10000L) {
                hold = false;
            }
            firstHits.put(entity.getEntityId(), now);
        }
        if (hold && fakeSwing.isToggled()) {
            Utils.setSwinging();
        }
        return hold;
    }

    @SubscribeEvent
    public void onJoin(EntityJoinWorldEvent e) {
        if (e.entity == mc.thePlayer) {
            combo = 0;
            firstHits.clear();
            lastHitTimes.clear();
        }
    }

    @Override
    public void onUpdate() {
        if (combo > 0 && Math.abs(System.currentTimeMillis() - lastAttack) > 1250L) {
            combo = 0;
        }
        if (!lastHitTimes.isEmpty() && lastAttack != 0L && Math.abs(System.currentTimeMillis() - lastAttack) > 3000L) {
            lastHitTimes.clear();
        }
    }

    private static void onHeldItemChange() {
        if (resetComboOnSwap.isToggled()) {
            combo = 0;
        }
    }

    private static boolean shouldHold(EntityLivingBase e) {
        int hurtLimit = 10 - (int) pause.getInput() / 50;
        if (!atMin(pause)) {
            if (e.hurtTime > hurtLimit) {
                return true;
            }
            Long t = lastHitTimes.get(e.getEntityId());
            if (t != null) {
                long elapsed = System.currentTimeMillis() - t;
                long window = Math.max(50L, (10L - (long) hurtLimit) * 50L);
                if (elapsed >= 0L && elapsed < window) {
                    return true;
                }
            }
        }
        return !(!onlyCriticalHits.isToggled() || mc.thePlayer.onGround || mc.thePlayer.fallDistance != 0.0f || mc.thePlayer.isInWater()
                || mc.thePlayer.ridingEntity != null || mc.thePlayer.isPotionActive(Potion.blindness) || mc.thePlayer.isOnLadder());
    }

    @Override
    public void onDisable() {
        combo = 0;
        damagedAt = 0L;
        firstHits.clear();
        lastHitTimes.clear();
    }

    @SubscribeEvent
    public void onKnockback(PreEntityVelocityEvent e) {
        if (!Utils.nullCheck() || e.packet.getEntityID() != mc.thePlayer.getEntityId()) {
            return;
        }
        combo = 0;
        if (resetOnDamage.isToggled()) {
            damagedAt = System.currentTimeMillis();
        }
    }
}
