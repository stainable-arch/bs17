package keystrokesmod.module.impl.network;

import keystrokesmod.clickgui.ClickGui;
import keystrokesmod.event.ReceivePacketEvent;
import keystrokesmod.helper.RotationHelper;
import keystrokesmod.module.Module;
import keystrokesmod.module.ModuleManager;
import keystrokesmod.module.impl.client.Settings;
import keystrokesmod.module.impl.combat.KillAura;
import keystrokesmod.module.impl.world.AntiBot;
import keystrokesmod.module.setting.impl.ButtonSetting;
import keystrokesmod.module.setting.impl.ColorSetting;
import keystrokesmod.module.setting.impl.DescriptionSetting;
import keystrokesmod.module.setting.impl.SliderSetting;
import keystrokesmod.utility.RotationUtils;
import keystrokesmod.utility.Utils;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.Packet;
import net.minecraft.network.ThreadQuickExitException;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.network.play.server.*;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Backtrack extends Module { // OpenB4-aligned logic
    private final SliderSetting delay;
    private final SliderSetting distanceMin;
    private final SliderSetting distanceMax;
    private final SliderSetting cooldown;
    private final SliderSetting fov;
    private final ButtonSetting disableAdventure;
    private final ButtonSetting disableWhileChasing;
    private final ButtonSetting flushOnDamage;
    private final ButtonSetting ignoreTeammates;
    private final ButtonSetting showServerPosition;
    private final ButtonSetting onlyHittable;
    private final ButtonSetting onlyMovement;
    private final ButtonSetting weaponOnly;
    private final ColorSetting positionColor;

    private final TreeMap<Integer, List<Packet<?>>> held = new TreeMap<>();
    private final Object packetLock = new Object();
    private int tick;
    private volatile int delayTicks;
    private volatile boolean holding;
    private volatile boolean ready;
    private volatile EntityLivingBase target;
    private volatile Vec3 serverPos;
    private volatile EntityOtherPlayerMP ghost;
    private volatile Packet<?> processing;
    private volatile long lastFlush;
    private double minRange;
    private double maxRange;
    private double maxRangeSq;
    private double scanRangeSq;

    public Backtrack() {
        super("Backtrack", category.network);
        this.liteModule = true;
        this.registerSetting(new DescriptionSetting("Attack previous positions."));
        this.registerSetting(delay = new SliderSetting("Delay", "ms", 150.0, 50.0, 1500.0, 50.0));
        this.registerSetting(distanceMin = new SliderSetting("Distance (min)", 2.7, 0.0, 8.0, 0.1));
        this.registerSetting(distanceMax = new SliderSetting("Distance (max)", 5.0, 2.0, 8.0, 0.1));
        this.registerSetting(cooldown = new SliderSetting("Cooldown", "s", "&cDisabled", 0.0, 0.0, 8.0, 0.1));
        this.registerSetting(fov = new SliderSetting("FOV", 360.0, 20.0, 360.0, 5.0));
        this.registerSetting(disableAdventure = new ButtonSetting("Disable adventure", true));
        this.registerSetting(disableWhileChasing = new ButtonSetting("Disable while chasing", false));
        this.registerSetting(flushOnDamage = new ButtonSetting("Flush on damage", true));
        this.registerSetting(ignoreTeammates = new ButtonSetting("Ignore teammates", true));
        this.registerSetting(showServerPosition = new ButtonSetting("Show server position", false));
        this.registerSetting(onlyHittable = new ButtonSetting("Only hittable", false));
        this.registerSetting(onlyMovement = new ButtonSetting("Only movement", false));
        this.registerSetting(weaponOnly = new ButtonSetting("Weapon only", false));
        this.registerSetting(positionColor = new ColorSetting("Position color", 0, 0, 250, 100));
        guiUpdate();
    }

    private boolean canStart() {
        if (ModuleManager.freeze != null && ModuleManager.freeze.isFrozen()
                || ModuleManager.knockbackDelay != null && ModuleManager.knockbackDelay.isDelayingPackets()) {
            return false;
        }
        return cooldown.getInput() == 0.0
                || Math.abs(System.currentTimeMillis() - lastFlush) > cooldown.getInput() * 1000.0 - 20.0;
    }

    private void start() {
        delayTicks = Math.max(1, (int) delay.getInput() / 50);
        updateServerPos();
        holding = true;
        if (showServerPosition.isToggled()) {
            makeGhost(target);
        }
    }

    @Override
    public void onEnable() {
        guiUpdate();
    }

    @Override
    public void onDisable() {
        flush();
    }

    @Override
    public String getInfo() {
        return (int) delay.getInput() + "ms";
    }

    private boolean passesThrough(Packet<?> packet) {
        return packet instanceof S02PacketChat || packet instanceof S06PacketUpdateHealth
                || packet instanceof S14PacketEntity.S16PacketEntityLook || packet instanceof S19PacketEntityStatus
                || packet instanceof S22PacketMultiBlockChange || packet instanceof S23PacketBlockChange
                || packet instanceof S29PacketSoundEffect || packet instanceof S2APacketParticles
                || packet instanceof S3BPacketScoreboardObjective || packet instanceof S3CPacketUpdateScore
                || packet instanceof S3DPacketDisplayScoreboard || packet instanceof S3EPacketTeams;
    }

    public void flush() {
        List<Packet<?>> packets = new ArrayList<>();
        synchronized (packetLock) {
            for (List<Packet<?>> list : held.values()) {
                packets.addAll(list);
            }
            held.clear();
            reset();
        }
        process(packets);
    }

    private boolean valid(EntityLivingBase entity) {
        if (onlyHittable.isToggled() && entity.hurtTime > Settings.hittableHurtTime.getInput()) {
            return false;
        }
        if (!disableWhileChasing.isToggled() || mc.thePlayer.getDistanceSqToEntity(entity) <= 1.0) {
            return true;
        }
        float yaw = (float) (-Math.atan2(mc.thePlayer.posX - entity.posX, mc.thePlayer.posZ - entity.posZ)
                * (double) 57.29578f);
        return Math.abs(MathHelper.wrapAngleTo180_double(yaw - entity.rotationYaw)) <= 90.0;
    }

    @Override
    public void guiUpdate() {
        Utils.correctValue(distanceMin, distanceMax);
        minRange = distanceMin.getInput();
        maxRange = distanceMax.getInput();
        double range = maxRange + 1.2;
        double scanRange = maxRange + 2.5;
        maxRangeSq = range * range;
        scanRangeSq = scanRange * scanRange;
    }

    private void reset() {
        ready = false;
        holding = false;
        ghost = null;
        target = null;
        tick = 0;
        lastFlush = System.currentTimeMillis();
    }

    private boolean targetValid() {
        if (!Utils.nullCheck() || mc.isSingleplayer()) {
            return false;
        }
        if (target == null || mc.theWorld.getEntityByID(target.getEntityId()) == null || target.deathTime != 0) {
            return false;
        }
        if (mc.currentScreen != null && !(mc.currentScreen instanceof ClickGui)) {
            return false;
        }
        if (mc.thePlayer.capabilities.allowFlying
                || disableAdventure.isToggled() && mc.playerController.getCurrentGameType().isAdventure()) {
            return false;
        }
        return !weaponOnly.isToggled() || Utils.holdingWeapon();
    }

    private void updateServerPos() {
        serverPos = new Vec3(target.serverPosX / 32.0, target.serverPosY / 32.0, target.serverPosZ / 32.0);
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public void onReceivePacket(ReceivePacketEvent event) {
        try {
            handlePacket(event);
        } catch (Throwable exception) {
            Utils.sendMessage("&cBacktrack could not handle packet: " + exception.getClass().getSimpleName());
        }
    }

    private void handlePacket(ReceivePacketEvent event) {
        Packet<?> packet = event.getPacket();
        if (event.isCanceled() || packet == processing) {
            return;
        }
        if (!Utils.nullCheck() || mc.getNetHandler() == null) {
            if (holding) {
                discardPackets();
            }
            return;
        }
        if (holding) {
            if (packet instanceof S08PacketPlayerPosLook || packet instanceof S40PacketDisconnect
                    || flushOnDamage.isToggled() && packet instanceof S12PacketEntityVelocity
                    && ((S12PacketEntityVelocity) packet).getEntityID() == mc.thePlayer.getEntityId()) {
                flush();
                return;
            }
        } else if (!ready) {
            return;
        }

        Vec3 position = serverPos;
        if (position == null) {
            return;
        }
        double x = position.xCoord;
        double y = position.yCoord;
        double z = position.zCoord;
        boolean moves = false;
        boolean teleport = false;
        if (packet instanceof S14PacketEntity.S15PacketEntityRelMove
                || packet instanceof S14PacketEntity.S17PacketEntityLookMove) {
            S14PacketEntity movement = (S14PacketEntity) packet;
            Entity entity = movement.getEntity(mc.theWorld);
            if (entity != null && target != null && entity.getEntityId() == target.getEntityId()) {
                moves = true;
                x += movement.func_149062_c() / 32.0;
                y += movement.func_149061_d() / 32.0;
                z += movement.func_149064_e() / 32.0;
            }
        } else if (packet instanceof S18PacketEntityTeleport) {
            S18PacketEntityTeleport movement = (S18PacketEntityTeleport) packet;
            if (target != null && movement.getEntityId() == target.getEntityId()) {
                teleport = true;
                moves = true;
                x = movement.getX() / 32.0;
                y = movement.getY() / 32.0;
                z = movement.getZ() / 32.0;
            }
        }
        if (moves) {
            boolean flush = true;
            double distanceSq = mc.thePlayer.getDistanceSq(x, y, z);
            AxisAlignedBB box = target.getEntityBoundingBox();
            AxisAlignedBB newBox = box.offset(x - target.posX, y - target.posY, z - target.posZ);
            float[] rotations = toBox(target, newBox);
            if (distanceSq <= maxRangeSq && !rayHits(target, newBox, rotations, minRange)
                    && rayHits(target, newBox, rotations, maxRange)) {
                AxisAlignedBB oldBox = box.offset(position.xCoord - target.posX, position.yCoord - target.posY,
                        position.zCoord - target.posZ);
                float[] oldRotations = toBox(target, oldBox);
                double newDistance = rayDistanceSq(target, newBox, rotations, maxRange);
                double oldDistance = rayDistanceSq(target, oldBox, oldRotations, maxRange + 2.0);
                if (oldDistance >= 0.0 && newDistance > oldDistance
                        && (!teleport || newDistance - oldDistance < 64.0)) {
                    if (!holding && canStart()) {
                        start();
                    }
                    serverPos = new Vec3(x, y, z);
                    EntityOtherPlayerMP copy = ghost;
                    if (copy != null) {
                        copy.setPositionAndRotation2(x, y, z, 0.0f, 0.0f, 3, teleport);
                    }
                    flush = false;
                }
            }
            if (holding && flush) {
                flush();
                return;
            }
        }
        if (holding && !(onlyMovement.isToggled() ? !moves : passesThrough(packet))) {
            hold(packet);
            event.setCanceled(true);
        }
    }

    private float[] toBox(Entity entity, AxisAlignedBB box) {
        float border = entity.getCollisionBorderSize();
        box = box.expand(border, border, border);
        Vec3 eyes = mc.thePlayer.getPositionEyes(1.0f);
        if (box.isVecInside(eyes)) {
            return new float[]{mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch};
        }
        double amount = Settings.aimClosestPoint.getInput() / 100.0;
        double centerX = (box.minX + box.maxX) / 2.0;
        double centerY = box.minY + (box.maxY - box.minY) * 0.825;
        double centerZ = (box.minZ + box.maxZ) / 2.0;
        double closestX = MathHelper.clamp_double(eyes.xCoord, box.minX + 0.03, box.maxX - 0.03);
        double closestY = MathHelper.clamp_double(eyes.yCoord, box.minY + 0.03, box.maxY - 0.03);
        double closestZ = MathHelper.clamp_double(eyes.zCoord, box.minZ + 0.03, box.maxZ - 0.03);
        double dx = centerX + (closestX - centerX) * amount - eyes.xCoord;
        double dy = centerY + (closestY - centerY) * amount - eyes.yCoord;
        double dz = centerZ + (closestZ - centerZ) * amount - eyes.zCoord;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.atan2(dz, dx) * (double) 57.29578f) - 90.0f;
        float pitch = (float) (-Math.atan2(dy, horizontal) * (double) 57.29578f);
        RotationHelper helper = RotationHelper.get();
        float currentYaw = helper.isActive() && helper.getServerYaw() != null
                ? helper.getServerYaw() : mc.thePlayer.rotationYaw;
        float currentPitch = helper.isActive() && helper.getServerPitch() != null
                ? helper.getServerPitch() : mc.thePlayer.rotationPitch;
        return new float[]{currentYaw + MathHelper.wrapAngleTo180_float(yaw - currentYaw),
                RotationUtils.clampPitch(currentPitch + MathHelper.wrapAngleTo180_float(pitch - currentPitch))};
    }

    private MovingObjectPosition rayHit(Entity entity, AxisAlignedBB box, float[] rotations, double range) {
        if (!entity.canBeCollidedWith()) {
            return null;
        }
        Vec3 from = mc.thePlayer.getPositionEyes(1.0f);
        Vec3 direction = RotationUtils.getVectorForRotation(rotations[1], rotations[0]);
        Vec3 to = from.addVector(direction.xCoord * range, direction.yCoord * range, direction.zCoord * range);
        float border = entity.getCollisionBorderSize();
        return box.expand(border, border, border).calculateIntercept(from, to);
    }

    private boolean rayHits(Entity entity, AxisAlignedBB box, float[] rotations, double range) {
        return rayHit(entity, box, rotations, range) != null;
    }

    private double rayDistanceSq(Entity entity, AxisAlignedBB box, float[] rotations, double range) {
        MovingObjectPosition hit = rayHit(entity, box, rotations, range);
        return hit == null ? -1.0 : mc.thePlayer.getPositionEyes(1.0f).squareDistanceTo(hit.hitVec);
    }

    private void hold(Packet<?> packet) {
        synchronized (packetLock) {
            held.computeIfAbsent(tick + delayTicks, key -> new ArrayList<>()).add(packet);
        }
    }

    @SuppressWarnings("unchecked")
    private void process(List<Packet<?>> packets) {
        NetHandlerPlayClient handler = mc.getNetHandler();
        if (packets.isEmpty() || !Utils.nullCheck() || handler == null) {
            return;
        }
        for (Packet<?> packet : packets) {
            try {
                processing = packet;
                ReceivePacketEvent replay = new ReceivePacketEvent(packet);
                MinecraftForge.EVENT_BUS.post(replay);
                if (!replay.isCanceled()) {
                    ((Packet<INetHandlerPlayClient>) packet).processPacket(handler);
                }
            } catch (ThreadQuickExitException ignored) {
            } catch (Throwable exception) {
                Utils.sendMessage("&cBacktrack could not process " + packet.getClass().getSimpleName()
                        + ": " + exception.getClass().getSimpleName());
            } finally {
                processing = null;
            }
        }
    }

    private void releaseDue() {
        List<Packet<?>> packets = new ArrayList<>();
        synchronized (packetLock) {
            Iterator<Map.Entry<Integer, List<Packet<?>>>> iterator = held.entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<Integer, List<Packet<?>>> entry = iterator.next();
                if (tick < entry.getKey()) {
                    break;
                }
                packets.addAll(entry.getValue());
                iterator.remove();
            }
            ++tick;
        }
        process(packets);
    }

    @Override
    public void guiButtonToggled(ButtonSetting setting) {
        if (setting == onlyMovement) {
            flush();
        } else if (setting == showServerPosition) {
            if (!setting.isToggled()) {
                ghost = null;
            } else if (holding) {
                makeGhost(target);
            }
        }
    }

    private EntityLivingBase findTarget() {
        if (ModuleManager.killAura != null && ModuleManager.killAura.isEnabled()
                && KillAura.target != null && valid(KillAura.target)) {
            return KillAura.target;
        }
        if (ModuleManager.aimAssist != null && ModuleManager.aimAssist.isEnabled()) {
            Entity aimed = ModuleManager.aimAssist.getAimAssistTarget();
            if (aimed instanceof EntityLivingBase && valid((EntityLivingBase) aimed)) {
                return (EntityLivingBase) aimed;
            }
        }
        double halfFov = fov.getInput() / 2.0;
        double best = 999.0;
        EntityPlayer found = null;
        for (EntityPlayer player : mc.theWorld.playerEntities) {
            if (player == mc.thePlayer || player.deathTime != 0 || !valid(player) || AntiBot.isBot(player)) {
                continue;
            }
            if (mc.thePlayer.getDistanceSqToEntity(player) > scanRangeSq) {
                continue;
            }
            double yaw = RotationUtils.distanceFromYaw(player, false);
            if (yaw > halfFov || Utils.isFriended(player)
                    || ignoreTeammates.isToggled() && Utils.isTeammate(player)) {
                continue;
            }
            if (yaw < best) {
                best = yaw;
                found = player;
            }
        }
        return found;
    }

    private void makeGhost(EntityLivingBase entity) {
        EntityOtherPlayerMP copy = new EntityOtherPlayerMP(mc.theWorld, mc.thePlayer.getGameProfile());
        copy.copyLocationAndAnglesFrom(entity);
        Vec3 position = serverPos;
        copy.setPosition(position.xCoord, position.yCoord, position.zCoord);
        copy.setPositionAndRotation2(position.xCoord, position.yCoord, position.zCoord,
                entity.rotationYaw, entity.rotationPitch, 0, false);
        ghost = copy;
    }

    @Override
    public void onUpdate() {
        if (!Utils.nullCheck() || mc.isSingleplayer()) {
            discardPackets();
            return;
        }
        guiUpdate();
        EntityLivingBase entity = findTarget();
        if (holding) {
            if (entity != target || !targetValid()) {
                flush();
                return;
            }
            EntityOtherPlayerMP copy = ghost;
            if (copy != null) {
                copy.prevPosX = copy.lastTickPosX = copy.posX;
                copy.prevPosY = copy.lastTickPosY = copy.posY;
                copy.prevPosZ = copy.lastTickPosZ = copy.posZ;
                copy.onLivingUpdate();
            }
            releaseDue();
        } else {
            if (entity != null) {
                target = entity;
                updateServerPos();
            }
            ready = target != null && targetValid();
        }
    }

    private void discardPackets() {
        synchronized (packetLock) {
            held.clear();
            reset();
            serverPos = null;
        }
    }

    @SubscribeEvent
    public void onWorldUnload(WorldEvent.Unload event) {
        if (event.world == mc.theWorld) {
            discardPackets();
        }
    }

    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent event) {
        if (!Utils.nullCheck()) {
            return;
        }
        EntityOtherPlayerMP copy = ghost;
        if (copy == null) {
            return;
        }
        RenderManager renderManager = mc.getRenderManager();
        double x = copy.lastTickPosX + (copy.posX - copy.lastTickPosX) * event.partialTicks - renderManager.viewerPosX;
        double y = copy.lastTickPosY + (copy.posY - copy.lastTickPosY) * event.partialTicks - renderManager.viewerPosY;
        double z = copy.lastTickPosZ + (copy.posZ - copy.lastTickPosZ) * event.partialTicks - renderManager.viewerPosZ;
        AxisAlignedBB bounds = copy.getEntityBoundingBox().expand(0.1, 0.1, 0.1);
        AxisAlignedBB box = new AxisAlignedBB(bounds.minX - copy.posX + x, bounds.minY - copy.posY + y,
                bounds.minZ - copy.posZ + z, bounds.maxX - copy.posX + x, bounds.maxY - copy.posY + y,
                bounds.maxZ - copy.posZ + z);
        GL11.glBlendFunc(770, 771);
        GL11.glEnable(3042);
        GL11.glDisable(3553);
        filledBox(box, positionColor.getRed() / 255.0f, positionColor.getGreen() / 255.0f,
                positionColor.getBlue() / 255.0f, positionColor.getAlpha() / 255.0f);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glEnable(3553);
        GL11.glDisable(3042);
    }

    private void filledBox(AxisAlignedBB box, float red, float green, float blue, float alpha) {
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer renderer = tessellator.getWorldRenderer();
        renderer.begin(7, DefaultVertexFormats.POSITION_COLOR);
        double[][] vertices = {
                {box.minX, box.minY, box.minZ}, {box.minX, box.maxY, box.minZ},
                {box.maxX, box.maxY, box.minZ}, {box.maxX, box.minY, box.minZ},
                {box.minX, box.minY, box.maxZ}, {box.maxX, box.minY, box.maxZ},
                {box.maxX, box.maxY, box.maxZ}, {box.minX, box.maxY, box.maxZ},
                {box.minX, box.minY, box.minZ}, {box.minX, box.minY, box.maxZ},
                {box.minX, box.maxY, box.maxZ}, {box.minX, box.maxY, box.minZ},
                {box.maxX, box.minY, box.minZ}, {box.maxX, box.maxY, box.minZ},
                {box.maxX, box.maxY, box.maxZ}, {box.maxX, box.minY, box.maxZ},
                {box.minX, box.minY, box.minZ}, {box.maxX, box.minY, box.minZ},
                {box.maxX, box.minY, box.maxZ}, {box.minX, box.minY, box.maxZ},
                {box.minX, box.maxY, box.minZ}, {box.minX, box.maxY, box.maxZ},
                {box.maxX, box.maxY, box.maxZ}, {box.maxX, box.maxY, box.minZ}
        };
        for (double[] vertex : vertices) {
            renderer.pos(vertex[0], vertex[1], vertex[2]).color(red, green, blue, alpha).endVertex();
        }
        tessellator.draw();
    }

    public boolean isRenderingServerPositionFor(EntityLivingBase entity) {
        return isEnabled() && holding && showServerPosition.isToggled() && target == entity && ghost != null;
    }

    public Vec3 getBacktrackPosition() {
        return holding && target != null && !target.isDead ? serverPos : null;
    }

    public EntityLivingBase getBacktrackTarget() {
        return holding && target != null && !target.isDead ? target : null;
    }
}
