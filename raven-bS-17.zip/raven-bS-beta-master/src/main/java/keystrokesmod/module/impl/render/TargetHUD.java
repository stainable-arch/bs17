package keystrokesmod.module.impl.render;

import keystrokesmod.event.AttackEvent;
import keystrokesmod.event.ClickMouseEvent;
import keystrokesmod.module.Module;
import keystrokesmod.module.ModuleManager;
import keystrokesmod.module.impl.combat.AimAssist;
import keystrokesmod.module.impl.combat.KillAura;
import keystrokesmod.module.impl.client.Settings;
import keystrokesmod.module.setting.impl.ButtonSetting;
import keystrokesmod.module.setting.impl.DescriptionSetting;
import keystrokesmod.module.setting.impl.SliderSetting;
import keystrokesmod.utility.RenderUtils;
import keystrokesmod.utility.Theme;
import keystrokesmod.utility.shader.effects.Animation;
import keystrokesmod.utility.Utils;
import keystrokesmod.utility.shader.effects.TargetHudRenderer;
import keystrokesmod.utility.shader.effects.Render3D;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.client.config.GuiButtonExt;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.awt.*;
import java.io.IOException;

public class TargetHUD extends Module {
    private SliderSetting mode;
    private SliderSetting theme;
    private ButtonSetting renderEsp;
    private ButtonSetting showDifference;
    private ButtonSetting showHealth;
    private ButtonSetting showStatus;
    private ButtonSetting healthColor;
    private ButtonSetting manual;
    private ButtonSetting aimAssist;
    private ButtonSetting killAura;

    private Animation fadeTimer;
    private EntityLivingBase target;
    private EntityLivingBase manualClickTarget;
    private long lastAliveMS;
    private String hudName;
    private float hudHealth;
    private double hudRatio;
    public int posX = 70;
    public int posY = 40;

    private String[] modes = new String[]{ "Modern", "Legacy" };

    public TargetHUD() {
        super("TargetHUD", category.render);
        this.liteModule = true;
        this.registerSetting(mode = new SliderSetting("Mode", true, 0, modes));
        this.registerSetting(theme = new SliderSetting("Theme", 0, Theme.THEMES_SETTING));
        this.registerSetting(new ButtonSetting("Edit position", () -> {
            mc.displayGuiScreen(new EditScreen());
        }));
        this.registerSetting(renderEsp = new ButtonSetting("Render ESP", true));
        this.registerSetting(showDifference = new ButtonSetting("Show difference", true));
        this.registerSetting(showHealth = new ButtonSetting("Show health", true));
        this.registerSetting(showStatus = new ButtonSetting("Show win or loss", true));
        this.registerSetting(healthColor = new ButtonSetting("Traditional health color", false));
        this.registerSetting(new DescriptionSetting("Targets"));
        this.registerSetting(manual = new ButtonSetting("Manual", false));
        this.registerSetting(aimAssist = new ButtonSetting("AimAssist", false));
        this.registerSetting(killAura = new ButtonSetting("KillAura", true));
    }

    public void onDisable() {
        reset();
        TargetHudRenderer.reset();
    }

    @SubscribeEvent
    public void onClickMouse(ClickMouseEvent event) {
        manualClickTarget = null;
        if (!manual.isToggled() || !Utils.nullCheck() || mc.objectMouseOver == null) {
            return;
        }
        Entity clickedEntity = mc.objectMouseOver.entityHit;
        if (!(clickedEntity instanceof EntityLivingBase)) {
            return;
        }
        if (ModuleManager.killAura != null && ModuleManager.killAura.isEnabled() && KillAura.attackingEntity == clickedEntity) {
            return;
        }
        manualClickTarget = (EntityLivingBase) clickedEntity;
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onAttack(AttackEvent event) {
        if (manualClickTarget == null) {
            return;
        }
        if (event.attacker == mc.thePlayer && event.target == manualClickTarget) {
            activateTarget(manualClickTarget);
        }
        manualClickTarget = null;
    }

    @SubscribeEvent
    public void onRenderTick(TickEvent.RenderTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        if (!Utils.nullCheck()) {
            reset();
            return;
        }
        EntityLivingBase activeTarget = getActiveTarget();
        if (activeTarget != null) {
            activateTarget(activeTarget);
        }
        if (target == null) {
            return;
        }
        long age = System.currentTimeMillis() - lastAliveMS;
        if (age >= 650) {
            fadeTimer = null;
            target = null;
            return;
        }
        if (age >= 250 && fadeTimer == null) {
            fadeTimer = new Animation(400L);
            fadeTimer.start();
        }
        if (mc.gameSettings.showDebugInfo || !(mc.currentScreen == null
                || !Settings.setChatAsInventory.isToggled() && mc.currentScreen instanceof net.minecraft.client.gui.GuiChat)) {
            return;
        }
        EntityLivingBase dataTarget = killAura.isToggled() && ModuleManager.killAura.isEnabled() && KillAura.target != null
                ? KillAura.target : activeTarget;
        if (dataTarget != null) {
            hudName = dataTarget.getDisplayName().getUnformattedText();
            hudHealth = mc.theWorld.getEntityByID(dataTarget.getEntityId()) != null ? Utils.getTotalHealth(dataTarget) : 0.0f;
            hudRatio = (double) Math.min(hudHealth / dataTarget.getMaxHealth(), 1.0f);
        }
        drawTargetHUD(fadeTimer, hudName, hudHealth, hudRatio);
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onRenderWorld(RenderWorldLastEvent renderWorldLastEvent) {
        if (!renderEsp.isToggled() || !Utils.nullCheck()) {
            return;
        }
        EntityLivingBase hudTarget = getEspTarget();

        if (hudTarget == null || hudTarget.isDead) {
            return;
        }

        if (ModuleManager.backtrack.isRenderingServerPositionFor(hudTarget)) {
            return;
        }

        drawTargetBox(hudTarget, renderWorldLastEvent.partialTicks, Theme.getGradient((int) theme.getInput(), 0.0));
    }

    private EntityLivingBase getEspTarget() {
        if (killAura.isToggled() && ModuleManager.killAura.isEnabled() && KillAura.target != null) {
            return KillAura.target;
        }
        EntityLivingBase activeTarget = getActiveTarget();
        return activeTarget != null ? activeTarget : manual.isToggled() ? target : null;
    }

    private void drawTargetBox(EntityLivingBase entity, float partialTicks, int color) {
        Render3D.entityBox(entity, 2, color, partialTicks);
    }

    private EntityLivingBase getActiveTarget() {
        if (killAura.isToggled() && ModuleManager.killAura != null) {
            EntityLivingBase auraTarget = ModuleManager.killAura.getRenderTarget();
            if (auraTarget != null) {
                return auraTarget;
            }
        }
        if (aimAssist.isToggled()) {
            Module aimAssistModule = ModuleManager.getModule(AimAssist.class);
            if (aimAssistModule instanceof AimAssist && aimAssistModule.isEnabled()) {
                Entity aimAssistTarget = ((AimAssist) aimAssistModule).getAimAssistTarget();
                if (aimAssistTarget instanceof EntityLivingBase) {
                    return (EntityLivingBase) aimAssistTarget;
                }
            }
        }
        return null;
    }

    private void activateTarget(EntityLivingBase activeTarget) {
        target = activeTarget;
        lastAliveMS = System.currentTimeMillis();
        fadeTimer = null;
        hudName = activeTarget.getDisplayName().getUnformattedText();
        hudHealth = Utils.getTotalHealth(activeTarget);
        hudRatio = (double) Math.min(hudHealth / activeTarget.getMaxHealth(), 1.0f);
    }

    private void bindRenderer() {
        RenderUtils.updateResolution();
        TargetHudRenderer.mode = mode.getInput() == 1 ? TargetHudRenderer.Mode.Legacy : TargetHudRenderer.Mode.Modern;
        TargetHudRenderer.theme = Theme.values()[(int) theme.getInput()];
        TargetHudRenderer.offsetX = posX;
        TargetHudRenderer.offsetY = posY;
        TargetHudRenderer.showHealth = showHealth;
        TargetHudRenderer.showDifference = showDifference;
        TargetHudRenderer.showWinLoss = showStatus;
        TargetHudRenderer.traditionalHealthColor = healthColor;
    }

    private String getTargetText(String name, float health, double ratio) {
        bindRenderer();
        return TargetHudRenderer.text(name, health, ratio);
    }

    private void drawTargetHUD(Animation fade, String name, float health, double ratio) {
        if (mode.getInput() == -1) {
            return;
        }
        bindRenderer();
        TargetHudRenderer.render(fade, name, health, ratio);
    }

    private void reset() {
        fadeTimer = null;
        target = null;
        manualClickTarget = null;
        hudName = null;
        hudHealth = 0;
        hudRatio = 0;
    }

    public boolean isEspActiveFor(EntityLivingBase entity) {
        return this.isEnabled() && this.renderEsp.isToggled() && entity != null && getEspTarget() == entity;
    }

    public Color getCurrentEspColor(int alpha) {
        int color = Theme.getGradient((int) theme.getInput(), 0.0);
        int safeAlpha = Math.max(0, Math.min(255, alpha));

        return new Color(color >> 16 & 255, color >> 8 & 255, color & 255, safeAlpha);
    }

    class EditScreen extends GuiScreen {
        GuiButtonExt resetPosition;
        boolean d = false;
        int miX = 0;
        int miY = 0;
        int maX = 0;
        int maY = 0;
        int aX = 70;
        int aY = 40;
        int laX = 0;
        int laY = 0;
        int lmX = 0;
        int lmY = 0;
        int clickMinX = 0;

        public void initGui() {
            super.initGui();
            this.buttonList.add(this.resetPosition = new GuiButtonExt(1, this.width - 90, this.height - 25, 85, 20, "Reset position"));
            this.aX = posX;
            this.aY = posY;
        }

        public void drawScreen(int mX, int mY, float pt) {
            ScaledResolution res = new ScaledResolution(this.mc);
            drawRect(0, 0, this.width, this.height, -1308622848);
            int miX = this.aX;
            int miY = this.aY;
            String playerInfo = mc.thePlayer.getDisplayName().getUnformattedText();
            double health = Math.min(mc.thePlayer.getHealth() / mc.thePlayer.getMaxHealth(), 1.0f);
            posX = miX;
            posY = miY;
            drawTargetHUD(null, playerInfo, mc.thePlayer.getHealth(), health);
            int stringWidth = mc.fontRendererObj.getStringWidth(getTargetText(playerInfo, mc.thePlayer.getHealth(), health)) + 8;
            int maX = res.getScaledWidth() / 2 - stringWidth / 2 + miX + stringWidth;
            int maY = res.getScaledHeight() / 2 + miY + mc.fontRendererObj.FONT_HEIGHT - 1 + 8 + 13;
            int minX = res.getScaledWidth() / 2 - stringWidth / 2 + miX - 8;
            int minY = res.getScaledHeight() / 2 + miY - 8;
            this.miX = minX;
            this.miY = minY;
            this.maX = maX;
            this.maY = maY;
            this.clickMinX = minX;
            posX = miX;
            posY = miY;
            String edit = "Edit the HUD position by dragging.";
            int x = res.getScaledWidth() / 2 - fontRendererObj.getStringWidth(edit) / 2;
            int y = res.getScaledHeight() / 2 - 20;
            RenderUtils.drawColoredString(edit, '-', x, y, 2L, 0L, true, this.mc.fontRendererObj);

            try {
                this.handleInput();
            }
            catch (IOException var12) {
            }

            super.drawScreen(mX, mY, pt);
        }

        protected void mouseClickMove(int mX, int mY, int b, long t) {
            super.mouseClickMove(mX, mY, b, t);
            if (b == 0) {
                if (this.d) {
                    this.aX = this.laX + (mX - this.lmX);
                    this.aY = this.laY + (mY - this.lmY);
                }
                else if (mX > this.clickMinX && mX < this.maX && mY > this.miY && mY < this.maY) {
                    this.d = true;
                    this.lmX = mX;
                    this.lmY = mY;
                    this.laX = this.aX;
                    this.laY = this.aY;
                }

            }
        }

        protected void mouseReleased(int mX, int mY, int s) {
            super.mouseReleased(mX, mY, s);
            if (s == 0) {
                this.d = false;
            }

        }

        public void actionPerformed(GuiButton b) {
            if (b == this.resetPosition) {
                this.aX = posX = 70;
                this.aY = posY = 40;
            }

        }

        public boolean doesGuiPauseGame() {
            return false;
        }
    }
}
