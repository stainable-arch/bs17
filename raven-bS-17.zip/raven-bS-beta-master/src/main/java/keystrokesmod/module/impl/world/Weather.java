package keystrokesmod.module.impl.world;

import keystrokesmod.event.ReceivePacketEvent;
import keystrokesmod.module.Module;
import keystrokesmod.module.setting.impl.ButtonSetting;
import keystrokesmod.module.setting.impl.SliderSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.network.play.server.S03PacketTimeUpdate;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.world.ChunkCoordIntPair;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.storage.WorldInfo;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.ReflectionHelper;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class Weather extends Module {
    public final SliderSetting time;
    public final SliderSetting lightning;
    public final ButtonSetting rain;
    public Lightning mode = Lightning.Disabled;

    private static final Random RANDOM = new Random();
    private static Field activeChunkSet;
    private static Field updateLCG;
    private WorldClient weatherWorld;
    private WorldInfo rainInfo;
    private long savedTime = -9L;
    private long savedRain = -1L;
    private boolean savedDaylightCycle;
    private boolean savedServerRain;
    private float savedRainStrength;
    private long lastThunder;

    public enum Lightning {
        Disabled, Vanilla, Uncommon, Common, Frequent, Intense, Chaotic;

        public boolean shouldStrike() {
            if (this == Vanilla) {
                return RANDOM.nextInt(100000) == 0;
            }
            double d = Math.random();
            switch (this) {
                case Uncommon: return d > 0.9999;
                case Common: return d > 0.999;
                case Frequent: return d > 0.99;
                case Intense: return d > 0.9;
                case Chaotic: return d > 0.3;
                default: return false;
            }
        }
    }

    public Weather() {
        super("Weather", category.world);
        this.registerSetting(time = new SliderSetting("Time", "", "§eVanilla", 0.0, 0.0, 24.0, 0.3));
        this.registerSetting(lightning = new SliderSetting("Lightning", 0,
                new String[]{"Disabled", "Vanilla", "Uncommon", "Common", "Frequent", "Intense", "Chaotic"}));
        lightning.setMinString("§cDisabled");
        this.registerSetting(rain = new ButtonSetting("Rain", false));
        this.liteModule = true;
        this.closetModule = true;
    }

    @Override
    public void onEnable() {
        synchronizeWorld();
        guiUpdate();
    }

    @Override
    public void guiUpdate() {
        mode = Lightning.values()[MathHelper.clamp_int((int) lightning.getInput(), 0, Lightning.values().length - 1)];
    }

    @Override
    public void onUpdate() {
        synchronizeWorld();
        if (weatherWorld == null) {
            return;
        }
        guiUpdate();
        updateTime();
        updateRain();
        strike();
    }

    @Override
    public void onDisable() {
        restoreTime();
        restoreRain();
        weatherWorld = null;
        lastThunder = 0L;
    }

    @SubscribeEvent
    public void onWorldUnload(WorldEvent.Unload event) {
        if (event.world == weatherWorld) {
            onDisable();
        }
    }

    private void synchronizeWorld() {
        if (weatherWorld != mc.theWorld) {
            restoreTime();
            restoreRain();
            weatherWorld = mc.theWorld;
            lastThunder = 0L;
        }
    }

    private void updateTime() {
        if (time.getInput() != 0.0) {
            if (savedTime == -9L) {
                savedTime = weatherWorld.getWorldTime();
                savedDaylightCycle = weatherWorld.getGameRules().getBoolean("doDaylightCycle");
            }
            weatherWorld.setWorldTime((long) (-1000.0 * (16.0 + time.getInput())));
        } else {
            restoreTime();
        }
    }

    private void restoreTime() {
        if (savedTime != -9L && weatherWorld != null) {
            weatherWorld.setWorldTime(savedTime);
            weatherWorld.getGameRules().setOrCreateGameRule("doDaylightCycle", Boolean.toString(savedDaylightCycle));
        }
        savedTime = -9L;
    }

    private void updateRain() {
        if (rain.isToggled()) {
            if (savedRain == -1L) {
                savedRain = weatherWorld.getWorldInfo().isRaining() ? 1L : 0L;
                savedRainStrength = weatherWorld.getRainStrength(1.0f);
                rainInfo = worldInfo();
                savedServerRain = rainInfo.isRaining();
            }
            rainInfo.setRaining(true);
            weatherWorld.getWorldInfo().setRaining(true);
            weatherWorld.setRainStrength(1.0f);
        } else {
            restoreRain();
        }
    }

    private void restoreRain() {
        if (savedRain != -1L) {
            if (rainInfo != null) {
                rainInfo.setRaining(savedServerRain);
            }
            if (weatherWorld != null) {
                weatherWorld.getWorldInfo().setRaining(savedRain == 1L);
                weatherWorld.setRainStrength(savedRainStrength);
            }
        }
        savedRain = -1L;
        rainInfo = null;
    }

    private WorldInfo worldInfo() {
        MinecraftServer server = mc.getIntegratedServer();
        if (server != null && server.worldServers != null && server.worldServers.length > 0) {
            WorldServer world = server.worldServerForDimension(weatherWorld.provider.getDimensionId());
            if (world != null) {
                return world.getWorldInfo();
            }
        }
        return weatherWorld.getWorldInfo();
    }

    @SuppressWarnings("unchecked")
    private void strike() {
        Minecraft mc = Minecraft.getMinecraft();
        if (lightning.getInput() == 0.0 || mc.isGamePaused()) {
            return;
        }
        try {
            if (activeChunkSet == null) {
                activeChunkSet = ReflectionHelper.findField(World.class, "activeChunkSet", "field_72993_I");
                updateLCG = ReflectionHelper.findField(World.class, "updateLCG", "field_73005_l");
            }
            long l = System.currentTimeMillis();
            Set<ChunkCoordIntPair> set = (Set<ChunkCoordIntPair>) activeChunkSet.get(mc.theWorld);
            for (ChunkCoordIntPair c : set) {
                if (!mode.shouldStrike()) continue;
                int x = c.chunkXPos * 16;
                int z = c.chunkZPos * 16;
                int n3 = (Integer) updateLCG.get(mc.theWorld);
                n3 = n3 * 3 + 1013904223;
                updateLCG.set(mc.theWorld, n3);
                int n4 = n3 >> 2;
                BlockPos pos = this.target(new BlockPos(x + (n4 & 0xF), 0, z + (n4 >> 8 & 0xF)));
                if (!mc.theWorld.canSeeSky(pos)) continue;
                mc.theWorld.addWeatherEffect(new EntityLightningBolt(mc.theWorld, pos.getX(), pos.getY(), pos.getZ()));
                if (Math.abs(l - lastThunder) <= 250L) continue;
                mc.theWorld.playSound(pos.getX(), pos.getY(), pos.getZ(), "ambient.weather.thunder", 10.0f, 0.8f + RANDOM.nextFloat() * 0.2f, false);
                lastThunder = l;
            }
        } catch (Exception exception) {
        }
    }

    private BlockPos target(BlockPos blockPos) {
        Minecraft mc = Minecraft.getMinecraft();
        BlockPos top = mc.theWorld.getPrecipitationHeight(blockPos);
        BlockPos sky = new BlockPos(top.getX(), mc.theWorld.getHeight(), top.getZ());
        AxisAlignedBB box = new AxisAlignedBB(top, sky).expand(3.0, 3.0, 3.0);
        List<EntityLivingBase> list = mc.theWorld.getEntitiesWithinAABB(EntityLivingBase.class, box, Weather::canStrike);
        return !list.isEmpty() ? list.get(RANDOM.nextInt(list.size())).getPosition() : top;
    }

    private static boolean canStrike(EntityLivingBase e) {
        return e != null && e.isEntityAlive() && Minecraft.getMinecraft().theWorld.canSeeSky(e.getPosition());
    }

    @SubscribeEvent
    public void onReceivePacket(ReceivePacketEvent event) {
        if (time.getInput() == 0.0 || !(event.getPacket() instanceof S03PacketTimeUpdate) || mc.theWorld == null) {
            return;
        }
        S03PacketTimeUpdate packet = (S03PacketTimeUpdate) event.getPacket();
        WorldClient world = mc.theWorld;
        event.setCanceled(true);
        Runnable update = () -> {
            if (mc.theWorld != world) {
                return;
            }
            world.setTotalWorldTime(packet.getTotalWorldTime());
            if (!isEnabled() || time.getInput() == 0.0) {
                world.setWorldTime(packet.getWorldTime());
                savedTime = -9L;
                return;
            }
            synchronizeWorld();
            savedTime = packet.getWorldTime();
            savedDaylightCycle = savedTime >= 0L;
        };
        if (mc.isCallingFromMinecraftThread()) {
            update.run();
        } else {
            mc.addScheduledTask(update);
        }
    }
}
