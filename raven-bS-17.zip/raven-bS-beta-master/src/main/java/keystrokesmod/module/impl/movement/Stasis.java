package keystrokesmod.module.impl.movement;

import keystrokesmod.event.PostPlayerInputEvent;
import keystrokesmod.event.PreUpdateEvent;
import keystrokesmod.event.ReceivePacketEvent;
import keystrokesmod.event.SendPacketEvent;
import keystrokesmod.module.Module;
import keystrokesmod.module.setting.impl.DescriptionSetting;
import keystrokesmod.module.setting.impl.SliderSetting;
import keystrokesmod.utility.Utils;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Stasis extends Module {
    private final SliderSetting pulse;
    private boolean frozen;
    private double savedX;
    private double savedY;
    private double savedZ;
    private int frozenAt;
    private int delay;

    public Stasis() {
        super("Stasis", category.movement);
        this.registerSetting(new DescriptionSetting("Hangs the player midair."));
        this.registerSetting(pulse = new SliderSetting("Pulse", " ticks", "\u00a7cDisabled", 65.0, 2.0, 85.0, 1.0));
    }

    @Override
    public void onEnable() {
        delay = 2;
    }

    @Override
    public void onDisable() {
        freeze(false);
        delay = 0;
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onPreUpdate(PreUpdateEvent e) {
        if (!Utils.nullCheck()) {
            return;
        }

        if (delay > 0 && --delay == 0) {
            freeze(true);
        }
        if (frozen) {
            mc.thePlayer.motionX = 0.0;
            mc.thePlayer.motionY = 0.0;
            mc.thePlayer.motionZ = 0.0;
            if (pulse.getInput() != pulse.getMin() && mc.thePlayer.ticksExisted - frozenAt >= (int) pulse.getInput()) {
                freeze(false);
                delay = 1;
            }
        }
    }

    @SubscribeEvent
    public void onSendPacket(SendPacketEvent e) {
        if (!Utils.nullCheck() || !frozen || !(e.getPacket() instanceof C03PacketPlayer)) {
            return;
        }

        if (Utils.isHypixel() && !(e.getPacket() instanceof C03PacketPlayer.C05PacketPlayerLook)) {
            mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C05PacketPlayerLook(
                    mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, mc.thePlayer.onGround));
            e.setCanceled(true);
        }
    }

    @SubscribeEvent(priority = EventPriority.LOW)
    public void onReceivePacket(ReceivePacketEvent e) {
        if (!Utils.nullCheck() || !frozen) {
            return;
        }

        if (e.getPacket() instanceof S08PacketPlayerPosLook) {
            freeze(false);
            delay = 3;
        }
        else if (e.getPacket() instanceof S12PacketEntityVelocity
                && ((S12PacketEntityVelocity) e.getPacket()).getEntityID() == mc.thePlayer.getEntityId()) {
            freeze(false);
            delay = 4;
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onPostPlayerInput(PostPlayerInputEvent e) {
        if (Utils.nullCheck() && (frozen || delay == 1)) {
            mc.thePlayer.movementInput.moveForward = 0.0f;
            mc.thePlayer.movementInput.moveStrafe = 0.0f;
        }
    }

    private void freeze(boolean freeze) {
        if (!Utils.nullCheck()) {
            frozen = false;
            return;
        }

        if (freeze) {
            savedX = mc.thePlayer.motionX;
            savedY = mc.thePlayer.motionY;
            savedZ = mc.thePlayer.motionZ;
            frozenAt = mc.thePlayer.ticksExisted;
        }
        else {
            mc.thePlayer.motionX = savedX;
            mc.thePlayer.motionY = savedY;
            mc.thePlayer.motionZ = savedZ;
        }
        frozen = freeze;
    }
}
