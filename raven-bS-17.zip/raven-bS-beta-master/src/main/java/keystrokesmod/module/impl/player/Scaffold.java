package keystrokesmod.module.impl.player;

import keystrokesmod.event.*;
import keystrokesmod.helper.RotationHelper;
import keystrokesmod.mixin.interfaces.IMixinItemRenderer;
import keystrokesmod.module.Module;
import keystrokesmod.module.ModuleManager;
import keystrokesmod.module.setting.impl.ButtonSetting;
import keystrokesmod.module.setting.impl.SliderSetting;
import keystrokesmod.utility.RenderUtils;
import keystrokesmod.utility.Theme;
import keystrokesmod.utility.Utils;
import keystrokesmod.utility.scaffold.ScaffoldSupport;
import keystrokesmod.utility.scaffold.ScaffoldSupport.*;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.*;
import net.minecraft.network.play.server.*;
import net.minecraft.potion.Potion;
import net.minecraft.util.*;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fml.client.config.GuiButtonExt;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.io.IOException;
import java.util.*;

public class Scaffold extends Module {

    public enum Rotation {
        None, Strict, Smooth, Simple, Lazy, Offset;

        public float side;
        public float sideJitter;
        public float groundSide;

        public void onDisable() {
            this.groundSide = 0.0f;
            this.sideJitter = 0.0f;
            this.side = 0.0f;
        }
    }

    public enum FastScaffold {
        Disabled(false, false, false),
        Vanilla(true, false, false),
        Constant_A(true, false, false),
        Constant_B(false, false, false),
        Float_A(true, false, false),
        Float_B(true, false, false),
        Jump_A(false, true, false),
        Jump_B(false, true, false),
        Jump_C(true, true, false),
        Jump_D(true, true, false),
        Keep_Y_A(false, false, true),
        Keep_Y_B(false, false, true),
        Side(true, false, false);

        public final boolean sprint;
        public final boolean jump;
        public final boolean keepY;
        public int state;
        public int ticks;
        public double height;

        FastScaffold(boolean sprint, boolean jump, boolean keepY) {
            this.sprint = sprint;
            this.jump = jump;
            this.keepY = keepY;
        }

        public boolean canSprint() {
            if (!this.canFastScaffold()) {
                if (mc.thePlayer.ticksExisted == startTick && jumpState == 2) {
                    return false;
                }
                return (ModuleManager.movementFix != null && ModuleManager.movementFix.isEnabled());
            }
            if (legitMotion.isToggled() && (this.jump || this.keepY)) {
                return legitTicks > 0;
            }
            if (!this.sprint) {
                return false;
            }
            return this != Side || this.ticks != -1;
        }

        public void onEnable() {
            enableTick = mc.thePlayer.ticksExisted;
            this.state = 0;
            if (this == Float_A) {
                if (mc.thePlayer.onGround) {
                    this.ticks = 1;
                    delay = 1;
                    if (mc.thePlayer.motionY == -0.0784000015258789) {
                        PlayerUtils.jump();
                    }
                    keptY = (int) Math.floor(mc.thePlayer.posY) - 1;
                }
            } else if (this == Jump_B || this == Jump_C) {
                this.height = 2.2;
            } else if (this == Jump_D) {
                this.height = 2.5;
            } else if (this == Side) {
                this.ticks = 4;
            }
        }

        public boolean canFastScaffold() {
            if (!active || this == Disabled) {
                return false;
            }
            if (Tower.towering || PlayerUtils.jumpKeyDown()) {
                return false;
            }
            if (this != Float_A) {
                if (!PlayerUtils.isMoving() || mc.thePlayer.isSneaking()) {
                    return false;
                }
                if (this.sprint && !this.jump && !PlayerUtils.direction().forward) {
                    return false;
                }
            }
            if (this == Side) {
                return !PlayerUtils.isDiagonal();
            }
            return true;
        }

        public void onDisable(boolean disabling) {
            if (this.jump || this.keepY) {
                keptY = -1;
            }
            if (this.jump && !disabling && !Tower.towering && Tower.slowedTicks.getInput() > 0.0) {
                MoveUtils.setSpeed(0.05);
            }
            if (this == Float_A) {
                if (disablingModule) {
                    if (mc.thePlayer.onGround && PlayerUtils.isAirBelow()) {
                        PlayerUtils.jump();
                    }
                    if (rotation != Rotation.Offset) {
                        multiplyMotion(0.58, false);
                    }
                }
            } else if (this == Float_B && disablingModule) {
                multiplyMotion(0.85, false);
            }
            this.ticks = 0;
        }
    }

    public enum MultiPlace {
        Disabled, _1_extra, _2_extra
    }

    public static Scaffold instance;

    public static SliderSetting motion, rotationSetting, fakeRotationSetting, fastScaffoldSetting, fastScaffoldRmbSetting, fastScaffoldMotion,
            multiPlaceSetting, precisionSetting, sneakEvery, speedBoost, highlightTheme;
    private static ButtonSetting spoofItem;
    public static ButtonSetting autoSwap, cancelKnockback, highlightBlocks, jumpFacingForward, legitMotion, safeWalk, showBlockCount,
            silentSwing, slowOnEnable, slowSpeedPotion, tower;

    public static Rotation rotation = Rotation.Strict;
    public static FakeRotation fakeRotation = FakeRotation.None;
    public static FastScaffold fastScaffold = FastScaffold.Disabled;
    private static FastScaffold lastFastScaffold = FastScaffold.Disabled;
    public static MultiPlace multiPlace = MultiPlace.Disabled;
    public static RotationUtils.Precision precision = RotationUtils.Precision.High;
    public static Theme theme = Theme.Default;

    public static boolean active;
    public static boolean disablingModule;
    private static boolean fastEnabled;
    private static boolean rightHeld;
    public static int keptY = -1;
    private static int searchMode;
    public static int legitTicks;
    public static int delay;
    public static int enableTick;
    public static int jumpState;
    public static int startTick;
    private static int jumpTick;
    private static int airBelowTicks;
    private static int placedCount;
    public static int pausedTicks;
    private static boolean sneakQueued;
    private static boolean smoothSnap;
    private static BlockPos lastPlaced;
    private static float aimYaw, aimPitch = 100.0f;
    private static float smoothLimit;
    private static float legitYaw;
    private static float restPitch;
    private static double yawOffset;
    private static long placedAt;
    public static long startedAt;
    public static float startPitch;
    private static long stoppedAt;
    private static long smoothAt;
    private static final HashMap<BlockPos, Long> placed = new HashMap<BlockPos, Long>();
    public static String countText;
    private static int originalSlot = -1;
    private static boolean hasSwapped;
    private static boolean sentCloseWindow;
    private static boolean sentUseOrDig;
    private static float lastPlayerYaw;
    private static Float smoothYaw;
    private static net.minecraft.client.entity.EntityPlayerSP sessionPlayer;
    private float posX = Float.NaN;
    private float posY = Float.NaN;
    private float relativePosX = Float.NaN;
    private float relativePosY = Float.NaN;

    private static final EnumFacing[] SIDES = {EnumFacing.EAST, EnumFacing.SOUTH, EnumFacing.NORTH, EnumFacing.WEST};
    private static final BlockPos.MutableBlockPos SCRATCH = new BlockPos.MutableBlockPos();

    public Scaffold() {
        super("Scaffold", category.player);
        instance = this;
        this.liteModule = true;
        this.closetModule = true;
        this.alwaysOn = true;
        this.registerSetting(motion = new SliderSetting("Motion", "x", 1.0, 0.5, 1.2, 0.01));
        this.registerSetting(rotationSetting = new SliderSetting("Rotation", 1, new String[]{"None", "Strict", "Smooth", "Simple", "Lazy", "Offset"}));
        this.registerSetting(fakeRotationSetting = new SliderSetting("Rotation (fake)", 0, new String[]{"None", "Smooth", "Forward", "Spin"}));
        this.registerSetting(fastScaffoldSetting = new SliderSetting("Fast scaffold", 0, new String[]{"Disabled", "Vanilla", "Constant A", "Constant B", "Float A", "Float B", "Jump A", "Jump B", "Jump C", "Jump D", "Keep-Y A", "Keep-Y B", "Side"}));
        this.registerSetting(fastScaffoldRmbSetting = new SliderSetting("Fast scaffold RMB", 0, new String[]{"Disabled", "Vanilla", "Constant A", "Constant B", "Float A", "Float B", "Jump A", "Jump B", "Jump C", "Jump D", "Keep-Y A", "Keep-Y B", "Side"}));
        this.registerSetting(fastScaffoldMotion = new SliderSetting("Fast scaffold motion", "x", 1.0, 0.5, 1.2, 0.01));
        this.registerSetting(multiPlaceSetting = new SliderSetting("Multi-place", 0, new String[]{"Disabled", "1 extra", "2 extra"}));
        this.registerSetting(precisionSetting = new SliderSetting("Precision", 2, new String[]{"Low", "Medium", "High", "Very high"}));
        this.registerSetting(sneakEvery = new SliderSetting("Sneak every", " blocks", 0.0, 0.0, 20.0, 1.0));
        this.registerSetting(speedBoost = new SliderSetting("Speed boost", "", 1.3, 0.0, 2.0, 0.05));
        this.registerSetting(highlightTheme = new SliderSetting("Highlight theme", 0, new String[]{"Default", "Rainbow", "Aurora", "Cherry", "Cotton candy", "Flare", "Flower", "Forest", "Frost", "Gold", "Grayscale", "Inferno", "Royal", "Sandstorm", "Sky", "Vine"}));
        rotationSetting.setMinString("\u00a7cNone");
        fakeRotationSetting.setMinString("\u00a7cNone");
        fastScaffoldSetting.setMinString("\u00a7cDisabled");
        fastScaffoldRmbSetting.setMinString("\u00a7cDisabled");
        multiPlaceSetting.setMinString("\u00a7cDisabled");
        sneakEvery.setMinString("\u00a7cDisabled");
        this.registerSetting(autoSwap = new ButtonSetting("Auto swap", false));
        this.registerSetting(cancelKnockback = new ButtonSetting("Cancel knockback", false));
        this.registerSetting(highlightBlocks = new ButtonSetting("Highlight blocks", true));
        this.registerSetting(jumpFacingForward = new ButtonSetting("Jump facing forward", true));
        this.registerSetting(legitMotion = new ButtonSetting("Legit motion", true));
        this.registerSetting(safeWalk = new ButtonSetting("SafeWalk", false));
        this.registerSetting(showBlockCount = new ButtonSetting("Show block count", true));
        this.registerSetting(silentSwing = new ButtonSetting("Silent swing", false));
        this.registerSetting(slowOnEnable = new ButtonSetting("Slow on enable", false));
        this.registerSetting(slowSpeedPotion = new ButtonSetting("Slow speed potion", false));
        this.registerSetting(tower = new ButtonSetting("Tower", false));
        this.registerSetting(spoofItem = new ButtonSetting("Spoof item", false));
        this.registerSetting(new ButtonSetting("Edit position", () -> mc.displayGuiScreen(new EditScreen())));
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onMouse(MouseEvent e) {
        if (!e.buttonstate || e.button < 0 || !isEnabled() || !active || mc.currentScreen != null) {
            return;
        }
        int keyCode = e.button - 100;
        if (keyCode == mc.gameSettings.keyBindAttack.getKeyCode()
                || keyCode == mc.gameSettings.keyBindUseItem.getKeyCode()) {
            e.setCanceled(true);
        }
    }

    @Override
    public void onEnable() {
        clearState();
        if (!Utils.nullCheck()) {
            return;
        }
        sessionPlayer = mc.thePlayer;
        guiUpdate();
        placed.clear();
        sentCloseWindow = false;
        sentUseOrDig = false;
        lastPlayerYaw = mc.thePlayer.rotationYaw;
        if (autoSwap.isToggled()) {
            rememberSlot();
        }
        restPitch = randomFloat(84.5f, 87.5f);
        yawOffset = RotationUtils.randomOffset();
        if (!mc.thePlayer.onGround) {
            delay = 3;
        } else if (PlayerUtils.potionLevel(Potion.jump) <= 3 && PlayerUtils.nearEdge(0.2) && countBlocks() > 0) {
            jumpState = 2;
            jumpTick = mc.thePlayer.ticksExisted;
            delay = 4;
        }
    }

    @Override
    public void onDisable() {
        if (!Utils.nullCheck()) {
            clearState();
            return;
        }
        disablingModule = true;
        stop();
        legitTicks = 0;
        delay = 0;
        airBelowTicks = 0;
        pausedTicks = 0;
        placedCount = 0;
        placedAt = 0L;
        double d = MoveUtils.speed();
        if (d > 0.34) {
            multiplyMotion((0.29 + 0.02 * Math.random()) / d, false);
        }
        disablingModule = false;
        restoreSlot();
        Tower.reset();
    }

    @Override
    public void guiUpdate() {
        rotation = Rotation.values()[(int) rotationSetting.getInput()];
        fakeRotation = FakeRotation.values()[(int) fakeRotationSetting.getInput()];
        fastScaffold = FastScaffold.values()[(int) (rightHeld ? fastScaffoldRmbSetting.getInput() : fastScaffoldSetting.getInput())];
        multiPlace = MultiPlace.values()[(int) multiPlaceSetting.getInput()];
        precision = RotationUtils.Precision.values()[(int) precisionSetting.getInput()];
        theme = Theme.values()[(int) highlightTheme.getInput()];
        Tower.setFromScaffold(tower);
    }

    @Override
    public String getInfo() {
        if (fastScaffold == FastScaffold.Disabled) {
            return rotationSetting.getSelectedOption();
        }
        if (fastScaffold.jump) {
            return "Jump";
        }
        if (fastScaffold.keepY) {
            return "Keep-Y";
        }
        if (fastScaffold == FastScaffold.Constant_A || fastScaffold == FastScaffold.Constant_B) {
            return "Constant";
        }
        if (fastScaffold == FastScaffold.Float_A || fastScaffold == FastScaffold.Float_B) {
            return "Float";
        }
        return fastScaffold.name().replace("_", " ");
    }

    private static void updateCount() {
        int n = countBlocks();
        String color = null;
        if (n <= 5) {
            color = "§c";
        } else if (n <= 15) {
            color = "§6";
        } else if (n <= 25) {
            color = "§e";
        }
        countText = color == null ? n + " blocks" : color + n + "§f blocks";
    }

    public static void renderPlaced() {
        if (placed.isEmpty()) {
            return;
        }
        long l = System.currentTimeMillis();
        Iterator<Map.Entry<BlockPos, Long>> iterator = placed.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<BlockPos, Long> entry = iterator.next();
            long l2 = l - Math.abs(entry.getValue());
            float f = (float) l2 / 500.0f;
            if (f >= 1.0f) {
                iterator.remove();
                continue;
            }
            if (!highlightBlocks.isToggled()) continue;
            float f2 = 255.0f - Math.min(f * 255.0f, 255.0f);
            RenderUtils.renderBlock(entry.getKey(), Utils.mergeAlpha(Theme.getGradient((int) highlightTheme.getInput(), 0.0), (int) f2), true, false);
        }
    }

    private static BlockPos place(BlockPos last, ItemStack itemStack) {
        BlockPos target = search(last);
        if (target == null) {
            return null;
        }
        EnumFacing facing = faceFor(target, null);
        if (facing == null) {
            return null;
        }
        BlockPos against = target.offset(facing.getOpposite());
        if (airBelowTicks > 0) {
            float yaw = aimYaw;
            float pitch = aimPitch;
            MovingObjectPosition hit = aim(against, facing, -170.0f, keystrokesmod.utility.RotationUtils.serverRotations[0]);
            if (hit == null) {
                return last == null ? null : place(null, itemStack);
            }
            switch (rotation) {
                case Simple: {
                    float f3 = PlayerUtils.movementAngle();
                    if (!(Math.abs(f3 - aimYaw) < 100.0f)) break;
                    float f4 = aimYaw - f3;
                    f4 = (f4 + 540.0f) % 360.0f - 180.0f;
                    float f6 = 0.0f;
                    if (Math.abs(f4) >= 10.0f) {
                        f6 = Math.max(-10.0f, Math.min(f4, 10.0f));
                    }
                    aimYaw = f3 + f6;
                    if (!mc.thePlayer.onGround) break;
                    aimPitch = 82.5f;
                    break;
                }
                case Lazy: {
                    if (pitch == 100.0f || PlayerUtils.rayTraceBlock(against, null, mc.playerController.getBlockReachDistance(), yaw, pitch) == null) break;
                    aimYaw = yaw;
                    aimPitch = pitch;
                    break;
                }
                default:
                    break;
            }
            Vec3 vec3 = hit.hitVec;
            if (mc.playerController.onPlayerRightClick(mc.thePlayer, mc.theWorld, itemStack, against, facing, vec3)) {
                PlayerUtils.swing(silentSwing.isToggled(), true);
                if (searchMode == 1 || searchMode == 2 && fastScaffold.keepY) {
                    fastScaffold.ticks = mc.thePlayer.ticksExisted;
                }
                lastPlaced = target;
                placedAt = System.currentTimeMillis();
                placed.put(target, placedAt);
                airBelowTicks = 0;
                return target;
            }
        } else if (PlayerUtils.isMoving() && Math.random() > 0.8) {
            PlayerUtils.syncCurrentPlayItem();
            mc.thePlayer.sendQueue.addToSendQueue(new C08PacketPlayerBlockPlacement(itemStack));
        }
        return null;
    }

    private static BlockPos search(BlockPos last) {
        ArrayList<Vec3> list = new ArrayList<Vec3>();
        searchMode = 0;
        if (keptY != -1 && fastScaffold.canFastScaffold()) {
            int decimals = PlayerUtils.posYDecimals();
            if (fastScaffold == FastScaffold.Jump_A) {
                if (decimals == 1661 || decimals == 2492 && mc.thePlayer.motionY > 0.0) {
                    searchMode = 1;
                } else {
                    searchMode = 2;
                }
            } else if (fastScaffold == FastScaffold.Jump_B || fastScaffold == FastScaffold.Jump_C || fastScaffold == FastScaffold.Jump_D) {
                if (mc.thePlayer.ticksExisted - fastScaffold.ticks > 4 && mc.thePlayer.posY - (double) keptY < fastScaffold.height && mc.thePlayer.motionY < -0.1) {
                    searchMode = 1;
                    if (fastScaffold.ticks == 0) {
                        multiplyMotion(0.4, false);
                    }
                } else {
                    searchMode = 2;
                }
            } else if (fastScaffold.keepY) {
                searchMode = 2;
            } else if (fastScaffold == FastScaffold.Float_A) {
                if (mc.thePlayer.onGround && mc.thePlayer.ticksExisted - enableTick > 0) {
                    keptY = -1;
                } else {
                    searchMode = 2;
                }
            }
        }
        return candidates(list, searchMode, keptY) ? firstPlaceable(list, last) : null;
    }

    private static boolean candidates(List<Vec3> list, int mode, int y) {
        int n3;
        double d;
        for (int i = -5; i <= 5; ++i) {
            for (int j = -5; j <= 5; ++j) {
                for (int k = -3; k <= -1; ++k) {
                    int n4 = MathHelper.floor_double(mc.thePlayer.posY) + k;
                    if (mode > 0 && n4 != y) continue;
                    double d2 = mc.thePlayer.posX + (double) i;
                    d = mc.thePlayer.posZ + (double) j;
                    SCRATCH.set(MathHelper.floor_double(d2), n4, MathHelper.floor_double(d));
                    if (BlockUtils.isReplaceable(SCRATCH)) continue;
                    for (n3 = -1; n3 <= 1; n3 += 2) {
                        switch (mode) {
                            case 0:
                                list.add(new Vec3(d2 + (double) n3, (double) n4, d));
                                list.add(new Vec3(d2, (double) n4, d + (double) n3));
                            case 1:
                                list.add(new Vec3(d2, (double) (n4 + n3), d));
                                continue;
                            case 2:
                                list.add(new Vec3(d2 + (double) n3, (double) n4, d));
                                list.add(new Vec3(d2, (double) n4, d + (double) n3));
                        }
                    }
                }
            }
        }
        if (list.isEmpty()) {
            return false;
        }
        HashSet<Long> seen = new HashSet<Long>(list.size() * 2);
        ArrayList<Vec3> unique = new ArrayList<Vec3>(list.size());
        for (Vec3 vec3 : list) {
            long l = Double.doubleToLongBits(vec3.xCoord) ^ Double.doubleToLongBits(vec3.yCoord) * 31L ^ Double.doubleToLongBits(vec3.zCoord) * 31L * 31L;
            if (!seen.add(l)) continue;
            unique.add(vec3);
        }
        list.clear();
        list.addAll(unique);
        final double x = mc.thePlayer.posX;
        double y2 = mc.thePlayer.posY - 1.0;
        final double z = mc.thePlayer.posZ;
        if (!mc.thePlayer.onGround && !PlayerUtils.jumpKeyDown() && !fastScaffold.canFastScaffold()) {
            y2 -= 1.0;
        }
        final double fy = y2;
        Comparator<Vec3> comparator = Comparator.comparingDouble(p -> WorldUtils.distanceSq(x, fy, z, p));
        if (mc.thePlayer.ticksExisted - startTick <= 3) {
            double yaw = mc.thePlayer.rotationYaw * ((float) Math.PI / 180);
            final double dirX = -Math.sin(yaw);
            final double dirZ = Math.cos(yaw);
            comparator = comparator.thenComparingDouble(p -> WorldUtils.behind(x, z, dirX, dirZ, p));
        }
        list.sort(comparator);
        return true;
    }

    private static BlockPos firstPlaceable(List<Vec3> list, BlockPos last) {
        for (Vec3 vec3 : list) {
            SCRATCH.set(MathHelper.floor_double(vec3.xCoord), MathHelper.floor_double(vec3.yCoord), MathHelper.floor_double(vec3.zCoord));
            if (!BlockUtils.isReplaceable(SCRATCH) || faceFor(SCRATCH, last) == null) continue;
            return new BlockPos((Vec3i) SCRATCH);
        }
        return null;
    }

    private static float[] rotations(float f, float f2) {
        if (!active || rotation == Rotation.None) {
            return null;
        }
        long l = sincePlace();
        float f7;
        float f8;
        float f9;
        float f10;
        if (rotation == Rotation.Offset) {
            float f6 = (float) RotationUtils.inputAngleSigned();
            f7 = mc.thePlayer.rotationYaw + f6;
            f8 = (f7 % 360.0f + 360.0f) % 360.0f;
            f9 = f8 % 90.0f;
            if (!(f9 >= 80.0f) && !(f9 < 10.0f)) {
                f10 = f9 >= 10.0f && f9 < 45.0f ? 45.0f : -45.0f;
            } else {
                f10 = -45.0f;
            }
            if (!mc.thePlayer.onGround && rotation.groundSide != 0.0f) {
                f10 = rotation.groundSide;
            } else {
                rotation.groundSide = f10;
            }
            if (f10 != rotation.side) {
                rotation.side = f10;
                rotation.sideJitter = (float) ((double) Math.signum(f10) * ScaffoldSupport.randomBetween(0.02, 0.08));
            }
            aimYaw = PlayerUtils.movementAngle() + (f10 + rotation.sideJitter);
        }
        boolean jumpRotation = false;
        if (legitTicks <= 0) {
            if (fastScaffold == FastScaffold.Float_A && fastScaffold.ticks == 1 && mc.thePlayer.ticksExisted == enableTick) {
                jumpRotation = true;
            }
        } else {
            --legitTicks;
            jumpRotation = true;
        }
        if (jumpRotation) {
            f7 = -180.0f;
            f8 = aimPitch == 100.0f ? mc.thePlayer.rotationPitch : aimPitch;
            if (legitMotion.isToggled()) {
                if (legitTicks == 4) {
                    if ((double) (mc.thePlayer.rotationYaw - lastPlayerYaw) < -0.7) {
                        f7 = -f7;
                    }
                    legitYaw = f7;
                    --delay;
                    jumpRotation = false;
                } else if (legitTicks == 3) {
                    if (legitYaw > 0.0f) {
                        f7 = -f7;
                    }
                    if (rotation == Rotation.Smooth) {
                        legitTicks = Math.min(legitTicks, 1);
                        if (delay > legitTicks) {
                            delay = legitTicks;
                        }
                        smoothSnap = true;
                    }
                    f8 = randomFloat(20.0f, 25.0f);
                } else if (legitTicks == 2) {
                    legitYaw += randomFloat(105.0f, 120.0f) * -Math.signum(legitYaw);
                    f7 = legitYaw;
                    f8 = randomFloat(40.0f, 45.0f);
                } else if (legitTicks == 1) {
                    legitYaw += randomFloat(33.0f, 35.0f) * -Math.signum(legitYaw);
                    f7 = legitYaw;
                    if (aimPitch == 100.0f || rotation == Rotation.Simple) {
                        f8 = randomFloat(50.0f, 55.0f);
                    }
                } else if (legitTicks == 0) {
                    legitYaw += randomFloat(29.0f, 33.0f) * -Math.signum(legitYaw);
                    f7 = legitYaw;
                    if (aimPitch == 100.0f || rotation == Rotation.Simple) {
                        f8 = randomFloat(65.0f, 70.0f);
                    }
                }
            }
            if (rotation == Rotation.Offset && rotation.side > 0.0f) {
                f7 = -f7;
            }
            if (jumpRotation) {
                return RotationUtils.fixSensitivity(PlayerUtils.movementAngle() + f7 + RotationUtils.randomOffset(), f8, f, f2, false);
            }
        }
        float yaw;
        float pitch;
        if (rotation == Rotation.Smooth && lastPlaced != null && PlayerUtils.groundTicks <= 3L) {
            yaw = aimYaw;
            pitch = aimPitch;
            f7 = smoothLimit;
            if (smoothSnap) {
                smoothSnap = false;
                f7 = 81.0f;
                f7 += randomFloat(-2.0f, 2.0f);
            }
            f8 = MathHelper.wrapAngleTo180_float(yaw - f);
            if (Math.abs(f8) > f7) {
                yaw = f + (!(f8 > 0.0f) ? -f7 : f7);
            }
            float[] r = RotationUtils.fixSensitivity(yaw, pitch, f, f2, false);
            return new float[]{r[0], r[1]};
        }
        if (aimPitch != 100.0f && l < holdTime()) {
            yaw = aimYaw;
            pitch = aimPitch;
            if (l > 5L && PlayerUtils.isMoving() && Math.random() > 0.3) {
                yaw = (float) ((double) yaw + ScaffoldSupport.randomBetween(0.05, 0.5) * (double) (!(Math.random() < 0.5) ? 1 : -1));
                pitch += RotationUtils.randomOffset();
            }
            float[] r = RotationUtils.fixSensitivity(yaw, pitch, f, f2, false);
            yaw = r[0];
            pitch = r[1];
        } else {
            if (aimPitch != 100.0f) {
                aimPitch = 100.0f;
            }
            int n = mc.thePlayer.ticksExisted - startTick;
            f8 = PlayerUtils.movementAngle();
            f9 = rotation != Rotation.Simple ? restPitch : 82.5f;
            f8 += (float) yawOffset;
            f9 += RotationUtils.randomOffset();
            if (n <= 2 && !mc.thePlayer.onGround && mc.thePlayer.ticksExisted - jumpTick > 3) {
                BlockPos target = search(null);
                if (target != null) {
                    EnumFacing facing = faceFor(target, null);
                    if (facing != null && facing != EnumFacing.UP) {
                        BlockPos against = target.offset(facing.getOpposite());
                        float[] r = RotationUtils.searchBlockRotation(against, facing, -170.0f, precision, f, false);
                        if (r != null) {
                            f8 = r[0];
                            f9 = r[1];
                        }
                    }
                }
            } else if (rotation == Rotation.Offset) {
                f8 = aimYaw;
            }
            yaw = f8;
            pitch = f9;
            if (n <= 2) {
                f10 = n != 0 ? (n != 2 ? 0.8f : 0.55f) : 0.3f;
                f10 = (float) ((double) f10 + ScaffoldSupport.randomBetween(-0.02, 0.02));
                yaw = f + f10 * (f8 - f);
                pitch = f2 + f10 * (f9 - f2);
                if (Math.abs(yaw - f8) < 5.0f) {
                    delay = 0;
                }
            }
            float[] r = RotationUtils.fixSensitivity(yaw, pitch, f, f2, false);
            yaw = r[0];
            if (yaw != f) {
                pitch = r[1];
                yawOffset = RotationUtils.randomOffset();
            } else {
                pitch = f2;
            }
        }
        return new float[]{yaw, pitch};
    }

    private static void jumpWith(double d) {
        if (legitMotion.isToggled()) {
            return;
        }
        PlayerUtils.jump(boosted(d));
    }

    private static boolean placeExtra(ItemStack itemStack) {
        BlockPos target = search(lastPlaced);
        if (target == null) {
            return false;
        }
        EnumFacing facing = faceFor(target, lastPlaced);
        if (facing == null) {
            return false;
        }
        BlockPos against = target.offset(facing.getOpposite());
        float[] r = RotationUtils.searchBlockRotation(against, facing, -170.0f, precision, keystrokesmod.utility.RotationUtils.serverRotations[0], false);
        if (r == null) {
            return false;
        }
        MovingObjectPosition hit = PlayerUtils.rayTraceBlock(against, null, mc.playerController.getBlockReachDistance(), r[0], r[1]);
        if (hit == null) {
            return false;
        }
        PlayerUtils.place(hit, itemStack);
        PlayerUtils.swing(silentSwing.isToggled(), true);
        lastPlaced = target;
        placedAt = System.currentTimeMillis();
        placed.put(target, placedAt);
        return true;
    }

    private static void fastScaffoldTick() {
        rightHeld = Mouse.isButtonDown(1) && mc.currentScreen == null;
        fastScaffold = FastScaffold.values()[(int) (!rightHeld ? fastScaffoldSetting.getInput() : fastScaffoldRmbSetting.getInput())];
        boolean moving = PlayerUtils.isMoving();
        boolean groundMoving = mc.thePlayer.onGround && moving;
        boolean can = fastScaffold.canFastScaffold();
        boolean sprintForward = fastScaffold.sprint && PlayerUtils.direction().forward;
        boolean applied = false;
        if (fastScaffold == lastFastScaffold) {
            if (!can) {
                if (fastEnabled) {
                    fastEnabled = false;
                    fastScaffold.onDisable(false);
                }
            } else if (!fastEnabled) {
                fastEnabled = true;
                fastScaffold.onEnable();
            }
        } else {
            if (fastEnabled && lastFastScaffold != null) {
                lastFastScaffold.onDisable(false);
            }
            if (can) {
                fastScaffold.onEnable();
            }
            fastEnabled = can;
            lastFastScaffold = fastScaffold;
        }
        double d;
        if (!can) {
            if (!Tower.towering && legitTicks > 0 && mc.thePlayer.onGround) {
                delay = 0;
                legitTicks = 0;
            }
        } else {
            boolean newY;
            double speed;
            switch (fastScaffold) {
                case Constant_A:
                    if (groundMoving) {
                        d = 0.153 + PlayerUtils.perSpeedLevel(0.034);
                        if (PlayerUtils.speedLevel() == 0 && PlayerUtils.isDiagonal()) {
                            d *= 0.87;
                        }
                        MoveUtils.strafe(d);
                    }
                    break;
                case Constant_B:
                    if (groundMoving) {
                        MoveUtils.strafe(0.181);
                    }
                    break;
                case Jump_A:
                case Jump_B:
                case Jump_C:
                case Jump_D:
                    if (!groundMoving) {
                        if (moving && jumpFacingForward.isToggled() && mc.thePlayer.motionY < 0.0) {
                            d = Math.floor(mc.thePlayer.posY);
                            if (d - 2.0 == (double) keptY && mc.thePlayer.posY + mc.thePlayer.motionY < d) {
                                legitTicks = !legitMotion.isToggled() ? 1 : 5;
                            }
                        }
                        break;
                    }
                    if (fastScaffold.state != 2) {
                        newY = false;
                        if (mc.thePlayer.ticksExisted - fastScaffold.ticks > 10) {
                            keptY = (int) Math.floor(mc.thePlayer.posY) - 1;
                            newY = true;
                        }
                        if ((jumpFacingForward.isToggled() || FastScaffold.Float_A.state == 1 || FastScaffold.Float_B.state == 1) && newY) {
                            if (jumpFacingForward.isToggled()) {
                                legitTicks = !legitMotion.isToggled() ? 1 : 5;
                            }
                            fastScaffold.state = 1;
                        }
                        if (fastScaffold.state == 0) {
                            if (fastScaffold != FastScaffold.Jump_A) {
                                if (!sprintForward) {
                                    speed = !newY ? 0.545 : 0.4;
                                } else {
                                    speed = !newY ? 0.3 : 0.25;
                                }
                            } else {
                                speed = !PlayerUtils.isDiagonal() ? 0.53 : 0.37;
                            }
                            jumpWith(speed);
                        }
                    } else {
                        fastScaffold.state = 0;
                    }
                    multiplyMotion(0.95, false);
                    break;
                case Keep_Y_A:
                case Keep_Y_B:
                    if (!groundMoving) {
                        if (moving && jumpFacingForward.isToggled() && mc.thePlayer.motionY < 0.0) {
                            d = Math.floor(mc.thePlayer.posY);
                            if (d - 1.0 == (double) keptY && mc.thePlayer.posY + mc.thePlayer.motionY < d) {
                                legitTicks = !legitMotion.isToggled() ? 1 : 5;
                            }
                        }
                    } else {
                        if (fastScaffold.state != 2) {
                            newY = false;
                            if (mc.thePlayer.ticksExisted - fastScaffold.ticks > 10) {
                                keptY = (int) Math.floor(mc.thePlayer.posY) - 1;
                                newY = true;
                            }
                            if ((jumpFacingForward.isToggled() || FastScaffold.Float_A.state == 1 || FastScaffold.Float_B.state == 1) && newY) {
                                if (jumpFacingForward.isToggled() && legitTicks == 0) {
                                    legitTicks = !legitMotion.isToggled() ? 1 : 5;
                                }
                                fastScaffold.state = 1;
                                multiplyMotion(PlayerUtils.speedLevel() <= 0 ? 0.8 : 0.4, false);
                            }
                            if (fastScaffold.state == 0) {
                                if (!sprintForward) {
                                    speed = !newY ? 0.545 : 0.54;
                                } else {
                                    speed = !newY ? 0.3 : 0.25;
                                }
                                jumpWith(speed);
                            }
                        } else {
                            fastScaffold.state = 0;
                        }
                        multiplyMotion(0.95, false);
                    }
                    break;
                default:
                    break;
            }
            if (!mc.thePlayer.onGround && (fastScaffold == FastScaffold.Jump_D || fastScaffold == FastScaffold.Keep_Y_B) && PlayerUtils.motionYDecimals() == 30) {
                mc.thePlayer.motionY -= 0.14;
            }
            if (groundMoving) {
                d = fastScaffoldMotion.getInput();
                if (!legitMotion.isToggled() && PlayerUtils.direction().diagonal) {
                    d -= 0.02;
                }
                multiplyMotion(d, true);
                applied = true;
            }
        }
        if (!applied && groundMoving) {
            d = motion.getInput();
            if (!legitMotion.isToggled()) {
                if (slowSpeedPotion.isToggled()) {
                    d -= PlayerUtils.perSpeedLevel(0.17);
                }
                if (PlayerUtils.direction().diagonal) {
                    d -= 0.02;
                }
                if (mc.thePlayer.ticksExisted - startTick <= 2) {
                    d -= 0.05;
                }
            }
            multiplyMotion(d, true);
        }
    }

    private static long holdTime() {
        if (mc.thePlayer.isSprinting()) {
            return 710L;
        }
        if (!PlayerUtils.isMoving()) {
            return 460L;
        }
        return 110L;
    }

    private static void stop() {
        if (mc.thePlayer == null) {
            clearState();
            return;
        }
        if (active) {
            stoppedAt = System.currentTimeMillis();
            rotation.onDisable();
            if (mc.currentScreen == null) {
                restoreSlot();
            }
            if (fastEnabled) {
                fastScaffold.onDisable(true);
                fastEnabled = false;
            }
            Tower.stop();
            sneakQueued = false;
            smoothSnap = false;
            rightHeld = false;
            active = false;
            smoothYaw = null;
            jumpState = 1;
            if (mc.thePlayer.onGround && rotation != Rotation.Offset) {
                multiplyMotion(0.75, false);
            }
        }
        keptY = -1;
        lastPlaced = null;
        aimPitch = 100.0f;
    }

    public static void resetKeepY() {
        keptY = -1;
    }

    private static boolean stopOnEdge() {
        if (active) {
            if (safeWalk.isToggled()) {
                if (fastScaffold.jump || fastScaffold.keepY) {
                    return !fastScaffold.canFastScaffold();
                }
                return true;
            }
            if ((fastScaffold == FastScaffold.Float_A || fastScaffold == FastScaffold.Float_B) && fastScaffold.canFastScaffold()) {
                return true;
            }
        }
        return false;
    }

    public static EnumFacing faceFor(BlockPos pos, BlockPos only) {
        BlockPos down = pos.down();
        if (canPlaceAgainst(down) && (only == null || down.equals(only))) {
            return EnumFacing.UP;
        }
        double d = mc.thePlayer.posX - ((double) pos.getX() + 0.5);
        double d2 = mc.thePlayer.posZ - ((double) pos.getZ() + 0.5);
        EnumFacing facing = Math.abs(d) > Math.abs(d2) ? (d > 0.0 ? EnumFacing.EAST : EnumFacing.WEST) : (d2 > 0.0 ? EnumFacing.SOUTH : EnumFacing.NORTH);
        BlockPos toward = pos.offset(facing);
        if (canPlaceAgainst(toward) && (only == null || toward.equals(only))) {
            return facing.getOpposite();
        }
        for (EnumFacing side : SIDES) {
            if (side == facing) continue;
            BlockPos other = pos.offset(side);
            if (!canPlaceAgainst(other)) continue;
            if (only != null && !other.equals(only)) continue;
            return side.getOpposite();
        }
        return null;
    }

    public static void multiplyMotion(double d, boolean always) {
        if (!always && legitMotion.isToggled()) {
            return;
        }
        PlayerUtils.multiplyMotion(d);
    }

    private static double speedBonus() {
        int n = PlayerUtils.speedLevel();
        switch (n) {
            case 0:
                return 0.0;
            case 1:
                return 0.05;
            case 2:
                return speedBoost.getInput() / 10.0;
        }
        return 0.06 * (double) n;
    }

    private static void afterPlace(BlockPos pos, ItemStack itemStack) {
        if (fastScaffold == FastScaffold.Side && fastScaffold.canFastScaffold() && (fastScaffold.ticks == -1 || ++fastScaffold.ticks == 2 || fastScaffold.ticks >= 5)) {
            if (fastScaffold.ticks >= 5) {
                fastScaffold.ticks = 0;
            }
            double cx = (double) pos.getX() + 0.5;
            double cz = (double) pos.getZ() + 0.5;
            EnumFacing facing = null;
            switch (PlayerUtils.facing()) {
                case NORTH:
                case SOUTH:
                    facing = mc.thePlayer.posX > cx ? EnumFacing.EAST : EnumFacing.WEST;
                    break;
                case WEST:
                case EAST:
                    facing = mc.thePlayer.posZ > cz ? EnumFacing.SOUTH : EnumFacing.NORTH;
                    break;
                default:
                    break;
            }
            Vec3 vec3 = BlockUtils.hitVec(pos, facing);
            MovingObjectPosition hit = new MovingObjectPosition(MovingObjectPosition.MovingObjectType.BLOCK, vec3, facing, pos);
            if (BlockUtils.isReplaceable(BlockUtils.placedPos(hit))) {
                PlayerUtils.place(hit, itemStack);
                PlayerUtils.swing(silentSwing.isToggled(), true);
                placedAt = System.currentTimeMillis();
                placed.put(pos, placedAt);
                if (fastScaffold.ticks == -1) {
                    fastScaffold.ticks = 0;
                }
                return;
            }
            fastScaffold.ticks = -1;
        }
        if (multiPlace != MultiPlace.Disabled && itemStack.stackSize > 0 && (Tower.towering || fastScaffold.canFastScaffold()) && placeExtra(itemStack)
                && multiPlace == MultiPlace._2_extra && itemStack.stackSize > 0) {
            placeExtra(itemStack);
        }
    }

    private static boolean canPlaceAgainst(BlockPos pos) {
        if (!placed.isEmpty() && !placed.containsKey(pos) && sincePlace() < 250L) {
            boolean near = false;
            for (Map.Entry<BlockPos, Long> entry : placed.entrySet()) {
                if (!(mc.thePlayer.getDistanceSq(entry.getKey()) < 12.0)) continue;
                near = true;
                break;
            }
            if (near) {
                return false;
            }
        }
        return !BlockUtils.isReplaceable(pos) && !BlockUtils.isInteractable(BlockUtils.getBlock(pos));
    }

    private static void postPlayerInput() {
        if (sneakQueued && sincePlace() > 90L) {
            sneakQueued = false;
            PlayerUtils.setSneak(true);
        }
        if (jumpState == 1) {
            if (PlayerUtils.jumpKeyDown()) {
                PlayerUtils.setJump(false);
                jumpState = 2;
            } else {
                jumpState = 0;
            }
        } else if (jumpState == 2) {
            PlayerUtils.setJump(true);
            jumpState = 0;
        }
        if (fastScaffold == FastScaffold.Float_A || fastScaffold == FastScaffold.Float_B) {
            if (!fastScaffold.canFastScaffold() && fastScaffold.state == 1) {
                fastScaffold.state = 0;
            }
        } else if ((fastScaffold.jump || fastScaffold.keepY) && legitMotion.isToggled() && fastScaffold.canFastScaffold() && mc.thePlayer.onGround && fastScaffold.state == 0) {
            PlayerUtils.setJump(true);
        }
    }

    private static double boosted(double d) {
        d += speedBonus();
        d += 1.0E-4 * Math.random();
        if (ScaffoldSupport.sinceSetback(500L)) {
            d *= PlayerUtils.speedLevel() > 0 ? 0.85 : 0.95;
        }
        return d;
    }

    private static void update() {
        if (showBlockCount.isToggled()) {
            updateCount();
        }
        if (pausedTicks > 0 && --pausedTicks != 0) {
            stop();
            return;
        }
        if (sentCloseWindow || mc.currentScreen != null || PlayerUtils.isAdventure()) {
            stop();
            return;
        }
        if (autoSwap.isToggled()) {
            selectBlocks();
        }
        ItemStack itemStack = mc.thePlayer.getHeldItem();
        if (!ItemUtils.isScaffoldBlock(itemStack)) {
            stop();
            return;
        }
        long l = System.currentTimeMillis();
        if (!active) {
            startTick = mc.thePlayer.ticksExisted;
            startedAt = l;
            startPitch = mc.thePlayer.rotationPitch;
            releaseKey(mc.gameSettings.keyBindAttack);
            releaseKey(mc.gameSettings.keyBindUseItem);
            if (slowOnEnable.isToggled()) {
                multiplyMotion(0.2, true);
            }
        }
        active = true;
        fastScaffoldTick();
        if (delay > 0) {
            --delay;
            return;
        }
        if (sentUseOrDig) {
            return;
        }
        BlockPos below = BlockUtils.below(1.0);
        airBelowTicks = BlockUtils.isReplaceable(below) ? ++airBelowTicks : 0;
        BlockPos pos = place(null, itemStack);
        if (pos != null) {
            ++placedCount;
            if (!(sneakEvery.getInput() == sneakEvery.getMin()) && placedCount % (int) sneakEvery.getInput() == 0) {
                sneakQueued = true;
            }
            if (itemStack.stackSize > 0) {
                afterPlace(pos, itemStack);
            }
        }
    }

    private static MovingObjectPosition aim(BlockPos pos, EnumFacing facing, float offset, float lastYaw) {
        float[] r = RotationUtils.searchBlockRotation(pos, facing, offset, precision, lastYaw, false);
        if (r == null) {
            return null;
        }
        aimYaw = r[0];
        aimPitch = r[1];
        if (rotation == Rotation.Smooth && lastPlaced != null && PlayerUtils.groundTicks <= 3L) {
            smoothLimit = 35.0f + (float) (1.0 * Math.random());
            smoothAt = System.currentTimeMillis();
            float f3 = MathHelper.wrapAngleTo180_float(aimYaw - lastYaw);
            if (Math.abs(f3) > smoothLimit) {
                return null;
            }
        }
        return PlayerUtils.rayTraceBlock(pos, null, mc.playerController.getBlockReachDistance(), aimYaw, aimPitch);
    }

    private static long sincePlace() {
        return Math.abs(System.currentTimeMillis() - placedAt);
    }

    public static boolean towerAllowed() {
        long l;
        return instance != null && instance.isEnabled() && tower.isToggled() && active && ((l = sincePlace()) < 400L || l > 700L);
    }

    private static void preMotion(PreMotionEvent e) {
        boolean floatWasSet = FastScaffold.Float_A.state == 1 || FastScaffold.Float_B.state == 1;
        FastScaffold.Float_A.state = 0;
        FastScaffold.Float_B.state = 0;
        if (!fastScaffold.canFastScaffold()) {
            return;
        }
        if (fastScaffold == FastScaffold.Float_A) {
            if (e.posY % 1.0 == 0.0 && mc.thePlayer.motionY == -0.0784000015258789) {
                if (Utils.isHypixel()) {
                    e.posY += 1.0E-13;
                }
                fastScaffold.state = 1;
                if (PlayerUtils.isMoving() && !mc.thePlayer.isSneaking() && !ScaffoldSupport.sinceSetback(3000L)) {
                    double d = fastScaffold.sprint ? 0.2 + PlayerUtils.perSpeedLevel(PlayerUtils.isDiagonal() ? 0.035 : 0.043)
                            : 0.23 + PlayerUtils.perSpeedLevel(PlayerUtils.isDiagonal() ? 0.042 : 0.05);
                    if (PlayerUtils.speedLevel() == 0 && PlayerUtils.isDiagonal()) {
                        d *= 0.87;
                    }
                    MoveUtils.strafe(d);
                    if (!fastScaffold.sprint) {
                        mc.thePlayer.setSprinting(true);
                        mc.thePlayer.spawnRunningParticles();
                    }
                }
            }
        } else if (fastScaffold == FastScaffold.Float_B) {
            if (e.posY % 1.0 == 0.0 && mc.thePlayer.motionY == -0.0784000015258789 && PlayerUtils.isMoving() && !mc.thePlayer.isSneaking()
                    && !ScaffoldSupport.sinceSetback(3000L)) {
                double d;
                if (!floatWasSet && (PlayerUtils.isDiagonal() || !PlayerUtils.isAirBelow())) {
                    if (Utils.isHypixel()) {
                        e.posY += 0.001 + Double.parseDouble("0.0000" + PlayerUtils.idOffset());
                        e.setOnGround(false);
                    }
                    fastScaffold.state = 1;
                    d = 0.153;
                } else {
                    d = 0.245 + PlayerUtils.perSpeedLevel(0.025);
                }
                MoveUtils.strafe(d);
            }
        } else if ((fastScaffold.jump || fastScaffold.keepY) && mc.thePlayer.onGround && (jumpFacingForward.isToggled() || floatWasSet)) {
            if (fastScaffold.state == 1) {
                fastScaffold.state = 2;
                double d = fastScaffold.sprint && PlayerUtils.direction().forward ? 0.25 : (fastScaffold.keepY ? 0.54 : 0.4);
                jumpWith(d);
            }
            delay = legitTicks;
        }
    }

    private static float randomFloat(float a, float b) {
        return (float) ((double) a + (double) (b - a) * Math.random());
    }
    @SubscribeEvent
    public void onPreUpdate(PreUpdateEvent event) {
        if (!isEnabled()) {
            return;
        }
        if (!Utils.nullCheck()) {
            clearState();
            return;
        }
        if (sessionPlayer != mc.thePlayer) {
            onEnable();
        }
        guiUpdate();
        if (active && rotation != Rotation.None) {
            RotationHelper.get().withRotations(keystrokesmod.utility.RotationUtils.serverRotations[0],
                    keystrokesmod.utility.RotationUtils.serverRotations[1], Scaffold::update);
        } else {
            update();
        }
        float[] result = rotations(keystrokesmod.utility.RotationUtils.serverRotations[0],
                keystrokesmod.utility.RotationUtils.serverRotations[1]);
        if (result != null) {
            RotationHelper.get().setRotations(result[0], result[1]);
        }
        if (getSpoofedSlot() != -1 && originalSlot != mc.thePlayer.inventory.currentItem) {
            ((IMixinItemRenderer) mc.getItemRenderer()).setCancelUpdate(true);
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onInput(PostPlayerInputEvent event) {
        if (!Utils.nullCheck()) {
            clearState();
            return;
        }
        if (isEnabled()) {
            if (sessionPlayer != mc.thePlayer) {
                onEnable();
            }
            guiUpdate();
            postPlayerInput();
            Tower.handleInput();
        } else if (jumpState != 0) {
            postPlayerInput();
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onMotion(PreMotionEvent event) {
        ScaffoldSupport.updateTicks();
        if (!isEnabled() || !Utils.nullCheck() || sessionPlayer != mc.thePlayer) {
            return;
        }
        Tower.handleMotion(event);
        preMotion(event);
        lastPlayerYaw = mc.thePlayer.rotationYaw;
        if (!active) {
            return;
        }
        if (!canSprint()) {
            mc.thePlayer.setSprinting(false);
            event.setSprinting(false);
        } else {
            event.setSprinting(mc.thePlayer.isSprinting());
        }
        if (fakeRotation != FakeRotation.None && rotation != Rotation.None) {
            float yaw = mc.thePlayer.rotationYaw;
            float pitch = mc.thePlayer.rotationPitch;
            if (fakeRotation != FakeRotation.Forward) {
                float progress = Math.min((System.currentTimeMillis() - startedAt) / 140.0f, 1.0f);
                pitch = startPitch + progress * (84.5f - startPitch);
                if (fakeRotation == FakeRotation.Spin) {
                    yaw += (System.currentTimeMillis() - startedAt) % 750L / 750.0f * 360.0f;
                } else {
                    if (smoothYaw == null) {
                        smoothYaw = yaw;
                    }
                    smoothYaw += MathHelper.wrapAngleTo180_float(PlayerUtils.movementAngle() - 0.01f - smoothYaw) * 0.4f;
                    yaw = smoothYaw;
                }
            }
            keystrokesmod.utility.RotationUtils.setFakeRotations(yaw, pitch);
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onSendPacket(SendPacketEvent event) {
        if (event.isCanceled()) {
            return;
        }
        Packet<?> packet = event.getPacket();
        if (packet instanceof C03PacketPlayer) {
            sentCloseWindow = false;
            sentUseOrDig = false;
        } else if (packet instanceof C0DPacketCloseWindow) {
            sentCloseWindow = true;
        } else if (packet instanceof C02PacketUseEntity || packet instanceof C07PacketPlayerDigging) {
            sentUseOrDig = true;
        }
    }

    @SubscribeEvent
    public void onDispatchPacket(DispatchPacketEvent event) {
        if (isEnabled() && Utils.nullCheck() && sessionPlayer == mc.thePlayer && event.getPacket() instanceof C03PacketPlayer) {
            Tower.handleMovementPacket((C03PacketPlayer) event.getPacket());
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onReceivePacket(ReceivePacketEvent event) {
        if (!Utils.nullCheck()) {
            return;
        }
        if (event.getPacket() instanceof S08PacketPlayerPosLook) {
            ScaffoldSupport.recordSetback();
        }
        if (active && cancelKnockback.isToggled() && (Tower.towering || PlayerUtils.isMoving())
                && (event.getPacket() instanceof S27PacketExplosion
                || event.getPacket() instanceof S12PacketEntityVelocity
                && ((S12PacketEntityVelocity) event.getPacket()).getEntityID() == mc.thePlayer.getEntityId())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public void onWorldUnload(WorldEvent.Unload event) {
        if (event.world == mc.theWorld) {
            clearState();
            ScaffoldSupport.resetTicks();
        }
    }

    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent event) {
        if (Utils.nullCheck()) {
            renderPlaced();
        }
    }

    @SubscribeEvent
    public void onRenderTick(TickEvent.RenderTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !Utils.nullCheck() || mc.currentScreen != null
                || !showBlockCount.isToggled()) {
            return;
        }
        long elapsed = System.currentTimeMillis() - (active ? startedAt : stoppedAt);
        int alpha = active ? (int) (Math.min(elapsed / 125.0f, 1.0f) * 240.0f)
                : (int) (Math.max(1.0f - elapsed / 125.0f, 0.0f) * 240.0f);
        if (alpha > 0) {
            renderBlockCount(alpha);
        }
    }

    public boolean isAlwaysSprinting() {
        return active && isEnabled() && canSprint() && fastScaffold.canFastScaffold()
                && fastScaffold.sprint && (mc.gameSettings.keyBindSprint.isKeyDown()
                || ModuleManager.sprint != null && ModuleManager.sprint.isEnabled());
    }

    public boolean canSprint() {
        return !active || !isEnabled() || Tower.vanillaTowering() || !Tower.towering && fastScaffold.canSprint();
    }

    public static boolean canSafeWalk() {
        return instance != null && instance.isEnabled() && Utils.nullCheck()
                && PlayerUtils.isAirBelow() && (!Tower.towering || !Tower.disableSafewalk.isToggled()) && stopOnEdge();
    }

    public int getSpoofedSlot() {
        return isEnabled() && active && autoSwap.isToggled() && spoofItem.isToggled() && hasSwapped
                ? originalSlot : -1;
    }

    private static void rememberSlot() {
        if (originalSlot == -1 && mc.thePlayer != null) {
            originalSlot = mc.thePlayer.inventory.currentItem;
        }
    }

    private static void restoreSlot() {
        if (originalSlot != -1 && mc.thePlayer != null && autoSwap.isToggled() && mc.currentScreen == null) {
            Utils.switchSlot(originalSlot, false);
        }
        hasSwapped = false;
        originalSlot = -1;
    }

    private static void selectBlocks() {
        if (ModuleManager.autoSwap == null) {
            return;
        }
        rememberSlot();
        if (ModuleManager.autoSwap.swapForScaffold()) {
            hasSwapped = true;
        }
    }

    private static int countBlocks() {
        int count = 0;
        if (mc.thePlayer != null) {
            for (int i = 0; i < 9; ++i) {
                ItemStack stack = mc.thePlayer.inventory.getStackInSlot(i);
                if (ItemUtils.isScaffoldBlock(stack)) {
                    count += stack.stackSize;
                }
            }
        }
        return count;
    }

    public int getTotalBlocks() {
        return countBlocks();
    }

    private static void releaseKey(KeyBinding binding) {
        KeyBinding.setKeyBindState(binding.getKeyCode(), false);
    }

    private static void clearState() {
        active = false;
        fastEnabled = false;
        rightHeld = false;
        disablingModule = false;
        keptY = -1;
        lastPlaced = null;
        aimPitch = 100.0f;
        legitTicks = delay = jumpState = airBelowTicks = pausedTicks = placedCount = 0;
        placedAt = startedAt = stoppedAt = 0L;
        originalSlot = -1;
        hasSwapped = sneakQueued = smoothSnap = sentUseOrDig = sentCloseWindow = false;
        smoothYaw = null;
        sessionPlayer = null;
        countText = null;
        placed.clear();
        for (Rotation value : Rotation.values()) {
            value.onDisable();
        }
        for (FastScaffold value : FastScaffold.values()) {
            value.state = value.ticks = 0;
            value.height = 0.0;
        }
        lastFastScaffold = FastScaffold.Disabled;
        Tower.reset();
    }

    public float getPosX() {
        syncPosition();
        return posX;
    }

    public float getPosY() {
        syncPosition();
        return posY;
    }

    public float getRelativePosX() {
        syncPosition();
        return relativePosX;
    }

    public float getRelativePosY() {
        syncPosition();
        return relativePosY;
    }

    public void setRelativePosition(float normalizedX, float normalizedY) {
        relativePosX = normalizedX;
        relativePosY = normalizedY;
        syncPosition();
    }

    public void setAbsolutePosition(float absoluteX, float absoluteY) {
        setAbsolutePosition(absoluteX, absoluteY, new ScaledResolution(mc));
    }

    public void setAbsolutePosition(float absoluteX, float absoluteY, ScaledResolution resolution) {
        posX = absoluteX;
        posY = absoluteY;
        int w = Math.max(1, resolution.getScaledWidth());
        int h = Math.max(1, resolution.getScaledHeight());
        relativePosX = absoluteX / w;
        relativePosY = absoluteY / h;
    }

    public void resetPosition() {
        relativePosX = Float.NaN;
        relativePosY = Float.NaN;
        posX = Float.NaN;
        posY = Float.NaN;
        syncPosition();
    }

    private void syncPosition() {
        syncPosition(new ScaledResolution(mc));
    }

    private void syncPosition(ScaledResolution resolution) {
        int w = Math.max(1, resolution.getScaledWidth());
        int h = Math.max(1, resolution.getScaledHeight());
        if (Float.isNaN(relativePosX) || Float.isNaN(relativePosY)) {
            if (Float.isNaN(posX) || Float.isNaN(posY)) {
                posX = (float) w / 2 + 9;
                posY = (float) h / 2 - (float) mc.fontRendererObj.FONT_HEIGHT / 2 + 1;
            }
            relativePosX = posX / w;
            relativePosY = posY / h;
        }
        posX = relativePosX * w;
        posY = relativePosY * h;
    }

    private void renderBlockCount(int alpha) {
        renderBlockCount(alpha, false);
    }

    private void renderBlockCount(int alpha, boolean editing) {
        int blocks = getTotalBlocks();
        if (editing && blocks == 0) {
            blocks = 64;
        }
        String color = "§";
        if (blocks <= 5) {
            color += "c";
        } else if (blocks <= 15) {
            color += "6";
        } else if (blocks <= 25) {
            color += "e";
        } else {
            color = "";
        }
        int colorAlpha = Utils.mergeAlpha(-1, alpha);
        ScaledResolution scaledResolution = new ScaledResolution(mc);
        syncPosition(scaledResolution);

        GlStateManager.pushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        mc.fontRendererObj.drawStringWithShadow(color + blocks + " §rblock" + (blocks == 1 ? "" : "s"),
                posX,
                posY,
                colorAlpha
        );
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    private class EditScreen extends GuiScreen {
        private GuiButtonExt resetBtn;
        private boolean dragging;
        private float actualX, actualY;
        private float lastActualX, lastActualY;
        private int lastMouseX, lastMouseY;

        @Override
        public void initGui() {
            super.initGui();
            buttonList.add(resetBtn = new GuiButtonExt(1, width - 90, height - 25, 85, 20, "Reset position"));
            syncPosition(new ScaledResolution(mc));
            actualX = posX;
            actualY = posY;
        }

        @Override
        public void drawScreen(int mouseX, int mouseY, float partialTicks) {
            ScaledResolution resolution = new ScaledResolution(mc);
            if (!dragging) {
                syncPosition(resolution);
                actualX = posX;
                actualY = posY;
            }

            drawRect(0, 0, width, height, 0xB2000000);
            setAbsolutePosition(actualX, actualY, resolution);
            renderBlockCount(255, true);
            actualX = posX;
            actualY = posY;

            String message = "Edit the position by dragging.";
            int textX = resolution.getScaledWidth() / 2 - fontRendererObj.getStringWidth(message) / 2;
            int textY = resolution.getScaledHeight() / 2 - 20;
            RenderUtils.drawColoredString(message, '-', textX, textY, 2L, 0L, true, mc.fontRendererObj);

            try {
                handleInput();
            } catch (IOException ignored) {
            }
            super.drawScreen(mouseX, mouseY, partialTicks);
        }

        @Override
        protected void mouseClickMove(int mouseX, int mouseY, int button, long timeSinceLastClick) {
            super.mouseClickMove(mouseX, mouseY, button, timeSinceLastClick);
            if (button != 0) return;

            if (dragging) {
                actualX = lastActualX + (mouseX - lastMouseX);
                actualY = lastActualY + (mouseY - lastMouseY);
            } else {
                int blocks = getTotalBlocks();
                if (blocks == 0) blocks = 64;
                String text = blocks + " block" + (blocks == 1 ? "" : "s");
                int textWidth = fontRendererObj.getStringWidth(text);
                int textHeight = fontRendererObj.FONT_HEIGHT;
                float minX = posX - 2;
                float minY = posY - 2;
                float maxX = posX + textWidth + 2;
                float maxY = posY + textHeight + 2;
                if (mouseX >= minX && mouseX <= maxX && mouseY >= minY && mouseY <= maxY) {
                    dragging = true;
                    lastMouseX = mouseX;
                    lastMouseY = mouseY;
                    lastActualX = actualX;
                    lastActualY = actualY;
                }
            }
        }

        @Override
        protected void mouseReleased(int mouseX, int mouseY, int state) {
            super.mouseReleased(mouseX, mouseY, state);
            if (state == 0) {
                dragging = false;
            }
        }

        @Override
        public void actionPerformed(GuiButton button) {
            if (button == resetBtn) {
                resetPosition();
                actualX = posX;
                actualY = posY;
            }
        }

        @Override
        public boolean doesGuiPauseGame() {
            return false;
        }
    }
}
