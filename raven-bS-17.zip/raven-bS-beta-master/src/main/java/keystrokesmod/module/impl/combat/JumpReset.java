package keystrokesmod.module.impl.combat;

import keystrokesmod.event.PostPlayerInputEvent;
import keystrokesmod.event.PreEntityVelocityEvent;
import keystrokesmod.event.PreExplosionPacketEvent;
import keystrokesmod.module.Module;
import keystrokesmod.module.setting.impl.ButtonSetting;
import keystrokesmod.module.setting.impl.SliderSetting;
import keystrokesmod.utility.Utils;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraft.network.play.server.S27PacketExplosion;
import net.minecraft.potion.Potion;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class JumpReset extends Module {
    public static JumpReset instance;
    public static SliderSetting chance;
    public static ButtonSetting minimizeVertical, onlyWhileTargeting;
    public static boolean pending;
    private static boolean explosion;
    private static double kbX, kbZ;
    private static int kbY;

    public JumpReset() {
        super("Jump Reset", category.combat);
        instance = this;
        this.liteModule = true;
        this.registerSetting(chance = new SliderSetting("Chance", "%", 100, 0, 100, 1));
        this.registerSetting(minimizeVertical = new ButtonSetting("Minimize vertical", false));
        this.registerSetting(onlyWhileTargeting = new ButtonSetting("Only while targeting", false));
        this.closetModule = true;
    }

    public static boolean on() {
        return instance != null && instance.isEnabled();
    }

    @SubscribeEvent
    public void onExplosion(PreExplosionPacketEvent e) {
        if (!Utils.nullCheck()) {
            return;
        }
        S27PacketExplosion p = e.packet;
        if (mc.thePlayer.getDistanceSq(p.getX(), p.getY(), p.getZ()) > 36.0) {
            return;
        }
        explosion = true;
    }

    @Override
    public void onDisable() {
        explosion = false;
        pending = false;
    }

    @SubscribeEvent
    public void onKnockback(PreEntityVelocityEvent e) {
        S12PacketEntityVelocity p = e.packet;
        if (!Utils.nullCheck() || p.getEntityID() != mc.thePlayer.getEntityId()) {
            return;
        }
        if (explosion) {
            return;
        }
        if (minimizeVertical.isToggled() && (long) p.getMotionY() < 3000L) {
            return;
        }
        kbX = (double) p.getMotionX() / 8000.0;
        kbY = p.getMotionY();
        kbZ = (double) p.getMotionZ() / 8000.0;
        pending = true;
    }

    @SubscribeEvent
    public void onPostPlayerInput(PostPlayerInputEvent e) {
        if (!pending) {
            return;
        }
        pending = false;
        if (!Utils.nullCheck()) {
            return;
        }
        if (!mc.thePlayer.onGround || !mc.thePlayer.isSprinting()) {
            return;
        }
        if (mc.thePlayer.isInWater() || mc.thePlayer.isInLava() || mc.thePlayer.isRiding() || mc.thePlayer.isPotionActive(Potion.jump)) {
            return;
        }
        if (onlyWhileTargeting.isToggled() && !targeting()) {
            return;
        }
        if (chance.getInput() != 100.0 && !(Math.random() < chance.getInput() / 100.0)) {
            return;
        }
        if (!helps()) {
            return;
        }
        mc.thePlayer.movementInput.jump = true;
    }

    private static boolean targeting() {
        MovingObjectPosition result = mc.objectMouseOver;
        return result != null && result.typeOfHit == MovingObjectPosition.MovingObjectType.ENTITY && result.entityHit instanceof EntityPlayer;
    }

    private static boolean helps() {
        if (kbX == 0.0 && kbZ == 0.0) {
            return false;
        }
        double kb = Math.sqrt(kbX * kbX + kbZ * kbZ);
        float yaw = MathHelper.wrapAngleTo180_float(mc.thePlayer.rotationYaw);
        double after = withJump(kbX, kbZ, yaw);
        double less = (kb - after) / kb;
        return less >= 0.03;
    }

    @Override
    public void onUpdate() {
        explosion = false;
    }

    private static double withJump(double x, double z, float yaw) {
        double r = Math.toRadians(yaw);
        double nx = x + -Math.sin(r) * 0.2;
        double nz = z + Math.cos(r) * 0.2;
        return Math.sqrt(nx * nx + nz * nz);
    }
}
