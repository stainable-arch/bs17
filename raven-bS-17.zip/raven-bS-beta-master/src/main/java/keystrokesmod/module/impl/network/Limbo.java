package keystrokesmod.module.impl.network;

import keystrokesmod.Raven;
import keystrokesmod.event.PreUpdateEvent;
import keystrokesmod.module.Module;
import keystrokesmod.module.setting.impl.ButtonSetting;
import keystrokesmod.module.setting.impl.DescriptionSetting;
import keystrokesmod.utility.Utils;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Limbo extends Module {
    private final ButtonSetting lock;

    public Limbo() {
        super("Limbo", category.network);
        this.registerSetting(new DescriptionSetting("Sends you to Hypixel limbo."));
        this.registerSetting(lock = new ButtonSetting("Lock", true));
    }

    @Override
    public void onEnable() {
        if (lock.isToggled()) {
            Utils.sendMessage("&cDisable 'Lock' to enable.");
            this.disable();
            return;
        }
        if (!Utils.nullCheck() || mc.getNetHandler() == null || !Utils.isHypixel()) {
            Utils.sendMessage("&cMust be on Hypixel.");
            this.disable();
        }
    }

    @SubscribeEvent
    public void onPreUpdate(PreUpdateEvent event) {
        try {
            if (Utils.nullCheck() && mc.getNetHandler() != null && Utils.isHypixel()) {
                Raven.lagHandler.sendThroughLag(new C08PacketPlayerBlockPlacement());
            }
        } finally {
            this.disable();
        }
    }
}
