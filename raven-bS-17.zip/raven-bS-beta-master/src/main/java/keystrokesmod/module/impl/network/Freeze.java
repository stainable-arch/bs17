package keystrokesmod.module.impl.network;

import keystrokesmod.event.GameTickEvent;
import keystrokesmod.event.ReceivePacketEvent;
import keystrokesmod.event.SendPacketEvent;
import keystrokesmod.module.Module;
import keystrokesmod.module.ModuleManager;
import keystrokesmod.module.setting.impl.ButtonSetting;
import keystrokesmod.module.setting.impl.DescriptionSetting;
import keystrokesmod.module.setting.impl.SliderSetting;
import keystrokesmod.utility.Theme;
import keystrokesmod.utility.Utils;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.init.Blocks;
import net.minecraft.network.Packet;
import net.minecraft.network.ThreadQuickExitException;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.server.*;
import net.minecraft.potion.Potion;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;

import java.util.ArrayList;
import java.util.List;

public class Freeze extends Module {
    private final SliderSetting autoDisable;

    public final ButtonSetting activateOnHit;
    public final ButtonSetting disableOnBedBreak;
    public final ButtonSetting disableOnInteract;
    public final ButtonSetting showFreezeTicks;
    public final ButtonSetting showKnockbackDirection;
    public final ButtonSetting updateChatMessages;
    public final ButtonSetting updateBlockChanges;
    public final ButtonSetting updatePlayerHealth;
    public final ButtonSetting updatePlayerPositions;
    public final ButtonSetting updateScoreboard;
    public final ButtonSetting updateSoundEffects;

    private final Object packetLock = new Object();
    private final List<Packet<?>> heldPackets = new ArrayList<>();
    private volatile boolean frozen;
    private volatile boolean releasing;
    private volatile boolean disableNext;
    private volatile int ticks;
    private volatile NetHandlerPlayClient packetHandler;
    private volatile WorldClient packetWorld;
    private boolean shown;
    private long shownAt;
    private long hiddenAt;
    private String text;
    private volatile boolean knockback;
    private volatile double knockbackX;
    private volatile double knockbackZ;

    public Freeze() {
        super("Freeze", category.network);
        this.registerSetting(new DescriptionSetting("Freeze inbound packets."));
        this.registerSetting(autoDisable = new SliderSetting("Auto-disable", " second", "\u00a7cNever", 0, 0, 15, 0.2));
        this.registerSetting(activateOnHit = new ButtonSetting("Activate on hit", false));
        this.registerSetting(disableOnBedBreak = new ButtonSetting("Disable on bed break", false));
        this.registerSetting(disableOnInteract = new ButtonSetting("Disable on interact", false));
        this.registerSetting(showFreezeTicks = new ButtonSetting("Show freeze ticks", true));
        this.registerSetting(showKnockbackDirection = new ButtonSetting("Show knockback direction", true));
        this.registerSetting(updateChatMessages = new ButtonSetting("Update chat messages", true));
        this.registerSetting(updateBlockChanges = new ButtonSetting("Update block changes", true));
        this.registerSetting(updatePlayerHealth = new ButtonSetting("Update player health", true));
        this.registerSetting(updatePlayerPositions = new ButtonSetting("Update player positions", true));
        this.registerSetting(updateScoreboard = new ButtonSetting("Update scoreboard", true));
        this.registerSetting(updateSoundEffects = new ButtonSetting("Update sound effects", true));
        this.alwaysOn = true;
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Override
    public void onEnable() {
        if (frozen || releasing || !Utils.nullCheck() || mc.getNetHandler() == null) {
            this.disable();
            return;
        }
        if (mc.isSingleplayer()) {
            Utils.sendMessage("&cCan't enable Freeze in singleplayer.");
            this.disable();
            return;
        }

        if (blinksInbound()) {
            Utils.sendMessage("&cConflicted modules, disable blink or use outbound-only.");
            this.disable();
            return;
        }
        synchronized (packetLock) {
            heldPackets.clear();
            packetHandler = mc.getNetHandler();
            packetWorld = mc.theWorld;
            ticks = 0;
            disableNext = false;
        }
        clearKnockback();
        shown = true;
        shownAt = System.currentTimeMillis();
        text = "idle";
        if (!activateOnHit.isToggled()) {
            startFreeze();
            updateText();
        }
    }

    @Override
    public void onDisable() {
        shown = false;
        hiddenAt = System.currentTimeMillis();
        clearKnockback();
        releasePackets();
        disableNext = false;
    }

    public boolean isFrozen() {
        return frozen;
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onReceivePacketHigh(ReceivePacketEvent event) {
        if (!isEnabled() || event.isCanceled() || event.getPacket() == null || packetHandler == null) {
            return;
        }
        Packet<?> packet = event.getPacket();
        if (!Utils.nullCheck() || mc.isSingleplayer() || mc.getNetHandler() != packetHandler
                || mc.theWorld != packetWorld || packet instanceof S40PacketDisconnect
                || packet instanceof S01PacketJoinGame || packet instanceof S07PacketRespawn) {
            discardPackets();
            disableNext = true;
            return;
        }
        if (!frozen) {
            if (!activateOnHit.isToggled() || !isHitPacket(packet)) {
                return;
            }
            startFreeze();
            if (!frozen) {
                return;
            }
        }
        if (packet instanceof S12PacketEntityVelocity) {
            S12PacketEntityVelocity velocity = (S12PacketEntityVelocity) packet;
            if (velocity.getEntityID() == mc.thePlayer.getEntityId()) {
                if (Math.abs(velocity.getMotionX()) < 400 && Math.abs(velocity.getMotionZ()) < 400) {
                    clearKnockback();
                } else {
                    knockbackX = velocity.getMotionX() / 8000.0;
                    knockbackZ = velocity.getMotionZ() / 8000.0;
                    knockback = true;
                }
            }
        }
        if (shouldUpdateImmediately(packet)) {
            return;
        }
        synchronized (packetLock) {
            if (isEnabled() && frozen && mc.getNetHandler() == packetHandler && mc.theWorld == packetWorld) {
                heldPackets.add(packet);
                event.setCanceled(true);
            }
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onSendPacketHigh(SendPacketEvent event) {
        if (!isEnabled() || !Utils.nullCheck() || event.isCanceled() || event.getPacket() == null) {
            return;
        }
        Packet<?> packet = event.getPacket();
        if (packet instanceof C02PacketUseEntity) {
            if (frozen && disableOnInteract.isToggled()) {
                disableNext = true;
            }
        } else if (packet instanceof C07PacketPlayerDigging && disableOnBedBreak.isToggled()) {
            C07PacketPlayerDigging digging = (C07PacketPlayerDigging) packet;
            if (digging.getStatus() == C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK
                    && mc.theWorld.getBlockState(digging.getPosition()).getBlock() == Blocks.bed) {
                disableNext = true;
            }
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onGameTick(GameTickEvent event) {
        if (!isEnabled()) {
            return;
        }
        if (!Utils.nullCheck() || mc.isSingleplayer() || mc.thePlayer.isDead
                || mc.getNetHandler() != packetHandler || mc.theWorld != packetWorld) {
            discardPackets();
            disable();
            return;
        }
        if (frozen) {
            if (disableNext || (autoDisable.getInput() > 0 && ticks >= autoDisable.getInput() * 20.0)) {
                disable();
                return;
            }
            ++ticks;
        }
        updateText();
    }

    private void updateText() {
        text = frozen ? String.valueOf(autoDisable.getInput() > 0
                ? (int) (autoDisable.getInput() * 20.0) - ticks + 1 : ticks) : "idle";
    }

    private void startFreeze() {
        synchronized (packetLock) {
            if (!isEnabled() || frozen || mc.getNetHandler() != packetHandler || mc.theWorld != packetWorld) {
                return;
            }
            frozen = true;
            ticks = 0;
        }
        if (ModuleManager.knockbackDelay != null) {
            ModuleManager.knockbackDelay.flush();
        }
        if (ModuleManager.backtrack != null) {
            ModuleManager.backtrack.flush();
        }
    }

    private boolean isHitPacket(Packet<?> packet) {
        if (packet instanceof S12PacketEntityVelocity) {
            S12PacketEntityVelocity velocity = (S12PacketEntityVelocity) packet;
            return velocity.getEntityID() == mc.thePlayer.getEntityId() && velocity.getMotionY() != -627;
        }
        if (packet instanceof S1DPacketEntityEffect) {
            S1DPacketEntityEffect effect = (S1DPacketEntityEffect) packet;
            return effect.getEntityId() == mc.thePlayer.getEntityId()
                    && effect.getEffectId() == Potion.moveSlowdown.id && effect.getDuration() == 20
                    && Utils.getBedwarsStatus() == 2;
        }
        return false;
    }

    private boolean shouldUpdateImmediately(Packet<?> packet) {
        return updateChatMessages.isToggled() && packet instanceof S02PacketChat
                || updateBlockChanges.isToggled() && (packet instanceof S22PacketMultiBlockChange || packet instanceof S23PacketBlockChange)
                || updatePlayerHealth.isToggled() && packet instanceof S06PacketUpdateHealth
                || updatePlayerPositions.isToggled() && packet instanceof S14PacketEntity
                || updateScoreboard.isToggled() && (packet instanceof S3BPacketScoreboardObjective
                || packet instanceof S3CPacketUpdateScore || packet instanceof S3DPacketDisplayScoreboard || packet instanceof S3EPacketTeams)
                || updateSoundEffects.isToggled() && packet instanceof S29PacketSoundEffect;
    }

    private void discardPackets() {
        synchronized (packetLock) {
            heldPackets.clear();
            frozen = false;
            packetWorld = null;
        }
        clearKnockback();
    }

    @SuppressWarnings("unchecked")
    private void releasePackets() {
        List<Packet<?>> packets;
        NetHandlerPlayClient handler;
        WorldClient world;
        synchronized (packetLock) {
            if (releasing) {
                return;
            }
            releasing = true;
            frozen = false;
            packets = new ArrayList<>(heldPackets);
            heldPackets.clear();
            handler = packetHandler;
            world = packetWorld;
            packetHandler = null;
            packetWorld = null;
        }
        try {
            for (Packet<?> packet : packets) {
                if (!Utils.nullCheck() || handler == null || mc.getNetHandler() != handler || mc.theWorld != world) {
                    break;
                }
                try {
                    ReceivePacketEvent event = new ReceivePacketEvent(packet);
                    if (!MinecraftForge.EVENT_BUS.post(event)) {
                        ((Packet<INetHandlerPlayClient>) packet).processPacket(handler);
                    }
                } catch (ThreadQuickExitException ignored) {
                } catch (Exception exception) {
                    Utils.sendDebugMessage("Freeze failed to release " + packet.getClass().getSimpleName());
                }
            }
        } finally {
            releasing = false;
        }
    }

    private void clearKnockback() {
        knockback = false;
        knockbackX = 0.0;
        knockbackZ = 0.0;
    }

    @SubscribeEvent
    public void onRenderTick(TickEvent.RenderTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !Utils.nullCheck() || mc.currentScreen != null) {
            return;
        }
        long age = System.currentTimeMillis() - (shown ? shownAt : hiddenAt);
        int alpha = (int) (240.0 * (shown ? Math.min(1.0, age / 125.0) : Math.max(0.0, 1.0 - age / 125.0)));
        if (!shown && alpha <= 0) {
            text = null;
        }
        boolean drawArrow = showKnockbackDirection.isToggled() && knockback;
        boolean drawText = showFreezeTicks.isToggled() && text != null && alpha > 0
                && (ModuleManager.blink == null || !ModuleManager.blink.isEnabled());
        if (!drawArrow && !drawText) {
            return;
        }
        ScaledResolution resolution = new ScaledResolution(mc);
        int themeColor = Theme.getGradient(Theme.DEFAULT_THEME_INDEX, 0.0);
        boolean blend = GL11.glIsEnabled(GL11.GL_BLEND);
        boolean texture = GL11.glIsEnabled(GL11.GL_TEXTURE_2D);
        boolean alphaTest = GL11.glIsEnabled(GL11.GL_ALPHA_TEST);
        boolean lineSmooth = GL11.glIsEnabled(GL11.GL_LINE_SMOOTH);
        float lineWidth = GL11.glGetFloat(GL11.GL_LINE_WIDTH);
        int sourceRGB = GL11.glGetInteger(GL14.GL_BLEND_SRC_RGB);
        int destinationRGB = GL11.glGetInteger(GL14.GL_BLEND_DST_RGB);
        int sourceAlpha = GL11.glGetInteger(GL14.GL_BLEND_SRC_ALPHA);
        int destinationAlpha = GL11.glGetInteger(GL14.GL_BLEND_DST_ALPHA);
        GlStateManager.pushMatrix();
        try {
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ZERO);
            if (drawArrow) {
                renderArrow(resolution, themeColor);
            }
            if (drawText) {
                GlStateManager.enableTexture2D();
                GlStateManager.enableAlpha();
                float halfWidth = mc.fontRendererObj.getStringWidth(text) / 2.0f - 0.5f;
                mc.fontRendererObj.drawString(text, resolution.getScaledWidth() / 2.0f - halfWidth,
                        resolution.getScaledHeight() / 2.0f + 9.0f, Utils.mergeAlpha(themeColor, Math.max(4, alpha)), true);
            }
        } finally {
            GL11.glLineWidth(lineWidth);
            if (lineSmooth) GL11.glEnable(GL11.GL_LINE_SMOOTH); else GL11.glDisable(GL11.GL_LINE_SMOOTH);
            if (texture) GlStateManager.enableTexture2D(); else GlStateManager.disableTexture2D();
            if (alphaTest) GlStateManager.enableAlpha(); else GlStateManager.disableAlpha();
            GlStateManager.tryBlendFuncSeparate(sourceRGB, destinationRGB, sourceAlpha, destinationAlpha);
            if (blend) GlStateManager.enableBlend(); else GlStateManager.disableBlend();
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.popMatrix();
        }
    }

    private void renderArrow(ScaledResolution resolution, int themeColor) {
        double direction = Math.atan2(knockbackZ, knockbackX) - Math.toRadians(mc.thePlayer.rotationYaw + 90.0f);
        float sin = (float) Math.sin(direction);
        float cos = (float) -Math.cos(direction);
        float centerX = resolution.getScaledWidth() / 2.0f;
        float centerY = resolution.getScaledHeight() / 2.0f - 14.0f;
        float x1 = centerX - sin * 2.5f;
        float y1 = centerY - cos * 2.5f;
        float x2 = centerX + sin * 7.0f;
        float y2 = centerY + cos * 7.0f;
        float x3 = x2 - sin * 3.0f - cos * 1.95f;
        float y3 = y2 - cos * 3.0f + sin * 1.95f;
        float x4 = x2 - sin * 3.0f + cos * 1.95f;
        float y4 = y2 - cos * 3.0f - sin * 1.95f;
        GlStateManager.disableTexture2D();
        GlStateManager.disableAlpha();
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glLineWidth(3.5f);
        GlStateManager.color(0.0f, 0.0f, 0.0f, 176.0f / 255.0f);
        drawArrowLines(x1, y1, x2, y2, x3, y3, x4, y4);
        GL11.glLineWidth(1.75f);
        GlStateManager.color((themeColor >> 16 & 255) / 255.0f, (themeColor >> 8 & 255) / 255.0f,
                (themeColor & 255) / 255.0f, 1.0f);
        drawArrowLines(x1, y1, x2, y2, x3, y3, x4, y4);
        GL11.glBegin(GL11.GL_QUADS);
        GL11.glVertex2f(centerX - 1.75f, centerY - 1.75f);
        GL11.glVertex2f(centerX + 1.75f, centerY - 1.75f);
        GL11.glVertex2f(centerX + 1.75f, centerY + 1.75f);
        GL11.glVertex2f(centerX - 1.75f, centerY + 1.75f);
        GL11.glEnd();
    }

    private void drawArrowLines(float x1, float y1, float x2, float y2, float x3, float y3, float x4, float y4) {
        GL11.glBegin(GL11.GL_LINES);
        GL11.glVertex2f(x1, y1);
        GL11.glVertex2f(x2, y2);
        GL11.glVertex2f(x2, y2);
        GL11.glVertex2f(x3, y3);
        GL11.glVertex2f(x2, y2);
        GL11.glVertex2f(x4, y4);
        GL11.glEnd();
    }

    private static boolean blinksInbound() {
        Blink blink = ModuleManager.blink;
        return blink != null && blink.isEnabled() && blink.delaysInboundPackets();
    }

    @Override
    public String getInfo() {
        return ticks > 0 ? String.valueOf(ticks) : "Idle";
    }
}
