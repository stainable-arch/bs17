package keystrokesmod.module.impl.render;

import keystrokesmod.Raven;
import keystrokesmod.clickgui.ClickGui;
import keystrokesmod.clickgui.components.impl.CategoryComponent;
import keystrokesmod.clickgui.components.impl.ModuleComponent;
import keystrokesmod.module.Module;
import keystrokesmod.module.setting.Setting;
import keystrokesmod.module.setting.impl.ButtonSetting;
import keystrokesmod.module.setting.impl.ColorSetting;
import keystrokesmod.module.setting.impl.DescriptionSetting;
import keystrokesmod.module.setting.impl.GroupSetting;
import keystrokesmod.module.setting.impl.KeySetting;
import keystrokesmod.module.setting.impl.SliderSetting;
import keystrokesmod.module.setting.impl.TextSetting;
import keystrokesmod.utility.RenderUtils;
import keystrokesmod.utility.Utils;
import keystrokesmod.utility.font.FontManager;
import keystrokesmod.utility.font.RavenFontRenderer;
import keystrokesmod.utility.profile.ProfileModule;
import keystrokesmod.utility.shader.RoundedUtils;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

// Credit to Slinkware and Opus 4.8
public class SlinkyGui extends Module {
    private static final int TOGGLE_OFF = 0xFF404040;
    private static final int HOVER = 0xFF4C4C4C;
    private static final int TRACK = 0xFF2E2E2E;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int CHIP_BG = 0xFF333333;
    private static final int DIVIDER = 0x1AFFFFFF;
    private static final String[] CORNERS = {"Top left", "Top right", "Bottom left", "Bottom right"};

    private final KeySetting openKey;
    private final ButtonSetting replaceClickGui;
    private final ColorSetting accentColor;
    private final ColorSetting backgroundColor;
    private final ColorSetting textColorSetting;
    private final SliderSetting scaleSlider;
    private final SliderSetting fontSlider;
    private final ButtonSetting compactButton;
    private final SliderSetting widthSlider;
    private final SliderSetting columnsSlider;
    private final SliderSetting opacitySlider;
    private final SliderSetting dimSlider;
    private final ButtonSetting arraylistButton;
    private final SliderSetting arraylistCorner;
    private final ButtonSetting notificationsButton;
    private final SliderSetting notificationCorner;

    private boolean guiOpen;
    private int activeCategory;
    private final float[] scrolls = new float[24];
    private final Set<String> expanded = new HashSet<>();
    private final Map<String, Float> expandAnims = new HashMap<>();
    private final Set<String> colorExpanded = new HashSet<>();
    private float tabIndX, tabIndW;
    private boolean tabIndInit;
    private long lastFrame;
    private float dt;
    private float pageAnim = 1f;
    private int categoryDirection = 1;
    private final Map<String, Float> arrayWidths = new HashMap<>();
    private final String[] notifNames = new String[16];
    private final boolean[] notifStates = new boolean[16];
    private final long[] notifTimes = new long[16];
    private int notifCount;
    private final Map<String, Boolean> enableStates = new HashMap<>();
    private boolean notifInit;
    private final Set<String> hiddenByArraylist = new HashSet<>();
    private final Map<String, Boolean> userHidden = new HashMap<>();
    private final List<Module> allModules = new ArrayList<>();
    private boolean visInit;
    private Module bindModule;
    private KeySetting bindKey;
    private TextSetting textEditing;
    private String textBuffer = "";
    private SliderSetting dragSlider;
    private boolean tooltipActive;
    private float tooltipX, tooltipY;
    private String tooltipText = "";
    private boolean tooltipOff;
    private ButtonSetting pendingButton;
    private ColorSetting dragColor;
    private int dragChannel = -1;
    private boolean scrollDrag;
    private float scrollDragOffset;
    private long lastToggle;
    private boolean prevLeftDown, prevRightDown, leftDown, clicked, released, rightClicked, prevOpenKey;
    private float mouseX, mouseY;
    private int screenW = 1, screenH = 1, scaleFactor = 1;
    private float uiScale = 1f;
    private int accent = 0xFFE7090A;
    private boolean compact;
    private String fontName = "Sf-Regular";
    private RavenFontRenderer f125, f105, f095;
    private float panelX, panelW = 100f, contentTop, contentBottom, cardWidth = 40f;
    private int columns = 2;
    private float panelXBase;
    private float widthFrac = -1f;
    private int columnsCache = -1;
    private float openAnim;
    private float gap = 12f;
    private float maxContentHeight;
    private boolean scissorActive;
    private int panelBg = 0xF2202020, solidBg = 0xFF202020, opacityAlpha = 255;
    private int textColor = 0xFFE3DAD3, textDim = 0xFFA1A1A1, textDimmer = 0xFF6E6E72;

    public SlinkyGui() {
        super("SlinkyGui", category.render);
        this.registerSetting(new DescriptionSetting("Slinky-style menu. Default bind: RSHIFT."));
        this.registerSetting(openKey = new KeySetting("Open menu", 54));
        this.registerSetting(scaleSlider = new SliderSetting("Scale", "x", 0.9, 0.6, 1.6, 0.05));
        String[] fonts = FontManager.getHudFontOptions();
        int defaultFont = 0;
        for (int i = 0; i < fonts.length; i++) {
            if (fonts[i].equals("Sf-Regular")) {
                defaultFont = i;
            }
        }
        this.registerSetting(fontSlider = new SliderSetting("Font", defaultFont, fonts));
        this.registerSetting(widthSlider = new SliderSetting("Width", "%", 50.0, 40.0, 92.0, 1.0));
        this.registerSetting(columnsSlider = new SliderSetting("Columns", "", 2.0, 1.0, 4.0, 1.0));
        this.registerSetting(opacitySlider = new SliderSetting("Opacity", "%", 98.0, 40.0, 100.0, 1.0));
        this.registerSetting(dimSlider = new SliderSetting("Background dim", "", 35.0, 0.0, 220.0, 5.0));
        this.registerSetting(arraylistCorner = new SliderSetting("Arraylist corner", 1, CORNERS));
        this.registerSetting(notificationCorner = new SliderSetting("Notification corner", 3, CORNERS));
        this.registerSetting(accentColor = new ColorSetting("Accent color", 255, 115, 15));
        this.registerSetting(backgroundColor = new ColorSetting("Background color", 22, 22, 22));
        this.registerSetting(textColorSetting = new ColorSetting("Text color", 220, 220, 220));
        this.registerSetting(replaceClickGui = new ButtonSetting("Replace ClickGUI", true));
        this.registerSetting(compactButton = new ButtonSetting("Compact", false));
        this.registerSetting(arraylistButton = new ButtonSetting("Arraylist", true));
        this.registerSetting(notificationsButton = new ButtonSetting("Notifications", true));
    }

    @Override
    public void onDisable() {
        if (guiOpen) {
            closeGui();
        }
        if (!hiddenByArraylist.isEmpty()) {
            restoreHidden();
        }
    }

    private class SlinkyScreen extends GuiScreen {
        @Override
        public boolean doesGuiPauseGame() {
            return false;
        }

        @Override
        protected void keyTyped(char typedChar, int keyCode) throws IOException {
            handleKey(typedChar, keyCode);
        }

        @Override
        protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        }

        @Override
        public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        }
    }

    private void handleKey(char typed, int key) {
        if (!guiOpen) {
            return;
        }
        if (textEditing != null) {
            if (key == 1) {
                textEditing = null;
                textBuffer = "";
            } else if (key == 28 || key == 156) {
                textEditing.setText(textBuffer);
                textEditing.submit();
                textEditing = null;
                textBuffer = "";
            } else if (key == 14) {
                if (textBuffer.length() > 0) {
                    textBuffer = textBuffer.substring(0, textBuffer.length() - 1);
                }
            } else if (typed >= ' ' && typed != (char) 127 && textBuffer.length() < textEditing.getMaxLength()) {
                textBuffer = textBuffer + typed;
            }
            return;
        }
        if (bindModule != null || bindKey != null) {
            finishBind(key == 1 ? 0 : key);
            return;
        }
        if (key == 1) {
            closeGui();
        }
    }

    private void finishBind(int key) {
        if (bindKey != null) {
            bindKey.setKey(key);
        } else if (bindModule != null) {
            bindModule.setBind(key);
        }
        bindKey = null;
        bindModule = null;
    }

    private void handleBindMouse() {
        if (bindModule == null && bindKey == null) {
            return;
        }
        for (int button = 2; button <= 4; button++) {
            if (Mouse.isButtonDown(button)) {
                finishBind(1000 + button);
                return;
            }
        }
    }

    @SubscribeEvent
    public void onRenderTick(TickEvent.RenderTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !Utils.nullCheck()) {
            return;
        }
        mc.entityRenderer.setupOverlayRendering();
        ScaledResolution sr = new ScaledResolution(mc);
        screenW = sr.getScaledWidth();
        screenH = sr.getScaledHeight();
        scaleFactor = sr.getScaleFactor();

        boolean keyDown = openKey.isPressed();
        long now = System.currentTimeMillis();
        if (keyDown && !prevOpenKey && now - lastToggle > 150L) {
            lastToggle = now;
            if (guiOpen) {
                closeGui();
            } else {
                openGui();
            }
        }
        prevOpenKey = keyDown;
        if (replaceClickGui.isToggled() && mc.currentScreen instanceof ClickGui) {
            mc.displayGuiScreen(null);
            openGui();
        }

        if (lastFrame == 0L) {
            lastFrame = now;
        }
        dt = (float) (now - lastFrame) / 1000f;
        if (dt < 0f) {
            dt = 0f;
        }
        if (dt > 0.1f) {
            dt = 0.1f;
        }
        lastFrame = now;

        uiScale = currentScale();
        accent = 0xFF000000 | (accentColor.getColor() & 0x00FFFFFF);
        int text = textColorSetting.getColor() & 0x00FFFFFF;
        textColor = 0xFF000000 | text;
        textDim = 0xFF000000 | scaleColor(text, 0.66f);
        textDimmer = 0xFF000000 | scaleColor(text, 0.45f);
        opacityAlpha = (int) (opacitySlider.getInput() / 100.0 * 255.0);
        if (opacityAlpha < 0) {
            opacityAlpha = 0;
        }
        if (opacityAlpha > 255) {
            opacityAlpha = 255;
        }
        int bg = backgroundColor.getColor() & 0x00FFFFFF;
        panelBg = (opacityAlpha << 24) | bg;
        solidBg = 0xFF000000 | bg;
        String[] fontOptions = fontSlider.getOptions();
        if (fontOptions != null && fontOptions.length > 0) {
            fontName = fontOptions[(int) Math.max(0, Math.min(fontOptions.length - 1, fontSlider.getInput()))];
        }
        f125 = fontFor(1.25f);
        f105 = fontFor(1.05f);
        f095 = fontFor(0.95f);
        refreshModuleList();
        trackNotifications();
        arraylistVisibility();

        boolean showArraylist = arraylistButton.isToggled();
        boolean showNotifications = notificationsButton.isToggled();
        if (showArraylist || showNotifications) {
            GL11.glDisable(GL11.GL_DEPTH_TEST);
            GL11.glDepthMask(false);
            if (showArraylist) {
                drawArraylist();
            }
            if (showNotifications) {
                drawNotifications();
            }
            GL11.glDepthMask(true);
            GL11.glEnable(GL11.GL_DEPTH_TEST);
        }
        if (!guiOpen) {
            return;
        }
        if (!(mc.currentScreen instanceof SlinkyScreen)) {
            guiOpen = false;
            resetInteraction();
            return;
        }
        updateMouse();
        drawGui();
    }

    private void openGui() {
        guiOpen = true;
        panelXBase = 0f;
        tabIndInit = false;
        openAnim = 0f;
        resetInteraction();
        prevLeftDown = Mouse.isButtonDown(0);
        prevRightDown = Mouse.isButtonDown(1);
        Mouse.getDWheel();
        mc.displayGuiScreen(new SlinkyScreen());
    }

    private void closeGui() {
        guiOpen = false;
        resetInteraction();
        if (mc.currentScreen instanceof SlinkyScreen) {
            mc.displayGuiScreen(null);
        }
    }

    private void resetInteraction() {
        bindModule = null;
        bindKey = null;
        textEditing = null;
        textBuffer = "";
        dragSlider = null;
        dragColor = null;
        dragChannel = -1;
        scrollDrag = false;
        scissorActive = false;
        GL11.glDisable(GL11.GL_SCISSOR_TEST);
    }

    private void updateMouse() {
        mouseX = (float) Mouse.getX() / (float) scaleFactor;
        mouseY = (float) screenH - ((float) Mouse.getY() / (float) scaleFactor) - 1f;
        leftDown = Mouse.isButtonDown(0);
        boolean rightDown = Mouse.isButtonDown(1);
        clicked = leftDown && !prevLeftDown;
        released = !leftDown && prevLeftDown;
        rightClicked = rightDown && !prevRightDown;
        prevLeftDown = leftDown;
        prevRightDown = rightDown;
    }

    private float currentScale() {
        float v = (float) scaleSlider.getInput();
        if (v <= 0.1f) {
            v = 1f;
        }
        return v;
    }

    private RavenFontRenderer fontFor(float scale) {
        float s = scale * uiScale;
        if (s < 0.5f) {
            s = 0.5f;
        }
        if (s > 2.0f) {
            s = 2.0f;
        }
        return FontManager.getHudRenderer(fontName, s);
    }

    private float approach(float current, float target, float speed) {
        float t = 1f - (float) Math.pow(0.0025, dt * speed);
        if (t < 0f) {
            t = 0f;
        }
        if (t > 1f) {
            t = 1f;
        }
        float next = current + (target - current) * t;
        if (Math.abs(target - next) < 0.001f) {
            next = target;
        }
        return next;
    }

    private float smooth(float v) {
        if (v < 0f) {
            v = 0f;
        }
        if (v > 1f) {
            v = 1f;
        }
        return v * v * (3f - 2f * v);
    }

    private float stepExpand(String key, boolean open) {
        Float stored = expandAnims.get(key);
        float value = stored == null ? (open ? 1f : 0f) : stored;
        value = approach(value, open ? 1f : 0f, 3.2f);
        if (value <= 0.0005f && !open) {
            expandAnims.remove(key);
            return 0f;
        }
        expandAnims.put(key, value);
        return value;
    }

    private int scaleColor(int rgb, float factor) {
        int r = Math.min(255, (int) (((rgb >> 16) & 255) * factor));
        int g = Math.min(255, (int) (((rgb >> 8) & 255) * factor));
        int b = Math.min(255, (int) ((rgb & 255) * factor));
        return (r << 16) | (g << 8) | b;
    }

    private int lighten(int rgb, int amount) {
        int r = Math.max(0, Math.min(255, ((rgb >> 16) & 255) + amount));
        int g = Math.max(0, Math.min(255, ((rgb >> 8) & 255) + amount));
        int b = Math.max(0, Math.min(255, (rgb & 255) + amount));
        return (r << 16) | (g << 8) | b;
    }

    private int argb(int a, int r, int g, int b) {
        return ((a & 255) << 24) | ((r & 255) << 16) | ((g & 255) << 8) | (b & 255);
    }

    private boolean hover(float x, float y, float w, float h) {
        if (mouseX < x || mouseX > x + w || mouseY < y || mouseY > y + h) {
            return false;
        }
        return !scissorActive || (mouseY >= contentTop && mouseY <= contentBottom);
    }

    private boolean click(float x, float y, float w, float h) {
        if (!clicked || !hover(x, y, w, h)) {
            return false;
        }
        clicked = false;
        return true;
    }

    private void beginScissor(float x, float y, float w, float h) {
        if (w < 0f) {
            w = 0f;
        }
        if (h < 0f) {
            h = 0f;
        }
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        GL11.glScissor((int) (x * scaleFactor), (int) (((float) screenH - (y + h)) * scaleFactor), (int) (w * scaleFactor), (int) (h * scaleFactor));
        scissorActive = true;
    }

    private void endScissor() {
        scissorActive = false;
        GL11.glDisable(GL11.GL_SCISSOR_TEST);
    }

    private void drawText(RavenFontRenderer font, String text, float x, float y, int color) {
        if (font == null || text == null || text.length() == 0) {
            return;
        }
        font.drawString(text, x, y - (float) font.getFontHeight() / 2f, color, false);
    }

    private float textWidth(RavenFontRenderer font, String text) {
        if (font == null || text == null) {
            return 0f;
        }
        return (float) font.getStringWidth(text);
    }

    private String ellipsize(RavenFontRenderer font, String text, float maxWidth) {
        if (font == null || text == null || maxWidth <= 0f) {
            return "";
        }
        if (textWidth(font, text) <= maxWidth) {
            return text;
        }
        String cut = text;
        while (cut.length() > 1 && textWidth(font, cut + "..") > maxWidth) {
            cut = cut.substring(0, cut.length() - 1);
        }
        return cut + "..";
    }

    private String tailFit(RavenFontRenderer font, String text, float maxWidth) {
        if (font == null || text == null || maxWidth <= 0f) {
            return "";
        }
        String cut = text;
        while (cut.length() > 1 && textWidth(font, cut) > maxWidth) {
            cut = cut.substring(1);
        }
        return cut;
    }

    private String capitalize(String s) {
        if (s == null || s.length() == 0) {
            return "";
        }
        return s.substring(0, 1).toUpperCase() + s.substring(1);
    }

    private String formatNumber(double v) {
        if (v == Math.rint(v) && Math.abs(v) < 1.0E9D) {
            return Integer.toString((int) v);
        }
        return Double.toString(Math.round(v * 100.0) / 100.0);
    }

    private String keyName(int key) {
        if (key == 0) {
            return "NONE";
        }
        if (key == 1069) {
            return "SCROLL UP";
        }
        if (key == 1070) {
            return "SCROLL DOWN";
        }
        if (key >= 1000) {
            return "MOUSE" + (key - 999);
        }
        String name = Keyboard.getKeyName(key);
        return name == null ? "KEY" + key : name.toUpperCase();
    }

    private void drawPanelBox(float x1, float y1, float x2, float y2, float radius, boolean lighter) {
        int outer = 0xFF000000 | lighten(panelBg & 0x00FFFFFF, lighter ? 34 : 22);
        int inner = 0xFF000000 | (panelBg & 0x00FFFFFF);
        float inset = 1f * uiScale;
        RoundedUtils.drawRoundedRectRise(x1, y1, x2 - x1, y2 - y1, radius, outer);
        RoundedUtils.drawRoundedRectRise(x1 + inset, y1 + inset, x2 - x1 - 2f * inset, y2 - y1 - 2f * inset, radius - inset, inner);
    }

    private void roundRect(float x1, float y1, float x2, float y2, float radius, int color) {
        RoundedUtils.drawRoundedRectRise(x1, y1, x2 - x1, y2 - y1, radius, color);
    }

    private void rect(float x1, float y1, float x2, float y2, int color) {
        RenderUtils.drawRect(x1, y1, x2, y2, color);
    }

    private void markUnsaved(Module module) {
        if (Raven.currentProfile == null || module.ignoreOnSave) {
            return;
        }
        if (Raven.currentProfile.getModule() != null) {
            Raven.currentProfile.getModule().saved = false;
        }
    }

    private GroupSetting groupOf(Setting setting) {
        if (setting instanceof SliderSetting) {
            return ((SliderSetting) setting).groupSetting;
        }
        if (setting instanceof ButtonSetting) {
            return ((ButtonSetting) setting).group;
        }
        if (setting instanceof ColorSetting) {
            return ((ColorSetting) setting).groupSetting;
        }
        if (setting instanceof KeySetting) {
            return ((KeySetting) setting).group;
        }
        if (setting instanceof TextSetting) {
            return ((TextSetting) setting).group;
        }
        return null;
    }

    private String categoryLabelOf(Module module) {
        if (ClickGui.categories == null) {
            return "";
        }
        for (CategoryComponent component : ClickGui.categories) {
            if (component == null || component.category == null) {
                continue;
            }
            for (ModuleComponent mc : component.modules) {
                if (mc != null && mc.mod == module) {
                    return capitalize(component.category.name());
                }
            }
        }
        return "";
    }

    private String descriptionOf(Module module) {
        List<Setting> settings = module.getSettings();
        if (!settings.isEmpty() && settings.get(0) instanceof DescriptionSetting) {
            String desc = ((DescriptionSetting) settings.get(0)).getDesc();
            if (desc != null && desc.length() > 0) {
                return desc;
            }
        }
        String label = categoryLabelOf(module);
        if (label.length() > 0) {
            return module.getName() + " - " + label.toLowerCase() + " module.";
        }
        return "Toggle to use " + module.getName() + ".";
    }

    private List<String> categoryNames() {
        List<String> names = new ArrayList<>();
        if (ClickGui.categories == null) {
            return names;
        }
        for (CategoryComponent component : ClickGui.categories) {
            if (component != null && component.category != null) {
                names.add(component.category.name());
            }
        }
        return names;
    }

    private List<Module> modulesOfCategory(int index) {
        List<Module> list = new ArrayList<>();
        if (ClickGui.categories == null) {
            return list;
        }
        int i = 0;
        for (CategoryComponent component : ClickGui.categories) {
            if (i == index && component != null) {
                for (ModuleComponent mc : component.modules) {
                    if (mc != null && mc.mod != null) {
                        list.add(mc.mod);
                    }
                }
            }
            i++;
        }
        return list;
    }

    private boolean isUserHidden(Module module) {
        return Boolean.TRUE.equals(userHidden.get(module.getName()));
    }

    private void drawGui() {
        compact = compactButton.isToggled();
        int dim = (int) dimSlider.getInput();
        if (dim > 0) {
            rect(0f, 0f, (float) screenW, (float) screenH, argb(dim, 0, 0, 0));
        }
        if (dragSlider == null || widthFrac < 0f) {
            widthFrac = (float) widthSlider.getInput() / 100f;
        }
        panelW = (float) screenW * widthFrac;
        if (panelW > (float) screenW - 12f) {
            panelW = (float) screenW - 12f;
        }
        float targetX = ((float) screenW - panelW) / 2f;
        if (panelXBase <= 0f) {
            panelXBase = targetX;
        } else {
            panelXBase = approach(panelXBase, targetX, 14f);
        }
        openAnim = approach(openAnim, 1f, 3.5f);
        float slide = (1f - smooth(openAnim)) * ((float) screenW - panelXBase + 10f * uiScale);
        panelX = panelXBase + slide;
        float tabsH = 27f * uiScale;
        float topGap = 9f * uiScale;
        if (topGap > (float) screenH * 0.05f) {
            topGap = (float) screenH * 0.05f;
        }
        contentTop = topGap + tabsH + 7f * uiScale;
        contentBottom = (float) screenH - 8f * uiScale;
        if (contentBottom < contentTop + 20f) {
            contentBottom = contentTop + 20f;
        }
        gap = 12f * uiScale;
        if (dragSlider == null || columnsCache < 0) {
            columnsCache = (int) columnsSlider.getInput();
            if (columnsCache < 1) {
                columnsCache = 1;
            }
            if (columnsCache > 4) {
                columnsCache = 4;
            }
        }
        columns = columnsCache;
        cardWidth = (panelW - gap * (float) (columns - 1)) / (float) columns;
        handleBindMouse();
        drawTabs(topGap, tabsH);
        if (!guiOpen) {
            return;
        }
        drawModulesPage();
        clicked = false;
        rightClicked = false;
        if (released) {
            dragSlider = null;
            dragColor = null;
            dragChannel = -1;
            scrollDrag = false;
        }
        if (pendingButton != null) {
            ButtonSetting button = pendingButton;
            pendingButton = null;
            restoreHidden();
            try {
                button.runMethod();
            } catch (Throwable ignored) {
            }
        }
    }

    private void drawTabs(float topGap, float tabsH) {
        List<String> names = categoryNames();
        int n = names.size();
        roundRect(panelX, topGap, panelX + panelW, topGap + tabsH, tabsH / 2f, panelBg);
        if (n == 0) {
            return;
        }
        float innerPad = 4.5f * uiScale;
        float midY = topGap + tabsH / 2f;
        float pillH = tabsH - 2f * innerPad;
        float pillR = pillH / 2f;
        float tabPad = 10f * uiScale;
        float tabGap = 4f * uiScale;
        float edge = innerPad;
        float avail = panelW - 2f * edge;
        float fontScale = 1.25f;
        RavenFontRenderer font = fontFor(fontScale);
        for (int attempt = 0; attempt < 24; attempt++) {
            float total = 0f;
            for (int i = 0; i < n; i++) {
                total += textWidth(font, capitalize(names.get(i)));
            }
            total += 2f * tabPad * (float) n + tabGap * (float) (n - 1);
            if (total <= avail || fontScale <= 0.5f) {
                break;
            }
            fontScale *= (avail / total);
            if (fontScale < 0.5f) {
                fontScale = 0.5f;
            }
            font = fontFor(fontScale);
        }
        float[] widths = new float[n];
        float total = 0f;
        for (int i = 0; i < n; i++) {
            widths[i] = textWidth(font, capitalize(names.get(i))) + 2f * tabPad;
            total += widths[i];
        }
        total += tabGap * (float) (n - 1);
        if (total > avail) {
            float textSum = 0f;
            for (int i = 0; i < n; i++) {
                textSum += textWidth(font, capitalize(names.get(i)));
            }
            float free = avail - textSum;
            if (free < 0f) {
                free = 0f;
            }
            float gapTotal = free * 0.25f;
            tabGap = n > 1 ? (gapTotal / (float) (n - 1)) : 0f;
            tabPad = (free - gapTotal) / (2f * (float) n);
            if (tabPad < 0f) {
                tabPad = 0f;
            }
            total = textSum + 2f * tabPad * (float) n + tabGap * (float) (n - 1);
            for (int i = 0; i < n; i++) {
                widths[i] = textWidth(font, capitalize(names.get(i))) + 2f * tabPad;
            }
        }
        float left = panelX + edge;
        float right = panelX + panelW - edge;
        float availWidth = right - left;
        float textTotal = total - tabGap * (float) (n - 1);
        float baseGap = tabGap;
        if (n > 1) {
            tabGap = (availWidth - textTotal) / (float) (n - 1);
            if (tabGap < baseGap) {
                tabGap = baseGap;
            }
        }
        float totalWidth = textTotal + tabGap * (float) (n - 1);
        float startX = left;
        if (totalWidth < availWidth) {
            startX = left + (availWidth - totalWidth) / 2f;
        }
        float[] xs = new float[n];
        float cursor = startX;
        for (int i = 0; i < n; i++) {
            xs[i] = cursor;
            cursor += widths[i] + tabGap;
        }
        if (activeCategory >= 0 && activeCategory < n) {
            float targetX = xs[activeCategory];
            float targetW = widths[activeCategory];
            if (!tabIndInit) {
                tabIndX = targetX;
                tabIndW = targetW;
                tabIndInit = true;
            }
            tabIndX = approach(tabIndX, targetX, 5.0f);
            tabIndW = approach(tabIndW, targetW, 5.0f);
            roundRect(tabIndX, topGap + innerPad, tabIndX + tabIndW, topGap + innerPad + pillH, pillR, TOGGLE_OFF);
        }
        for (int i = 0; i < n; i++) {
            String name = names.get(i);
            String label = capitalize(name);
            boolean scripts = name.equalsIgnoreCase("scripts");
            boolean active = i == activeCategory;
            boolean hovered = hover(xs[i], topGap + innerPad, widths[i], pillH);
            if (hovered && !active) {
                roundRect(xs[i], topGap + innerPad, xs[i] + widths[i], topGap + innerPad + pillH, pillR, 0x14FFFFFF);
            }
            float tw = textWidth(font, label);
            int color = scripts ? accent : (active ? textColor : textDim);
            drawText(font, label, xs[i] + widths[i] / 2f - tw / 2f, midY, color);
            if (click(xs[i], topGap, widths[i], tabsH) && i != activeCategory) {
                categoryDirection = i > activeCategory ? 1 : -1;
                activeCategory = i;
                pageAnim = 0f;
                scrollDrag = false;
            }
        }
    }

    private void drawModulesPage() {
        tooltipActive = false;
        pageAnim = approach(pageAnim, 1f, 4.0f);
        float eased = smooth(pageAnim);
        float slideX = (1f - eased) * (float) categoryDirection * (panelW * 0.07f + 18f * uiScale);
        List<Module> mods = modulesOfCategory(activeCategory);
        int count = mods.size();
        float scroll = scrolls[activeCategory % scrolls.length];
        float viewH = contentBottom - contentTop;
        float rowGap = 6f * uiScale;
        float[] colX = new float[count];
        float[] colY = new float[count];
        float[] heights = new float[count];
        int cols = columns;
        float[] colHeights = new float[cols];
        for (int i = 0; i < count; i++) {
            Module m = mods.get(i);
            float h = cardHeight(m, activeCategory);
            int c = i % cols;
            colX[i] = panelX + (float) c * (cardWidth + gap);
            colY[i] = colHeights[c];
            heights[i] = h;
            colHeights[c] += h + rowGap;
        }
        maxContentHeight = 0f;
        for (int c = 0; c < cols; c++) {
            if (colHeights[c] > maxContentHeight) {
                maxContentHeight = colHeights[c];
            }
        }
        float maxScroll = maxContentHeight - viewH;
        if (maxScroll < 0f) {
            maxScroll = 0f;
        }
        int wheel = Mouse.getDWheel();
        if (wheel != 0 && mouseX >= panelX && mouseX <= panelX + panelW) {
            scroll -= (float) wheel / 6f;
        }
        if (scroll > maxScroll) {
            scroll = maxScroll;
        }
        if (scroll < 0f) {
            scroll = 0f;
        }
        if (maxScroll > 0f) {
            float barX = panelX + panelW + 3f * uiScale;
            float barW = 3f * uiScale;
            float thumbH = viewH * (viewH / maxContentHeight);
            if (thumbH < 16f * uiScale) {
                thumbH = 16f * uiScale;
            }
            float thumbY = contentTop + (viewH - thumbH) * (scroll / maxScroll);
            roundRect(barX, contentTop, barX + barW, contentBottom, barW / 2f, 0x22FFFFFF);
            roundRect(barX, thumbY, barX + barW, thumbY + thumbH, barW / 2f, scrollDrag ? accent : 0x77FFFFFF);
            if (clicked && hover(barX - 4f * uiScale, contentTop, barW + 8f * uiScale, viewH)) {
                clicked = false;
                scrollDrag = true;
                scrollDragOffset = (mouseY >= thumbY && mouseY <= thumbY + thumbH) ? (mouseY - thumbY) : (thumbH / 2f);
            }
            if (scrollDrag && leftDown) {
                float track = viewH - thumbH;
                scroll = track <= 0f ? 0f : ((mouseY - scrollDragOffset - contentTop) / track) * maxScroll;
                if (scroll < 0f) {
                    scroll = 0f;
                }
                if (scroll > maxScroll) {
                    scroll = maxScroll;
                }
            }
        } else {
            scrollDrag = false;
        }
        scrolls[activeCategory % scrolls.length] = scroll;
        if (count == 0) {
            drawText(f105, "No modules on this page.", panelX + 4f * uiScale, contentTop + 10f * uiScale, textDimmer);
            return;
        }
        beginScissor(panelX - 4f * uiScale, contentTop, panelW + 12f * uiScale, contentBottom - contentTop);
        try {
            for (int i = 0; i < count; i++) {
                float cardY = contentTop + colY[i] - scroll;
                if (cardY > contentBottom || cardY + heights[i] < contentTop) {
                    continue;
                }
                Module m = mods.get(i);
                try {
                    drawModuleCard(m, colX[i] + slideX, cardY, cardWidth, activeCategory);
                } catch (Throwable t) {
                    reportError(m, t);
                }
            }
        } finally {
            endScissor();
        }
        if (tooltipActive) {
            float pad = 5f * uiScale;
            float h = 12f * uiScale;
            float w = textWidth(f095, tooltipText) + 2f * pad;
            float y = tooltipY;
            if (y < contentTop) {
                y = contentTop;
            }
            if (y + h > contentBottom) {
                y = contentBottom - h;
            }
            drawPanelBox(tooltipX, y, tooltipX + w, y + h, 3f * uiScale, false);
            drawText(f095, tooltipText, tooltipX + pad, y + h / 2f, tooltipOff ? textDimmer : textColor);
        }
    }

    private void reportError(Module module, Throwable t) {
        Utils.sendMessage("&cSlinky: '" + (module == null ? "module" : module.getName()) + "' errored (" + (t == null ? "unknown error" : t.getClass().getSimpleName()) + ") - skipped to avoid a crash.");
    }

    private float cardHeight(Module module, int cat) {
        float base = compact ? (26f * uiScale) : (22f * uiScale + 20f * uiScale);
        String key = cat + ":" + module.getName();
        boolean isExpanded = expanded.contains(key);
        Float stored = expandAnims.get(key);
        float value = stored == null ? (isExpanded ? 1f : 0f) : stored;
        float eased = smooth(value);
        if (eased > 0.0005f) {
            base += (settingsHeight(module) + 6f * uiScale) * eased;
        }
        return base;
    }

    private void drawModuleCard(Module mod, float x, float y, float w, int cat) {
        String key = cat + ":" + mod.getName();
        boolean isExpanded = expanded.contains(key);
        float h = cardHeight(mod, cat);
        roundRect(x, y, x + w, y + h, 11f * uiScale, panelBg);
        float headerH = 22f * uiScale;
        float r = 11f * uiScale;
        float midY = y + headerH / 2f + 1.5f * uiScale;
        boolean canToggle = mod.canBeEnabled();
        float switchW = 26f * uiScale;
        float switchH = 13f * uiScale;
        float switchX = x + w - r - switchW;
        float switchY = midY - switchH / 2f;
        if (canToggle) {
            boolean on = mod.isEnabled();
            roundRect(switchX, switchY, switchX + switchW, switchY + switchH, switchH / 2f, on ? accent : TOGGLE_OFF);
            float knob = switchH - 3f * uiScale;
            float knobX = on ? (switchX + switchW - knob - 1.5f * uiScale) : (switchX + 1.5f * uiScale);
            roundRect(knobX, switchY + 1.5f * uiScale, knobX + knob, switchY + switchH - 1.5f * uiScale, knob / 2f, solidBg);
            if (click(switchX - 3f * uiScale, switchY - 4f * uiScale, switchW + 6f * uiScale, switchH + 8f * uiScale)) {
                toggleModule(mod);
            }
        }
        float btn = 11f * uiScale;
        float rightEdge = canToggle ? switchX : (x + w - r);
        if (compact && canToggle) {
            rightEdge = switchX - btn - 8f * uiScale;
        }
        float nameX = x + r;
        float nameMaxW = rightEdge - nameX - 6f * uiScale;
        String nameStr = ellipsize(f125, mod.getName(), nameMaxW * 0.72f);
        drawText(f125, nameStr, nameX, midY, textColor);
        boolean bindingThis = bindModule == mod && bindKey == null;
        String bindText = bindingThis ? "..." : keyName(mod.getKeycode());
        float chipPad = 4f * uiScale;
        float chipX = nameX + textWidth(f125, nameStr) + 6f * uiScale;
        float chipW = textWidth(f095, bindText) + 2f * chipPad;
        float chipH = 12f * uiScale;
        float chipY = midY - chipH / 2f;
        if (canToggle && chipX + chipW < rightEdge - 4f * uiScale) {
            boolean bound = mod.getKeycode() != 0;
            roundRect(chipX, chipY, chipX + chipW, chipY + chipH, 4f * uiScale, CHIP_BG);
            drawText(f095, bindText, chipX + chipPad, midY, bindingThis ? textColor : (bound ? accent : textDim));
            if (click(chipX - 2f * uiScale, chipY - 2f * uiScale, chipW + 4f * uiScale, chipH + 4f * uiScale)) {
                if (bindingThis) {
                    mod.setBind(0);
                    bindModule = null;
                } else {
                    bindModule = mod;
                    bindKey = null;
                    textEditing = null;
                }
            } else if (bindingThis && rightClicked && hover(chipX - 2f * uiScale, chipY - 2f * uiScale, chipW + 4f * uiScale, chipH + 4f * uiScale)) {
                rightClicked = false;
                mod.setBind(0);
                bindModule = null;
            }
        }
        float expBtn = compact ? btn : (13f * uiScale);
        float expX;
        float expY;
        if (compact) {
            expX = switchX - expBtn - 8f * uiScale;
            expY = midY - expBtn / 2f;
        } else {
            expX = x + r;
            expY = y + headerH + 1f * uiScale;
        }
        boolean hoverExp = hover(expX, expY, expBtn, expBtn);
        roundRect(expX, expY, expX + expBtn, expY + expBtn, 3f * uiScale, hoverExp ? HOVER : TOGGLE_OFF);
        String symbol = isExpanded ? "-" : "+";
        drawText(f105, symbol, expX + expBtn / 2f - textWidth(f105, symbol) / 2f, expY + expBtn / 2f, textColor);
        if (!compact) {
            String desc = descriptionOf(mod);
            if (desc.length() > 0) {
                float descX = expX + expBtn + 5f * uiScale;
                drawText(f095, ellipsize(f095, desc, x + w - descX - r), descX, expY + expBtn / 2f, textDim);
            }
        }
        if (click(expX - 3f * uiScale, expY - 3f * uiScale, expBtn + 6f * uiScale, expBtn + 6f * uiScale)) {
            if (isExpanded) {
                expanded.remove(key);
                if (!expandAnims.containsKey(key)) {
                    expandAnims.put(key, 1f);
                }
            } else {
                expanded.add(key);
                expandAnims.put(key, 0f);
            }
            return;
        }
        float anim = stepExpand(key, isExpanded);
        float eased = smooth(anim);
        if (eased > 0.0005f) {
            float settingsY = compact ? (y + headerH + 4f * uiScale) : (expY + expBtn + 6f * uiScale);
            float full = settingsHeight(mod);
            float shown = full * eased;
            float inset = r - 3f * uiScale;
            rect(x + inset, settingsY - 3f * uiScale, x + w - inset, settingsY - 3f * uiScale + 1f, DIVIDER);
            boolean hadScissor = scissorActive;
            beginScissor(x, settingsY - 2f * uiScale, w, shown + 2f * uiScale);
            drawSettings(mod, x + inset, settingsY, w - 2f * inset);
            endScissor();
            if (hadScissor) {
                beginScissor(panelX - 4f * uiScale, contentTop, panelW + 12f * uiScale, contentBottom - contentTop);
            }
        }
    }

    private void toggleModule(Module module) {
        if (module instanceof ProfileModule) {
            if (Raven.profileManager == null) {
                return;
            }
            String name = module.getName();
            keystrokesmod.utility.profile.Profile profile = Raven.profileManager.getProfile(name);
            Raven.profileManager.loadProfile(name);
            if (profile != null) {
                Raven.currentProfile = profile;
            }
            resetStates();
            ((ProfileModule) module).saved = true;
            Utils.sendMessage("&7Enabled profile: &b" + name);
            return;
        }
        try {
            module.toggle();
        } catch (Throwable t) {
            reportError(module, t);
            return;
        }
        markUnsaved(module);
    }

    private float settingsHeight(Module module) {
        float total = 0f;
        List<Setting> settings = module.getSettings();
        for (int i = 0; i < settings.size(); i++) {
            Setting setting = settings.get(i);
            if (!settingVisible(setting, i)) {
                continue;
            }
            total += settingRowHeight(setting);
        }
        if (hasArraylistRow(module)) {
            total += 17f * uiScale;
        }
        return total;
    }

    private boolean hasArraylistRow(Module module) {
        if (!module.canBeEnabled()) {
            return false;
        }
        if (module.getName().equals("HUD")) {
            return false;
        }
        return !(module instanceof ProfileModule);
    }

    private float settingRowHeight(Setting setting) {
        if (setting instanceof SliderSetting) {
            return ((SliderSetting) setting).isString ? 17f * uiScale : 18f * uiScale;
        }
        if (setting instanceof ColorSetting) {
            ColorSetting color = (ColorSetting) setting;
            float height = 17f * uiScale;
            if (colorExpanded.contains(colorKey(color))) {
                height += (color.hasAlpha() ? 4f : 3f) * (12f * uiScale);
            }
            return height;
        }
        if (setting instanceof DescriptionSetting) {
            return 15f * uiScale;
        }
        if (setting instanceof TextSetting) {
            return 19f * uiScale;
        }
        return 17f * uiScale;
    }

    private String colorKey(ColorSetting color) {
        return "c" + Integer.toHexString(color.hashCode());
    }

    private boolean settingVisible(Setting setting, int index) {
        if (!setting.visible) {
            return false;
        }
        if (setting instanceof DescriptionSetting && index == 0) {
            return false;
        }
        GroupSetting group = groupOf(setting);
        return group == null || group.isOpened();
    }

    private void drawSettings(Module module, float x, float y, float w) {
        List<Setting> settings = module.getSettings();
        float cursor = y;
        for (int i = 0; i < settings.size(); i++) {
            Setting setting = settings.get(i);
            if (!settingVisible(setting, i)) {
                continue;
            }
            float rowH = settingRowHeight(setting);
            float indent = groupOf(setting) != null ? 7f * uiScale : 0f;
            float rx = x + indent;
            float rw = w - indent;
            if (setting instanceof GroupSetting) {
                drawGroupRow((GroupSetting) setting, rx, cursor, rw, rowH);
            } else if (setting instanceof DescriptionSetting) {
                DescriptionSetting description = (DescriptionSetting) setting;
                drawText(f095, ellipsize(f095, description.getDesc(), rw), rx, cursor + rowH / 2f, textDimmer);
            } else if (setting instanceof ButtonSetting) {
                drawButtonRow(module, (ButtonSetting) setting, rx, cursor, rw, rowH);
            } else if (setting instanceof SliderSetting) {
                SliderSetting slider = (SliderSetting) setting;
                if (slider.isString) {
                    drawStringSliderRow(module, slider, rx, cursor, rw, rowH);
                } else {
                    drawSliderRow(module, slider, rx, cursor, rw, rowH);
                }
            } else if (setting instanceof ColorSetting) {
                drawColorRow(module, (ColorSetting) setting, rx, cursor, rw, rowH);
            } else if (setting instanceof KeySetting) {
                drawKeyRow((KeySetting) setting, rx, cursor, rw, rowH);
            } else if (setting instanceof TextSetting) {
                drawTextRow((TextSetting) setting, rx, cursor, rw, rowH);
            } else {
                drawText(f095, ellipsize(f095, setting.getName(), rw * 0.6f), rx, cursor + rowH / 2f, textDim);
                String note = "clickgui";
                drawText(f095, note, rx + rw - textWidth(f095, note), cursor + rowH / 2f, textDimmer);
            }
            cursor += rowH;
        }
        if (hasArraylistRow(module)) {
            drawArraylistRow(module, x, cursor, w, 17f * uiScale);
        }
    }

    private void drawArraylistRow(Module module, float x, float y, float w, float h) {
        float midY = y + h / 2f;
        boolean shown = !isUserHidden(module);
        float switchW = 22f * uiScale;
        float switchH = 11f * uiScale;
        float switchX = x + w - switchW;
        float switchY = midY - switchH / 2f;
        roundRect(switchX, switchY, switchX + switchW, switchY + switchH, switchH / 2f, shown ? accent : TOGGLE_OFF);
        float knob = switchH - 2.5f * uiScale;
        float knobX = shown ? (switchX + switchW - knob - 1.25f * uiScale) : (switchX + 1.25f * uiScale);
        roundRect(knobX, switchY + 1.25f * uiScale, knobX + knob, switchY + switchH - 1.25f * uiScale, knob / 2f, solidBg);
        drawText(f095, ellipsize(f095, "Show in arraylist", w - switchW - 6f * uiScale), x, midY, shown ? textColor : textDim);
        if (click(x, y, w, h)) {
            userHidden.put(module.getName(), shown);
            hiddenByArraylist.remove(module.getName());
            module.setHidden(shown);
        }
    }

    private void drawGroupRow(GroupSetting group, float x, float y, float w, float h) {
        String symbol = group.isOpened() ? "-" : "+";
        float midY = y + h / 2f;
        drawText(f095, symbol, x, midY, accent);
        drawText(f095, ellipsize(f095, group.getName(), w - 11f * uiScale), x + 9f * uiScale, midY, textColor);
        if (click(x, y, w, h)) {
            group.setOpened(!group.isOpened());
        }
    }

    private void drawButtonRow(Module module, ButtonSetting button, float x, float y, float w, float h) {
        float midY = y + h / 2f;
        if (button.isMethodButton) {
            String label = "RUN";
            float chipW = textWidth(f095, label) + 10f * uiScale;
            float chipH = 12f * uiScale;
            float chipX = x + w - chipW;
            float chipY = midY - chipH / 2f;
            boolean hovered = hover(chipX, chipY, chipW, chipH);
            drawPanelBox(chipX, chipY, chipX + chipW, chipY + chipH, chipH / 2f, hovered);
            drawText(f095, label, chipX + chipW / 2f - textWidth(f095, label) / 2f, midY, hovered ? accent : textColor);
            drawText(f095, ellipsize(f095, button.getName(), w - chipW - 6f * uiScale), x, midY, textColor);
            if (click(chipX, chipY - 2f * uiScale, chipW, chipH + 4f * uiScale)) {
                pendingButton = button;
            }
            return;
        }
        float switchW = 22f * uiScale;
        float switchH = 11f * uiScale;
        float switchX = x + w - switchW;
        float switchY = midY - switchH / 2f;
        boolean on = button.isToggled();
        roundRect(switchX, switchY, switchX + switchW, switchY + switchH, switchH / 2f, on ? accent : TOGGLE_OFF);
        float knob = switchH - 2.5f * uiScale;
        float knobX = on ? (switchX + switchW - knob - 1.25f * uiScale) : (switchX + 1.25f * uiScale);
        roundRect(knobX, switchY + 1.25f * uiScale, knobX + knob, switchY + switchH - 1.25f * uiScale, knob / 2f, solidBg);
        drawText(f095, ellipsize(f095, button.getName(), w - switchW - 6f * uiScale), x, midY, on ? textColor : textDim);
        if (click(x, y, w, h)) {
            button.toggle();
            module.guiButtonToggled(button);
            markUnsaved(module);
        }
    }

    private void drawStringSliderRow(Module module, SliderSetting slider, float x, float y, float w, float h) {
        String[] options = slider.getOptions();
        if (options == null || options.length == 0) {
            return;
        }
        int index = (int) Math.round(slider.getInput());
        if (index < 0) {
            index = 0;
        }
        if (index >= options.length) {
            index = options.length - 1;
        }
        String current = options[index];
        float midY = y + h / 2f;
        float labelW = w * 0.42f;
        float boxX = x + labelW + 8f * uiScale;
        float boxW = x + w - boxX;
        float boxH = 13f * uiScale;
        float boxY = midY - boxH / 2f;
        boolean hovered = hover(boxX, boxY, boxW, boxH);
        drawPanelBox(boxX, boxY, boxX + boxW, boxY + boxH, boxH / 2f, hovered);
        String shown = ellipsize(f095, current, boxW - 7f * uiScale);
        drawText(f095, shown, boxX + boxW / 2f - textWidth(f095, shown) / 2f, midY, textColor);
        drawText(f095, ellipsize(f095, slider.getName(), labelW), x, midY, textDim);
        if (click(boxX, boxY - 1f * uiScale, boxW, boxH + 2f * uiScale)) {
            slider.setValue((double) ((index + 1) % options.length));
            markUnsaved(module);
        } else if (rightClicked && hover(boxX, boxY - 1f * uiScale, boxW, boxH + 2f * uiScale)) {
            rightClicked = false;
            slider.setValue((double) ((index - 1 + options.length) % options.length));
            markUnsaved(module);
        }
    }

    private void drawSliderRow(Module module, SliderSetting slider, float x, float y, float w, float h) {
        double value = slider.getInput();
        boolean off = slider.canBeDisabled && value == -1.0D;
        String valueText;
        if (off) {
            String minString = slider.getMinString();
            valueText = minString == null ? "OFF" : minString;
        } else {
            valueText = formatNumber(value) + slider.getSuffix();
        }
        float midY = y + h / 2f;
        float labelW = w * 0.42f;
        drawText(f095, ellipsize(f095, slider.getName(), labelW), x, midY, textColor);
        float trackX = x + labelW + 8f * uiScale;
        float trackW = x + w - trackX;
        float trackY = midY - 1.5f * uiScale;
        float trackH = 3f * uiScale;
        roundRect(trackX, trackY, trackX + trackW, trackY + trackH, trackH / 2f, TRACK);
        double min = slider.getMin();
        double max = slider.getMax();
        double range = max - min;
        if (range <= 0.0D) {
            range = 1.0D;
        }
        float frac = off ? 0f : (float) ((value - min) / range);
        if (frac < 0f) {
            frac = 0f;
        }
        if (frac > 1f) {
            frac = 1f;
        }
        if (frac > 0f) {
            roundRect(trackX, trackY, trackX + trackW * frac, trackY + trackH, trackH / 2f, accent);
        }
        float knobR = 3.5f * uiScale;
        float knobX = trackX + trackW * frac;
        roundRect(knobX - knobR, trackY + trackH / 2f - knobR, knobX + knobR, trackY + trackH / 2f + knobR, knobR, accent);
        boolean hovered = hover(trackX - 2f * uiScale, trackY - 6f * uiScale, trackW + 4f * uiScale, trackH + 12f * uiScale);
        if (dragSlider == slider || hovered) {
            float pad = 5f * uiScale;
            float tipW = textWidth(f095, valueText) + 2f * pad;
            float tipX = knobX - tipW / 2f;
            if (tipX < trackX) {
                tipX = trackX;
            }
            if (tipX + tipW > trackX + trackW) {
                tipX = trackX + trackW - tipW;
            }
            tooltipActive = true;
            tooltipX = tipX;
            tooltipY = trackY - 12f * uiScale - 4f * uiScale;
            tooltipText = valueText;
            tooltipOff = off;
        }
        if (clicked && hover(trackX - 2f * uiScale, trackY - 6f * uiScale, trackW + 4f * uiScale, trackH + 12f * uiScale)) {
            clicked = false;
            dragSlider = slider;
        }
        if (dragSlider == slider && leftDown) {
            float local = mouseX - trackX;
            if (local < 0f) {
                local = 0f;
            }
            if (local > trackW) {
                local = trackW;
            }
            if (local <= 0.5f && slider.canBeDisabled) {
                slider.setValueRaw(-1.0D);
            } else {
                slider.setValue(min + (double) (local / trackW) * range);
            }
            markUnsaved(module);
        }
    }

    private void drawColorRow(Module module, ColorSetting color, float x, float y, float w, float h) {
        String key = colorKey(color);
        boolean open = colorExpanded.contains(key);
        float headerH = 17f * uiScale;
        float midY = y + headerH / 2f;
        float swatchW = 20f * uiScale;
        float swatchH = 10f * uiScale;
        float swatchX = x + w - swatchW;
        int border = 0xFF000000 | lighten(panelBg & 0x00FFFFFF, 20);
        float edge = 1.5f * uiScale;
        roundRect(swatchX - edge, midY - swatchH / 2f - edge, swatchX + swatchW + edge, midY + swatchH / 2f + edge, (swatchH / 2f) + edge, border);
        roundRect(swatchX, midY - swatchH / 2f, swatchX + swatchW, midY + swatchH / 2f, swatchH / 2f, argb(255, color.getRed(), color.getGreen(), color.getBlue()));
        drawText(f095, ellipsize(f095, color.getName(), w - swatchW - 8f * uiScale), x, midY, textColor);
        if (click(x, y, w, headerH)) {
            if (open) {
                colorExpanded.remove(key);
            } else {
                colorExpanded.add(key);
            }
            return;
        }
        if (!open) {
            return;
        }
        int channels = color.hasAlpha() ? 4 : 3;
        float cursor = y + headerH;
        for (int i = 0; i < channels; i++) {
            drawColorChannel(module, color, i, x + 7f * uiScale, cursor, w - 7f * uiScale);
            cursor += 12f * uiScale;
        }
    }

    private void drawColorChannel(Module module, ColorSetting color, int channel, float x, float y, float w) {
        String label = channel == 0 ? "R" : (channel == 1 ? "G" : (channel == 2 ? "B" : "A"));
        int value = channel == 0 ? color.getRed() : (channel == 1 ? color.getGreen() : (channel == 2 ? color.getBlue() : color.getAlpha()));
        float midY = y + 6f * uiScale;
        drawText(f095, label, x, midY, textDim);
        String valueText = Integer.toString(value);
        float valueW = textWidth(f095, valueText);
        drawText(f095, valueText, x + w - valueW, midY, textDim);
        float trackX = x + 11f * uiScale;
        float trackW = w - 11f * uiScale - valueW - 5f * uiScale;
        if (trackW < 10f * uiScale) {
            trackW = 10f * uiScale;
        }
        float trackH = 3f * uiScale;
        float trackY = midY - trackH / 2f;
        int fill = channel == 0 ? argb(255, 255, 60, 60) : (channel == 1 ? argb(255, 60, 220, 90) : (channel == 2 ? argb(255, 70, 130, 255) : WHITE));
        roundRect(trackX, trackY, trackX + trackW, trackY + trackH, trackH / 2f, TRACK);
        roundRect(trackX, trackY, trackX + trackW * ((float) value / 255f), trackY + trackH, trackH / 2f, fill);
        if (clicked && hover(trackX - 2f * uiScale, trackY - 5f * uiScale, trackW + 4f * uiScale, trackH + 10f * uiScale)) {
            clicked = false;
            dragColor = color;
            dragChannel = channel;
        }
        if (dragColor == color && dragChannel == channel && leftDown) {
            float local = mouseX - trackX;
            if (local < 0f) {
                local = 0f;
            }
            if (local > trackW) {
                local = trackW;
            }
            int v = (int) ((local / trackW) * 255f);
            if (channel == 0) {
                color.setColor(v, color.getGreen(), color.getBlue());
            } else if (channel == 1) {
                color.setColor(color.getRed(), v, color.getBlue());
            } else if (channel == 2) {
                color.setColor(color.getRed(), color.getGreen(), v);
            } else {
                color.setAlpha(v);
            }
            markUnsaved(module);
        }
    }

    private void drawKeyRow(KeySetting key, float x, float y, float w, float h) {
        boolean binding = bindKey == key;
        String text = binding ? "..." : keyName(key.getKey());
        float midY = y + h / 2f;
        float chipW = textWidth(f095, text) + 10f * uiScale;
        float chipH = 13f * uiScale;
        float chipX = x + w - chipW;
        float chipY = midY - chipH / 2f;
        drawPanelBox(chipX, chipY, chipX + chipW, chipY + chipH, 4f * uiScale, false);
        drawText(f095, text, chipX + chipW / 2f - textWidth(f095, text) / 2f, midY, binding ? textColor : (key.getKey() != 0 ? accent : textDimmer));
        drawText(f095, ellipsize(f095, key.getName(), w - chipW - 6f * uiScale), x, midY, textColor);
        if (click(chipX, chipY - 1f * uiScale, chipW, chipH + 2f * uiScale)) {
            if (binding) {
                key.setKey(0);
                bindKey = null;
            } else {
                bindKey = key;
                bindModule = null;
                textEditing = null;
            }
        }
    }

    private void drawTextRow(TextSetting setting, float x, float y, float w, float h) {
        boolean editing = textEditing == setting;
        float midY = y + h / 2f;
        float labelW = textWidth(f095, setting.getName()) + 6f * uiScale;
        if (labelW > w * 0.42f) {
            labelW = w * 0.42f;
        }
        drawText(f095, ellipsize(f095, setting.getName(), labelW - 4f * uiScale), x, midY, textColor);
        float boxX = x + labelW;
        float boxW = w - labelW;
        float boxH = 14f * uiScale;
        float boxY = midY - boxH / 2f;
        roundRect(boxX, boxY, boxX + boxW, boxY + boxH, boxH / 2f, editing ? HOVER : TOGGLE_OFF);
        String shown;
        int color;
        if (editing) {
            boolean caret = (System.currentTimeMillis() / 500L) % 2L == 0L;
            shown = textBuffer + (caret ? "_" : "");
            color = textColor;
        } else if (setting.getText() != null && setting.getText().length() > 0) {
            shown = setting.getText();
            color = textColor;
        } else {
            shown = setting.getPlaceholder();
            color = textDimmer;
        }
        drawText(f095, tailFit(f095, shown, boxW - 8f * uiScale), boxX + 4f * uiScale, midY, color);
        if (click(boxX, boxY - 2f * uiScale, boxW, boxH + 4f * uiScale)) {
            if (editing) {
                textEditing.setText(textBuffer);
                textEditing.submit();
                textEditing = null;
                textBuffer = "";
            } else {
                textEditing = setting;
                textBuffer = setting.getText() == null ? "" : setting.getText();
                bindKey = null;
                bindModule = null;
            }
        }
    }

    private void trackNotifications() {
        boolean notify = notificationsButton.isToggled();
        for (Module module : allModules) {
            if (!module.canBeEnabled()) {
                continue;
            }
            String name = module.getName();
            boolean enabledNow = module.isEnabled();
            Boolean previous = enableStates.get(name);
            boolean wasEnabled = previous != null && previous;
            if (notifInit && previous != null && enabledNow != wasEnabled && notify) {
                pushNotification(name, enabledNow);
            }
            enableStates.put(name, enabledNow);
        }
        notifInit = true;
    }

    private void arraylistVisibility() {
        boolean first = !visInit;
        visInit = true;
        boolean arraylistOn = arraylistButton.isToggled();
        hiddenByArraylist.clear();
        for (Module module : allModules) {
            String name = module.getName();
            if (first) {
                userHidden.put(name, module.isHidden());
            } else if (!userHidden.containsKey(name)) {
                userHidden.put(name, module.isHidden());
            }
            if (name.equals("HUD")) {
                continue;
            }
            boolean hiddenByUser = isUserHidden(module);
            boolean hideForSlinky = arraylistOn && module.isEnabled() && !hiddenByUser;
            if (hideForSlinky) {
                hiddenByArraylist.add(name);
            }
            boolean shouldHide = hiddenByUser || hideForSlinky;
            if (module.isHidden() != shouldHide) {
                module.setHidden(shouldHide);
            }
        }
    }

    private void resetStates() {
        userHidden.clear();
        hiddenByArraylist.clear();
        refreshModuleList();
        for (Module module : allModules) {
            userHidden.put(module.getName(), module.isHidden());
        }
    }

    private void restoreHidden() {
        refreshModuleList();
        for (Module module : allModules) {
            boolean hiddenByUser = isUserHidden(module);
            if (module.isHidden() != hiddenByUser) {
                module.setHidden(hiddenByUser);
            }
        }
        hiddenByArraylist.clear();
    }

    private void pushNotification(String name, boolean enabled) {
        if (notifCount >= notifNames.length) {
            for (int i = 1; i < notifCount; i++) {
                notifNames[i - 1] = notifNames[i];
                notifStates[i - 1] = notifStates[i];
                notifTimes[i - 1] = notifTimes[i];
            }
            notifCount--;
        }
        notifNames[notifCount] = name;
        notifStates[notifCount] = enabled;
        notifTimes[notifCount] = System.currentTimeMillis();
        notifCount++;
    }

    private void drawNotifications() {
        if (notifCount == 0) {
            return;
        }
        long life = 2600L;
        float fade = 260f;
        float rowH = 17f * uiScale;
        float padX = 7f * uiScale;
        float rowGap = 4f * uiScale;
        float margin = 6f * uiScale;
        float bar = 3f * uiScale;
        int corner = (int) Math.round(notificationCorner.getInput());
        boolean right = corner == 1 || corner == 3;
        boolean bottom = corner == 2 || corner == 3;
        RavenFontRenderer font = f105;
        long now = System.currentTimeMillis();
        while (notifCount > 0 && now - notifTimes[0] > life) {
            for (int i = 1; i < notifCount; i++) {
                notifNames[i - 1] = notifNames[i];
                notifStates[i - 1] = notifStates[i];
                notifTimes[i - 1] = notifTimes[i];
            }
            notifCount--;
        }
        float y = bottom ? ((float) screenH - margin - rowH) : margin;
        for (int i = notifCount - 1; i >= 0; i--) {
            long age = now - notifTimes[i];
            float fadeIn = age < fade ? (float) age / fade : 1f;
            float fadeOut = age > life - fade ? (float) (life - age) / fade : 1f;
            if (fadeOut < 0f) {
                fadeOut = 0f;
            }
            float progress = smooth(fadeIn) * smooth(fadeOut);
            String text = (notifStates[i] ? "Enabled " : "Disabled ") + notifNames[i];
            float width = textWidth(font, text) + 3f * padX + bar;
            int barColor = notifStates[i] ? accent : textDimmer;
            float x;
            if (right) {
                x = (float) screenW - margin - width * progress;
                roundRect(x, y, x + width, y + rowH, rowH / 2f, panelBg);
                roundRect(x, y, x + bar, y + rowH, 1.5f * uiScale, barColor);
                drawText(font, text, x + padX + bar, y + rowH / 2f, textColor);
            } else {
                x = margin - (width * (1f - progress));
                roundRect(x, y, x + width, y + rowH, rowH / 2f, panelBg);
                roundRect(x + width - bar, y, x + width, y + rowH, 1.5f * uiScale, barColor);
                drawText(font, text, x + padX, y + rowH / 2f, textColor);
            }
            if (bottom) {
                y -= rowH + rowGap;
                if (y < 0f) {
                    break;
                }
            } else {
                y += rowH + rowGap;
                if (y > (float) screenH) {
                    break;
                }
            }
        }
    }

    private List<Module> arraylistModules() {
        List<Module> list = new ArrayList<>();
        for (Module module : allModules) {
            if (module.isEnabled() && module.canBeEnabled() && !isUserHidden(module) && !(module instanceof ProfileModule) && !module.getName().equals("HUD")) {
                list.add(module);
            }
        }
        return list;
    }

    private float arraylistWidth(Module module, RavenFontRenderer font) {
        String info = moduleInfo(module);
        float width = textWidth(font, module.getName());
        if (info.length() > 0) {
            width += textWidth(font, " " + info);
        }
        return width;
    }

    private void sortByWidth(List<Module> list, RavenFontRenderer font) {
        int n = list.size();
        for (int i = 0; i < n - 1; i++) {
            int best = i;
            float bestWidth = arraylistWidth(list.get(i), font);
            for (int j = i + 1; j < n; j++) {
                float width = arraylistWidth(list.get(j), font);
                if (width > bestWidth) {
                    bestWidth = width;
                    best = j;
                }
            }
            if (best != i) {
                Module tmp = list.get(i);
                list.set(i, list.get(best));
                list.set(best, tmp);
            }
        }
    }

    private void pruneArrayWidths(List<Module> list) {
        List<String> keys = new ArrayList<>(arrayWidths.keySet());
        for (String key : keys) {
            boolean found = false;
            for (Module module : list) {
                if (module.getName().equals(key)) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                arrayWidths.remove(key);
            }
        }
    }

    private void drawArraylist() {
        List<Module> list = arraylistModules();
        int n = list.size();
        if (n == 0) {
            return;
        }
        RavenFontRenderer font = f105;
        float rowH = 15f * uiScale;
        float padX = 6f * uiScale;
        float margin = 3f * uiScale;
        float bar = 2.5f * uiScale;
        int corner = (int) Math.round(arraylistCorner.getInput());
        boolean right = corner == 1 || corner == 3;
        boolean bottom = corner == 2 || corner == 3;
        sortByWidth(list, font);
        float step = rowH + 1.5f * uiScale;
        float y = bottom ? ((float) screenH - margin - rowH) : margin;
        for (int i = 0; i < n; i++) {
            Module module = list.get(i);
            String name = module.getName();
            String info = moduleInfo(module);
            float nameW = textWidth(font, name);
            float infoW = info.length() > 0 ? textWidth(font, " " + info) : 0f;
            float target = nameW + infoW + 2f * padX + bar;
            Float stored = arrayWidths.get(name);
            float width = stored == null ? target : stored;
            width = approach(width, target, 8f);
            arrayWidths.put(name, width);
            float x = right ? ((float) screenW - margin - width) : margin;
            roundRect(x, y, x + width, y + rowH, 3.5f * uiScale, panelBg);
            if (right) {
                roundRect(x + width - bar, y, x + width, y + rowH, 1.5f * uiScale, accent);
            } else {
                roundRect(x, y, x + bar, y + rowH, 1.5f * uiScale, accent);
            }
            float textX = right ? (x + padX) : (x + padX + bar);
            drawText(font, name, textX, y + rowH / 2f, textColor);
            if (info.length() > 0) {
                drawText(font, info, textX + nameW + textWidth(font, " "), y + rowH / 2f, textDim);
            }
            y += bottom ? -step : step;
            if (y < 0f || y > (float) screenH) {
                break;
            }
        }
        pruneArrayWidths(list);
    }

    private String moduleInfo(Module module) {
        List<Setting> settings = module.getSettings();
        for (Setting setting : settings) {
            if (!setting.visible) {
                continue;
            }
            if (setting instanceof SliderSetting) {
                SliderSetting slider = (SliderSetting) setting;
                if (slider.isString) {
                    String[] options = slider.getOptions();
                    if (options != null && options.length > 0) {
                        int index = (int) Math.round(slider.getInput());
                        if (index < 0) {
                            index = 0;
                        }
                        if (index >= options.length) {
                            index = options.length - 1;
                        }
                        return options[index];
                    }
                } else {
                    double value = slider.getInput();
                    if (!(slider.canBeDisabled && value == -1.0D)) {
                        return formatNumber(value) + slider.getSuffix();
                    }
                }
            }
        }
        return "";
    }

    private void refreshModuleList() {
        allModules.clear();
        if (ClickGui.categories == null) {
            return;
        }
        for (CategoryComponent component : ClickGui.categories) {
            if (component == null) {
                continue;
            }
            for (ModuleComponent mc : component.modules) {
                if (mc != null && mc.mod != null) {
                    allModules.add(mc.mod);
                }
            }
        }
    }
}
