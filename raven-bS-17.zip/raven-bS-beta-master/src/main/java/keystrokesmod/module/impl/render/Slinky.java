package keystrokesmod.module.impl.render;

import keystrokesmod.module.Module;
import keystrokesmod.module.ModuleManager;
import keystrokesmod.module.setting.impl.ButtonSetting;
import keystrokesmod.module.setting.impl.ColorSetting;
import keystrokesmod.module.setting.impl.GroupSetting;
import keystrokesmod.module.setting.impl.SliderSetting;
import keystrokesmod.utility.RenderUtils;
import keystrokesmod.utility.Utils;
import keystrokesmod.utility.font.FontManager;
import keystrokesmod.utility.font.RavenFontRenderer;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public class Slinky extends Module {
    private final Map<Module.category, ButtonSetting> categoryToggles = new EnumMap<>(Module.category.class);
    private final SliderSetting textSize;
    private final SliderSetting font;
    private final SliderSetting paddingX;
    private final SliderSetting paddingY;
    private final SliderSetting rounding;
    private final ColorSetting textColor;
    private final ColorSetting detailsColor;
    private final ColorSetting backgroundColor;
    private final ButtonSetting lowercase;
    private final ButtonSetting showModuleInfo;

    public Slinky() {
        super("Slinky", Module.category.render);

        GroupSetting visible = new GroupSetting("Visible categories");
        this.registerSetting(visible);
        addCategoryToggle(visible, "Combat", Module.category.combat);
        addCategoryToggle(visible, "Movement", Module.category.movement);
        addCategoryToggle(visible, "Player", Module.category.player);
        addCategoryToggle(visible, "World", Module.category.world);
        addCategoryToggle(visible, "NetWork", Module.category.network);
        addCategoryToggle(visible, "Render", Module.category.render);
        addCategoryToggle(visible, "MiniGames", Module.category.minigames);
        addCategoryToggle(visible, "Other", Module.category.other);
        addCategoryToggle(visible, "Client", Module.category.client);
        addCategoryToggle(visible, "Scripts", Module.category.scripts);

        GroupSetting customization = new GroupSetting("Customization");
        this.registerSetting(customization);
        this.registerSetting(textSize = new SliderSetting(customization, "Text Size", "px", 18, 1, 24, 1));
        this.registerSetting(font = new SliderSetting(customization, "Font", 0, FontManager.getHudFontOptions()));
        this.registerSetting(paddingX = new SliderSetting(customization, "Padding X", "px", 2, 0, 5, 1));
        this.registerSetting(paddingY = new SliderSetting(customization, "Padding Y", "px", 1, 0, 5, 1));
        this.registerSetting(rounding = new SliderSetting(customization, "Rounding", "px", 3, 0, 16, 1));
        this.registerSetting(textColor = new ColorSetting(customization, "Text color", 255, 255, 255));
        this.registerSetting(detailsColor = new ColorSetting(customization, "Details color", 190, 190, 190));
        this.registerSetting(backgroundColor = new ColorSetting(customization, "Background color", 0, 0, 0, 110));
        this.registerSetting(lowercase = new ButtonSetting(customization, "Lowercase", true));
        this.registerSetting(showModuleInfo = new ButtonSetting(customization, "Show module info", true));
    }

    private void addCategoryToggle(GroupSetting group, String label, Module.category category) {
        ButtonSetting toggle = new ButtonSetting(group, label, true);
        categoryToggles.put(category, toggle);
        this.registerSetting(toggle);
    }

    @SubscribeEvent
    public void onRenderTick(TickEvent.RenderTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !Utils.nullCheck() || mc.currentScreen != null || mc.gameSettings.showDebugInfo) {
            return;
        }

        boolean lower = lowercase.isToggled();
        boolean details = showModuleInfo.isToggled();
        float scale = (float) textSize.getInput() / 10.0f;
        float padX = (float) paddingX.getInput();
        float padY = (float) paddingY.getInput();
        float radius = (float) rounding.getInput();
        int text = textColor.getColor();
        int detail = detailsColor.getColor();
        int background = backgroundColor.getColor();
        RavenFontRenderer fontRenderer = getFont();

        List<Row> rows = collectRows(fontRenderer, scale, lower, details);
        if (rows.isEmpty()) {
            return;
        }
        rows.sort((a, b) -> Float.compare(b.width, a.width));

        float right = new ScaledResolution(mc).getScaledWidth();
        float rowHeight = fontRenderer.getFontHeight() * scale + padY * 2.0f;

        List<Float> rowXs = new ArrayList<>(rows.size());
        for (Row row : rows) {
            rowXs.add(right - row.width - padX * 2.0f);
        }
        drawConnectedBackground(rowXs, right, rowHeight, radius, background);

        float y = 0.0f;
        for (int i = 0; i < rows.size(); i++) {
            Row row = rows.get(i);
            float x = rowXs.get(i);
            drawText(fontRenderer, row.title, x + padX, y + padY, scale, text);
            if (!row.details.isEmpty()) {
                drawText(fontRenderer, row.details, x + padX + row.titleWidth, y + padY, scale, detail);
            }
            y += rowHeight;
        }
    }

    private List<Row> collectRows(RavenFontRenderer fontRenderer, float scale, boolean lower, boolean details) {
        List<Module> snapshot;
        synchronized (ModuleManager.organizedModules) {
            snapshot = new ArrayList<>(ModuleManager.organizedModules);
        }
        List<Row> rows = new ArrayList<>();
        for (Module module : snapshot) {
            if (module == this || !module.isEnabled() || module.isHidden()) {
                continue;
            }
            ButtonSetting toggle = categoryToggles.get(module.moduleCategory());
            if (toggle == null || !toggle.isToggled()) {
                continue;
            }
            String title = module.getNameInHud();
            String info = details ? getInfo(module) : "";
            if (lower) {
                title = title.toLowerCase();
                info = info.toLowerCase();
            }
            float titleWidth = fontRenderer.getStringWidth(title) * scale;
            float width = fontRenderer.getStringWidth(title + info) * scale;
            rows.add(new Row(title, info, titleWidth, width));
        }
        return rows;
    }

    private static String getInfo(Module module) {
        String info = module.getInfoUpdate();
        if (info == null || info.isEmpty()) {
            return "";
        }
        return " " + info;
    }

    private RavenFontRenderer getFont() {
        String[] options = font.getOptions();
        String name = FontManager.getDefaultFontName();
        if (options != null && options.length > 0) {
            int index = (int) Math.max(0, Math.min(options.length - 1, font.getInput()));
            name = options[index];
        }
        return FontManager.getHudRenderer(name, 1.0f);
    }

    private static void drawText(RavenFontRenderer fontRenderer, String text, float x, float y, float scale, int color) {
        GL11.glPushMatrix();
        GL11.glScalef(scale, scale, 1.0f);
        fontRenderer.drawString(text, x / scale, y / scale, color, true);
        GL11.glPopMatrix();
    }

    private static void drawConnectedBackground(List<Float> rowXs, float right, float rowHeight, float requestedRadius, int color) {
        for (int i = 0; i < rowXs.size(); i++) {
            float top = i * rowHeight;
            float radius = requestedRadius;
            if (i + 1 < rowXs.size()) {
                radius = Math.min(radius, Math.max(0.0f, rowXs.get(i + 1) - rowXs.get(i)));
            }
            drawRowBackground(rowXs.get(i), top, right, rowHeight, radius, color);
        }
    }

    private static void drawRowBackground(float left, float top, float right, float height, float requestedRadius, int color) {
        float radius = Math.min(requestedRadius, height);
        if (radius <= 0.0f) {
            RenderUtils.drawRect(left, top, right, top + height, color);
            return;
        }

        float bottom = top + height;
        RenderUtils.drawRect(left, top, right, bottom - radius, color);
        RenderUtils.drawRect(left + radius, bottom - radius, right, bottom, color);

        float centerX = left + radius;
        float centerY = bottom - radius;
        float red = ((color >> 16) & 255) / 255.0f;
        float green = ((color >> 8) & 255) / 255.0f;
        float blue = (color & 255) / 255.0f;
        float alpha = ((color >> 24) & 255) / 255.0f;
        GL11.glPushMatrix();
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.disableAlpha();
        GlStateManager.disableCull();
        GlStateManager.disableDepth();
        GlStateManager.color(red, green, blue, alpha);
        GL11.glBegin(GL11.GL_TRIANGLE_FAN);
        GL11.glVertex2f(centerX, centerY);
        for (int point = 0; point <= 96; point++) {
            double angle = Math.PI - (Math.PI / 2.0) * point / 96.0;
            GL11.glVertex2f((float) (centerX + Math.cos(angle) * radius), (float) (centerY + Math.sin(angle) * radius));
        }
        GL11.glEnd();
        GlStateManager.enableDepth();
        GlStateManager.enableCull();
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.resetColor();
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glPopMatrix();
    }

    private static final class Row {
        private final String title;
        private final String details;
        private final float titleWidth;
        private final float width;

        private Row(String title, String details, float titleWidth, float width) {
            this.title = title;
            this.details = details;
            this.titleWidth = titleWidth;
            this.width = width;
        }
    }
}
