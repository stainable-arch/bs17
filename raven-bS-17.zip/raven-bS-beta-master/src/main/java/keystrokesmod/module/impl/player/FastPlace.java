package keystrokesmod.module.impl.player;

import keystrokesmod.event.SendPacketEvent;
import keystrokesmod.mixin.impl.accessor.IAccessorMinecraft;
import keystrokesmod.module.Module;
import keystrokesmod.module.setting.impl.ButtonSetting;
import keystrokesmod.module.setting.impl.SliderSetting;
import keystrokesmod.utility.Utils;
import keystrokesmod.utility.scaffold.ScaffoldSupport.ItemUtils;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Mouse;

public class FastPlace extends Module {
    public static FastPlace instance;
    public static SliderSetting delay, minimumHoldTime;
    public static ButtonSetting allowLadders, autoSwapBlocks, blocksOnly, pitchCheck, showBlockCount;
    private static boolean active;
    private static long fadeInStart, fadeOutStart;
    private static long holdStart;
    private static String countText;
    private static int lastSlot = -1;
    private static boolean lastHeldBlocks;

    public FastPlace() {
        super("Fast Place", category.player);
        instance = this;
        this.liteModule = true;
        this.registerSetting(delay = new SliderSetting("Delay", " tick", 1.0, 1.0, 3.0, 1.0));
        this.registerSetting(minimumHoldTime = new SliderSetting("Minimum hold time", "ms", 0.0, 0.0, 100.0, 5.0));
        this.registerSetting(allowLadders = new ButtonSetting("Allow ladders", false));
        this.registerSetting(autoSwapBlocks = new ButtonSetting("Auto swap blocks", false));
        this.registerSetting(blocksOnly = new ButtonSetting("Blocks only", true));
        this.registerSetting(pitchCheck = new ButtonSetting("Pitch check", false));
        this.registerSetting(showBlockCount = new ButtonSetting("Show block count", false));
        this.closetModule = true;
    }

    @Override
    public void guiUpdate() {
        allowLadders.setVisible(blocksOnly.isToggled(), this);
    }

    @SubscribeEvent
    public void onSendPacket(SendPacketEvent e) {
        if (!(e.getPacket() instanceof C08PacketPlayerBlockPlacement)) {
            return;
        }
        C08PacketPlayerBlockPlacement p = (C08PacketPlayerBlockPlacement) e.getPacket();
        if (p.getPlacedBlockDirection() == 255 && p.getStack() != null && p.getStack().getItem() instanceof ItemBlock && Math.random() > 0.4) {
            e.setCanceled(true);
        }
    }

    private static void setActive(boolean b) {
        if (b) {
            if (!active) {
                active = true;
                fadeInStart = System.currentTimeMillis();
            }
        } else if (active) {
            active = false;
            fadeOutStart = System.currentTimeMillis();
        }
    }

    private static int countBlocks() {
        int total = 0;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.thePlayer.inventory.mainInventory[i];
            if (stack != null && stack.stackSize > 0 && ItemUtils.isScaffoldBlock(stack)) {
                total += stack.stackSize;
            }
        }
        return total;
    }

    private static boolean holdingScaffoldBlock() {
        ItemStack held = mc.thePlayer.getHeldItem();
        return held != null && ItemUtils.isScaffoldBlock(held);
    }

    private static void swapToBlocks() {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.thePlayer.inventory.mainInventory[i];
            if (i != mc.thePlayer.inventory.currentItem && stack != null && stack.stackSize > 0 && ItemUtils.isScaffoldBlock(stack)) {
                mc.thePlayer.inventory.currentItem = i;
                return;
            }
        }
    }

    private static void updateCount() {
        int n = autoSwapBlocks.isToggled() ? countBlocks() : mc.thePlayer.getHeldItem().stackSize;
        String color = null;
        if (n <= 5) {
            color = "§c";
        } else if (n <= 15) {
            color = "§6";
        } else if (n <= 25) {
            color = "§e";
        }
        if (color == null) {
            countText = n + " blocks";
        } else {
            countText = color + n + "§f blocks";
        }
    }

    @SubscribeEvent
    public void onRenderTick(TickEvent.RenderTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !Utils.nullCheck() || mc.currentScreen != null) {
            return;
        }
        if (!showBlockCount.isToggled() || countText == null || SafeWalk.scaffoldActive) {
            return;
        }
        long now = System.currentTimeMillis();
        int alpha;
        if (active) {
            long l = now - fadeInStart;
            alpha = l < 125L ? (int) ((float) l / 125.0f * 240.0f) : 240;
        } else {
            long l = now - fadeOutStart;
            if (l < 125L) {
                alpha = (int) (240.0f - (float) l / 125.0f * 240.0f);
            } else {
                alpha = 0;
                countText = null;
            }
        }
        if (alpha > 0) {
            ScaledResolution sr = new ScaledResolution(mc);
            float x = (float) sr.getScaledWidth() / 2.0f + 11.0f;
            float y = (float) sr.getScaledHeight() / 2.0f - 3.0f;
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            mc.fontRendererObj.drawString(countText, x, y, Utils.mergeAlpha(-1, Math.max(5, Math.min(255, alpha))), true);
            GlStateManager.disableBlend();
        }
    }

    @Override
    public void onDisable() {
        setActive(false);
        lastHeldBlocks = false;
        holdStart = 0L;
    }

    @Override
    public void onUpdate() {
        if (!Utils.nullCheck()) {
            return;
        }
        if (pitchCheck.isToggled() && mc.thePlayer.rotationPitch < 65.0f) {
            setActive(false);
            return;
        }
        int slot = mc.thePlayer.inventory.currentItem;
        boolean blocks = holdingScaffoldBlock();
        if (autoSwapBlocks.isToggled() && !blocks && lastHeldBlocks && slot == lastSlot) {
            swapToBlocks();
            blocks = holdingScaffoldBlock();
        }
        lastSlot = mc.thePlayer.inventory.currentItem;
        lastHeldBlocks = blocks;
        if (blocks) {
            if (showBlockCount.isToggled()) {
                updateCount();
            }
        } else {
            ItemStack held = mc.thePlayer.getHeldItem();
            boolean ladder = held != null && held.getItem() instanceof ItemBlock && ((ItemBlock) held.getItem()).getBlock() == Blocks.ladder;
            if (!(!blocksOnly.isToggled() || allowLadders.isToggled() && ladder)) {
                setActive(false);
                return;
            }
            countText = null;
        }
        if (minimumHoldTime.getInput() != 0.0) {
            long now = System.currentTimeMillis();
            if (!Mouse.isButtonDown(1)) {
                holdStart = 0L;
                setActive(false);
                return;
            }
            if (holdStart == 0L) {
                holdStart = now;
            }
            if ((double) (now - holdStart) < minimumHoldTime.getInput() - 10.0) {
                setActive(false);
                return;
            }
        }
        setActive(true);
        IAccessorMinecraft accessor = (IAccessorMinecraft) mc;
        int d = (int) delay.getInput();
        if (d > 1) {
            if (accessor.getRightClickDelayTimer() == 4) {
                accessor.setRightClickDelayTimer(d);
            }
        } else {
            accessor.setRightClickDelayTimer(1);
        }
    }
}
