package keystrokesmod.module.impl.minigames;

import keystrokesmod.Raven;
import keystrokesmod.event.ReceivePacketEvent;
import keystrokesmod.event.SendPacketEvent;
import keystrokesmod.module.Module;
import keystrokesmod.module.ModuleManager;
import keystrokesmod.module.impl.world.AntiBot;
import keystrokesmod.module.setting.impl.ButtonSetting;
import keystrokesmod.module.setting.impl.DescriptionSetting;
import keystrokesmod.module.setting.impl.SliderSetting;
import keystrokesmod.utility.BlockUtils;
import keystrokesmod.utility.DragonDivePrediction;
import keystrokesmod.utility.RenderUtils;
import keystrokesmod.utility.Utils;
import net.minecraft.block.BlockBed;
import net.minecraft.block.BlockObsidian;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.resources.model.IBakedModel;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.boss.EntityDragon;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemEnderPearl;
import net.minecraft.item.ItemFireball;
import net.minecraft.item.ItemMonsterPlacer;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.server.S23PacketBlockChange;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.StringUtils;
import net.minecraft.util.Vec3;
import net.minecraftforge.client.ForgeHooksClient;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.entity.player.PlayerUseItemEvent;
import net.minecraftforge.fml.client.config.GuiButtonExt;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.io.IOException;
import java.util.*;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BedWars extends Module {
    private static final long MAGIC_MILK_DURATION_MS = 30000L;
    private static final long CLOSEST_ENEMY_ANIMATION_DURATION_MS = 100L;
    private static final int DRAGON_COLOR = new Color(214, 91, 191).getRGB();
    private static final int[] DRAGON_BLOCK_FACES = {
            0, 1, 3, 2, 4, 6, 7, 5, 0, 4, 5, 1, 2, 3, 7, 6, 0, 2, 6, 4, 1, 5, 7, 3
    };
    private static final int[] DRAGON_BLOCK_EDGES = {
            0, 1, 0, 2, 0, 4, 1, 3, 1, 5, 2, 3, 2, 6, 3, 7, 4, 5, 4, 6, 5, 7, 6, 7
    };
    private static final Set<String> SHOPS = new HashSet<>(Arrays.asList(
            "Quick Buy", "Blocks", "Melee", "Armor", "Tools", "Ranged", "Potions",
            "Utility", "Rotating Items", "Purchase Enemy Tracker"
    ));
    private static final Pattern SCOREBOARD_DATE = Pattern.compile("\\d{1,2}/\\d{1,2}/\\d{2,4}");

    private static final double OWN_BED_PROTECTION_RADIUS_SQ = 800.0;
    private static final int OWN_BED_SEARCH_HORIZONTAL_RADIUS = 24;
    private static final int OWN_BED_SEARCH_VERTICAL_RADIUS = 6;

    private final SliderSetting closestEnemy;
    private final SliderSetting alertInterval;
    private final ButtonSetting instantShop;
    private final ButtonSetting whitelistOwnBed;
    private final ButtonSetting magicMilkTimer;
    private final ButtonSetting dragon;
    private final ButtonSetting removeGameId;
    private final ButtonSetting targetUnicorn;

    private ButtonSetting bow;
    private ButtonSetting diamondArmor;
    private ButtonSetting dreamDefender;
    private ButtonSetting fireball;
    private ButtonSetting enderPearl;
    private ButtonSetting knockbackStick;
    private ButtonSetting magicMilk;
    private ButtonSetting obsidian;
    private ButtonSetting potions;
    private ButtonSetting rotationItems;
    private ButtonSetting waterBucket;
    private ButtonSetting ignoreTeammate;
    private ButtonSetting shouldPing;

    private List<String> armoredPlayer = new ArrayList<>();
    private Map<String, String> lastHeldMap = new ConcurrentHashMap<>();
    private Map<String, Long> lastAlertMap = new ConcurrentHashMap<>();
    private Map<BlockPos, Long> obsidianPos = new HashMap<>(); // blockPos, time received
    public List<SkyWars.SpawnEggInfo> entitySpawnQueue = new ArrayList<>();
    public List<Integer> spawnedMobs = new ArrayList<>(); // entity id

    private BlockPos spawnAnchor;
    private Vec3 ownBedCenter;
    private boolean ownBedDestroyed;
    private boolean pendingSpawnAnchorCapture;
    private boolean waitingForRespawn;
    private long respawnMessageTime;
    private long magicMilkExpiresAt;
    private double dragonDistance = -1.0;
    private final Map<EntityDragon, DragonDivePrediction> dragonDivePredictions = new HashMap<>();
    private final Map<EntityDragon, DragonConeVisual> dragonConeVisuals = new HashMap<>();

    private float closestEnemyPosX = Float.NaN;
    private float closestEnemyPosY = Float.NaN;
    private float closestEnemyRelativePosX = Float.NaN;
    private float closestEnemyRelativePosY = Float.NaN;
    private final EnemyHudLayout closestEnemyLayout = new EnemyHudLayout();
    private final EnemyHudLayout dragonHudLayout = new EnemyHudLayout();
    private float dragonPosX = Float.NaN;
    private float dragonPosY = Float.NaN;
    private float dragonRelativePosX = Float.NaN;
    private float dragonRelativePosY = Float.NaN;
    private float magicMilkPosX = Float.NaN;
    private float magicMilkPosY = Float.NaN;
    private float magicMilkRelativePosX = Float.NaN;
    private float magicMilkRelativePosY = Float.NaN;

    private int OBSIDIAN_COLOR = new Color(106, 13, 173).getRGB();

    public BedWars() {
        super("Bed Wars", category.minigames);
        this.registerSetting(instantShop = new ButtonSetting("Instant shop", true));
        this.registerSetting(removeGameId = new ButtonSetting("Remove game id", false));
        this.registerSetting(targetUnicorn = new ButtonSetting("Target unicorn", false));
        this.registerSetting(whitelistOwnBed = new ButtonSetting("Whitelist own bed", true));
        this.registerSetting(new DescriptionSetting("Game alerts"));
        this.registerSetting(alertInterval = new SliderSetting("Alert interval", " second", 5.0, 0.0, 30.0, 1.0));
        this.registerSetting(bow = new ButtonSetting("Bow", true));
        this.registerSetting(diamondArmor = new ButtonSetting("Diamond armor", true));
        this.registerSetting(dreamDefender = new ButtonSetting("Dream defender", true));
        this.registerSetting(fireball = new ButtonSetting("Fireball", false));
        this.registerSetting(knockbackStick = new ButtonSetting("Knockback stick", true));
        this.registerSetting(magicMilk = new ButtonSetting("Magic milk", true));
        this.registerSetting(obsidian = new ButtonSetting("Obsidian", true));
        this.registerSetting(enderPearl = new ButtonSetting("Ender pearl", true));
        this.registerSetting(potions = new ButtonSetting("Potions", true));
        this.registerSetting(rotationItems = new ButtonSetting("Rotation items", true));
        this.registerSetting(waterBucket = new ButtonSetting("Water bucket", true));
        this.registerSetting(ignoreTeammate = new ButtonSetting("Ignore teammates", false, "Ignore teammate"));
        this.registerSetting(shouldPing = new ButtonSetting("Should ping", true));
        this.registerSetting(new DescriptionSetting("HUD"));
        this.registerSetting(closestEnemy = new SliderSetting("Closest enemy", true, 1, 1, 10, 1));
        this.registerSetting(dragon = new ButtonSetting("Dragon", true));
        this.registerSetting(magicMilkTimer = new ButtonSetting("Magic milk timer", true));
        this.registerSetting(new ButtonSetting("Edit positions", () -> mc.displayGuiScreen(new EditPositionsScreen())));
        this.closetModule = true;
        this.liteModule = true;
    }

    public static boolean shouldTargetUnicorn() {
        return ModuleManager.bedwars != null && ModuleManager.bedwars.isEnabled()
                && ModuleManager.bedwars.targetUnicorn.isToggled() && Utils.getBedwarsStatus() == 2;
    }

    public String filterScoreboardLine(String line) {
        if (!removeGameId.isToggled()) {
            return line;
        }

        String visibleLine = StringUtils.stripControlCodes(line);
        Matcher date = SCOREBOARD_DATE.matcher(visibleLine);
        if (!date.find() || visibleLine.substring(date.end()).trim().isEmpty()) {
            return line;
        }

        int bedWarsStatus = Utils.getBedwarsStatus();
        if (bedWarsStatus != 1 && bedWarsStatus != 2) {
            return line;
        }

        int rawIndex = 0;
        int visibleIndex = 0;
        while (rawIndex < line.length() && visibleIndex < date.end()) {
            if (line.charAt(rawIndex) == '\u00a7' && rawIndex + 1 < line.length()) {
                rawIndex += 2;
            }
            else {
                rawIndex++;
                visibleIndex++;
            }
        }
        return line.substring(0, rawIndex);
    }

    @Override
    public void onDisable() {
        entitySpawnQueue.clear();
        spawnedMobs.clear();
        lastAlertMap.clear();
        resetSpawnTracking();
        magicMilkExpiresAt = 0L;
        resetDragonHud();
        resetClosestEnemyHud();
    }

    @Override
    public void guiButtonToggled(ButtonSetting setting) {
        if (setting == dragon && !dragon.isToggled()) {
            resetDragonHud();
        }
    }

    private boolean dragonFeaturesEnabled() {
        return dragon.isToggled() && (Raven.DEBUG || Utils.getBedwarsStatus() == 2);
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onRenderWorld(RenderWorldLastEvent e) {
        dragonDistance = -1.0;
        if (Utils.nullCheck() && dragonFeaturesEnabled()) {
            boolean bedWarsRules = Utils.getBedwarsStatus() == 2;
            Set<EntityDragon> activeDragons = new HashSet<>();
            for (Entity entity : mc.theWorld.loadedEntityList) {
                if (entity instanceof EntityDragon) {
                    EntityDragon dragonEntity = (EntityDragon) entity;
                    activeDragons.add(dragonEntity);
                    renderDragon(dragonEntity, e.partialTicks);
                    DragonDivePrediction prediction = dragonDivePredictions.computeIfAbsent(
                            dragonEntity, DragonDivePrediction::new
                    );
                    renderDragonDive(dragonEntity, prediction.update(bedWarsRules), e.partialTicks);
                    double distance = Math.sqrt(mc.thePlayer.getDistanceSqToEntity(entity));
                    if (dragonDistance < 0.0 || distance < dragonDistance) {
                        dragonDistance = distance;
                    }
                }
            }
            dragonDivePredictions.keySet().retainAll(activeDragons);
            dragonConeVisuals.keySet().retainAll(activeDragons);
        }
        else {
            dragonDivePredictions.clear();
            dragonConeVisuals.clear();
        }
        if (Utils.nullCheck() && obsidian.isToggled()) {
            if (this.obsidianPos.isEmpty()) {
                return;
            }
            try {
                List<BlockPos> blocksToRender = new ArrayList<>();
                Iterator<Map.Entry<BlockPos, Long>> iterator = this.obsidianPos.entrySet().iterator();
                while (iterator.hasNext()) {
                    Map.Entry<BlockPos, Long> entry = iterator.next();
                    BlockPos blockPos = entry.getKey();
                    Long receivedMs = entry.getValue();

                    if (!(mc.theWorld.getBlockState(blockPos).getBlock() instanceof BlockObsidian) && Utils.timeBetween(System.currentTimeMillis(), receivedMs) >= 500) {
                        iterator.remove();
                        continue;
                    }
                    blocksToRender.add(blockPos);
                }
                renderObsidianOverlays(mergeObsidianBounds(blocksToRender));

            }
            catch (Exception exception) {}
        }
    }

    private void renderDragon(EntityDragon entity, float partialTicks) {
        RenderManager renderManager = mc.getRenderManager();
        double x = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * partialTicks - renderManager.viewerPosX;
        double y = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * partialTicks - renderManager.viewerPosY;
        double z = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * partialTicks - renderManager.viewerPosZ;
        AxisAlignedBB bounds = entity.getEntityBoundingBox().expand(2.0, 0.0, 2.0);
        AxisAlignedBB box = new AxisAlignedBB(
                bounds.minX - entity.posX + x, bounds.minY - entity.posY + y, bounds.minZ - entity.posZ + z,
                bounds.maxX - entity.posX + x, bounds.maxY - entity.posY + y - 3.0, bounds.maxZ - entity.posZ + z
        );

        GL11.glPushAttrib(GL11.GL_ALL_ATTRIB_BITS);
        try {
            GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
            GL11.glEnable(GL11.GL_BLEND);
            GL11.glDisable(GL11.GL_TEXTURE_2D);
            GL11.glDisable(GL11.GL_DEPTH_TEST);
            GL11.glDepthMask(false);
            GL11.glColor4f((DRAGON_COLOR >> 16 & 0xFF) / 255.0f,
                    (DRAGON_COLOR >> 8 & 0xFF) / 255.0f, (DRAGON_COLOR & 0xFF) / 255.0f, 1.0f);
            GL11.glEnable(GL11.GL_LINE_SMOOTH);
            GL11.glLineWidth(2.0f);
            RenderGlobal.drawSelectionBoundingBox(box);
        }
        finally {
            GL11.glPopAttrib();
        }
    }

    private void renderDragonDive(EntityDragon entity, DragonDivePrediction.Result prediction, float partialTicks) {
        DragonConeVisual visual = dragonConeVisuals.computeIfAbsent(entity, ignored -> new DragonConeVisual());
        Vec3 markerImpact = visual.update(prediction);
        if (markerImpact == null && prediction.blocks.isEmpty()) {
            return;
        }

        RenderManager renderManager = mc.getRenderManager();
        GL11.glPushAttrib(GL11.GL_ALL_ATTRIB_BITS);
        try {
            GL11.glEnable(GL11.GL_BLEND);
            GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
            GL11.glDisable(GL11.GL_TEXTURE_2D);
            GL11.glDisable(GL11.GL_LIGHTING);
            GL11.glDisable(GL11.GL_FOG);
            GL11.glDisable(GL11.GL_CULL_FACE);
            GL11.glDisable(GL11.GL_DEPTH_TEST);
            GL11.glDepthMask(false);
            GL11.glEnable(GL11.GL_LINE_SMOOTH);
            GL11.glLineWidth(1.5f);

            GL11.glColor4f(0.62f, 0.25f, 1.0f, 0.14f);
            GL11.glBegin(GL11.GL_QUADS);
            for (BlockPos pos : prediction.blocks) {
                if (!mc.theWorld.isAirBlock(pos)) {
                    emitDragonBlockVertices(pos, DRAGON_BLOCK_FACES, renderManager);
                }
            }
            GL11.glEnd();

            GL11.glColor4f(0.72f, 0.36f, 1.0f, 0.65f);
            GL11.glBegin(GL11.GL_LINES);
            for (BlockPos pos : prediction.blocks) {
                if (!mc.theWorld.isAirBlock(pos)) {
                    emitDragonBlockVertices(pos, DRAGON_BLOCK_EDGES, renderManager);
                }
            }
            GL11.glEnd();

            if (markerImpact == null) {
                return;
            }

            AxisAlignedBB head = entity.dragonPartHead.getEntityBoundingBox();
            Vec3 headOrigin = new Vec3(
                    (head.minX + head.maxX) * 0.5 + (entity.lastTickPosX - entity.posX) * (1.0 - partialTicks),
                    (head.minY + head.maxY) * 0.5 + (entity.lastTickPosY - entity.posY) * (1.0 - partialTicks),
                    (head.minZ + head.maxZ) * 0.5 + (entity.lastTickPosZ - entity.posZ) * (1.0 - partialTicks)
            );
            GL11.glColor4f(0.68f, 0.30f, 1.0f, 0.65f);
            GL11.glBegin(GL11.GL_LINE_STRIP);
            for (int i = 0; i < prediction.path.size(); i++) {
                Vec3 point = i == prediction.path.size() - 1 ? markerImpact
                        : i == 0 ? headOrigin : prediction.path.get(i);
                GL11.glVertex3d(point.xCoord - renderManager.viewerPosX,
                        point.yCoord - renderManager.viewerPosY, point.zCoord - renderManager.viewerPosZ);
            }
            GL11.glEnd();

            double x = markerImpact.xCoord - renderManager.viewerPosX;
            double y = markerImpact.yCoord - renderManager.viewerPosY;
            double z = markerImpact.zCoord - renderManager.viewerPosZ;
            double rotation = (entity.ticksExisted + partialTicks) * 0.10;
            double directionX = markerImpact.xCoord - headOrigin.xCoord;
            double directionY = markerImpact.yCoord - headOrigin.yCoord;
            double directionZ = markerImpact.zCoord - headOrigin.zCoord;
            double yaw = Math.toDegrees(Math.atan2(directionX, -directionZ));
            double pitch = Math.toDegrees(Math.atan2(directionY,
                    Math.sqrt(directionX * directionX + directionZ * directionZ)));
            double radius = 0.85;
            double length = 1.8;
            int sides = 16;

            GL11.glPushMatrix();
            try {
                GL11.glTranslated(x, y, z);
                GL11.glRotated(-yaw, 0.0, 1.0, 0.0);
                GL11.glRotated(pitch, 1.0, 0.0, 0.0);
                GL11.glRotated(Math.toDegrees(rotation), 0.0, 0.0, 1.0);

                GL11.glBegin(GL11.GL_TRIANGLES);
                for (int i = 0; i < sides; i++) {
                    double angle = i * Math.PI * 2.0 / sides;
                    double nextAngle = (i + 1) * Math.PI * 2.0 / sides;
                    float shade = i % 2 == 0 ? 1.0f : 0.72f;
                    GL11.glColor4f(0.62f * shade, 0.25f * shade, shade, 0.42f);
                    GL11.glVertex3d(0.0, 0.0, 0.0);
                    GL11.glVertex3d(Math.cos(angle) * radius, Math.sin(angle) * radius, length);
                    GL11.glVertex3d(Math.cos(nextAngle) * radius, Math.sin(nextAngle) * radius, length);
                }
                GL11.glEnd();

                GL11.glColor4f(0.82f, 0.50f, 1.0f, 0.95f);
                GL11.glLineWidth(2.0f);
                GL11.glBegin(GL11.GL_LINE_LOOP);
                for (int i = 0; i < sides; i++) {
                    double angle = i * Math.PI * 2.0 / sides;
                    GL11.glVertex3d(Math.cos(angle) * radius, Math.sin(angle) * radius, length);
                }
                GL11.glEnd();
                GL11.glBegin(GL11.GL_LINES);
                for (int i = 0; i < sides; i += 4) {
                    double angle = i * Math.PI * 2.0 / sides;
                    GL11.glVertex3d(0.0, 0.0, 0.0);
                    GL11.glVertex3d(Math.cos(angle) * radius, Math.sin(angle) * radius, length);
                }
                GL11.glEnd();
            }
            finally {
                GL11.glPopMatrix();
            }
        }
        finally {
            GL11.glPopAttrib();
        }
    }

    private void emitDragonBlockVertices(BlockPos pos, int[] vertices, RenderManager renderManager) {
        double x = pos.getX() - renderManager.viewerPosX;
        double y = pos.getY() - renderManager.viewerPosY;
        double z = pos.getZ() - renderManager.viewerPosZ;
        for (int vertex : vertices) {
            GL11.glVertex3d(x + ((vertex & 1) == 0 ? -0.002 : 1.002),
                    y + ((vertex & 2) == 0 ? -0.002 : 1.002),
                    z + ((vertex & 4) == 0 ? -0.002 : 1.002));
        }
    }

    private List<AxisAlignedBB> mergeObsidianBounds(List<BlockPos> blocks) {
        List<AxisAlignedBB> bounds = new ArrayList<>();

        for (BlockPos pos : blocks) {
            bounds.add(new AxisAlignedBB(
                    pos.getX(),
                    pos.getY(),
                    pos.getZ(),
                    pos.getX() + 1.0,
                    pos.getY() + 1.0,
                    pos.getZ() + 1.0
            ));
        }

        boolean merged;
        do {
            merged = false;

            outer:
            for (int i = 0; i < bounds.size(); i++) {
                for (int j = i + 1; j < bounds.size(); j++) {
                    AxisAlignedBB combined = mergeAdjacentBounds(bounds.get(i), bounds.get(j));
                    if (combined != null) {
                        bounds.set(i, combined);
                        bounds.remove(j);
                        merged = true;
                        break outer;
                    }
                }
            }
        } while (merged);

        return bounds;
    }

    private AxisAlignedBB mergeAdjacentBounds(AxisAlignedBB first, AxisAlignedBB second) {
        boolean sameX = first.minX == second.minX && first.maxX == second.maxX;
        boolean sameY = first.minY == second.minY && first.maxY == second.maxY;
        boolean sameZ = first.minZ == second.minZ && first.maxZ == second.maxZ;

        if (sameY && sameZ && (first.maxX == second.minX || second.maxX == first.minX)) {
            return new AxisAlignedBB(
                    Math.min(first.minX, second.minX),
                    first.minY,
                    first.minZ,
                    Math.max(first.maxX, second.maxX),
                    first.maxY,
                    first.maxZ
            );
        }

        if (sameX && sameZ && (first.maxY == second.minY || second.maxY == first.minY)) {
            return new AxisAlignedBB(
                    first.minX,
                    Math.min(first.minY, second.minY),
                    first.minZ,
                    first.maxX,
                    Math.max(first.maxY, second.maxY),
                    first.maxZ
            );
        }

        if (sameX && sameY && (first.maxZ == second.minZ || second.maxZ == first.minZ)) {
            return new AxisAlignedBB(
                    first.minX,
                    first.minY,
                    Math.min(first.minZ, second.minZ),
                    first.maxX,
                    first.maxY,
                    Math.max(first.maxZ, second.maxZ)
            );
        }

        return null;
    }

    private void renderObsidianOverlays(List<AxisAlignedBB> obsidianBounds) {
        if (obsidianBounds.isEmpty()) {
            return;
        }

        float red = (OBSIDIAN_COLOR >> 16 & 0xFF) / 255.0f;
        float green = (OBSIDIAN_COLOR >> 8 & 0xFF) / 255.0f;
        float blue = (OBSIDIAN_COLOR & 0xFF) / 255.0f;
        RenderManager renderManager = mc.getRenderManager();

        GL11.glPushMatrix();
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glDepthMask(false);

        try {
            for (AxisAlignedBB bounds : obsidianBounds) {
                AxisAlignedBB renderedBounds = bounds.offset(
                        -renderManager.viewerPosX,
                        -renderManager.viewerPosY,
                        -renderManager.viewerPosZ
                );
                RenderUtils.drawBoundingBox(renderedBounds, red, green, blue, 0.25f);
            }
        } finally {
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            GL11.glEnable(GL11.GL_TEXTURE_2D);
            GL11.glEnable(GL11.GL_DEPTH_TEST);
            GL11.glDepthMask(true);
            GL11.glDisable(GL11.GL_BLEND);
            GL11.glPopMatrix();
        }
    }

    @SubscribeEvent
    public void onRenderTick(TickEvent.RenderTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !Utils.nullCheck()
                || mc.currentScreen != null || mc.gameSettings.showDebugInfo && !Raven.DEBUG) {
            return;
        }

        boolean playingBedWars = Utils.getBedwarsStatus() == 2;
        long remainingMilkTime = magicMilkExpiresAt - System.currentTimeMillis();
        boolean showMagicMilkTimer = !mc.gameSettings.showDebugInfo && playingBedWars && magicMilkTimer.isToggled()
                && magicMilkExpiresAt > 0L && remainingMilkTime > -2000L;
        boolean showClosestEnemy = !mc.gameSettings.showDebugInfo && playingBedWars && closestEnemy.getInput() != -1;
        boolean showDragon = dragonFeaturesEnabled() && dragonDistance >= 0.0;
        if (!showClosestEnemy && !showMagicMilkTimer && !showDragon) {
            return;
        }

        ScaledResolution resolution = new ScaledResolution(mc);
        syncHudPositions(resolution);

        if (showDragon) {
            drawDragonHudBox(dragonDistance, dragonPosX, dragonPosY);
        }

        if (showClosestEnemy) {
            Vec3 bedReference = !ownBedDestroyed ? getOwnBedReference() : null;
            List<EntityPlayer> enemies = findClosestEnemies(
                    bedReference,
                    (int) closestEnemy.getInput()
            );

            List<EnemyHudEntry> entries = new ArrayList<>();

            for (EntityPlayer enemy : enemies) {
                double distance = distanceToReference(enemy, bedReference);

                String name = enemy.getDisplayName().getUnformattedText();
                String distanceText = formatDistance(distance);

                entries.add(new EnemyHudEntry(name, distanceText, enemy.getHeldItem()));
            }

            drawEnemyHudBox(entries, closestEnemyPosX, closestEnemyPosY);
        }

        if (showMagicMilkTimer) {
            String text = remainingMilkTime > 0L
                    ? String.format(Locale.ROOT, "§7Magic Milk: §a%.1fs", remainingMilkTime / 1000.0D)
                    : "§7Magic milk: §cFinished";
            drawHudBox(text, magicMilkPosX, magicMilkPosY);
        }
    }

    private HudBoxBounds drawHudBox(String text, float x, float textY) {
        float horizontalPadding = 3.0f;
        float verticalPadding = 4.0f;
        float textX = x + horizontalPadding;
        float textWidth = mc.fontRendererObj.getStringWidth(text);
        float left = x - 10.0f;
        float top = textY - verticalPadding;
        float right = textX + textWidth + horizontalPadding + 1.0f;
        float bottom = textY + mc.fontRendererObj.FONT_HEIGHT + verticalPadding - 1.0f;
        RenderUtils.drawRoundedRectangle(
                left,
                top,
                right,
                bottom,
                7.0f,
                2013265920
        );
        enableClosestEnemyAlphaBlending();
        try {
            mc.fontRendererObj.drawString(text, textX, textY, Color.WHITE.getRGB(), true);
        }
        finally {
            GlStateManager.disableBlend();
        }
        return new HudBoxBounds(left, top, right, bottom);
    }

    private HudBoxBounds drawDragonHudBox(double distance, float x, float textY) {
        char color = distance <= 25.0 ? 'c' : distance <= 50.0 ? '6' : distance <= 75.0 ? 'e'
                : distance <= 125.0 ? 'a' : '2';
        String text = "§7Dragon: §" + color + (int) distance + "m";
        dragonHudLayout.update(mc.fontRendererObj.getStringWidth(text), 0.0f, 0.0f);
        ScaledResolution resolution = new ScaledResolution(mc);
        float left = x - 5.0f;
        float right = x + dragonHudLayout.width + 4.0f;
        float top = textY - 5.0f;
        float bottom = textY + mc.fontRendererObj.FONT_HEIGHT + 3.5f;
        if (left <= 0.0f) {
            left = -3.0f;
        }
        if (right > resolution.getScaledWidth()) {
            right = resolution.getScaledWidth() + 3.0f;
        }
        right -= 0.5f;

        GL11.glPushAttrib(GL11.GL_SCISSOR_BIT | GL11.GL_COLOR_BUFFER_BIT | GL11.GL_ENABLE_BIT | GL11.GL_CURRENT_BIT);
        try {
            enableClosestEnemyAlphaBlending();
            RenderUtils.drawRoundedRectangle(left, top, right, bottom, 8.0f, 0x7D000000);
            scissorEnemyHud(left, top, right, bottom, resolution);
            mc.fontRendererObj.drawString(text, x, textY, -1, true);
        }
        finally {
            GL11.glPopAttrib();
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.enableBlend();
            GlStateManager.disableBlend();
        }
        return new HudBoxBounds(left, top, right, bottom);
    }

    private void resetDragonHud() {
        dragonDistance = -1.0;
        dragonHudLayout.initialized = false;
        dragonDivePredictions.clear();
        dragonConeVisuals.clear();
    }

    private void renderHeldItem(ItemStack heldItem, float x, float y) {
        if (heldItem.getItem() == null) {
            return;
        }
        RenderItem renderItem = mc.getRenderItem();
        float previousZLevel = renderItem.zLevel;
        boolean previousDepthEnabled = GL11.glIsEnabled(GL11.GL_DEPTH_TEST);
        boolean previousDepthMask = GL11.glGetBoolean(GL11.GL_DEPTH_WRITEMASK);
        int previousDepthFunc = GL11.glGetInteger(GL11.GL_DEPTH_FUNC);
        double previousClearDepth = GL11.glGetDouble(GL11.GL_DEPTH_CLEAR_VALUE);
        boolean previousAlphaEnabled = GL11.glIsEnabled(GL11.GL_ALPHA_TEST);
        int previousAlphaFunc = GL11.glGetInteger(GL11.GL_ALPHA_TEST_FUNC);
        float previousAlphaRef = GL11.glGetFloat(GL11.GL_ALPHA_TEST_REF);
        RenderHelper.enableGUIStandardItemLighting();
        renderItem.zLevel = -100.0f;
        IBakedModel model = renderItem.getItemModelMesher().getItemModel(heldItem);
        GlStateManager.pushMatrix();
        mc.getTextureManager().bindTexture(TextureMap.locationBlocksTexture);
        mc.getTextureManager().getTexture(TextureMap.locationBlocksTexture).setBlurMipmap(false, false);
        try {
            GlStateManager.enableAlpha();
            GlStateManager.alphaFunc(GL11.GL_GREATER, 0.1f);
            GlStateManager.enableDepth();
            GlStateManager.depthMask(true);
            GlStateManager.depthFunc(GL11.GL_LEQUAL);
            GlStateManager.clearDepth(1.0);
            GlStateManager.clear(GL11.GL_DEPTH_BUFFER_BIT);
            GlStateManager.enableRescaleNormal();
            GlStateManager.enableBlend();
            GlStateManager.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.translate(x, y, 100.0f + renderItem.zLevel);
            GlStateManager.translate(8.0f, 8.0f, 0.0f);
            GlStateManager.scale(1.0f, 1.0f, -1.0f);
            GlStateManager.scale(0.5f, 0.5f, 0.5f);
            if (model.isGui3d()) {
                GlStateManager.scale(40.0f, 40.0f, 40.0f);
                GlStateManager.rotate(210.0f, 1.0f, 0.0f, 0.0f);
                GlStateManager.rotate(-135.0f, 0.0f, 1.0f, 0.0f);
                GlStateManager.enableLighting();
            }
            else {
                GlStateManager.scale(64.0f, 64.0f, 64.0f);
                GlStateManager.rotate(180.0f, 1.0f, 0.0f, 0.0f);
                GlStateManager.disableLighting();
            }
            model = ForgeHooksClient.handleCameraTransforms(model, ItemCameraTransforms.TransformType.GUI);
            renderItem.renderItem(heldItem, model);
        }
        finally {
            GlStateManager.disableBlend();
            GlStateManager.disableRescaleNormal();
            GlStateManager.disableLighting();
            GlStateManager.popMatrix();
            mc.getTextureManager().bindTexture(TextureMap.locationBlocksTexture);
            mc.getTextureManager().getTexture(TextureMap.locationBlocksTexture).restoreLastBlurMipmap();
            renderItem.zLevel = previousZLevel;
            RenderHelper.disableStandardItemLighting();
            GlStateManager.depthFunc(previousDepthFunc);
            GlStateManager.depthMask(previousDepthMask);
            GlStateManager.clearDepth(previousClearDepth);
            if (previousDepthEnabled) {
                GlStateManager.enableDepth();
            }
            else {
                GlStateManager.disableDepth();
            }
            GlStateManager.alphaFunc(previousAlphaFunc, previousAlphaRef);
            if (previousAlphaEnabled) {
                GlStateManager.enableAlpha();
            }
            else {
                GlStateManager.disableAlpha();
            }
        }
    }

    @SubscribeEvent
    public void onShopMouseInput(GuiScreenEvent.MouseInputEvent.Pre event) {
        if (!instantShop.isToggled() || !Utils.nullCheck() || Utils.getBedwarsStatus() != 2
                || !(event.gui instanceof GuiChest) || !(mc.thePlayer.openContainer instanceof ContainerChest)
                || Mouse.getEventButton() != 0 || !Mouse.getEventButtonState() || GuiScreen.isShiftKeyDown()
                || ModuleManager.inventory != null && ModuleManager.inventory.shouldCancelManualInventoryInput()) {
            return;
        }

        ContainerChest container = (ContainerChest) mc.thePlayer.openContainer;
        IInventory chest = container.getLowerChestInventory();
        if (!SHOPS.contains(chest.getName())) {
            return;
        }

        GuiChest gui = (GuiChest) event.gui;
        int guiLeft = (gui.width - 176) / 2;
        int guiTop = (gui.height - (114 + chest.getSizeInventory() / 9 * 18)) / 2;
        int mouseX = Mouse.getEventX() * gui.width / mc.displayWidth - guiLeft;
        int mouseY = gui.height - Mouse.getEventY() * gui.height / mc.displayHeight - 1 - guiTop;
        for (Slot slot : container.inventorySlots) {
            if (mouseX >= slot.xDisplayPosition - 1 && mouseX < slot.xDisplayPosition + 17
                    && mouseY >= slot.yDisplayPosition - 1 && mouseY < slot.yDisplayPosition + 17) {
                mc.playerController.windowClick(container.windowId, slot.slotNumber, 2, 3, mc.thePlayer);
                event.setCanceled(true);
                return;
            }
        }
    }

    @SubscribeEvent
    public void onItemUseFinish(PlayerUseItemEvent.Finish event) {
        if (magicMilkTimer.isToggled() && Utils.nullCheck() && Utils.getBedwarsStatus() == 2
                && event.entityPlayer == mc.thePlayer && event.item != null
                && event.item.getItem() == Items.milk_bucket) {
            magicMilkExpiresAt = System.currentTimeMillis() + MAGIC_MILK_DURATION_MS;
        }
    }

    @SubscribeEvent
    public void onWorldJoin(EntityJoinWorldEvent e) {
        if (e.entity == mc.thePlayer) {
            armoredPlayer.clear();
            lastHeldMap.clear();
            lastAlertMap.clear();
            obsidianPos.clear();
            entitySpawnQueue.clear();
            spawnedMobs.clear();
            resetSpawnTracking();
            magicMilkExpiresAt = 0L;
            resetDragonHud();
            resetClosestEnemyHud();
        }
        else {
            if (e.entity instanceof EntityIronGolem) {
                if (Utils.getBedwarsStatus() != 2) {
                    return;
                }
                Vec3 spawnPosition = new Vec3(e.entity.posX, e.entity.posY, e.entity.posZ);
                for (SkyWars.SpawnEggInfo eggInfo : entitySpawnQueue) {
                    if (eggInfo.spawnPos.distanceTo(spawnPosition) > 3 || Utils.timeBetween(mc.thePlayer.ticksExisted, eggInfo.tickSpawned) > 60) { // 3 seconds or not at spawn point then not own mob
                        return;
                    }
                    if (!entitySpawnQueue.remove(eggInfo)) {
                        return;
                    }
                    spawnedMobs.add(e.entity.getEntityId());
                }
            }
        }
    }

    @Override
    public void onUpdate() {
        if (!Utils.nullCheck()) {
            return;
        }

        if (pendingSpawnAnchorCapture && Utils.getBedwarsStatus() == 2) {
            spawnAnchor = mc.thePlayer.getPosition();
            ownBedCenter = findOwnBedCenter();
            pendingSpawnAnchorCapture = false;
        }

        if (Utils.getBedwarsStatus() == 2) {
            if (bow.isToggled() || diamondArmor.isToggled() || dreamDefender.isToggled()
                    || enderPearl.isToggled() || fireball.isToggled()
                    || knockbackStick.isToggled() || magicMilk.isToggled() || obsidian.isToggled()
                    || potions.isToggled() || rotationItems.isToggled() || waterBucket.isToggled()) {
                for (EntityPlayer p : mc.theWorld.playerEntities) {
                    if (p == null) {
                        continue;
                    }
                    if (p == mc.thePlayer) {
                        continue;
                    }
                    if (AntiBot.isBot(p)) {
                        continue;
                    }
                    if (ignoreTeammate.isToggled() && Utils.isTeammate(p)) {
                        continue;
                    }
                    String name = p.getName();
                    ItemStack item = p.getHeldItem();
                    if (diamondArmor.isToggled()) {
                        ItemStack leggings = p.inventory.armorInventory[1];
                        if (!armoredPlayer.contains(name) && leggings != null && leggings.getItem() != null && leggings.getItem() == Items.diamond_leggings) {
                            armoredPlayer.add(name);
                            double distance = mc.thePlayer.getDistanceToEntity(p);
                            Utils.sendMessage(p.getDisplayName().getUnformattedText() + " &7has purchased &bDiamond Armor " + formatDistance(distance));
                            ping();
                        }
                    }
                    if (item != null && !lastHeldMap.containsKey(name)) {
                        String itemType = getItemType(item);
                        if (itemType != null) {
                            lastHeldMap.put(name, itemType);
                            double distance = mc.thePlayer.getDistanceToEntity(p);
                            handleAlert(p, itemType, distance);
                        }
                    } else if (lastHeldMap.containsKey(name)) {
                        String itemType = lastHeldMap.get(name);
                        if (!itemType.equals(getItemType(item))) {
                            lastHeldMap.remove(name);
                        }
                    }
                }
            }
        }
    }

    @SubscribeEvent
    public void onChat(ClientChatReceivedEvent event) {
        if (!Utils.nullCheck()) {
            return;
        }

        String strippedMessage = Utils.stripColor(event.message.getUnformattedText());
        if (strippedMessage.startsWith(" ") && strippedMessage.contains("Protect your bed and destroy the enemy beds.")) {
            ownBedDestroyed = false;
            ownBedCenter = null;
            pendingSpawnAnchorCapture = true;
            waitingForRespawn = false;
            magicMilkExpiresAt = 0L;
        }
        else if (strippedMessage.equals("You will respawn because you still have a bed!")) {
            waitingForRespawn = true;
            respawnMessageTime = System.currentTimeMillis();
        }
        else if (strippedMessage.equals("You have respawned!") && waitingForRespawn && Utils.timeBetween(System.currentTimeMillis(), respawnMessageTime) <= 12000) {
            pendingSpawnAnchorCapture = true;
            waitingForRespawn = false;
        }

        if (strippedMessage.trim().startsWith("BED DESTRUCTION > Your Bed")) {
            ownBedDestroyed = true;
            waitingForRespawn = false;
        }
    }

    public boolean isOwnBed(BlockPos[] pair) {
        return ownBedCenter != null && Utils.getBedwarsStatus() == 2 && pair != null && pair.length >= 2
                && bedCenter(pair).squareDistanceTo(ownBedCenter) <= 0.25;
    }

    public void removeOwnBedPair(List<BlockPos[]> bedPairs) {
        if (!shouldWhitelistOwnBed() || bedPairs.isEmpty()) {
            return;
        }

        BlockPos[] ownBedPair = null;
        double closestDistance = Double.POSITIVE_INFINITY;
        Vec3 spawnCenter = spawnAnchorCenter();

        for (BlockPos[] pair : bedPairs) {
            double distance = spawnCenter.squareDistanceTo(bedCenter(pair));
            if (distance < closestDistance) {
                closestDistance = distance;
                ownBedPair = pair;
            }
        }

        if (ownBedPair != null) {
            ownBedCenter = bedCenter(ownBedPair);
            bedPairs.remove(ownBedPair);
        }
    }

    @SubscribeEvent
    public void onSendPacket(SendPacketEvent e) {
        if (e.getPacket() instanceof C08PacketPlayerBlockPlacement) {
            C08PacketPlayerBlockPlacement p = (C08PacketPlayerBlockPlacement) e.getPacket();
            if (p.getPlacedBlockDirection() != 255 && p.getStack() != null && p.getStack().getItem() != null) {
                if (p.getStack().getItem() instanceof ItemMonsterPlacer) {
                    Class<? extends Entity> oclass = EntityList.stringToClassMapping.get(ItemMonsterPlacer.getEntityName(p.getStack()));
                    if (oclass == null) {
                        return;
                    }
                    if (oclass.getSimpleName().equals("EntityIronGolem")) {
                        entitySpawnQueue.add(new SkyWars.SpawnEggInfo(p.getPosition(), mc.thePlayer.ticksExisted));
                    }
                }
            }
        }
    }

    @SubscribeEvent
    public void onReceivePacket(ReceivePacketEvent e) {
        if (e.getPacket() instanceof S23PacketBlockChange) {
            S23PacketBlockChange p = (S23PacketBlockChange) e.getPacket();
            if (p.getBlockState() != null && p.getBlockState().getBlock() instanceof BlockObsidian && isNextToBed(p.getBlockPosition())) {
                this.obsidianPos.put(p.getBlockPosition(), System.currentTimeMillis());
            }
        }
    }

    private boolean isNextToBed(BlockPos blockPos) {
        for (EnumFacing enumFacing : EnumFacing.values()) {
            BlockPos offset = blockPos.offset(enumFacing);
            if (BlockUtils.getBlock(offset) instanceof BlockBed) {
                return true;
            }
        }
        return false;
    }

    private boolean shouldWhitelistOwnBed() {
        return whitelistOwnBed.isToggled() && spawnAnchor != null && Utils.getBedwarsStatus() == 2
                && mc.thePlayer.getDistanceSq(spawnAnchor) <= OWN_BED_PROTECTION_RADIUS_SQ;
    }

    private Vec3 spawnAnchorCenter() {
        return new Vec3(spawnAnchor.getX() + 0.5, spawnAnchor.getY() + 0.5, spawnAnchor.getZ() + 0.5);
    }

    private Vec3 getOwnBedReference() {
        return ownBedCenter != null ? ownBedCenter : spawnAnchor == null ? null : spawnAnchorCenter();
    }

    private Vec3 findOwnBedCenter() {
        if (spawnAnchor == null) {
            return null;
        }

        Vec3 spawnCenter = spawnAnchorCenter();
        Vec3 closestBedCenter = null;
        double closestDistance = Double.POSITIVE_INFINITY;

        for (int x = -OWN_BED_SEARCH_HORIZONTAL_RADIUS; x <= OWN_BED_SEARCH_HORIZONTAL_RADIUS; x++) {
            for (int y = -OWN_BED_SEARCH_VERTICAL_RADIUS; y <= OWN_BED_SEARCH_VERTICAL_RADIUS; y++) {
                for (int z = -OWN_BED_SEARCH_HORIZONTAL_RADIUS; z <= OWN_BED_SEARCH_HORIZONTAL_RADIUS; z++) {
                    BlockPos position = spawnAnchor.add(x, y, z);
                    if (!(BlockUtils.getBlock(position) instanceof BlockBed)) {
                        continue;
                    }

                    Vec3 center = new Vec3(position.getX() + 0.5, position.getY() + 0.5, position.getZ() + 0.5);
                    double distance = spawnCenter.squareDistanceTo(center);
                    if (distance < closestDistance) {
                        closestDistance = distance;
                        closestBedCenter = center;
                    }
                }
            }
        }

        return closestBedCenter;
    }

    private List<EntityPlayer> findClosestEnemies(Vec3 bedReference, int players) {
        Map<UUID, EntityPlayer> enemiesById = new LinkedHashMap<>();

        for (EntityPlayer player : mc.theWorld.playerEntities) {
            if (player == null
                    || player == mc.thePlayer
                    || !player.isEntityAlive()
                    || player.isSpectator()
                    || AntiBot.isBot(player)
                    || Utils.isTeammate(player)
                    || Utils.isFriended(player)) {
                continue;
            }

            UUID playerId = player.getUniqueID();
            EntityPlayer existing = enemiesById.get(playerId);
            if (existing == null
                    || player.ticksExisted < existing.ticksExisted
                    || player.ticksExisted == existing.ticksExisted && player.getEntityId() > existing.getEntityId()) {
                enemiesById.put(playerId, player);
            }
        }

        List<EntityPlayer> enemies = new ArrayList<>(enemiesById.values());
        enemies.sort(Comparator.comparingDouble(player -> distanceToReference(player, bedReference)));

        int amount = Math.min(Math.max(players, 0), enemies.size());
        return new ArrayList<>(enemies.subList(0, amount));
    }

    private double distanceToReference(EntityPlayer player, Vec3 bedReference) {
        if (bedReference == null) {
            return mc.thePlayer.getDistanceToEntity(player);
        }
        return player.getDistance(bedReference.xCoord, bedReference.yCoord, bedReference.zCoord);
    }

    private Vec3 bedCenter(BlockPos[] pair) {
        return new Vec3(
                (pair[0].getX() + pair[1].getX() + 1.0) * 0.5,
                (pair[0].getY() + pair[1].getY() + 1.0) * 0.5,
                (pair[0].getZ() + pair[1].getZ() + 1.0) * 0.5
        );
    }

    private void resetSpawnTracking() {
        spawnAnchor = null;
        ownBedCenter = null;
        ownBedDestroyed = false;
        pendingSpawnAnchorCapture = false;
        waitingForRespawn = false;
        respawnMessageTime = 0L;
    }

    private void resetClosestEnemyHud() {
        closestEnemyLayout.initialized = false;
    }

    private String getItemType(ItemStack item) {
        if (item == null || item.getItem() == null) {
            return null;
        }
        if (item.getItem() instanceof ItemEnderPearl && enderPearl.isToggled()) {
            return "&3Ender Pearl";
        }
        else if (item.getItem() instanceof ItemBow && bow.isToggled()) {
            if (EnchantmentHelper.getEnchantmentLevel(Enchantment.punch.effectId, item) > 0) {
                return "&6Punch Bow";
            }
            if (EnchantmentHelper.getEnchantmentLevel(Enchantment.power.effectId, item) > 0) {
                return "&6Power Bow";
            }
            return "&6Bow";
        }
        else if (item.getItem() == Items.milk_bucket && magicMilk.isToggled()) {
            return "&fMagic Milk";
        }
        else if (item.getItem() == Items.stick && item.isItemEnchanted() && knockbackStick.isToggled()) {
            return "&6Knockback Stick";
        }
        else if (item.getItem() instanceof ItemMonsterPlacer && item.getDisplayName().contains("Dream Defender") && dreamDefender.isToggled()) {
            return "&fDream Defender";
        }
        else if (item.getItem() instanceof ItemPotion && potions.isToggled()) {
            String potionType = getPotionType(item);
            if (potionType != null) {
                String color = potionType.equals("Invis") ? "&d" : potionType.equals("Jump") ? "&a" : "&b";
                return color + potionType + " &7Potion";
            }
        }
        else if (item.getItem() == Items.water_bucket && waterBucket.isToggled()) {
            return "&bWater Bucket";
        }
        else if (item.getItem() == Item.getItemFromBlock(Blocks.obsidian) && obsidian.isToggled()) {
            return "&dObsidian";
        }
        else if (item.getItem() instanceof ItemFireball && fireball.isToggled()) {
            return "&6Fireball";
        }
        else if (rotationItems.isToggled()) {
            if (item.getItem() == Items.prismarine_shard) {
                return "&3Block Zapper";
            }
            if (item.getItem() == Items.golden_horse_armor) {
                return "&eCharlie Unicorn";
            }
            if (item.getItem() == Item.getItemFromBlock(Blocks.ice)) {
                return "&bIce Bridge";
            }
            if (item.getItem() == Items.snowball && item.getDisplayName().contains("Sleeping Dust")) {
                return "&fSleeping Dust";
            }
        }
        return null;
    }

    private String getPotionType(ItemStack item) {
        List<PotionEffect> effects = ((ItemPotion) item.getItem()).getEffects(item);
        if (effects == null) {
            return null;
        }
        for (PotionEffect effect : effects) {
            if (effect.getPotionID() == Potion.moveSpeed.id) {
                return "Speed";
            }
            if (effect.getPotionID() == Potion.invisibility.id) {
                return "Invis";
            }
            if (effect.getPotionID() == Potion.jump.id) {
                return "Jump";
            }
        }
        return null;
    }

    private void handleAlert(EntityPlayer player, String itemType, double distance) {
        long currentTime = System.currentTimeMillis();
        long interval = Math.round(alertInterval.getInput() * 1000.0);
        String alertKey = player.getUniqueID() + ":" + itemType;
        Long lastAlert = lastAlertMap.get(alertKey);
        if (lastAlert != null && currentTime - lastAlert < interval) {
            return;
        }

        lastAlertMap.put(alertKey, currentTime);
        String alert = player.getDisplayName().getUnformattedText() + " &7is holding " + itemType + " " + formatDistance(distance);
        Utils.sendMessage(alert);
        ping();
    }

    private String formatDistance(double distance) {
        char color = distance <= 10.0 ? 'c' : distance <= 25.0 ? '6' : distance <= 50.0 ? 'e'
                : distance <= 100.0 ? 'a' : '2';
        return "§" + color + (int) distance + "m";
    }

    public float getClosestEnemyPosX() {
        syncHudPositions();
        return closestEnemyPosX;
    }

    public float getClosestEnemyPosY() {
        syncHudPositions();
        return closestEnemyPosY;
    }

    public float getClosestEnemyRelativePosX() {
        syncHudPositions();
        return closestEnemyRelativePosX;
    }

    public float getClosestEnemyRelativePosY() {
        syncHudPositions();
        return closestEnemyRelativePosY;
    }

    public void setClosestEnemyRelativePosition(float normalizedX, float normalizedY) {
        closestEnemyRelativePosX = normalizedX;
        closestEnemyRelativePosY = normalizedY;
        syncHudPositions();
    }

    public void setClosestEnemyAbsolutePosition(float absoluteX, float absoluteY) {
        setClosestEnemyAbsolutePosition(absoluteX, absoluteY, new ScaledResolution(mc));
    }

    public float getDragonPosX() {
        syncHudPositions();
        return dragonPosX;
    }

    public float getDragonPosY() {
        syncHudPositions();
        return dragonPosY;
    }

    public float getDragonRelativePosX() {
        syncHudPositions();
        return dragonRelativePosX;
    }

    public float getDragonRelativePosY() {
        syncHudPositions();
        return dragonRelativePosY;
    }

    public void setDragonRelativePosition(float normalizedX, float normalizedY) {
        dragonRelativePosX = normalizedX;
        dragonRelativePosY = normalizedY;
        syncHudPositions();
    }

    public void setDragonAbsolutePosition(float absoluteX, float absoluteY) {
        setDragonAbsolutePosition(absoluteX, absoluteY, new ScaledResolution(mc));
    }

    public float getMagicMilkPosX() {
        syncHudPositions();
        return magicMilkPosX;
    }

    public float getMagicMilkPosY() {
        syncHudPositions();
        return magicMilkPosY;
    }

    public float getMagicMilkRelativePosX() {
        syncHudPositions();
        return magicMilkRelativePosX;
    }

    public float getMagicMilkRelativePosY() {
        syncHudPositions();
        return magicMilkRelativePosY;
    }

    public void setMagicMilkRelativePosition(float normalizedX, float normalizedY) {
        magicMilkRelativePosX = normalizedX;
        magicMilkRelativePosY = normalizedY;
        syncHudPositions();
    }

    public void setMagicMilkAbsolutePosition(float absoluteX, float absoluteY) {
        setMagicMilkAbsolutePosition(absoluteX, absoluteY, new ScaledResolution(mc));
    }

    private void syncHudPositions() {
        syncHudPositions(new ScaledResolution(mc));
    }

    private void syncHudPositions(ScaledResolution resolution) {
        int scaledWidth = Math.max(1, resolution.getScaledWidth());
        int scaledHeight = Math.max(1, resolution.getScaledHeight());
        float defaultClosestEnemyY = scaledHeight / 4.0f - mc.fontRendererObj.FONT_HEIGHT / 2.0f;

        if (Float.isNaN(closestEnemyRelativePosX) || Float.isNaN(closestEnemyRelativePosY)) {
            if (Float.isNaN(closestEnemyPosX) || Float.isNaN(closestEnemyPosY)) {
                closestEnemyPosX = 0.0f;
                closestEnemyPosY = defaultClosestEnemyY;
            }
            closestEnemyRelativePosX = closestEnemyPosX / scaledWidth;
            closestEnemyRelativePosY = closestEnemyPosY / scaledHeight;
        }
        closestEnemyPosX = closestEnemyRelativePosX * scaledWidth;
        closestEnemyPosY = closestEnemyRelativePosY * scaledHeight;

        if (Float.isNaN(dragonRelativePosX) || Float.isNaN(dragonRelativePosY)) {
            if (Float.isNaN(dragonPosX) || Float.isNaN(dragonPosY)) {
                dragonPosX = closestEnemyPosX;
                dragonPosY = Math.max(5.0f, closestEnemyPosY - mc.fontRendererObj.FONT_HEIGHT - 9.0f);
            }
            dragonRelativePosX = dragonPosX / scaledWidth;
            dragonRelativePosY = dragonPosY / scaledHeight;
        }
        dragonPosX = dragonRelativePosX * scaledWidth;
        dragonPosY = dragonRelativePosY * scaledHeight;

        if (Float.isNaN(magicMilkRelativePosX) || Float.isNaN(magicMilkRelativePosY)) {
            if (Float.isNaN(magicMilkPosX) || Float.isNaN(magicMilkPosY)) {
                magicMilkPosX = 0.0f;
                magicMilkPosY = defaultClosestEnemyY + mc.fontRendererObj.FONT_HEIGHT + 9.0f;
            }
            magicMilkRelativePosX = magicMilkPosX / scaledWidth;
            magicMilkRelativePosY = magicMilkPosY / scaledHeight;
        }
        magicMilkPosX = magicMilkRelativePosX * scaledWidth;
        magicMilkPosY = magicMilkRelativePosY * scaledHeight;
    }

    private void setClosestEnemyAbsolutePosition(float absoluteX, float absoluteY, ScaledResolution resolution) {
        closestEnemyPosX = absoluteX;
        closestEnemyPosY = absoluteY;
        closestEnemyRelativePosX = absoluteX / Math.max(1, resolution.getScaledWidth());
        closestEnemyRelativePosY = absoluteY / Math.max(1, resolution.getScaledHeight());
    }

    private void setDragonAbsolutePosition(float absoluteX, float absoluteY, ScaledResolution resolution) {
        dragonPosX = absoluteX;
        dragonPosY = absoluteY;
        dragonRelativePosX = absoluteX / Math.max(1, resolution.getScaledWidth());
        dragonRelativePosY = absoluteY / Math.max(1, resolution.getScaledHeight());
    }

    private void setMagicMilkAbsolutePosition(float absoluteX, float absoluteY, ScaledResolution resolution) {
        magicMilkPosX = absoluteX;
        magicMilkPosY = absoluteY;
        magicMilkRelativePosX = absoluteX / Math.max(1, resolution.getScaledWidth());
        magicMilkRelativePosY = absoluteY / Math.max(1, resolution.getScaledHeight());
    }

    private void resetHudPositions(ScaledResolution resolution) {
        float closestEnemyY = resolution.getScaledHeight() / 4.0f - mc.fontRendererObj.FONT_HEIGHT / 2.0f;
        setClosestEnemyAbsolutePosition(0.0f, closestEnemyY, resolution);
        setDragonAbsolutePosition(0.0f, Math.max(5.0f, closestEnemyY - mc.fontRendererObj.FONT_HEIGHT - 9.0f), resolution);
        setMagicMilkAbsolutePosition(0.0f, closestEnemyY + mc.fontRendererObj.FONT_HEIGHT + 9.0f, resolution);
    }

    private static final class HudBoxBounds {
        private final float left;
        private final float top;
        private final float right;
        private final float bottom;

        private HudBoxBounds(float left, float top, float right, float bottom) {
            this.left = left;
            this.top = top;
            this.right = right;
            this.bottom = bottom;
        }

        private boolean contains(int mouseX, int mouseY) {
            return mouseX >= left && mouseX <= right && mouseY >= top && mouseY <= bottom;
        }
    }

    private class EditPositionsScreen extends GuiScreen {
        private static final int DRAG_NONE = 0;
        private static final int DRAG_CLOSEST_ENEMY = 1;
        private static final int DRAG_MAGIC_MILK = 2;
        private static final int DRAG_DRAGON = 3;
        private static final long ARROW_HOLD_DELAY_MS = 300L;
        private static final long ARROW_INITIAL_REPEAT_MS = 120L;
        private static final long ARROW_MIN_REPEAT_MS = 40L;
        private static final double ARROW_ACCELERATION_HALF_LIFE_MS = 1500.0;

        private GuiButtonExt resetPositions;
        private HudBoxBounds closestEnemyBounds;
        private HudBoxBounds magicMilkBounds;
        private HudBoxBounds dragonBounds;
        private int dragging = DRAG_NONE;
        private float closestEnemyX;
        private float closestEnemyY;
        private float magicMilkX;
        private float magicMilkY;
        private float dragonX;
        private float dragonY;
        private float dragStartX;
        private float dragStartY;
        private int lastMouseX;
        private int lastMouseY;
        private int heldArrowBox = DRAG_NONE;
        private int heldArrowKey;
        private long arrowHoldStartedAt;
        private long lastArrowNudgeAt;

        @Override
        public void initGui() {
            super.initGui();
            this.buttonList.add(this.resetPositions = new GuiButtonExt(1, this.width - 95, this.height - 25, 90, 20, "Reset positions"));
            syncHudPositions(new ScaledResolution(this.mc));
            syncEditorPositions();
        }

        @Override
        public void drawScreen(int mouseX, int mouseY, float partialTicks) {
            ScaledResolution resolution = new ScaledResolution(this.mc);
            if (this.dragging == DRAG_NONE) {
                syncHudPositions(resolution);
                syncEditorPositions();
            }

            updateHeldArrowMovement();
            drawRect(0, 0, this.width, this.height, 0xB2000000);
            setClosestEnemyAbsolutePosition(this.closestEnemyX, this.closestEnemyY, resolution);
            setMagicMilkAbsolutePosition(this.magicMilkX, this.magicMilkY, resolution);
            setDragonAbsolutePosition(this.dragonX, this.dragonY, resolution);

            List<EnemyHudEntry> previewEntries = new ArrayList<>();

            int previewPlayers = Math.max(1, (int) closestEnemy.getInput());

            for (int i = 0; i < previewPlayers; i++) {
                String name = mc.thePlayer.getDisplayName().getUnformattedText();
                String distance = formatDistance(16 + i * 3);

                previewEntries.add(
                        new EnemyHudEntry(name, distance, mc.thePlayer.getHeldItem())
                );
            }

            this.closestEnemyBounds = drawEnemyHudBox(
                    previewEntries,
                    this.closestEnemyX,
                    this.closestEnemyY
            );

            this.magicMilkBounds = drawHudBox(
                    "§7Magic Milk: §a30.0s",
                    this.magicMilkX,
                    this.magicMilkY
            );

            this.dragonBounds = drawDragonHudBox(50.0, this.dragonX, this.dragonY);

            String message = "Drag a box to reposition it.";
            int messageX = resolution.getScaledWidth() / 2 - this.fontRendererObj.getStringWidth(message) / 2;
            int messageY = resolution.getScaledHeight() / 2 - 10;
            GlStateManager.enableAlpha();
            GlStateManager.alphaFunc(GL11.GL_GREATER, 0.1f);
            enableClosestEnemyAlphaBlending();
            try {
                RenderUtils.drawColoredString(message, '-', messageX, messageY, 2L, 0L, true, this.fontRendererObj);
            }
            finally {
                GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
                GlStateManager.disableBlend();
            }

            try {
                this.handleInput();
            }
            catch (IOException ignored) {
            }
            super.drawScreen(mouseX, mouseY, partialTicks);
        }

        @Override
        protected void keyTyped(char typedChar, int keyCode) throws IOException {
            if (keyCode == Keyboard.KEY_LEFT || keyCode == Keyboard.KEY_RIGHT
                    || keyCode == Keyboard.KEY_UP || keyCode == Keyboard.KEY_DOWN) {
                if (!Keyboard.isRepeatEvent() && this.dragging == DRAG_NONE) {
                    int mouseX = Mouse.getX() * this.width / this.mc.displayWidth;
                    int mouseY = this.height - Mouse.getY() * this.height / this.mc.displayHeight - 1;
                    int hoveredBox = hoveredBox(mouseX, mouseY);
                    clearHeldArrowMovement();
                    if (hoveredBox != DRAG_NONE) {
                        this.heldArrowBox = hoveredBox;
                        this.heldArrowKey = keyCode;
                        this.arrowHoldStartedAt = this.lastArrowNudgeAt = System.currentTimeMillis();
                        moveBoxWithArrow(hoveredBox, keyCode);
                    }
                }
                return;
            }
            super.keyTyped(typedChar, keyCode);
        }

        private int hoveredBox(int mouseX, int mouseY) {
            if (this.closestEnemyBounds != null && this.closestEnemyBounds.contains(mouseX, mouseY)) {
                return DRAG_CLOSEST_ENEMY;
            }
            if (this.magicMilkBounds != null && this.magicMilkBounds.contains(mouseX, mouseY)) {
                return DRAG_MAGIC_MILK;
            }
            if (this.dragonBounds != null && this.dragonBounds.contains(mouseX, mouseY)) {
                return DRAG_DRAGON;
            }
            return DRAG_NONE;
        }

        private void updateHeldArrowMovement() {
            if (this.heldArrowBox == DRAG_NONE) {
                return;
            }
            if (this.dragging != DRAG_NONE || !Keyboard.isKeyDown(this.heldArrowKey)) {
                clearHeldArrowMovement();
                return;
            }

            long now = System.currentTimeMillis();
            long acceleratingDuration = now - this.arrowHoldStartedAt - ARROW_HOLD_DELAY_MS;
            if (acceleratingDuration < 0L) {
                return;
            }
            long repeatDelay = Math.max(ARROW_MIN_REPEAT_MS,
                    Math.round(ARROW_INITIAL_REPEAT_MS * Math.pow(0.5, acceleratingDuration / ARROW_ACCELERATION_HALF_LIFE_MS)));
            if (now - this.lastArrowNudgeAt >= repeatDelay) {
                moveBoxWithArrow(this.heldArrowBox, this.heldArrowKey);
                this.lastArrowNudgeAt = now;
            }
        }

        private void moveBoxWithArrow(int box, int keyCode) {
            int offsetX = keyCode == Keyboard.KEY_LEFT ? -1 : keyCode == Keyboard.KEY_RIGHT ? 1 : 0;
            int offsetY = keyCode == Keyboard.KEY_UP ? -1 : keyCode == Keyboard.KEY_DOWN ? 1 : 0;
            ScaledResolution resolution = new ScaledResolution(this.mc);
            if (box == DRAG_CLOSEST_ENEMY) {
                this.closestEnemyX += offsetX;
                this.closestEnemyY += offsetY;
                setClosestEnemyAbsolutePosition(this.closestEnemyX, this.closestEnemyY, resolution);
            }
            else if (box == DRAG_MAGIC_MILK) {
                this.magicMilkX += offsetX;
                this.magicMilkY += offsetY;
                setMagicMilkAbsolutePosition(this.magicMilkX, this.magicMilkY, resolution);
            }
            else if (box == DRAG_DRAGON) {
                this.dragonX += offsetX;
                this.dragonY += offsetY;
                setDragonAbsolutePosition(this.dragonX, this.dragonY, resolution);
            }
        }

        private void clearHeldArrowMovement() {
            this.heldArrowBox = DRAG_NONE;
            this.heldArrowKey = Keyboard.KEY_NONE;
            this.arrowHoldStartedAt = 0L;
            this.lastArrowNudgeAt = 0L;
        }

        @Override
        protected void mouseClickMove(int mouseX, int mouseY, int button, long timeSinceLastClick) {
            super.mouseClickMove(mouseX, mouseY, button, timeSinceLastClick);
            if (button != 0) {
                return;
            }

            if (this.dragging == DRAG_CLOSEST_ENEMY) {
                this.closestEnemyX = this.dragStartX + mouseX - this.lastMouseX;
                this.closestEnemyY = this.dragStartY + mouseY - this.lastMouseY;
            }
            else if (this.dragging == DRAG_MAGIC_MILK) {
                this.magicMilkX = this.dragStartX + mouseX - this.lastMouseX;
                this.magicMilkY = this.dragStartY + mouseY - this.lastMouseY;
            }
            else if (this.dragging == DRAG_DRAGON) {
                this.dragonX = this.dragStartX + mouseX - this.lastMouseX;
                this.dragonY = this.dragStartY + mouseY - this.lastMouseY;
            }
            else if (this.closestEnemyBounds != null && this.closestEnemyBounds.contains(mouseX, mouseY)) {
                beginDragging(DRAG_CLOSEST_ENEMY, this.closestEnemyX, this.closestEnemyY, mouseX, mouseY);
            }
            else if (this.magicMilkBounds != null && this.magicMilkBounds.contains(mouseX, mouseY)) {
                beginDragging(DRAG_MAGIC_MILK, this.magicMilkX, this.magicMilkY, mouseX, mouseY);
            }
            else if (this.dragonBounds != null && this.dragonBounds.contains(mouseX, mouseY)) {
                beginDragging(DRAG_DRAGON, this.dragonX, this.dragonY, mouseX, mouseY);
            }
        }

        private void beginDragging(int element, float elementX, float elementY, int mouseX, int mouseY) {
            clearHeldArrowMovement();
            this.dragging = element;
            this.dragStartX = elementX;
            this.dragStartY = elementY;
            this.lastMouseX = mouseX;
            this.lastMouseY = mouseY;
        }

        @Override
        protected void mouseReleased(int mouseX, int mouseY, int state) {
            super.mouseReleased(mouseX, mouseY, state);
            if (state == 0) {
                this.dragging = DRAG_NONE;
            }
        }

        @Override
        public void actionPerformed(GuiButton button) {
            if (button == this.resetPositions) {
                clearHeldArrowMovement();
                this.dragging = DRAG_NONE;
                resetHudPositions(new ScaledResolution(this.mc));
                syncEditorPositions();
            }
        }

        private void syncEditorPositions() {
            this.closestEnemyX = closestEnemyPosX;
            this.closestEnemyY = closestEnemyPosY;
            this.magicMilkX = magicMilkPosX;
            this.magicMilkY = magicMilkPosY;
            this.dragonX = dragonPosX;
            this.dragonY = dragonPosY;
        }

        @Override
        public void onGuiClosed() {
            clearHeldArrowMovement();
            super.onGuiClosed();
        }

        @Override
        public boolean doesGuiPauseGame() {
            return false;
        }
    }

    private void ping() {
        if (shouldPing.isToggled()) {
            mc.thePlayer.playSound("note.pling", 1.0f, 1.0f);
        }
    }

    private HudBoxBounds drawEnemyHudBox(List<EnemyHudEntry> entries, float x, float textY) {
        if (entries.isEmpty()) {
            return null;
        }

        float gap = mc.fontRendererObj.getCharWidth(' ') * 2.0f;
        float maxNameWidth = 0.0f;
        float maxDistanceWidth = 0.0f;
        boolean hasItem = false;

        for (EnemyHudEntry entry : entries) {
            maxNameWidth = Math.max(maxNameWidth, mc.fontRendererObj.getStringWidth(entry.name));
            maxDistanceWidth = Math.max(maxDistanceWidth, mc.fontRendererObj.getStringWidth(entry.distance));
            hasItem |= entry.heldItem != null;
        }

        float width = maxNameWidth + gap + maxDistanceWidth + (hasItem ? gap + 10.0f : 0.0f);
        closestEnemyLayout.update(width, maxNameWidth, maxDistanceWidth);
        float animatedWidth = closestEnemyLayout.width;
        float nameWidth = closestEnemyLayout.nameWidth;
        float distanceWidth = closestEnemyLayout.distanceWidth;
        ScaledResolution resolution = new ScaledResolution(mc);
        float left = x - 5.0f;
        float right = x + animatedWidth + 4.0f;
        float top = textY - 5.0f;
        float bottom = textY + (entries.size() - 1) * 12.0f + mc.fontRendererObj.FONT_HEIGHT + 3.5f;
        if (left <= 0.0f) {
            left = -3.0f;
        }
        if (right > resolution.getScaledWidth()) {
            right = resolution.getScaledWidth() + 3.0f;
        }
        right -= 0.5f;

        GL11.glPushAttrib(GL11.GL_SCISSOR_BIT | GL11.GL_DEPTH_BUFFER_BIT | GL11.GL_COLOR_BUFFER_BIT
                | GL11.GL_ENABLE_BIT | GL11.GL_CURRENT_BIT);
        try {
            enableClosestEnemyAlphaBlending();
            RenderUtils.drawRoundedRectangle(left, top, right, bottom, 8.0f, 0x7D000000);
            scissorEnemyHud(x, top, x + nameWidth + 1.0f, bottom, resolution);

            for (int i = 0; i < entries.size(); i++) {
                mc.fontRendererObj.drawString(entries.get(i).name, x, textY + i * 12.0f, -1, true);
            }

            scissorEnemyHud(left, top, right, bottom, resolution);
            float distanceX = x + nameWidth + gap;
            for (int i = 0; i < entries.size(); i++) {
                EnemyHudEntry entry = entries.get(i);
                mc.fontRendererObj.drawString(entry.distance,
                        distanceX + distanceWidth - mc.fontRendererObj.getStringWidth(entry.distance),
                        textY + i * 12.0f, -1, true);
            }

            if (hasItem) {
                float itemX = (distanceX + distanceWidth + gap) * 1.6f;
                GlStateManager.pushMatrix();
                try {
                    GlStateManager.scale(0.625f, 0.625f, 0.625f);
                    for (int i = 0; i < entries.size(); i++) {
                        EnemyHudEntry entry = entries.get(i);
                        if (entry.heldItem != null) {
                            renderHeldItem(entry.heldItem, itemX, (textY + i * 12.0f - 0.5f) * 1.6f);
                        }
                    }
                }
                finally {
                    GlStateManager.popMatrix();
                }
            }
        }
        finally {
            GL11.glPopAttrib();
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.enableBlend();
            GlStateManager.disableBlend();
        }

        return new HudBoxBounds(left, top, right, bottom);
    }

    private void scissorEnemyHud(float left, float top, float right, float bottom, ScaledResolution resolution) {
        int scale = resolution.getScaleFactor();
        int x1 = Math.max(0, (int) Math.floor(left * scale));
        int x2 = Math.min(mc.displayWidth, (int) Math.ceil(right * scale));
        int y1 = Math.max(0, (int) Math.floor(mc.displayHeight - bottom * scale));
        int y2 = Math.min(mc.displayHeight, (int) Math.ceil(mc.displayHeight - top * scale));
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        GL11.glScissor(x1, y1, Math.max(0, x2 - x1), Math.max(0, y2 - y1));
    }

    private void enableClosestEnemyAlphaBlending() {
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(
                GL11.GL_SRC_ALPHA,
                GL11.GL_ONE_MINUS_SRC_ALPHA,
                GL11.GL_ONE,
                GL11.GL_ZERO
        );
    }

    private static final class DragonConeVisual {
        private Vec3 position;
        private long lastRenderNanos;

        private Vec3 update(DragonDivePrediction.Result prediction) {
            if (prediction.impact == null) {
                position = null;
                lastRenderNanos = 0L;
                return null;
            }

            long now = System.nanoTime();
            Vec3 target = prediction.impact;
            if (position == null || position.squareDistanceTo(target) > 16.0) {
                position = target;
            }
            else {
                double elapsed = Math.min(0.1, Math.max(0.0, (now - lastRenderNanos) / 1000000000.0));
                double progress = 1.0 - Math.exp(-elapsed / 0.045);
                position = new Vec3(position.xCoord + (target.xCoord - position.xCoord) * progress,
                        position.yCoord + (target.yCoord - position.yCoord) * progress,
                        position.zCoord + (target.zCoord - position.zCoord) * progress);
            }
            lastRenderNanos = now;

            AxisAlignedBB surface = prediction.impactSurface;
            double x = Math.max(surface.minX, Math.min(surface.maxX, position.xCoord));
            double y = Math.max(surface.minY, Math.min(surface.maxY, position.yCoord));
            double z = Math.max(surface.minZ, Math.min(surface.maxZ, position.zCoord));
            switch (prediction.impactFace) {
                case WEST:
                    x = surface.minX - 0.04;
                    break;
                case EAST:
                    x = surface.maxX + 0.04;
                    break;
                case DOWN:
                    y = surface.minY - 0.04;
                    break;
                case UP:
                    y = surface.maxY + 0.04;
                    break;
                case NORTH:
                    z = surface.minZ - 0.04;
                    break;
                case SOUTH:
                    z = surface.maxZ + 0.04;
                    break;
            }
            position = new Vec3(x, y, z);
            return position;
        }
    }

    private static final class EnemyHudLayout {
        private boolean initialized;
        private float width;
        private float nameWidth;
        private float distanceWidth;
        private float fromWidth;
        private float fromNameWidth;
        private float fromDistanceWidth;
        private float targetWidth;
        private float targetNameWidth;
        private float targetDistanceWidth;
        private long startedAt;

        private void update(float newWidth, float newNameWidth, float newDistanceWidth) {
            long now = System.currentTimeMillis();
            if (!initialized) {
                width = fromWidth = targetWidth = newWidth;
                nameWidth = fromNameWidth = targetNameWidth = newNameWidth;
                distanceWidth = fromDistanceWidth = targetDistanceWidth = newDistanceWidth;
                startedAt = now;
                initialized = true;
                return;
            }

            float progress = Math.min(1.0f, (float) (now - startedAt) / CLOSEST_ENEMY_ANIMATION_DURATION_MS);
            float eased = progress * progress * (3.0f - 2.0f * progress);
            width = fromWidth + (targetWidth - fromWidth) * eased;
            nameWidth = fromNameWidth + (targetNameWidth - fromNameWidth) * eased;
            distanceWidth = fromDistanceWidth + (targetDistanceWidth - fromDistanceWidth) * eased;
            if (Float.compare(targetWidth, newWidth) != 0 || Float.compare(targetNameWidth, newNameWidth) != 0
                    || Float.compare(targetDistanceWidth, newDistanceWidth) != 0) {
                fromWidth = width;
                fromNameWidth = nameWidth;
                fromDistanceWidth = distanceWidth;
                targetWidth = newWidth;
                targetNameWidth = newNameWidth;
                targetDistanceWidth = newDistanceWidth;
                startedAt = now;
            }
        }
    }

    private static final class EnemyHudEntry {
        private final String name;
        private final String distance;
        private final ItemStack heldItem;

        private EnemyHudEntry(String name, String distance, ItemStack heldItem) {
            this.name = name;
            this.distance = distance;
            this.heldItem = heldItem;
        }
    }
}
