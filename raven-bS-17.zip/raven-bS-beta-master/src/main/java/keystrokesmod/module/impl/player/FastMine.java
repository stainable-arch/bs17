package keystrokesmod.module.impl.player;

import keystrokesmod.mixin.impl.accessor.IAccessorPlayerControllerMP;
import keystrokesmod.module.Module;
import keystrokesmod.module.setting.impl.BlockListSetting;
import keystrokesmod.module.setting.impl.ButtonSetting;
import keystrokesmod.module.setting.impl.DescriptionSetting;
import keystrokesmod.module.setting.impl.SliderSetting;
import keystrokesmod.utility.Utils;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.ResourceLocation;

public class FastMine extends Module {
    private SliderSetting delay;
    public SliderSetting multiplier;
    private ButtonSetting creativeDisable;
    private ButtonSetting decreaseBreakDelay;
    private ButtonSetting ignoreShears;
    private final ButtonSetting blockBlacklistToggle;
    private final BlockListSetting blockBlacklist;
    private IBlockState blockHitDelayState;

    /** Stale check for passive decay; must not live on {@code MixinMinecraft} (Mixin 0.7 LVT vs {@code IAccessorPlayerControllerMP}). */
    private int passiveBlockHitLastSeen;

    public FastMine() {
        super("Fast Mine", category.player);
        this.liteModule = true;
        this.registerSetting(new DescriptionSetting("Vanilla is 250ms delay & 1x speed."));
        this.registerSetting(delay = new SliderSetting("Break delay", "ms", 250.0, 0.0, 250.0, 50.0));
        this.registerSetting(multiplier = new SliderSetting("Break speed", "x", 1.0, 1.0, 2.0, 0.02));
        this.registerSetting(creativeDisable = new ButtonSetting("Disable in creative", true));
        this.registerSetting(decreaseBreakDelay = new ButtonSetting("Decrease break delay", false));
        this.registerSetting(ignoreShears = new  ButtonSetting("Ignore shears", false));
        this.registerSetting(blockBlacklistToggle = new ButtonSetting("Block blacklist", false));
        this.registerSetting(blockBlacklist = new BlockListSetting("Blacklisted blocks"));
        this.closetModule = true;
    }

    @Override
    public void guiUpdate() {
        blockBlacklist.setVisible(blockBlacklistToggle.isToggled(), this);
    }

    private boolean isBlacklisted(IBlockState state) {
        if (!blockBlacklistToggle.isToggled() || state == null) {
            return false;
        }
        Block block = state.getBlock();
        ResourceLocation registryName = Block.blockRegistry.getNameForObject(block);
        if (registryName == null) {
            return false;
        }
        String registryId = registryName.toString();
        int meta = block.getMetaFromState(state);
        String storageId = meta != 0 ? registryId + ":" + meta : registryId;
        return blockBlacklist.contains(storageId) || blockBlacklist.contains(registryId);
    }

    private boolean isTargetBlacklisted() {
        return mc.theWorld != null && mc.objectMouseOver != null
                && mc.objectMouseOver.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK
                && isBlacklisted(mc.theWorld.getBlockState(mc.objectMouseOver.getBlockPos()));
    }

    public float getBreakSpeedMultiplier(IBlockState state) {
        if (!this.isEnabled() || isBlacklisted(state)) {
            return 1.0f;
        }
        if (creativeDisable.isToggled() && mc.thePlayer != null && mc.thePlayer.capabilities.isCreativeMode) {
            return 1.0f;
        }
        if (ignoreShears.isToggled() && mc.thePlayer != null && mc.thePlayer.getHeldItem() != null && mc.thePlayer.getHeldItem().getItem() instanceof net.minecraft.item.ItemShears) {
            return 1.0f;
        }
        float m = (float) multiplier.getInput();
        return m > 1.0f ? m : 1.0f;
    }

    public boolean shouldPassiveDecreaseBlockHitDelay() {
        return this.isEnabled() && decreaseBreakDelay.isToggled() && Utils.nullCheck()
                && !isBlacklisted(blockHitDelayState) && !isTargetBlacklisted();
    }

    public void tickPassiveBlockHitDecay(Minecraft mc) {
        if (mc.playerController == null) {
            return;
        }
        IAccessorPlayerControllerMP acc = (IAccessorPlayerControllerMP) mc.playerController;
        int delay = acc.getBlockHitDelay();
        if (delay <= 0) {
            blockHitDelayState = null;
        }
        if (!shouldPassiveDecreaseBlockHitDelay()) {
            this.passiveBlockHitLastSeen = delay;
            return;
        }
        if (delay > 0 && delay == this.passiveBlockHitLastSeen) {
            acc.setBlockHitDelay(delay - 1);
        }
        this.passiveBlockHitLastSeen = delay;
    }

    public int getBlockHitDelayOverrideOrMinusOne(IBlockState state) {
        blockHitDelayState = state;
        if (!this.isEnabled() || !Utils.nullCheck() || !mc.inGameHasFocus || isBlacklisted(state)) {
            return -1;
        }
        if (creativeDisable.isToggled() && mc.thePlayer != null && mc.thePlayer.capabilities.isCreativeMode) {
            return -1;
        }
        int ticks = (int) (this.delay.getInput() / 50.0);
        if (ticks >= 5) {
            return -1;
        }
        return ticks;
    }

    @Override
    public String getInfo() {
        return ((int) multiplier.getInput() == multiplier.getInput() ? (int) multiplier.getInput() + "" : multiplier.getInput()) + multiplier.getSuffix();
    }
}
