package keystrokesmod.module.impl.other;

import keystrokesmod.module.Module;
import keystrokesmod.module.setting.impl.ButtonSetting;
import keystrokesmod.module.setting.impl.SliderSetting;
import keystrokesmod.utility.Utils;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemSword;
import net.minecraft.util.EnumParticleTypes;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

import java.util.Random;

/**
 * OpenB4 HitParticles — same types, intensity, custom pool, filters.
 */
public class HitParticles extends Module {
    private static final String[] TYPE_NAMES = {
            "None", "Blood", "Criticals", "Enchantment table", "Redstone",
            "Sharpness", "Smoke", "Smoke large", "Sparks", "Hearts", "Stars", "Circles", "Diamonds"
    };

    private final SliderSetting intensity;
    private final SliderSetting primary;
    private final SliderSetting secondary;
    private final ButtonSetting disableReachHits;
    private final ButtonSetting playersOnly;
    private final ButtonSetting weaponOnly;
    private final Random random = new Random();

    private static final class Particle {
        boolean alive;
        double x, y, z, mx, my, mz;
        long born, life;
        int shape;
        float r, g, b;
    }
    private static final Particle[] POOL = new Particle[100];
    private static int aliveCount, next;
    static { for (int i = 0; i < POOL.length; i++) POOL[i] = new Particle(); }

    public HitParticles() {
        super("Hit Particles", Module.category.other);
        this.registerSetting(intensity = new SliderSetting("Intensity", 1.0, 0.5, 3.0, 0.1));
        this.registerSetting(primary = new SliderSetting("Primary", 5, TYPE_NAMES));
        this.registerSetting(secondary = new SliderSetting("Secondary", 0, TYPE_NAMES));
        this.registerSetting(disableReachHits = new ButtonSetting("Disable reach hits", false));
        this.registerSetting(playersOnly = new ButtonSetting("Players only", true));
        this.registerSetting(weaponOnly = new ButtonSetting("Weapon only", false));
    }

    @SubscribeEvent
    public void onAttack(AttackEntityEvent e) {
        if (!isEnabled() || !Utils.nullCheck()) return;
        if (e.entityPlayer != mc.thePlayer) return;
        Entity target = e.target;
        if (target == null) return;
        if (playersOnly.isToggled() && !(target instanceof EntityPlayer)) return;
        if (weaponOnly.isToggled()) {
            if (mc.thePlayer.getHeldItem() == null) return;
            Object it = mc.thePlayer.getHeldItem().getItem();
            if (!(it instanceof ItemSword) && !(it instanceof ItemAxe)) return;
        }
        if (disableReachHits.isToggled() && target instanceof EntityLivingBase) {
            if (mc.thePlayer.getDistanceToEntity(target) > 3.1) return;
        }
        int mult = Math.max(1, (int) Math.round(intensity.getInput()));
        spawnType((int) primary.getInput(), target, mult);
        int sec = (int) secondary.getInput();
        if (sec > 0) spawnType(sec, target, Math.max(1, mult / 2));
    }

    private void spawnType(int type, Entity entity, int mult) {
        if (type <= 0) return;
        switch (type) {
            case 1: burst(entity, EnumParticleTypes.REDSTONE, 8 * mult, 0.4, 0.1); break;
            case 2: emit(entity, EnumParticleTypes.CRIT, mult); break;
            case 3: burst(entity, EnumParticleTypes.ENCHANTMENT_TABLE, 6 * mult, 0.5, 0.8); break;
            case 4: burst(entity, EnumParticleTypes.REDSTONE, 6 * mult, 0.8, 0.1); break;
            case 5: emit(entity, EnumParticleTypes.CRIT_MAGIC, mult); break;
            case 6: burst(entity, EnumParticleTypes.SMOKE_NORMAL, 6 * mult, 0.4, 0.1); break;
            case 7: burst(entity, EnumParticleTypes.SMOKE_LARGE, 6 * mult, 0.4, 0.1); break;
            case 8: burst(entity, EnumParticleTypes.FIREWORKS_SPARK, 6 * mult, 0.4, 0.1); break;
            case 9: customBurst(entity, 0, mult); break;
            case 10: customBurst(entity, 1, mult); break;
            case 11: customBurst(entity, 2, mult); break;
            case 12: customBurst(entity, 3, mult); break;
            default: break;
        }
    }

    private void emit(Entity entity, EnumParticleTypes particle, int mult) {
        for (int i = 0; i < mult; i++) mc.effectRenderer.emitParticleAtEntity(entity, particle);
    }

    private void burst(Entity entity, EnumParticleTypes type, int n, double radius, double speed) {
        double x = entity.posX, y = entity.posY + entity.height * 0.5, z = entity.posZ;
        for (int i = 0; i < n; i++) {
            double dx = random.nextGaussian(), dy = random.nextGaussian(), dz = random.nextGaussian();
            double len = Math.sqrt(dx*dx+dy*dy+dz*dz); if (len < 1e-4) len = 1;
            mc.theWorld.spawnParticle(type,
                    x+(dx/len)*radius, y+(dy/len)*radius, z+(dz/len)*radius,
                    (dx/len)*speed, (dy/len)*speed, (dz/len)*speed);
        }
    }

    private void customBurst(Entity entity, int shape, int mult) {
        for (int i = 0; i < 8 * mult; i++) {
            Particle p = take();
            if (p == null) break;
            p.x = entity.posX + (random.nextDouble()-0.5)*0.4;
            p.y = entity.posY + entity.height * (0.3+random.nextDouble()*0.5);
            p.z = entity.posZ + (random.nextDouble()-0.5)*0.4;
            p.mx = (random.nextDouble()-0.5)*0.08;
            p.my = 0.05+random.nextDouble()*0.08;
            p.mz = (random.nextDouble()-0.5)*0.08;
            p.born = System.currentTimeMillis();
            p.life = 400+random.nextInt(400);
            p.shape = shape;
            p.r=1f; p.g=0.3f+random.nextFloat()*0.5f; p.b=0.4f+random.nextFloat()*0.4f;
            p.alive = true; aliveCount++;
        }
    }

    private static Particle take() {
        for (int i = 0; i < POOL.length; i++) {
            int idx = (next + i) % POOL.length;
            if (!POOL[idx].alive) { next = (idx+1)%POOL.length; return POOL[idx]; }
        }
        return null;
    }

    @SubscribeEvent
    public void onRender(RenderWorldLastEvent e) {
        if (aliveCount <= 0 || !Utils.nullCheck()) return;
        long now = System.currentTimeMillis();
        double px = mc.getRenderManager().viewerPosX;
        double py = mc.getRenderManager().viewerPosY;
        double pz = mc.getRenderManager().viewerPosZ;
        GlStateManager.pushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.disableDepth();
        for (Particle p : POOL) {
            if (!p.alive) continue;
            long age = now - p.born;
            if (age > p.life) { p.alive=false; aliveCount=Math.max(0,aliveCount-1); continue; }
            float t = (float)age/(float)p.life;
            p.x+=p.mx; p.y+=p.my; p.z+=p.mz; p.my-=0.003;
            float a = 1f-t;
            GlStateManager.color(p.r,p.g,p.b,a);
            GlStateManager.pushMatrix();
            GlStateManager.translate(p.x-px, p.y-py, p.z-pz);
            float s = 0.05f*(1f-t*0.5f);
            GlStateManager.scale(s,s,s);
            GL11.glBegin(GL11.GL_TRIANGLE_FAN);
            GL11.glVertex3d(0,0,0);
            for (int i=0;i<=8;i++) {
                double ang=i*Math.PI/4.0;
                GL11.glVertex3d(Math.cos(ang), Math.sin(ang), 0);
            }
            GL11.glEnd();
            GlStateManager.popMatrix();
        }
        GlStateManager.enableDepth();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    @Override
    public void onDisable() {
        for (Particle p : POOL) p.alive=false;
        aliveCount=0; next=0;
    }
}
