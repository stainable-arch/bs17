package keystrokesmod.module.impl.player;

import keystrokesmod.event.PreMotionEvent;
import keystrokesmod.module.Module;
import keystrokesmod.module.setting.impl.ButtonSetting;
import keystrokesmod.module.setting.impl.DescriptionSetting;
import keystrokesmod.module.setting.impl.SliderSetting;
import keystrokesmod.utility.Utils;
import keystrokesmod.utility.scaffold.ScaffoldSupport;
import keystrokesmod.utility.scaffold.ScaffoldSupport.BlockUtils;
import keystrokesmod.utility.scaffold.ScaffoldSupport.MoveUtils;
import keystrokesmod.utility.scaffold.ScaffoldSupport.PlayerUtils;
import keystrokesmod.utility.scaffold.ScaffoldSupport.RotationUtils;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.BlockPos;
import org.lwjgl.input.Mouse;

public class Tower extends Module {

    public enum Mode {
        Vanilla, Normal, Fly, _2_tick, _2__3_tick, _2__5_tick, _4_tick, _5_tick, _6_tick, Drop
    }

    public static SliderSetting modeSetting, speed, diagonalSpeed, speedBoost, slowedSpeed, slowedTicks;
    public static ButtonSetting disableInLiquid, disableWhileCollided, disableSafewalk, disableWhileHurt, onlyWhileRightClicking,
            setbackRecovery, skipSlowWithFastScaffold;

    public static Mode mode = Mode.Vanilla;
    public static boolean towering;
    public static boolean enabledByScaffold;
    private static int ticks;
    private static int diagonalTicks;
    private static int slowedLeft;
    private static boolean diagonal;
    private static int stage;
    private static volatile boolean dropPacketReady;

    public Tower() {
        super("Tower", category.player);
        this.canBeEnabled = false;
        this.registerSetting(new DescriptionSetting("Enable Tower in Scaffold."));
        this.registerSetting(modeSetting = new SliderSetting("Mode", 0, new String[]{"Vanilla", "Normal", "Fly", "2 tick", "2.3 tick", "2.5 tick", "4 tick", "5 tick", "6 tick", "Drop"}));
        this.registerSetting(speed = new SliderSetting("Speed", "", 1.2, 0.5, 7.0, 0.1));
        this.registerSetting(diagonalSpeed = new SliderSetting("Diagonal speed", "", 1.2, 0.4, 7.0, 0.1));
        this.registerSetting(speedBoost = new SliderSetting("Speed boost", "", 1.3, 0.0, 2.0, 0.05));
        this.registerSetting(slowedSpeed = new SliderSetting("Slowed speed", "", 1.0, 0.0, 1.0, 0.02));
        this.registerSetting(slowedTicks = new SliderSetting("Slowed ticks", "", 0.0, 0.0, 20.0, 1.0));
        diagonalSpeed.setMinString("\u00a7cDisabled");
        this.registerSetting(disableInLiquid = new ButtonSetting("Disable in liquid", true));
        this.registerSetting(disableWhileCollided = new ButtonSetting("Disable while collided", false));
        this.registerSetting(disableSafewalk = new ButtonSetting("Disable safewalk", false));
        this.registerSetting(disableWhileHurt = new ButtonSetting("Disable while hurt", false));
        this.registerSetting(onlyWhileRightClicking = new ButtonSetting("Only while right clicking", false));
        this.registerSetting(setbackRecovery = new ButtonSetting("Setback recovery", false));
        this.registerSetting(skipSlowWithFastScaffold = new ButtonSetting("Skip slow with fast scaffold", false));
    }

    @Override
    public void guiUpdate() {
        mode = Mode.values()[(int) modeSetting.getInput()];
    }

    private static boolean canTower() {
        if (mc.thePlayer.capabilities.isFlying || mc.currentScreen != null) {
            return false;
        }
        if ((Scaffold.instance == null || !Scaffold.instance.isEnabled()) || !Scaffold.towerAllowed()) {
            return false;
        }
        if (onlyWhileRightClicking.isToggled() && !Mouse.isButtonDown(1)) {
            return false;
        }
        ItemStack itemStack = mc.thePlayer.getHeldItem();
        if (itemStack == null || !(itemStack.getItem() instanceof ItemBlock)) {
            return false;
        }
        if ((!PlayerUtils.isMoving() && mode != Mode.Drop) || mc.thePlayer.isSneaking()) {
            return false;
        }
        if (!(PlayerUtils.jumpKeyDown() || stage != 0 && Scaffold.legitTicks != 0)) {
            return false;
        }
        if (disableInLiquid.isToggled() && PlayerUtils.inLiquid()) {
            return false;
        }
        if (disableWhileCollided.isToggled() && mc.thePlayer.isCollidedHorizontally) {
            return false;
        }
        if (disableWhileHurt.isToggled() && mc.thePlayer.hurtTime > 0) {
            return false;
        }
        if ((diagonalSpeed.getInput() == diagonalSpeed.getMin()) && PlayerUtils.isDiagonal()) {
            return false;
        }
        if (setbackRecovery.isToggled() && ScaffoldSupport.sinceSetback(2000L)) {
            PlayerUtils.setJump(false);
            return false;
        }
        return true;
    }

    private static void preMotion(PreMotionEvent e) {
        if (!towering) {
            ticks = 0;
            return;
        }
        ++ticks;
        diagonal = PlayerUtils.isDiagonal();
        if (diagonal) {
            diagonalTicks = 1;
        } else if (diagonalTicks > 0 && ++diagonalTicks < 8) {
            diagonal = true;
        }
        if (mode == Mode.Vanilla) {
            if (Scaffold.jumpFacingForward.isToggled()) {
                if (stage == 0) {
                    if (mc.thePlayer.onGround) {
                        if (Scaffold.legitTicks == 0) {
                            stage = 1;
                            Scaffold.legitTicks = Scaffold.legitMotion.isToggled() ? 5 : 1;
                        } else {
                            stage = 2;
                        }
                    }
                } else if (stage == 1) {
                    Scaffold.delay = Scaffold.legitTicks;
                    stage = 2;
                }
            }
            return;
        }
        boolean faceBack = false;
        mc.thePlayer.setSprinting(false);
        switch (mode) {
            case Drop: {
                if (mc.thePlayer.onGround) {
                    PlayerUtils.jump();
                }
                break;
            }
            case Normal: {
                if (!mc.thePlayer.onGround) break;
                double d = speed(diagonal);
                PlayerUtils.jump(d);
                if (!(d > 0.17)) break;
                faceBack = true;
                break;
            }
            case Fly: {
                if (mc.thePlayer.ticksExisted % 2 != 0) break;
                mc.thePlayer.motionY = 0.21 + speed.getInput() * 0.0525;
                double d = Math.min(0.17 + speed.getInput() * 0.015, 0.27) + speedBonus() + 1.0E-4 * Math.random();
                MoveUtils.strafe(d);
                break;
            }
            case _2_tick:
            case _2__3_tick:
            case _2__5_tick: {
                switch (PlayerUtils.posYDecimals()) {
                    case 0: {
                        if (stage <= 2) {
                            double d;
                            if (ticks == 1) {
                                d = 0.124;
                            } else if (mode == Mode._2__5_tick) {
                                if (stage == 0) {
                                    d = speed(diagonal);
                                    if (d > 0.17) {
                                        faceBack = true;
                                    }
                                } else {
                                    d = ticks == 4 ? 0.14 : MoveUtils.speed();
                                }
                            } else {
                                d = 0.14;
                            }
                            if (d != MoveUtils.speed()) {
                                mc.thePlayer.onGround = true;
                            }
                            e.setOnGround(true);
                            PlayerUtils.jump(d);
                            if (mode == Mode._2__3_tick) {
                                ++stage;
                                break;
                            }
                            if (mode != Mode._2__5_tick) break;
                            stage += 2;
                            break;
                        }
                        if (Utils.isHypixel()) {
                            e.posY += Double.parseDouble("0.0003" + PlayerUtils.idOffset());
                        } else {
                            e.setOnGround(true);
                        }
                        mc.thePlayer.motionY = 0.0;
                        stage = 0;
                        break;
                    }
                    case 4200: {
                        mc.thePlayer.motionY = 0.33f;
                        if (mode != Mode._2__5_tick) {
                            MoveUtils.strafe(speed(diagonal));
                            break;
                        }
                        if (ticks != 2 && ticks != 5) break;
                        MoveUtils.strafe(0.28 + speedBonus());
                        break;
                    }
                    case 7500: {
                        mc.thePlayer.motionY = 1.0 - mc.thePlayer.posY % 1.0;
                    }
                }
                break;
            }
            case _4_tick:
            case _5_tick: {
                switch (PlayerUtils.posYDecimals()) {
                    case 0: {
                        PlayerUtils.jump(speed(diagonal));
                        break;
                    }
                    case 13:
                    case 1661:
                    case 2492: {
                        e.posY = Math.floor(e.posY);
                        if (Utils.isHypixel()) {
                            e.posY += Double.parseDouble("0.0003" + PlayerUtils.idOffset());
                        } else {
                            e.setOnGround(true);
                        }
                        if (PlayerUtils.posYDecimals() != (mode == Mode._4_tick ? 1661 : 2492)) break;
                        mc.thePlayer.motionY -= 1.0;
                    }
                }
                break;
            }
            case _6_tick: {
                if (mc.thePlayer.onGround) {
                    double d = speed(diagonal);
                    PlayerUtils.jump(d);
                    if (d > 0.17) {
                        faceBack = true;
                    }
                    if (Utils.isHypixel()) {
                        mc.thePlayer.motionY -= 9.0E-4 - Double.parseDouble("0.00000" + PlayerUtils.idOffset());
                    }
                    stage = 1;
                    break;
                }
                if (stage == 1) {
                    int n = PlayerUtils.posYDecimals();
                    if (n == 4191) {
                        mc.thePlayer.motionY = 0.3275;
                        break;
                    }
                    if (n <= 2200 || n >= 2500) break;
                    stage = 2;
                    break;
                }
                if (stage != 2) break;
                mc.thePlayer.motionY -= 1.0;
                stage = 0;
                break;
            }
            default:
                break;
        }
        if (faceBack && Scaffold.jumpFacingForward.isToggled()) {
            e.setYaw(PlayerUtils.movementAngle() - 180.0f + RotationUtils.randomOffset());
            Scaffold.delay = 2;
        }
    }

    public static void reset() {
        diagonal = false;
        towering = false;
        enabledByScaffold = false;
        stage = 0;
        slowedLeft = 0;
        diagonalTicks = 0;
        ticks = 0;
        dropPacketReady = false;
    }

    private static double speed(boolean diagonal, double d) {
        double d2 = ((diagonal ? diagonalSpeed.getInput() : speed.getInput()) + d) / 10.0 + 1.0E-4 * Math.random();
        return (d2 += speedBonus()) > 0.0 ? d2 : 0.0;
    }

    private static double speed(boolean diagonal) {
        return speed(diagonal, 0.0);
    }

    public static void stop() {
        towering = false;
        if (ticks > 1 && (mode == Mode._2__3_tick || mode == Mode._2__5_tick) && stage >= 2) {
            if (mc.thePlayer.motionY == (double) 0.42f) {
                mc.thePlayer.motionY = 0.16659951058455766;
            }
        }
        diagonalTicks = 0;
        stage = 0;
    }

    public static boolean vanillaTowering() {
        return towering && mode == Mode.Vanilla;
    }

    private static double speedBonus() {
        int n = PlayerUtils.speedLevel();
        switch (n) {
            case 0:
                return 0.0;
            case 1:
                return 0.05;
            case 2:
                return speedBoost.getInput() / 10.0;
        }
        return 0.06 * (double) n;
    }

    public static void setFromScaffold(ButtonSetting tower) {
        if (tower.isToggled()) {
            if (!enabledByScaffold) {
                enabledByScaffold = true;
            }
        } else if (enabledByScaffold) {
            reset();
        }
    }

    private static void postPlayerInput() {
        if (canTower()) {
            towering = true;
            slowedLeft = 0;
            if (mode == Mode.Vanilla) {
                if (Scaffold.jumpFacingForward.isToggled()) {
                    PlayerUtils.setJump(true);
                    if (stage == 2) {
                        stage = 0;
                        PlayerUtils.setJump(true);
                    } else {
                        PlayerUtils.setJump(false);
                    }
                    if (Scaffold.legitMotion.isToggled() && diagonal && PlayerUtils.airTicks == 1L) {
                        PlayerUtils.setForward(0.0f);
                        PlayerUtils.setStrafe(0.0f);
                    }
                }
            } else {
                PlayerUtils.setJump(false);
            }
        } else if (towering) {
            towering = false;
            if (slowedLeft == 0) {
                slowedLeft = (int) slowedTicks.getInput();
            }
            stage = 0;
            Scaffold.resetKeepY();
        }
        if (slowedLeft > 0) {
            --slowedLeft;
            if (PlayerUtils.isMoving()) {
                boolean slow = false;
                if (Scaffold.fastScaffold.jump) {
                    if (PlayerUtils.perSpeedLevel(1.0) == 0.0 && Scaffold.fastScaffold.canFastScaffold()) {
                        PlayerUtils.multiplyMotion(0.4);
                    } else {
                        slow = true;
                    }
                } else if (!skipSlowWithFastScaffold.isToggled() || !Scaffold.fastScaffold.canFastScaffold()) {
                    slow = true;
                }
                if (slow) {
                    MoveUtils.setSpeed(slowedSpeed.getInput() / 10.0);
                }
            }
        }
    }
    public static void handleInput() {
        if (enabledByScaffold) {
            mode = Mode.values()[(int) modeSetting.getInput()];
            postPlayerInput();
        }
    }

    public static void handleMotion(PreMotionEvent event) {
        if (enabledByScaffold) {
            mode = Mode.values()[(int) modeSetting.getInput()];
            preMotion(event);
        }
    }

    public static void handleMovementPacket(C03PacketPlayer packet) {
        dropPacketReady = packet.getClass() == C03PacketPlayer.class || packet instanceof C03PacketPlayer.C05PacketPlayerLook;
    }

    public static void handleMoveFlying() {
        boolean canDrop = dropPacketReady;
        dropPacketReady = false;
        if (!enabledByScaffold || !towering || mode != Mode.Drop || !Utils.nullCheck()
                || mc.thePlayer.onGround || PlayerUtils.airTicks != 6L || !canDrop) {
            return;
        }
        BlockPos under = BlockUtils.below(2.0);
        if (BlockUtils.isReplaceable(under)) {
            return;
        }
        mc.thePlayer.motionY -= 0.25D - Math.random() * 0.001D;
    }
}
