package keystrokesmod.module.impl.combat;

import keystrokesmod.mixin.impl.accessor.IAccessorMinecraft;
import keystrokesmod.module.Module;
import keystrokesmod.module.ModuleManager;
import keystrokesmod.module.impl.movement.LongJump;
import keystrokesmod.module.setting.impl.ButtonSetting;
import keystrokesmod.module.setting.impl.SliderSetting;
import keystrokesmod.utility.Utils;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraft.util.Util;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.input.Keyboard;

import java.util.ArrayDeque;
import java.util.Queue;
import java.util.concurrent.FutureTask;

public class Velocity extends Module {
    private static final Logger logger = LogManager.getLogger(Velocity.class);
    public static SliderSetting horizontal;
    public static SliderSetting vertical;

    private SliderSetting chance;
    private ButtonSetting attackAfterKnockback;
    private ButtonSetting onlyWhileTargeting;
    private ButtonSetting disableS;
    private final Queue<Runnable> postAttackActions = new ArrayDeque<>();
    private NetworkManager postAttackConnection;
    private WorldClient postAttackWorld;
    private EntityPlayerSP postAttackPlayer;
    private double postAttackMultiplierX = 1.0;
    private double postAttackMultiplierZ = 1.0;
    private boolean inClientTick;
    private boolean finishingPostAttacks;
    private boolean replayingPostAttacks;
    public boolean disable;

    public Velocity() {
        super("Velocity", category.combat, 0);
        this.registerSetting(horizontal = new SliderSetting("Horizontal", "%", 90.0D, 0.0D, 100.0D, 1.0D));
        this.registerSetting(vertical = new SliderSetting("Vertical", "%", 100.0D, 0.0D, 100.0D, 1.0D));
        this.registerSetting(chance = new SliderSetting("Chance", "%", 100.0D, 0.0D, 100.0D, 1.0D));
        this.registerSetting(attackAfterKnockback = new ButtonSetting("Attack after knockback", true));
        this.registerSetting(onlyWhileTargeting = new ButtonSetting("Only while targeting", false));
        this.registerSetting(disableS = new ButtonSetting("Disable while holding S", false));
        this.closetModule = true;
    }

    @Override
    public String getInfo() {
        return (int) horizontal.getInput() + "%" + " " + (int) vertical.getInput() + "%";
    }

    public void beginClientTick() {
        if (inClientTick) {
            finishClientTick();
        }
        inClientTick = true;
    }

    public boolean deferAttackPacket(NetworkManager connection, Packet<?> packet, Runnable dispatch) {
        if (replayingPostAttacks || !mc.isCallingFromMinecraftThread() || mc.getNetHandler() == null
                || connection != mc.getNetHandler().getNetworkManager()) {
            return false;
        }

        if (!postAttackActions.isEmpty()) {
            if (isPostAttackContextValid() && postAttackConnection == connection) {
                postAttackActions.add(dispatch);
                return true;
            }
            clearPostAttacks();
        }

        if (!inClientTick || finishingPostAttacks || !isEnabled() || !attackAfterKnockback.isToggled()
                || !(packet instanceof C02PacketUseEntity)
                || ((C02PacketUseEntity) packet).getAction() != C02PacketUseEntity.Action.ATTACK
                || !canModifyVelocity() || mc.thePlayer.isDead) {
            return false;
        }

        postAttackConnection = connection;
        postAttackWorld = mc.theWorld;
        postAttackPlayer = mc.thePlayer;
        postAttackActions.add(dispatch);
        return true;
    }

    public static void applyAttackSlowdown(EntityPlayer player, double multiplierX, double multiplierZ) {
        Velocity velocity = ModuleManager.velocity;
        if (velocity != null) {
            velocity.recordAttackSlowdown(player, multiplierX, multiplierZ);
        }
        player.motionX *= multiplierX;
        player.motionZ *= multiplierZ;
    }

    private void recordAttackSlowdown(EntityPlayer player, double multiplierX, double multiplierZ) {
        if (!mc.isCallingFromMinecraftThread() || replayingPostAttacks || postAttackActions.isEmpty()
                || player != postAttackPlayer || !isPostAttackContextValid()) {
            return;
        }
        postAttackMultiplierX *= multiplierX;
        postAttackMultiplierZ *= multiplierZ;
    }

    public void onEntityVelocityApplied(S12PacketEntityVelocity packet) {
        if (!mc.isCallingFromMinecraftThread() || replayingPostAttacks || postAttackActions.isEmpty()
                || !isPostAttackContextValid() || packet.getEntityID() != postAttackPlayer.getEntityId()) {
            return;
        }
        postAttackPlayer.motionX *= postAttackMultiplierX;
        postAttackPlayer.motionZ *= postAttackMultiplierZ;
    }

    public void finishClientTick() {
        inClientTick = false;
        if (finishingPostAttacks || postAttackActions.isEmpty()) {
            return;
        }

        finishingPostAttacks = true;
        try {
            Queue<FutureTask<?>> scheduledTasks = ((IAccessorMinecraft) mc).getScheduledTasks();
            synchronized (scheduledTasks) {
                FutureTask<?> task;
                while ((task = scheduledTasks.poll()) != null) {
                    Util.runTask(task, logger);
                }
            }

            replayingPostAttacks = true;
            Runnable dispatch;
            while (isPostAttackContextValid() && (dispatch = postAttackActions.poll()) != null) {
                dispatch.run();
            }
        }
        finally {
            clearPostAttacks();
            replayingPostAttacks = false;
            finishingPostAttacks = false;
        }
    }

    @Override
    public void onDisable() {
        if (mc.isCallingFromMinecraftThread()) {
            finishClientTick();
        }
        else {
            mc.addScheduledTask(this::finishClientTick);
        }
    }

    @Override
    public void guiButtonToggled(ButtonSetting setting) {
        if (setting == attackAfterKnockback && !attackAfterKnockback.isToggled()) {
            finishClientTick();
        }
    }

    private boolean isPostAttackContextValid() {
        return postAttackPlayer != null && mc.theWorld == postAttackWorld && mc.thePlayer == postAttackPlayer
                && mc.getNetHandler() != null
                && mc.getNetHandler().getNetworkManager() == postAttackConnection
                && postAttackConnection.isChannelOpen() && !postAttackPlayer.isDead;
    }

    private void clearPostAttacks() {
        postAttackActions.clear();
        postAttackConnection = null;
        postAttackWorld = null;
        postAttackPlayer = null;
        postAttackMultiplierX = 1.0;
        postAttackMultiplierZ = 1.0;
    }

    private boolean canModifyVelocity() {
        return Utils.nullCheck() && !LongJump.stopVelocity && !disable
                && (ModuleManager.antiKnockback == null || !ModuleManager.antiKnockback.isEnabled())
                && (!onlyWhileTargeting.isToggled()
                    || (mc.objectMouseOver != null && mc.objectMouseOver.entityHit != null))
                && (!disableS.isToggled() || !Keyboard.isKeyDown(mc.gameSettings.keyBindBack.getKeyCode()));
    }

    @SubscribeEvent
    public void onLivingUpdate(LivingEvent.LivingUpdateEvent ev) {
        if (canModifyVelocity()) {
            if (ev.entity != mc.thePlayer) {
                return;
            }
            if (mc.thePlayer.maxHurtTime <= 0 || mc.thePlayer.hurtTime != mc.thePlayer.maxHurtTime) {
                return;
            }
            if (chance.getInput() == 0) {
                return;
            }
            if (chance.getInput() != 100) {
                double ch = Math.random();
                if (ch >= chance.getInput() / 100.0D) {
                    return;
                }
            }
            if (horizontal.getInput() != 100.0D) {
                mc.thePlayer.motionX *= horizontal.getInput() / 100;
                mc.thePlayer.motionZ *= horizontal.getInput() / 100;
            }
            if (vertical.getInput() != 100.0D) {
                mc.thePlayer.motionY *= vertical.getInput() / 100;
            }
        }
    }
}
