package keystrokesmod.module.impl.player;

import keystrokesmod.event.PostPlayerInputEvent;
import keystrokesmod.event.PreUpdateEvent;
import keystrokesmod.module.Module;
import keystrokesmod.module.setting.impl.ButtonSetting;
import keystrokesmod.module.setting.impl.SliderSetting;
import keystrokesmod.utility.Utils;
import keystrokesmod.utility.scaffold.ScaffoldSupport.ItemUtils;
import keystrokesmod.utility.scaffold.ScaffoldSupport.PlayerUtils;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Mouse;

public class SafeWalk extends Module {
    private static final String[] MODE_NAMES = {"Edge", "Sneak (Keybind)", "Sneak (State)", "Scaffold"};
    private static final String[] TOLERANCE_NAMES = {"Low", "Medium", "High", "Very High"};

    public static SafeWalk instance;
    public static SliderSetting modeSlider, edgeTolerance, minimumPitch, unsneakDelay;
    public static ButtonSetting blocksOnly, disableOnForward, onlyRightClicking, onlyWhileSneaking;

    public enum Mode {
        EDGE, SNEAK_KEYBIND, SNEAK_STATE, SCAFFOLD
    }

    public enum Tolerance {
        LOW(0.05), MEDIUM(0.15), HIGH(0.25), VERY_HIGH(0.3);
        public final double value;

        Tolerance(double value) {
            this.value = value;
        }
    }

    public static Mode mode = Mode.EDGE;
    public static Tolerance tolerance = Tolerance.MEDIUM;
    public static boolean sneaking;
    private static long sneakStart;
    public static boolean scaffoldActive;
    private static final BlockPos.MutableBlockPos POS = new BlockPos.MutableBlockPos();

    public SafeWalk() {
        super("SafeWalk", Module.category.player, 0);
        instance = this;
        this.liteModule = true;
        this.registerSetting(modeSlider = new SliderSetting("Mode", 0, MODE_NAMES));
        this.registerSetting(edgeTolerance = new SliderSetting("Edge tolerance", 1, TOLERANCE_NAMES));
        this.registerSetting(minimumPitch = new SliderSetting("Minimum pitch", 65.0, 19.0, 85.0, 1.0));
        this.registerSetting(unsneakDelay = new SliderSetting("Unsneak delay", "ms", 0.0, 0.0, 1000.0, 50.0));
        this.registerSetting(blocksOnly = new ButtonSetting("Blocks only", true));
        this.registerSetting(disableOnForward = new ButtonSetting("Disable on forward", false));
        this.registerSetting(onlyRightClicking = new ButtonSetting("Only while right clicking", false));
        this.registerSetting(onlyWhileSneaking = new ButtonSetting("Only while sneaking", false));
    }

    private static boolean enabled() {
        return instance != null && instance.isEnabled();
    }

    @SubscribeEvent
    public void onPostPlayerInput(PostPlayerInputEvent e) {
        if (mode != Mode.SNEAK_STATE) {
            return;
        }
        if (sneaking) {
            PlayerUtils.setSneak(true);
        }
    }

    @Override
    public void onDisable() {
        if (!Utils.nullCheck()) {
            sneaking = false;
            scaffoldActive = false;
            return;
        }
        if (mode == Mode.SNEAK_KEYBIND && PlayerUtils.isAirBelow()) {
            setSneak(false);
        }
        if (scaffoldActive) {
            scaffoldActive = false;
            if (Scaffold.instance != null) {
                Scaffold.instance.disable();
            }
        }
        if (sneaking && (mode == Mode.SNEAK_KEYBIND || mode == Mode.SCAFFOLD)) {
            pressSneak(GameSettings.isKeyDown(mc.gameSettings.keyBindSneak));
        }
        sneaking = false;
    }

    public static boolean conditions(boolean needGround) {
        if (needGround && !mc.thePlayer.onGround) {
            return false;
        }
        if (minimumPitch.getInput() > minimumPitch.getMin() && (double) mc.thePlayer.rotationPitch < minimumPitch.getInput()) {
            return false;
        }
        if (onlyRightClicking.isToggled() && !Mouse.isButtonDown(1)) {
            return false;
        }
        if (onlyWhileSneaking.isToggled() && !GameSettings.isKeyDown(mc.gameSettings.keyBindSneak)) {
            return false;
        }
        if (disableOnForward.isToggled() && GameSettings.isKeyDown(mc.gameSettings.keyBindForward)) {
            return false;
        }
        return !blocksOnly.isToggled() || holdingScaffoldBlock();
    }

    private static boolean holdingScaffoldBlock() {
        ItemStack held = mc.thePlayer.getHeldItem();
        return held != null && ItemUtils.isScaffoldBlock(held);
    }

    @SubscribeEvent
    public void onGuiOpen(GuiOpenEvent e) {
        if (mode != Mode.EDGE && e.gui == null && mc.thePlayer != null) {
            sneaking = mc.thePlayer.isSneaking();
        }
    }

    @SubscribeEvent
    public void onMouse(MouseEvent e) {
        if (!e.buttonstate || e.button != 1) {
            return;
        }
        if (!Utils.nullCheck()) {
            return;
        }
        if (mode == Mode.SCAFFOLD && onlyRightClicking.isToggled() && conditions(false)) {
            e.setCanceled(true);
        }
    }

    private static void pressSneak(boolean b) {
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), b);
    }

    public static boolean stopsOnEdge() {
        if (!enabled() || mode != Mode.EDGE) {
            return false;
        }
        return conditions(true);
    }

    public static boolean canSafeWalk() {
        if (Scaffold.canSafeWalk()) {
            return true;
        }
        return Utils.nullCheck() && stopsOnEdge();
    }

    public static boolean atEdge() {
        float f;
        double x = mc.thePlayer.posX;
        double y = mc.thePlayer.getEntityBoundingBox().minY - 0.01;
        double z = mc.thePlayer.posZ;
        double mx = mc.thePlayer.motionX;
        double mz = mc.thePlayer.motionZ;
        float forward = keyAxis(mc.gameSettings.keyBindForward, mc.gameSettings.keyBindBack) * 0.98f;
        float sq = forward * forward + (f = keyAxis(mc.gameSettings.keyBindLeft, mc.gameSettings.keyBindRight) * 0.98f) * f;
        if (sq >= 1.0E-4f) {
            float speed = mc.thePlayer.getAIMoveSpeed();
            float len = MathHelper.sqrt_float(sq);
            speed *= 0.9999998f;
            if (len >= 1.0f) {
                speed /= len;
            }
            float yaw = mc.thePlayer.rotationYaw * ((float) Math.PI / 180);
            float sin = MathHelper.sin(yaw);
            float cos = MathHelper.cos(yaw);
            mx += (double) (f * speed * cos - forward * speed * sin);
            mz += (double) (forward * speed * cos + f * speed * sin);
        }
        double nx = x + mx;
        double nz = z + mz;
        double t = tolerance.value;
        int by = MathHelper.floor_double(y);
        int x1 = MathHelper.floor_double(nx - t);
        int z1 = MathHelper.floor_double(nz - t);
        if (solidAt(x1, by, z1)) {
            return false;
        }
        int z2 = MathHelper.floor_double(nz + t);
        if (z1 != z2 && solidAt(x1, by, z2)) {
            return false;
        }
        int x2 = MathHelper.floor_double(nx + t);
        if (x1 != x2) {
            if (solidAt(x2, by, z1)) {
                return false;
            }
            if (z1 != z2 && solidAt(x2, by, z2)) {
                return false;
            }
        }
        return true;
    }

    private static float keyAxis(KeyBinding plus, KeyBinding minus) {
        float f = 0.0f;
        if (plus.isKeyDown()) f += 1.0f;
        if (minus.isKeyDown()) f -= 1.0f;
        return f;
    }

    @Override
    public void guiUpdate() {
        int mi = (int) modeSlider.getInput();
        mode = Mode.values()[Math.max(0, Math.min(Mode.values().length - 1, mi))];
        int ti = (int) edgeTolerance.getInput();
        tolerance = Tolerance.values()[Math.max(0, Math.min(Tolerance.values().length - 1, ti))];
    }

    private static boolean unsneakReady() {
        return unsneakDelay.getInput() <= 0.0 || (double) (System.currentTimeMillis() - sneakStart) > unsneakDelay.getInput() + 50.0 - 10.0;
    }

    @SubscribeEvent
    public void onPreUpdate(PreUpdateEvent e) {
        if (!Utils.nullCheck()) {
            return;
        }
        guiUpdate();
        if (onlyWhileSneaking.isToggled()) {
            if (mode == Mode.SNEAK_KEYBIND || mode == Mode.SCAFFOLD) {
                pressSneak(sneaking);
            } else {
                pressSneak(false);
            }
        }
        if (mode == Mode.EDGE) {
            return;
        }
        if (mode == Mode.SCAFFOLD) {
            if (conditions(false)) {
                if (!scaffoldActive) {
                    scaffoldActive = true;
                    if (Scaffold.instance != null) {
                        Scaffold.instance.enable();
                    }
                }
                if (mc.thePlayer.onGround && !GameSettings.isKeyDown(mc.gameSettings.keyBindJump) && atEdge()) {
                    setSneak(true);
                } else if (sneaking && unsneakReady()) {
                    setSneak(false);
                }
            } else if (scaffoldActive) {
                scaffoldActive = false;
                if (Scaffold.instance != null) {
                    Scaffold.instance.disable();
                }
                if (sneaking) {
                    setSneak(false);
                }
            }
            return;
        }
        if (!conditions(true)) {
            if (sneaking) {
                setSneak(false);
            }
            return;
        }
        if (atEdge()) {
            setSneak(true);
        } else if (sneaking && unsneakReady()) {
            setSneak(false);
        }
    }

    private static boolean solidAt(int x, int y, int z) {
        POS.set(x, y, z);
        return mc.theWorld.getBlockState(POS).getBlock().getMaterial().isSolid();
    }

    public static void setSneak(boolean b) {
        if (sneaking) {
            if (b) {
                return;
            }
        } else if (!b) {
            return;
        }
        if (!b && !onlyWhileSneaking.isToggled() && GameSettings.isKeyDown(mc.gameSettings.keyBindSneak)) {
            return;
        }
        sneaking = b;
        if (sneaking) {
            sneakStart = System.currentTimeMillis();
        }
        if (mode == Mode.SNEAK_KEYBIND || mode == Mode.SCAFFOLD) {
            pressSneak(b);
        }
    }
}
