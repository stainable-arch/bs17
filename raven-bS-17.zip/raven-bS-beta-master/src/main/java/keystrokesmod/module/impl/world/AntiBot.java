package keystrokesmod.module.impl.world;

import keystrokesmod.Raven;
import keystrokesmod.module.Module;
import keystrokesmod.module.ModuleManager;
import keystrokesmod.module.impl.player.Freecam;
import keystrokesmod.module.setting.impl.ButtonSetting;
import keystrokesmod.module.setting.impl.SliderSetting;
import keystrokesmod.utility.Chat;
import keystrokesmod.utility.Utils;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.event.HoverEvent;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Team;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.ChatStyle;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class AntiBot extends Module {
    private static final HashMap<EntityPlayer, Long> entities = new HashMap();
    private static SliderSetting spawnDelay;
    private static SliderSetting respawnDelay;
    private static SliderSetting pitSpawn;
    private static ButtonSetting tablist;
    private ButtonSetting printWorldJoin;
    private static long respawnTime;

    public AntiBot() {
        super("Anti Bot", category.world);
        this.registerSetting(spawnDelay = new SliderSetting("Delay (spawn)", true, -1, 0.5, 15.0, 0.5, "Delay"));
        spawnDelay.setSuffix(" second");
        this.registerSetting(respawnDelay = new SliderSetting("Delay (respawn)", " second", true, -1, 0.5, 15.0, 0.5));
        this.registerSetting(pitSpawn = new SliderSetting("Pit spawn", true, -1, 70, 120, 1));
        this.registerSetting(tablist = new ButtonSetting("Tab list", false));
        this.registerSetting(printWorldJoin = new ButtonSetting("Print world join", false));
        this.closetModule = true;
        this.liteModule = true;
    }

    @SubscribeEvent
    public void onEntityJoin(EntityJoinWorldEvent e) {
        if ((e.entity instanceof EntityPlayer || Raven.DEBUG) && e.entity != mc.thePlayer) {
            if (spawnDelay.getInput() != -1 && e.entity instanceof EntityPlayer) {
                entities.put((EntityPlayer) e.entity, System.currentTimeMillis());
            }
            if (printWorldJoin.isToggled()) {
                printJoin((EntityPlayer) e.entity, false);
            }
        }
    }

    @SubscribeEvent
    public void onChat(ClientChatReceivedEvent e) {
        if (e.type == 2 || !Utils.nullCheck() || respawnDelay.getInput() == -1) {
            return;
        }
        if (Utils.stripColor(e.message.getUnformattedText()).equals("You have respawned!")) {
            respawnTime = System.currentTimeMillis();
        }
    }

    @SubscribeEvent
    public void onWorldUnload(WorldEvent.Unload e) {
        if (e.world == mc.theWorld) {
            entities.clear();
            respawnTime = 0;
        }
    }

    @Override
    public void onUpdate() {
        if (spawnDelay.getInput() != -1 && !entities.isEmpty()) {
            long cutoff = System.currentTimeMillis() - (long) (spawnDelay.getInput() * 1000.0);
            entities.values().removeIf(n -> n <= cutoff);
        }
    }

    @Override
    public void onDisable() {
        entities.clear();
        respawnTime = 0;
    }

    public static boolean isBot(Entity entity) {
        return isBot(entity, true);
    }

    public static boolean isBot(Entity entity, boolean useDelays) {
        if (!ModuleManager.antiBot.isEnabled()) {
            return false;
        }
        if (Freecam.freeEntity != null && Freecam.freeEntity == entity) {
            return true;
        }
        if (!(entity instanceof EntityPlayer)) {
            return true;
        }
        final EntityPlayer entityPlayer = (EntityPlayer) entity;
        if (useDelays && spawnDelay.getInput() != -1 && !entities.isEmpty() && entities.containsKey(entityPlayer)) {
            return true;
        }
        if (useDelays && respawnDelay.getInput() != -1 && respawnTime != 0
                && System.currentTimeMillis() - respawnTime < respawnDelay.getInput() * 1000.0) {
            return true;
        }
        if (entityPlayer.isDead) {
            return true;
        }
        if (Utils.removeFormatCodes(entityPlayer.getName()).trim().isEmpty()) {
            return true;
        }
        if (tablist.isToggled() && !getTablist().contains(entityPlayer.getName())) {
            return true;
        }
        if (entityPlayer.getHealth() != 20.0f && entityPlayer.getName().startsWith("§c")) {
            return true;
        }
        if (pitSpawn.getInput() != -1 && entityPlayer.posY >= pitSpawn.getInput()) {
            return true;
        }
        if (entityPlayer.maxHurtTime == 0) {
            if (entityPlayer.getHealth() == 20.0f) {
                String unformattedText = entityPlayer.getDisplayName().getUnformattedText();
                if (unformattedText.length() == 10 && unformattedText.charAt(0) != '§') {
                    return true;
                }
                if (unformattedText.length() == 12 && entityPlayer.isPlayerSleeping() && unformattedText.charAt(0) == '§') {
                    return true;
                }
                if (unformattedText.length() >= 7 && unformattedText.charAt(2) == '[' && unformattedText.charAt(3) == 'N' && unformattedText.charAt(6) == ']') {
                    return true;
                }
                if (entityPlayer.getName().contains(" ")) {
                    return true;
                }
            } else if (entityPlayer.isInvisible()) {
                String unformattedText = entityPlayer.getDisplayName().getUnformattedText();
                if (unformattedText.length() >= 3 && unformattedText.charAt(0) == '§' && unformattedText.charAt(1) == 'c') {
                    return true;
                }
            }
        }
        return false;
    }

    private static List<String> getTablist() {
        List<String> tab = new ArrayList<>();
        for (NetworkPlayerInfo networkPlayerInfo : Utils.getTablist(true)) {
            if (networkPlayerInfo == null) {
                continue;
            }
            tab.add(networkPlayerInfo.getGameProfile().getName());
        }
        return tab;
    }

    public void printJoin(EntityPlayer p, boolean watchdog) {
        String s = "&7Entity &b" + p.getEntityId() + " &7joined: &r" + p.getDisplayName().getUnformattedText() + (watchdog ? " &7(&cwatchdog&7)" : "");
        try {
            ChatComponentText text = new ChatComponentText(Chat.color(Chat.PREFIX + s));
            String hover = "&ename: &r" + p.getName() + "\n&edisplay name: &r" + p.getDisplayName().getUnformattedText()
                    + "\n&estripped: &r" + Chat.strip(p.getDisplayName().getUnformattedText()) + "\n&euuid: &7" + p.getUniqueID()
                    + "\n&ex: &7" + p.posX + "\n&ey: &7" + p.posY + "\n&ez: &7" + p.posZ + "\n&eyaw: &7" + p.rotationYaw
                    + "\n&epitch: &7" + p.rotationPitch + "\n&ehealth: &7" + p.getHealth() + "\n&ehurt time: &7" + p.hurtTime + "/" + p.maxHurtTime
                    + "\n&einvisible: &7" + p.isInvisible() + "\n&eitem: &7" + (p.getHeldItem() == null ? "null" : p.getHeldItem().getDisplayName())
                    + (watchdog ? "" : "\n&ebot: &7" + isBot(p, false));
            Team team = p.getTeam();
            if (team != null) {
                hover = hover + "\n&eteam: &7" + team.getRegisteredName();
            } else {
                hover = hover + "\n&eteam: &7null";
            }
            NetworkPlayerInfo info = Utils.info(p);
            if (info != null) {
                hover = hover + "\n&etablist: &7true";
                ScorePlayerTeam t = info.getPlayerTeam();
                hover = hover + "\n&enetwork team: &7" + (t == null ? "null" : t.getTeamName()) + "\n&eping: &7" + info.getResponseTime();
            } else {
                hover = hover + "\ntablist: false";
            }
            ChatStyle style = new ChatStyle();
            style.setChatHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new ChatComponentText(Chat.color(hover))));
            text.setChatStyle(style);
            mc.thePlayer.addChatMessage(text);
        }
        catch (Exception ex) {
            Chat.moduleMessage(this, s + " &7(&c" + ex.getClass().getSimpleName() + "&7)");
        }
    }
}