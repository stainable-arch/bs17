package keystrokesmod.module.impl.other;

import keystrokesmod.clickgui.ClickGui;
import keystrokesmod.module.impl.client.Settings;
import keystrokesmod.utility.BlockUtils;
import keystrokesmod.utility.IMinecraftInstance;
import keystrokesmod.utility.Utils;
import net.minecraft.block.Block;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiPlayerTabOverlay;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.util.BlockPos;
import net.minecraft.util.IChatComponent;
import net.minecraftforge.fml.relauncher.ReflectionHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

final class AnticheatContext implements IMinecraftInstance {
    public enum State {
        NOT_HYPIXEL, UNKNOWN, LIMBO, LOBBY, REPLAY, BRIDGE_PRACTICE, PIT, MURDER_MYSTERY_GAME, BEDWARS_PREGAME,
        BEDWARS_GAME_BED, BEDWARS_GAME_NO_BED, SKYWARS_QUEUE, SKYWARS_GAME_SOLO, SKYWARS_GAME_TEAM, DUELS_QUEUE, DUELS_GAME
    }
    private static final String HOST = "hypixel.net";
    private static final String LOBBY_MARK = "  §8L";
    private static final char BED_MARK = '✓';

    private AnticheatContext() {
    }

    public static boolean onHypixel() {
        return isHypixelServer();
    }

    public static boolean sameTeam(EntityPlayer player) {
        if (!onHypixel() || detect() == State.PIT) {
            return false;
        }
        ScorePlayerTeam team = (ScorePlayerTeam) player.getTeam();
        NetworkPlayerInfo info = mc.getNetHandler() == null ? null : mc.getNetHandler().getPlayerInfo(mc.thePlayer.getUniqueID());
        ScorePlayerTeam own = info == null ? (ScorePlayerTeam) mc.thePlayer.getTeam() : info.getPlayerTeam();
        return team != null && own != null && team.getColorPrefix().equals(own.getColorPrefix());
    }

    public static boolean skywars() {
        State state = detect();
        return state == State.SKYWARS_QUEUE || state == State.SKYWARS_GAME_SOLO || state == State.SKYWARS_GAME_TEAM;
    }

    public static int buildBattle() {
        List<String> list;
        if (onHypixel() && (list = sidebar()) != null && list.size() > 6 && Utils.stripColor(list.get(0)).contains("BUILD BATTLE")) {
            boolean startsIn = false;
            boolean timeLeft = false;
            boolean theme = false;
            boolean judging = false;
            for (String s : list) {
                if (s.contains("Mode:") && s.contains("Speed Bu")) {
                    return 1;
                }
                if (s.contains("Starts In:")) {
                    startsIn = true;
                    continue;
                }
                if (s.contains("Time Left:")) {
                    timeLeft = true;
                    continue;
                }
                if (s.contains("Judging:")) {
                    judging = true;
                    continue;
                }
                if (s.contains("Theme:")) {
                    theme = true;
                    continue;
                }
                if (!s.contains("Perfect Builds:")) continue;
                if (theme) {
                    if (startsIn) {
                        boolean items = false;
                        for (int i = 0; i < 9; ++i) {
                            if (net.minecraft.client.Minecraft.getMinecraft().thePlayer.inventory.getStackInSlot(i) == null) continue;
                            items = true;
                            break;
                        }
                        return items ? 4 : 3;
                    }
                    if (timeLeft) {
                        return 4;
                    }
                    if (!judging) continue;
                    return 5;
                }
                return 2;
            }
        }
        return 0;
    }
    public static String tabHeader() {
        try {
            Object o = ReflectionHelper.getPrivateValue(GuiPlayerTabOverlay.class, mc.ingameGUI.getTabList(), "header", "field_175256_i");
            if (o != null) {
                return ((IChatComponent) o).getUnformattedText();
            }
        } catch (Exception ignored) {
        }
        return "";
    }

    public static boolean isHypixelServer() {
        if (mc.isSingleplayer() || mc.getCurrentServerData() == null) {
            return false;
        }
        if (mc.getCurrentServerData().serverIP.toLowerCase(Locale.ROOT).endsWith(HOST)) {
            return true;
        }
        return tabHeader().toLowerCase(Locale.ROOT).contains(HOST);
    }
    public static List<String> sidebar() {
        if (mc.theWorld == null) return null;
        Scoreboard sb = mc.theWorld.getScoreboard();
        if (sb == null) return null;
        ScoreObjective obj = sb.getObjectiveInDisplaySlot(1);
        if (obj == null) return null;
        ArrayList<Score> scores = new ArrayList<>(sb.getSortedScores(obj));
        ArrayList<String> out = new ArrayList<>(10);
        out.add(obj.getDisplayName());
        int n = 0;
        for (int i = scores.size() - 1; i >= 0 && n < 15; --i) {
            Score s = scores.get(i);
            String name;
            if (s == null || (name = s.getPlayerName()) == null || name.startsWith("#")) continue;
            ScorePlayerTeam team = sb.getPlayersTeam(name);
            out.add(ScorePlayerTeam.formatPlayerName(team, name));
            ++n;
        }
        return out;
    }
    public static State detect() {
        if (!isHypixelServer()) return State.NOT_HYPIXEL;
        List<String> lines = sidebar();
        if (lines == null) {
            if (mc.theWorld.provider.getDimensionId() == 1) return State.LIMBO;
            return State.UNKNOWN;
        }
        boolean bedwars = false, skywars = false, skyPlayers = false, duels = false, murder = false;
        for (int i = 0; i < lines.size(); ++i) {
            String line = lines.get(i);
            if (i == 0) {
                String t = Utils.stripColor(line);
                if (t.equals("REPLAY")) return State.REPLAY;
                if (t.equals("BED WARS PRACTICE")) return State.BRIDGE_PRACTICE;
                if (t.equals("THE HYPIXEL PIT")) return State.PIT;
                if (t.equals("BED WARS")) bedwars = true;
                else if (t.equals("SKYWARS")) skywars = true;
                else if (t.equals("DUELS")) duels = true;
                else if (t.equals("MURDER MYSTERY")) murder = true;
                continue;
            }
            if (i == 1 && line.contains(LOBBY_MARK)) return State.LOBBY;
            if (bedwars) {
                if (i >= 5) {
                    if (i == 8 && line.startsWith("Mode")) return State.BEDWARS_PREGAME;
                    if (line.endsWith(" YOU")) {
                        return line.indexOf(BED_MARK) != -1 ? State.BEDWARS_GAME_BED : State.BEDWARS_GAME_NO_BED;
                    }
                }
            } else if (skywars) {
                if (i == 3) {
                    if (line.startsWith("Player")) return State.SKYWARS_QUEUE;
                } else if (i == 6) {
                    if (line.startsWith("Player")) skyPlayers = true;
                } else if (i == 7 && skyPlayers) {
                    return !line.startsWith("Team") ? State.SKYWARS_GAME_SOLO : State.SKYWARS_GAME_TEAM;
                }
            } else if (murder) {
                if (i == 3 && line.startsWith("Role")) return State.MURDER_MYSTERY_GAME;
            } else if (duels) {
                if (i == 3) {
                    if (line.startsWith("Time")) return State.DUELS_GAME;
                } else if (i == 6) {
                    if (line.startsWith("Waiting.")) return State.DUELS_QUEUE;
                    if (line.startsWith("Starting ")) return State.DUELS_QUEUE;
                }
            }
        }
        return State.UNKNOWN;
    }
    public static boolean screenOpen() {
        return !(mc.currentScreen == null || mc.currentScreen instanceof ClickGui
                || !Settings.setChatAsInventory.isToggled() && mc.currentScreen instanceof GuiChat);
    }

    public static String distance(double distance) {
        char color = distance <= 10.0 ? 'c' : distance <= 25.0 ? '6' : distance <= 50.0 ? 'e' : distance <= 100.0 ? 'a' : '2';
        String text = "&" + color + (int) distance + "m";
        return Settings.addBracketsToDistance.isToggled() ? "&7(" + text + "&7)" : text;
    }

    public static boolean isBlock(ItemStack stack) {
        return stack != null && stack.getItem() instanceof ItemBlock;
    }

    public static boolean isItem(ItemStack stack, Item item) {
        return stack != null && stack.getItem() == item;
    }

    public static net.minecraft.util.BlockPos offset(int n, net.minecraft.util.BlockPos pos) {
        if (n == 0) {
            return pos.up();
        }
        if (n == 1) {
            return pos.down();
        }
        if (n == 2) {
            return pos.north();
        }
        if (n == 3) {
            return pos.south();
        }
        if (n == 4) {
            return pos.east();
        }
        return pos.west();
    }

    public static boolean exposed(net.minecraft.util.BlockPos pos) {
        boolean bed = pos != null && BlockUtils.getBlock(pos) == net.minecraft.init.Blocks.bed;
        for (int i = 0; i < 6; ++i) {
            Block b = BlockUtils.getBlock(offset(i, pos));
            if (b == net.minecraft.init.Blocks.air || b instanceof net.minecraft.block.BlockLiquid || b == net.minecraft.init.Blocks.fire
                    || b == net.minecraft.init.Blocks.ladder || b == net.minecraft.init.Blocks.iron_bars || b == net.minecraft.init.Blocks.ender_chest
                    || b == net.minecraft.init.Blocks.enchanting_table || b == net.minecraft.init.Blocks.skull || b == net.minecraft.init.Blocks.anvil
                    || b == net.minecraft.init.Blocks.tripwire || b == net.minecraft.init.Blocks.vine || b == net.minecraft.init.Blocks.flower_pot
                    || b instanceof net.minecraft.block.BlockChest || b instanceof net.minecraft.block.BlockDoor || b instanceof net.minecraft.block.BlockTrapDoor
                    || b instanceof net.minecraft.block.BlockFence || b instanceof net.minecraft.block.BlockFenceGate || b instanceof net.minecraft.block.BlockWall
                    || b instanceof net.minecraft.block.BlockStairs) {
                return true;
            }
            if (i != 1 && b instanceof net.minecraft.block.BlockSlab) {
                return true;
            }
            if (i < 2 || (bed || b != net.minecraft.init.Blocks.bed) && b != net.minecraft.init.Blocks.end_portal_frame) continue;
            return true;
        }
        return false;
    }
}
