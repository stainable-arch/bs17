package keystrokesmod.module.impl.render;

import keystrokesmod.module.Module;
import keystrokesmod.module.ModuleManager;
import keystrokesmod.module.setting.impl.ButtonSetting;
import keystrokesmod.module.setting.impl.ColorSetting;
import keystrokesmod.module.setting.impl.SliderSetting;
import keystrokesmod.utility.RenderUtils;
import keystrokesmod.utility.SharedBlockHighlightCache;
import keystrokesmod.utility.Theme;
import keystrokesmod.utility.Utils;

import java.awt.Color;
import net.minecraft.block.Block;
import net.minecraft.block.BlockBed;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.World;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class BedESP extends Module {

    private static final String[] COLOR_MODES = {"Static", "Gradient", "Rainbow", "Theme"};
    private static final int THEME_COLOR_MODE = 3;
    private static final int DEFAULT_THEME_INDEX = Theme.DEFAULT_THEME_INDEX;
    private static final int THEME_ALPHA = 64;
    private static final int BED_BREAK_ANIMATION_DURATION = 250;
    private static final float BED_BREAK_ANIMATION_ALPHA = 0.95F;
    private static final float DEFENSE_AUTO_SCALE_THRESHOLD = 8.0F;
    private static final double BEAM_HEIGHT = 75.0;
    private static final double BEAM_WIDTH = 0.1;
    private static final float BEAM_ALPHA = 0.3F;

    private SliderSetting colorMode;
    private SliderSetting theme;
    private ColorSetting color;
    private ColorSetting color2;
    private SliderSetting gradientSpeed;
    private SliderSetting range;
    private SliderSetting scanSpeed;
    private ButtonSetting disableInLobby;
    private ButtonSetting firstBed;
    private ButtonSetting renderFullBlock;
    private ButtonSetting showExposedOutline;
    private ButtonSetting disableFullyExposed;
    private SliderSetting renderExposedBlocks;
    private ColorSetting exposedColor;
    private ColorSetting exposedOutlineColor;
    private ButtonSetting showDefenseLayers;
    private ButtonSetting showDefenseTools;
    private ButtonSetting showDefenseCounts;
    private SliderSetting defenseHeight;
    private SliderSetting defenseScale;
    private ButtonSetting defenseAutoScale;
    private ButtonSetting drawBeam;
    private boolean lastDefenseToolMode;
    private boolean pausedForLobby;

    private final List<BlockPos[]> lastRenderedBedPairs = new ArrayList<>();

    private static final int DEFENSE_ICON_SIZE = 16;
    private static final int DEFENSE_ICON_SPACING = 18;
    private static final int DEFENSE_PADDING = 3;
    private static final float DEFENSE_BACKGROUND_RADIUS = 8.0F;
    private static final int DEFENSE_BACKGROUND_COLOR = 0x73000000;
    private static final int DEFENSE_BACKGROUND_OUTLINE_COLOR = 0x96000000;
    private static final int DEFENSE_MAX_LAYERS = 5;
    private static final float DEFENSE_AIR_RATIO_THRESHOLD = 0.2F;
    private static final float DEFENSE_BLOCK_RATIO_THRESHOLD = 0.2F;
    private static final EnumMap<EnumFacing, LayerOffsets[]> DEFENSE_OFFSETS = buildLayerOffsetsByFacing();

    private final List<BlockPos[]> activeBedPairs = new ArrayList<>();
    private final Map<Long, BedBreakAnimation> bedBreakAnimations = new HashMap<>();
    private final Map<Long, DefenseOverlaySnapshot> defenseSnapshots = new HashMap<>();
    private final Map<Long, DefenseWatchRegion> defenseWatchRegions = new HashMap<>();
    private final Map<Long, Set<Long>> watchedBedsByDefensePos = new HashMap<>();
    private final Map<Long, Set<Long>> watchedBedsByChunk = new HashMap<>();
    private final Set<Long> dirtyDefenseBeds = new HashSet<>();
    private final SharedBlockHighlightCache.UpdateListener defenseUpdateListener = new SharedBlockHighlightCache.UpdateListener() {
        @Override
        public void onBlockChanged(BlockPos pos, IBlockState newState) {
            markBedsDirtyForDefensePos(pos);
        }

        @Override
        public void onChunkQueued(int chunkX, int chunkZ) {
            markBedsDirtyForChunk(chunkX, chunkZ);
        }

        @Override
        public void onChunkRemoved(int chunkX, int chunkZ) {
            markBedsDirtyForChunk(chunkX, chunkZ);
        }

        @Override
        public void onCacheCleared() {
            clearDefenseState();
        }
    };

    public BedESP() {
        super("BedESP", category.render);
        this.liteModule = true;
        this.registerSetting(colorMode = new SliderSetting("Color mode", 0, COLOR_MODES));
        this.registerSetting(theme = new SliderSetting("Theme", DEFAULT_THEME_INDEX, Theme.THEMES_SETTING));
        this.registerSetting(color = new ColorSetting("Color", 255, 85, 85, 64));
        this.registerSetting(color2 = new ColorSetting("Color 2", 85, 85, 255, 64));
        this.registerSetting(gradientSpeed = new SliderSetting("Gradient speed", 1.0, 0.1, 8.0, 0.1));
        this.registerSetting(range = new SliderSetting("Range", 10.0, 4.0, 200.0, 2.0));
        this.registerSetting(scanSpeed = new SliderSetting("Scan speed", 8.0, 1.0, 32.0, 1.0));
        this.registerSetting(disableInLobby = new ButtonSetting("Disable in lobby", true));
        this.registerSetting(drawBeam = new ButtonSetting("Draw beam", false));
        this.registerSetting(firstBed = new ButtonSetting("Only render first bed", false));
        this.registerSetting(renderFullBlock = new ButtonSetting("Render full block", false));
        this.registerSetting(renderExposedBlocks = new SliderSetting("Render exposed", " block", true, -1, 1, 8, 1));
        this.registerSetting(exposedColor = new ColorSetting("Exposed color", 255, 0, 0, 64));
        this.registerSetting(showExposedOutline = new ButtonSetting("Outline exposed", true));
        this.registerSetting(disableFullyExposed = new ButtonSetting("Disable fully exposed", false));
        this.registerSetting(exposedOutlineColor = new ColorSetting("Exposed outline color", 255, 220, 64, 255));
        this.registerSetting(showDefenseLayers = new ButtonSetting("Show defense layers", false));
        this.registerSetting(showDefenseTools = new ButtonSetting("Show break tools", false));
        this.registerSetting(showDefenseCounts = new ButtonSetting("Show defense counts", true));
        this.registerSetting(defenseHeight = new SliderSetting("Defense height", 0.6, 0.1, 3.0, 0.1));
        this.registerSetting(defenseScale = new SliderSetting("Defense scale", 1.0, 0.1, 2.0, 0.05));
        this.registerSetting(defenseAutoScale = new ButtonSetting("Auto Scale", false));
    }

    @Override
    public void guiUpdate() {
        int mode = colorMode == null ? 0 : (int) colorMode.getInput();

        boolean staticMode = mode == 0;
        boolean gradientMode = mode == 1;
        boolean rainbowMode = mode == 2;
        boolean themeMode = mode == THEME_COLOR_MODE;
        boolean renderExposedEnabled = (int) renderExposedBlocks.getInput() != -1;

        theme.setVisible(themeMode, this);
        color.setVisible(staticMode || gradientMode || rainbowMode, this);
        color2.setVisible(gradientMode, this);
        gradientSpeed.setVisible(gradientMode, this);

        exposedColor.setVisible(renderExposedEnabled, this);
        boolean exposedOutlineAvailable = showExposedOutline.isToggled();

        disableFullyExposed.setVisible(exposedOutlineAvailable, this);
        exposedOutlineColor.setVisible(exposedOutlineAvailable, this);

        boolean defenseVisible = showDefenseLayers.isToggled();
        showDefenseTools.setVisible(defenseVisible, this);
        showDefenseCounts.setVisible(defenseVisible && !showDefenseTools.isToggled(), this);
        defenseHeight.setVisible(defenseVisible, this);
        defenseScale.setVisible(defenseVisible, this);
        defenseAutoScale.setVisible(defenseVisible, this);
    }

    @Override
    public void onEnable() {
        SharedBlockHighlightCache cache = SharedBlockHighlightCache.get();
        cache.addUpdateListener(defenseUpdateListener);
        pausedForLobby = shouldPauseForLobby();
        if (pausedForLobby) {
            cache.detachBed();
            clearRenderedState();
        } else {
            cache.attachBed();
            cache.enqueueLoadedChunks();
        }
    }

    @Override
    public void onDisable() {
        SharedBlockHighlightCache cache = SharedBlockHighlightCache.get();
        cache.removeUpdateListener(defenseUpdateListener);
        cache.detachBed();
        pausedForLobby = false;
        clearRenderedState();
    }

    @SubscribeEvent
    public void onEntityJoin(EntityJoinWorldEvent e) {
        if (e.entity == mc.thePlayer) {
            clearRenderedState();
        }
    }

    public int getScanSpeedBudget() {
        return isEnabled() && !pausedForLobby ? (int) scanSpeed.getInput() : 0;
    }

    @Override
    public void onUpdate() {
        if (!Utils.nullCheck()) {
            activeBedPairs.clear();
            clearDefenseState();
            return;
        }

        boolean pauseForLobby = shouldPauseForLobby();
        if (pauseForLobby != pausedForLobby) {
            setPausedForLobby(pauseForLobby);
        }
        if (pauseForLobby) {
            clearRenderedState();
            return;
        }

        SharedBlockHighlightCache cache = SharedBlockHighlightCache.get();
        double rangeSq = range.getInput() * range.getInput();
        double px = mc.thePlayer.posX;
        double py = mc.thePlayer.posY;
        double pz = mc.thePlayer.posZ;
        List<BlockPos[]> candidatePairs = collectActiveBedPairs(cache, px, py, pz, rangeSq);

        for (BlockPos[] pair : activeBedPairs) {
            if (!hasBedAt(pair[0])) {
                startBedBreakAnimation(pair);
            }
        }

        activeBedPairs.clear();
        for (BlockPos[] pair : candidatePairs) {
            activeBedPairs.add(copyBedPair(pair));
        }

        boolean defenseToolMode = showDefenseTools.isToggled();
        if (lastDefenseToolMode != defenseToolMode) {
            clearDefenseState();
            lastDefenseToolMode = defenseToolMode;
        }

        if (!showDefenseLayers.isToggled()) {
            clearDefenseState();
            return;
        }

        Set<Long> activeFeet = new HashSet<>();
        for (BlockPos[] pair : candidatePairs) {
            BlockPos foot = pair[0];
            BlockPos head = pair[1];
            long footKey = foot.toLong();
            activeFeet.add(footKey);

            DefenseWatchRegion region = defenseWatchRegions.get(footKey);
            if (region == null || !region.matches(head)) {
                unregisterDefenseWatch(footKey);
                registerDefenseWatch(foot, head);
                dirtyDefenseBeds.add(footKey);
            }

            DefenseOverlaySnapshot snapshot = defenseSnapshots.get(footKey);
            if (snapshot == null || !snapshot.matches(head) || dirtyDefenseBeds.remove(footKey)) {
                defenseSnapshots.put(footKey, computeDefenseSnapshot(foot, head));
            }
        }

        for (Long footKey : new ArrayList<>(defenseWatchRegions.keySet())) {
            if (!activeFeet.contains(footKey)) {
                unregisterDefenseWatch(footKey);
            }
        }

        dirtyDefenseBeds.retainAll(activeFeet);
    }

    @Override
    public String getInfo() {
        if (pausedForLobby || shouldPauseForLobby()) {
            return "";
        }
        int n = SharedBlockHighlightCache.get().totalBedFeet();
        return n > 0 ? String.valueOf(n) : "";
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onRenderWorld(RenderWorldLastEvent e) {
        if (!Utils.nullCheck()) {
            return;
        }
        if (!isEnabled() || shouldPauseForLobby()) {
            return;
        }
        float blockHeight = getBlockHeight();
        double rangeSq = range.getInput() * range.getInput();
        double px = mc.thePlayer.posX;
        double py = mc.thePlayer.posY;
        double pz = mc.thePlayer.posZ;

        List<BlockPos[]> pairsToRender = new ArrayList<>();
        Set<BlockPos> addedFeet = new HashSet<>();
        Set<Long> activeFeet = new HashSet<>();
        Map<Long, Float> animatedAlphas = new HashMap<>();

        for (BlockPos[] pair : activeBedPairs) {
            BlockPos foot = pair[0];
            long footKey = foot.toLong();
            activeFeet.add(footKey);
            if (!hasBedAt(foot)) {
                startBedBreakAnimation(pair);
                continue;
            }
            bedBreakAnimations.remove(footKey);
            AxisAlignedBB bb = bedWorldBounds(pair[0], pair[1], blockHeight);
            if (!isBedOrBeamVisible(pair, bb)) {
                continue;
            }
            if (addedFeet.add(foot)) {
                pairsToRender.add(copyBedPair(pair));
            }
        }

        for (BlockPos[] prev : new ArrayList<>(lastRenderedBedPairs)) {
            if (prev == null || prev.length < 2) {
                continue;
            }
            BlockPos foot = prev[0];
            BlockPos head = prev[1];
            long footKey = foot.toLong();
            if (activeFeet.contains(footKey)) {
                continue;
            }
            if (!hasBedAt(foot)) {
                startBedBreakAnimation(prev);
                continue;
            }
            bedBreakAnimations.remove(footKey);
            double dx = foot.getX() + 0.5 - px;
            double dy = foot.getY() + 0.5 - py;
            double dz = foot.getZ() + 0.5 - pz;
            if (dx * dx + dy * dy + dz * dz > rangeSq) {
                continue;
            }
            AxisAlignedBB bb = bedWorldBounds(foot, head, blockHeight);
            if (!isBedOrBeamVisible(prev, bb)) {
                continue;
            }
            pairsToRender.add(copyBedPair(prev));
            addedFeet.add(foot);
        }

        long now = System.currentTimeMillis();
        java.util.Iterator<Map.Entry<Long, BedBreakAnimation>> animationIterator = bedBreakAnimations.entrySet().iterator();
        while (animationIterator.hasNext()) {
            Map.Entry<Long, BedBreakAnimation> entry = animationIterator.next();
            BedBreakAnimation animation = entry.getValue();
            BlockPos[] pair = animation.pair;
            BlockPos foot = pair[0];
            if (hasBedAt(foot)) {
                animationIterator.remove();
                continue;
            }

            float progress = (float) (now - animation.startedAt) / BED_BREAK_ANIMATION_DURATION;
            if (progress >= 1.0F) {
                animationIterator.remove();
                continue;
            }
            float alpha = BED_BREAK_ANIMATION_ALPHA * (1.0F - progress);

            double dx = foot.getX() + 0.5 - px;
            double dy = foot.getY() + 0.5 - py;
            double dz = foot.getZ() + 0.5 - pz;
            if (dx * dx + dy * dy + dz * dz > rangeSq) {
                continue;
            }
            AxisAlignedBB bb = bedWorldBounds(pair[0], pair[1], blockHeight);
            if (!isBedOrBeamVisible(pair, bb)) {
                continue;
            }
            if (addedFeet.add(foot)) {
                pairsToRender.add(copyBedPair(pair));
                animatedAlphas.put(entry.getKey(), alpha);
            }
        }

        for (BlockPos[] pair : pairsToRender) {
            long footKey = pair[0].toLong();
            Float animatedAlpha = animatedAlphas.get(footKey);
            renderBed(pair, blockHeight, animatedAlpha);
            if (showDefenseLayers.isToggled()) {
                BedBreakAnimation animation = bedBreakAnimations.get(footKey);
                if (animation != null || isLiveBedPair(pair)) {
                    DefenseOverlaySnapshot snapshot = animation == null ? defenseSnapshots.get(footKey) : animation.defenseSnapshot;
                    renderDefenseOverlay(pair, blockHeight, snapshot, animatedAlpha);
                }
            }
        }

        lastRenderedBedPairs.clear();
        for (BlockPos[] pair : pairsToRender) {
            lastRenderedBedPairs.add(copyBedPair(pair));
        }
    }

    private boolean shouldPauseForLobby() {
        return disableInLobby != null && disableInLobby.isToggled() && Utils.nullCheck() && Utils.isLobby();
    }

    private void setPausedForLobby(boolean paused) {
        pausedForLobby = paused;
        SharedBlockHighlightCache cache = SharedBlockHighlightCache.get();
        if (paused) {
            cache.detachBed();
            clearRenderedState();
        } else {
            cache.attachBed();
            cache.enqueueLoadedChunks();
        }
    }

    private void clearRenderedState() {
        activeBedPairs.clear();
        lastRenderedBedPairs.clear();
        bedBreakAnimations.clear();
        lastDefenseToolMode = false;
        clearDefenseState();
    }

    private void startBedBreakAnimation(BlockPos[] pair) {
        long footKey = pair[0].toLong();
        if (bedBreakAnimations.containsKey(footKey)) {
            return;
        }
        bedBreakAnimations.put(footKey, new BedBreakAnimation(copyBedPair(pair),
                System.currentTimeMillis(), defenseSnapshots.get(footKey)));
    }

    private static BlockPos[] copyBedPair(BlockPos[] pair) {
        return new BlockPos[]{new BlockPos(pair[0]), new BlockPos(pair[1])};
    }

    private List<BlockPos[]> collectActiveBedPairs(SharedBlockHighlightCache cache, double px, double py, double pz, double rangeSq) {
        List<BlockPos[]> candidatePairs = new ArrayList<>();

        for (Map.Entry<Long, Set<BlockPos>> chunk : cache.entriesBedFeet()) {
            for (BlockPos foot : chunk.getValue()) {
                double dx = foot.getX() + 0.5 - px;
                double dy = foot.getY() + 0.5 - py;
                double dz = foot.getZ() + 0.5 - pz;
                if (dx * dx + dy * dy + dz * dz > rangeSq) {
                    continue;
                }

                BlockPos[] pair = footAndHead(foot);
                if (pair == null || !stillHasRenderableBed(pair)) {
                    continue;
                }

                candidatePairs.add(copyBedPair(pair));
            }
        }

        if (!firstBed.isToggled() || candidatePairs.size() <= 1) {
            return candidatePairs;
        }

        BlockPos[] nearest = null;
        double nearestDistanceSq = Double.MAX_VALUE;
        for (BlockPos[] pair : candidatePairs) {
            double dx = pair[0].getX() + 0.5 - px;
            double dy = pair[0].getY() + 0.5 - py;
            double dz = pair[0].getZ() + 0.5 - pz;
            double distanceSq = dx * dx + dy * dy + dz * dz;
            if (distanceSq < nearestDistanceSq) {
                nearestDistanceSq = distanceSq;
                nearest = pair;
            }
        }

        candidatePairs.clear();
        if (nearest != null) {
            candidatePairs.add(nearest);
        }
        return candidatePairs;
    }

    private static boolean isBedFoot(IBlockState st) {
        return st != null && st.getBlock() instanceof BlockBed
                && st.getValue((IProperty) BlockBed.PART) == BlockBed.EnumPartType.FOOT;
    }

    private boolean stillHasRenderableBed(BlockPos[] pair) {
        if (pair == null || pair.length < 2 || mc.theWorld == null) {
            return false;
        }
        IBlockState a = mc.theWorld.getBlockState(pair[0]);
        IBlockState b = mc.theWorld.getBlockState(pair[1]);
        return a != null && a.getBlock() instanceof BlockBed
                || b != null && b.getBlock() instanceof BlockBed;
    }

    private boolean hasBedAt(BlockPos pos) {
        return mc.theWorld != null && mc.theWorld.getBlockState(pos).getBlock() instanceof BlockBed;
    }

    private boolean isLiveBedPair(BlockPos[] pair) {
        if (pair == null || pair.length < 2 || mc.theWorld == null) {
            return false;
        }
        IBlockState footState = mc.theWorld.getBlockState(pair[0]);
        IBlockState headState = mc.theWorld.getBlockState(pair[1]);
        return isBedFoot(footState) && headState != null && headState.getBlock() instanceof BlockBed;
    }

    private static AxisAlignedBB bedWorldBounds(BlockPos foot, BlockPos head, float height) {
        int fx = foot.getX(), fy = foot.getY(), fz = foot.getZ();
        double h = fy + height;
        if (foot.getX() != head.getX()) {
            if (foot.getX() > head.getX()) {
                return new AxisAlignedBB(fx - 1.0, fy, fz, fx + 1.0, h, fz + 1.0);
            }
            return new AxisAlignedBB(fx, fy, fz, fx + 2.0, h, fz + 1.0);
        }
        if (foot.getZ() > head.getZ()) {
            return new AxisAlignedBB(fx, fy, fz - 1.0, fx + 1.0, h, fz + 1.0);
        }
        return new AxisAlignedBB(fx, fy, fz, fx + 1.0, h, fz + 2.0);
    }

    private BlockPos[] footAndHead(BlockPos foot) {
        IBlockState st = mc.theWorld.getBlockState(foot);
        if (!(st.getBlock() instanceof BlockBed)) {
            return null;
        }
        EnumFacing facing = (EnumFacing) st.getValue((IProperty) BlockBed.FACING);
        return new BlockPos[]{foot, foot.offset(facing)};
    }

    private boolean isOwnBed(BlockPos[] blocks) {
        return ModuleManager.bedwars != null && ModuleManager.bedwars.isOwnBed(blocks);
    }

    private AxisAlignedBB beamWorldBounds(BlockPos[] blocks) {
        double x = (blocks[0].getX() + blocks[1].getX()) * 0.5 + 0.5;
        double z = (blocks[0].getZ() + blocks[1].getZ()) * 0.5 + 0.5;
        double y = blocks[0].getY();
        return new AxisAlignedBB(x - BEAM_WIDTH, y, z - BEAM_WIDTH,
                x + BEAM_WIDTH, y + BEAM_HEIGHT, z + BEAM_WIDTH);
    }

    private boolean isBedOrBeamVisible(BlockPos[] blocks, AxisAlignedBB bedBounds) {
        return RenderUtils.isInViewFrustum(bedBounds)
                || drawBeam.isToggled() && !isOwnBed(blocks) && RenderUtils.isInViewFrustum(beamWorldBounds(blocks));
    }

    private void renderBedBeam(BlockPos[] blocks, Float animatedAlpha) {
        if (!drawBeam.isToggled() || isOwnBed(blocks) || !RenderUtils.isInViewFrustum(beamWorldBounds(blocks))) {
            return;
        }
        double x = (blocks[0].getX() + blocks[1].getX()) * 0.5;
        double z = (blocks[0].getZ() + blocks[1].getZ()) * 0.5;
        float alpha = (animatedAlpha == null ? 1.0F : animatedAlpha) * BEAM_ALPHA;
        RenderUtils.drawBeam(x, blocks[0].getY(), z, BEAM_HEIGHT, BEAM_WIDTH,
                Theme.getGradient(Theme.Frost.ordinal(), 0.0), alpha);
    }

    private void renderBed(BlockPos[] blocks, float height, Float animatedAlpha) {
        renderBedBeam(blocks, animatedAlpha);
        if (!RenderUtils.isInViewFrustum(bedWorldBounds(blocks[0], blocks[1], height))) {
            return;
        }
        List<BlockPos> exposedBlocks = getExposedBlocks(blocks);
        List<AxisAlignedBB> mergedExposedBounds = mergeExposedBounds(exposedBlocks);

        int exposedCount = exposedBlocks.size();
        int exposedLimit = (int) renderExposedBlocks.getInput();

        boolean exposedRenderingEnabled = exposedLimit != -1;
        boolean renderExposedOverlays = exposedRenderingEnabled
                && exposedCount > 0
                && exposedCount <= exposedLimit;

        boolean fullyExposed = isFullyExposed(blocks);

        boolean renderExposedOutline = showExposedOutline.isToggled()
                && exposedCount > 0
                && (!disableFullyExposed.isToggled() || !fullyExposed)
                && (!exposedRenderingEnabled || exposedCount > exposedLimit);
        double x = blocks[0].getX() - mc.getRenderManager().viewerPosX;
        double y = blocks[0].getY() - mc.getRenderManager().viewerPosY;
        double z = blocks[0].getZ() - mc.getRenderManager().viewerPosZ;
        GL11.glBlendFunc(770, 771);
        GL11.glEnable(3042);
        GL11.glLineWidth(2.0f);
        GL11.glDisable(3553);
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        int col = getCurrentColor();
        float drawA = animatedAlpha == null ? (col >> 24 & 0xFF) / 255.0f : animatedAlpha;
        float r = (col >> 16 & 0xFF) / 255.0f;
        float g = (col >> 8 & 0xFF) / 255.0f;
        float b = (col & 0xFF) / 255.0f;
        GL11.glColor4d(r, g, b, drawA);
        AxisAlignedBB axisAlignedBB;
        if (blocks[0].getX() != blocks[1].getX()) {
            if (blocks[0].getX() > blocks[1].getX()) {
                axisAlignedBB = new AxisAlignedBB(x - 1.0, y, z, x + 1.0, y + height, z + 1.0);
            } else {
                axisAlignedBB = new AxisAlignedBB(x, y, z, x + 2.0, y + height, z + 1.0);
            }
        } else if (blocks[0].getZ() > blocks[1].getZ()) {
            axisAlignedBB = new AxisAlignedBB(x, y, z - 1.0, x + 1.0, y + height, z + 1.0);
        } else {
            axisAlignedBB = new AxisAlignedBB(x, y, z, x + 1.0, y + height, z + 2.0);
        }
        RenderUtils.drawBoundingBox(axisAlignedBB, r, g, b, drawA);
        if (renderExposedOverlays) {
            renderExposedBlockOverlays(mergedExposedBounds);
        }
        if (renderExposedOutline) {
            int outlineColor = exposedOutlineColor.getColor();
            float outlineA = (outlineColor >> 24 & 0xFF) / 255.0f;
            float outlineR = (outlineColor >> 16 & 0xFF) / 255.0f;
            float outlineG = (outlineColor >> 8 & 0xFF) / 255.0f;
            float outlineB = (outlineColor & 0xFF) / 255.0f;
            GL11.glLineWidth(3.0f);
            GL11.glColor4f(outlineR, outlineG, outlineB, outlineA);
            RenderGlobal.drawSelectionBoundingBox(axisAlignedBB);
            GL11.glLineWidth(2.0f);
        }
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glEnable(3553);
        GL11.glEnable(2929);
        GL11.glDepthMask(true);
        GL11.glDisable(3042);
    }

    private List<AxisAlignedBB> mergeExposedBounds(List<BlockPos> exposedBlocks) {
        List<AxisAlignedBB> bounds = new ArrayList<>();

        for (BlockPos pos : exposedBlocks) {
            bounds.add(new AxisAlignedBB(
                    pos.getX(),
                    pos.getY(),
                    pos.getZ(),
                    pos.getX() + 1.0,
                    pos.getY() + 1.0,
                    pos.getZ() + 1.0
            ));
        }

        boolean merged;

        do {
            merged = false;

            outer:
            for (int i = 0; i < bounds.size(); i++) {
                for (int j = i + 1; j < bounds.size(); j++) {
                    AxisAlignedBB combined = mergeAdjacentBounds(bounds.get(i), bounds.get(j));

                    if (combined != null) {
                        bounds.set(i, combined);
                        bounds.remove(j);
                        merged = true;
                        break outer;
                    }
                }
            }
        } while (merged);

        return bounds;
    }

    private AxisAlignedBB mergeAdjacentBounds(AxisAlignedBB first, AxisAlignedBB second) {
        boolean sameX = first.minX == second.minX && first.maxX == second.maxX;
        boolean sameY = first.minY == second.minY && first.maxY == second.maxY;
        boolean sameZ = first.minZ == second.minZ && first.maxZ == second.maxZ;

        if (sameY && sameZ && (first.maxX == second.minX || second.maxX == first.minX)) {
            return new AxisAlignedBB(
                    Math.min(first.minX, second.minX),
                    first.minY,
                    first.minZ,
                    Math.max(first.maxX, second.maxX),
                    first.maxY,
                    first.maxZ
            );
        }

        if (sameX && sameZ && (first.maxY == second.minY || second.maxY == first.minY)) {
            return new AxisAlignedBB(
                    first.minX,
                    Math.min(first.minY, second.minY),
                    first.minZ,
                    first.maxX,
                    Math.max(first.maxY, second.maxY),
                    first.maxZ
            );
        }

        if (sameX && sameY && (first.maxZ == second.minZ || second.maxZ == first.minZ)) {
            return new AxisAlignedBB(
                    first.minX,
                    first.minY,
                    Math.min(first.minZ, second.minZ),
                    first.maxX,
                    first.maxY,
                    Math.max(first.maxZ, second.maxZ)
            );
        }

        return null;
    }

    private void renderExposedBlockOverlays(List<AxisAlignedBB> exposedBounds) {
        if (exposedBounds.isEmpty()) {
            return;
        }

        int overlayColor = exposedColor.getColor();
        float overlayA = (overlayColor >> 24 & 0xFF) / 255.0f;
        float overlayR = (overlayColor >> 16 & 0xFF) / 255.0f;
        float overlayG = (overlayColor >> 8 & 0xFF) / 255.0f;
        float overlayB = (overlayColor & 0xFF) / 255.0f;

        RenderManager renderManager = mc.getRenderManager();

        GL11.glColor4f(overlayR, overlayG, overlayB, overlayA);

        for (AxisAlignedBB bounds : exposedBounds) {
            AxisAlignedBB renderedBounds = bounds.offset(
                    -renderManager.viewerPosX,
                    -renderManager.viewerPosY,
                    -renderManager.viewerPosZ
            );

            RenderUtils.drawBoundingBox(
                    renderedBounds,
                    overlayR,
                    overlayG,
                    overlayB,
                    overlayA
            );
        }
    }

    private List<BlockPos> getExposedBlocks(BlockPos[] pair) {
        if (pair == null || pair.length < 2 || mc.theWorld == null) {
            return Collections.emptyList();
        }

        Set<BlockPos> exposedBlocks = new HashSet<>();

        for (BlockPos bedPart : pair) {
            IBlockState bedState = mc.theWorld.getBlockState(bedPart);

            if (bedState == null || !(bedState.getBlock() instanceof BlockBed)) {
                continue;
            }

            for (EnumFacing side : EnumFacing.values()) {
                BlockPos neighbor = bedPart.offset(side);

                // Never treat either half of the tracked bed as exposed space. During
                // bed removal, the two halves can become air on different updates.
                if (neighbor.equals(pair[0]) || neighbor.equals(pair[1])) {
                    continue;
                }

                Block neighborBlock = mc.theWorld.getBlockState(neighbor).getBlock();

                if (neighborBlock == Blocks.air) {
                    exposedBlocks.add(neighbor);
                }
            }
        }

        return new ArrayList<>(exposedBlocks);
    }

    private boolean isFullyExposed(BlockPos[] pair) {
        if (pair == null || pair.length < 2 || mc.theWorld == null) {
            return false;
        }

        boolean hasBedPart = false;

        for (BlockPos bedPart : pair) {
            IBlockState state = mc.theWorld.getBlockState(bedPart);
            Block block = state.getBlock();

            if (block instanceof BlockBed) {
                hasBedPart = true;
            } else if (block != Blocks.air) {
                return false;
            }

            for (EnumFacing side : EnumFacing.values()) {
                if (side == EnumFacing.DOWN) {
                    continue;
                }

                BlockPos neighbor = bedPart.offset(side);

                if (neighbor.equals(pair[0]) || neighbor.equals(pair[1])) {
                    continue;
                }

                if (mc.theWorld.getBlockState(neighbor).getBlock() != Blocks.air) {
                    return false;
                }
            }
        }

        return hasBedPart;
    }

    private void renderDefenseOverlay(BlockPos[] blocks, float blockHeight, DefenseOverlaySnapshot snapshot, Float animatedAlpha) {
        if (snapshot == null || !snapshot.matches(blocks[1]) || snapshot.entries.isEmpty()) {
            return;
        }

        RenderManager renderManager = mc.getRenderManager();
        FontRenderer fontRenderer = mc.fontRendererObj;
        if (renderManager == null || fontRenderer == null) {
            return;
        }

        AxisAlignedBB bedBounds = bedWorldBounds(blocks[0], blocks[1], blockHeight);
        double x = (bedBounds.minX + bedBounds.maxX) * 0.5 - renderManager.viewerPosX;
        double y = bedBounds.maxY + defenseHeight.getInput() - renderManager.viewerPosY;
        double z = (bedBounds.minZ + bedBounds.maxZ) * 0.5 - renderManager.viewerPosZ;
        float renderScale = computeDefenseBaseScaleValue();
        if (defenseAutoScale.isToggled()) {
            float distance = (float) Math.sqrt(x * x + y * y + z * z);
            renderScale = computeDefenseScaleValue(distance);
        }
        if (animatedAlpha != null) {
            double t = animatedAlpha / BED_BREAK_ANIMATION_ALPHA;
            double scaleMultiplier = t <= 0.55
                    ? 1.3 * Math.exp(-5.0 * (1.0 - t))
                    : 1.3 * (1.0 + 0.3 * Math.sin((t - 0.55) * Math.PI / 0.3));
            renderScale *= (float) scaleMultiplier;
        }
        List<DefenseOverlayEntry> stacks = snapshot.entries;
        int contentWidth = stacks.size() * DEFENSE_ICON_SPACING - (DEFENSE_ICON_SPACING - DEFENSE_ICON_SIZE);
        int left = -contentWidth / 2;
        int iconY = -8;
        int backgroundLeft = left - DEFENSE_PADDING;
        int backgroundTop = iconY - DEFENSE_PADDING;
        int backgroundRight = left + contentWidth + DEFENSE_PADDING;
        int backgroundBottom = iconY + DEFENSE_ICON_SIZE + DEFENSE_PADDING;

        GlStateManager.pushMatrix();
        try {
            GlStateManager.translate((float) x, (float) y, (float) z);
            GlStateManager.rotate(-renderManager.playerViewY, 0.0F, 1.0F, 0.0F);
            GlStateManager.rotate(renderManager.playerViewX, 1.0F, 0.0F, 0.0F);
            GlStateManager.scale(-renderScale, -renderScale, renderScale);

            GlStateManager.disableLighting();
            GlStateManager.depthMask(false);
            GlStateManager.disableDepth();
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);

            renderDefenseBackground(backgroundLeft, backgroundTop, backgroundRight, backgroundBottom);
            applyDefenseOverlayTextState();

            for (int i = 0; i < stacks.size(); i++) {
                DefenseOverlayEntry stackData = stacks.get(i);
                int iconX = left + i * DEFENSE_ICON_SPACING;
                renderDefenseEntry(stackData, iconX, iconY);
                applyDefenseOverlayTextState();

                if (!showDefenseTools.isToggled() && showDefenseCounts.isToggled() && stackData.count > 1) {
                    String countText = String.valueOf(stackData.getCount());
                    fontRenderer.drawStringWithShadow(countText, iconX + 17 - fontRenderer.getStringWidth(countText), iconY + 9, 0xFFFFFF);
                    applyDefenseOverlayTextState();
                }
            }
        } finally {
            GlStateManager.enableDepth();
            GlStateManager.depthMask(true);
            GlStateManager.disableLighting();
            GlStateManager.disableRescaleNormal();
            GlStateManager.disableBlend();
            GlStateManager.enableAlpha();
            GlStateManager.enableTexture2D();
            GlStateManager.tryBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ZERO);
            GL11.glTexEnvi(GL11.GL_TEXTURE_ENV, GL11.GL_TEXTURE_ENV_MODE, GL11.GL_MODULATE);
            GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
            GlStateManager.popMatrix();
        }
    }

    private void renderDefenseEntry(DefenseOverlayEntry entry, int iconX, int iconY) {
        if (entry == null) {
            return;
        }

        if (entry.hasItemStack()) {
            RenderUtils.renderItemAndEffectIntoGui3D(entry.renderStack, iconX, iconY);
            return;
        }

        if (entry.hasBlockSprite()) {
            renderDefenseBlockSprite(entry.blockSprite, iconX, iconY);
        }
    }

    private void renderDefenseBlockSprite(TextureAtlasSprite sprite, int iconX, int iconY) {
        if (sprite == null) {
            return;
        }

        mc.getTextureManager().bindTexture(TextureMap.locationBlocksTexture);
        GlStateManager.enableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);

        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldRenderer = tessellator.getWorldRenderer();
        worldRenderer.begin(7, DefaultVertexFormats.POSITION_TEX);
        worldRenderer.pos(iconX, iconY + DEFENSE_ICON_SIZE, 0.0D).tex(sprite.getMinU(), sprite.getMaxV()).endVertex();
        worldRenderer.pos(iconX + DEFENSE_ICON_SIZE, iconY + DEFENSE_ICON_SIZE, 0.0D).tex(sprite.getMaxU(), sprite.getMaxV()).endVertex();
        worldRenderer.pos(iconX + DEFENSE_ICON_SIZE, iconY, 0.0D).tex(sprite.getMaxU(), sprite.getMinV()).endVertex();
        worldRenderer.pos(iconX, iconY, 0.0D).tex(sprite.getMinU(), sprite.getMinV()).endVertex();
        tessellator.draw();
    }

    private void renderDefenseBackground(int left, int top, int right, int bottom) {
        RenderUtils.drawRoundedGradientOutlinedRectangle(left, top, right, bottom, DEFENSE_BACKGROUND_RADIUS,
                DEFENSE_BACKGROUND_COLOR, DEFENSE_BACKGROUND_OUTLINE_COLOR, DEFENSE_BACKGROUND_OUTLINE_COLOR);
    }

    private void applyDefenseOverlayTextState() {
        GlStateManager.disableLighting();
        GlStateManager.disableDepth();
        GlStateManager.depthMask(false);
        GlStateManager.enableTexture2D();
        GlStateManager.enableAlpha();
        GlStateManager.alphaFunc(GL11.GL_GREATER, 0.1F);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ZERO);
        GL11.glTexEnvi(GL11.GL_TEXTURE_ENV, GL11.GL_TEXTURE_ENV_MODE, GL11.GL_MODULATE);
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    }

    private DefenseOverlaySnapshot computeDefenseSnapshot(BlockPos foot, BlockPos head) {
        LayerOffsets[] layers = getLayerOffsets(foot, head);
        if (layers == null) {
            return new DefenseOverlaySnapshot(new BlockPos(head), Collections.<DefenseOverlayEntry>emptyList());
        }

        Map<DefenseBlockKey, Integer> finalCounts = new HashMap<>();
        Map<Integer, DefenseBlockKey> resolvedBlockKeys = new HashMap<>();
        int sparseLayerCount = 0;
        BlockPos.MutableBlockPos mutablePos = new BlockPos.MutableBlockPos();

        for (LayerOffsets layerOffsets : layers) {
            Map<DefenseBlockKey, Integer> layerCounts = new HashMap<>();
            int layerTotalBlocks = 0;
            int layerAirBlocks = 0;

            for (RelativeOffset offset : layerOffsets.positions) {
                mutablePos.set(foot.getX() + offset.x, foot.getY() + offset.y, foot.getZ() + offset.z);
                if (accumulateDefenseBlock(mutablePos, layerCounts, resolvedBlockKeys)) {
                    layerAirBlocks++;
                }
                layerTotalBlocks++;
            }

            if (layerTotalBlocks == 0 || (float) layerAirBlocks / (float) layerTotalBlocks > DEFENSE_AIR_RATIO_THRESHOLD) {
                if (++sparseLayerCount >= 2) {
                    break;
                }
                continue;
            }

            sparseLayerCount = 0;
            for (Map.Entry<DefenseBlockKey, Integer> countedBlock : layerCounts.entrySet()) {
                int count = countedBlock.getValue();
                if ((float) count / (float) layerTotalBlocks >= DEFENSE_BLOCK_RATIO_THRESHOLD) {
                    finalCounts.put(countedBlock.getKey(), finalCounts.getOrDefault(countedBlock.getKey(), 0) + count);
                }
            }
        }

        List<DefenseOverlayEntry> entries;
        if (showDefenseTools.isToggled()) {
            Set<ToolOverlayType> toolTypes = new HashSet<>();
            for (DefenseBlockKey countedBlock : finalCounts.keySet()) {
                ToolOverlayType toolType = ToolOverlayType.fromState(countedBlock.state);
                if (toolType != null) {
                    toolTypes.add(toolType);
                }
            }
            if (toolTypes.contains(ToolOverlayType.DIAMOND_PICKAXE)) {
                toolTypes.remove(ToolOverlayType.IRON_PICKAXE);
            }

            entries = new ArrayList<>(toolTypes.size());
            for (ToolOverlayType toolType : toolTypes) {
                entries.add(new DefenseOverlayEntry(toolType.createRenderStack(), null, 1, toolType.sortName));
            }
            entries.sort((left, right) -> left.sortName.compareToIgnoreCase(right.sortName));
        } else {
            entries = new ArrayList<>();
            for (Map.Entry<DefenseBlockKey, Integer> countedBlock : finalCounts.entrySet()) {
                entries.add(new DefenseOverlayEntry(
                        countedBlock.getKey().createRenderStack(),
                        countedBlock.getKey().blockSprite,
                        countedBlock.getValue(),
                        countedBlock.getKey().sortName
                ));
            }
            entries.sort((left, right) -> {
                int countCompare = Integer.compare(right.count, left.count);
                if (countCompare != 0) {
                    return countCompare;
                }
                return left.sortName.compareToIgnoreCase(right.sortName);
            });
        }

        return new DefenseOverlaySnapshot(new BlockPos(head), Collections.unmodifiableList(entries));
    }

    private boolean accumulateDefenseBlock(BlockPos pos, Map<DefenseBlockKey, Integer> layerCounts, Map<Integer, DefenseBlockKey> resolvedBlockKeys) {
        IBlockState state = mc.theWorld.getBlockState(pos);
        if (state == null || state.getBlock() == Blocks.air) {
            return true;
        }

        IBlockState normalizedState = normalizeDefenseState(state);
        int stateId = Block.getStateId(normalizedState);
        DefenseBlockKey key = resolvedBlockKeys.get(stateId);
        if (key == null) {
            key = DefenseBlockKey.from(normalizedState, pos, mc.theWorld);
            resolvedBlockKeys.put(stateId, key);
        }
        layerCounts.put(key, layerCounts.getOrDefault(key, 0) + 1);
        return false;
    }

    private LayerOffsets[] getLayerOffsets(BlockPos foot, BlockPos head) {
        EnumFacing facing = getBedFacing(foot, head);
        return facing == null ? null : DEFENSE_OFFSETS.get(facing);
    }

    private static EnumMap<EnumFacing, LayerOffsets[]> buildLayerOffsetsByFacing() {
        EnumMap<EnumFacing, LayerOffsets[]> offsets = new EnumMap<>(EnumFacing.class);
        offsets.put(EnumFacing.EAST, buildLayerOffsets(EnumFacing.EAST));
        offsets.put(EnumFacing.WEST, buildLayerOffsets(EnumFacing.WEST));
        offsets.put(EnumFacing.SOUTH, buildLayerOffsets(EnumFacing.SOUTH));
        offsets.put(EnumFacing.NORTH, buildLayerOffsets(EnumFacing.NORTH));
        return offsets;
    }

    private static LayerOffsets[] buildLayerOffsets(EnumFacing canonicalFacing) {
        BlockPos foot = BlockPos.ORIGIN;
        BlockPos head = foot.offset(canonicalFacing);
        boolean facingZ = canonicalFacing.getAxis() == EnumFacing.Axis.Z;
        BlockPos firstBedPart = facingZ
                ? (head.getZ() > foot.getZ() ? head : foot)
                : (head.getX() > foot.getX() ? head : foot);
        BlockPos secondBedPart = firstBedPart.equals(foot) ? head : foot;
        BlockPos[] bedParts = {firstBedPart, secondBedPart};
        LayerOffsets[] layers = new LayerOffsets[DEFENSE_MAX_LAYERS];
        Set<Long> seenAcrossLayers = new HashSet<>();

        for (int layer = 1; layer <= DEFENSE_MAX_LAYERS; layer++) {
            List<RelativeOffset> offsets = new ArrayList<>();

            for (int bedIndex = 0; bedIndex < bedParts.length; bedIndex++) {
                BlockPos bed = bedParts[bedIndex];
                int outwardOffset = bedIndex == 0 ? layer : -layer;
                int startX = facingZ ? bed.getX() : bed.getX() + outwardOffset;
                int startZ = facingZ ? bed.getZ() + outwardOffset : bed.getZ();

                for (int advance = 0; advance <= layer; advance++) {
                    int yOffset = 0;
                    for (int breadth = advance; breadth >= 0; breadth--) {
                        int firstX;
                        int firstY = bed.getY() + yOffset;
                        int firstZ;
                        int secondX;
                        int secondY = firstY;
                        int secondZ;

                        if (facingZ) {
                            int z = startZ - (bedIndex == 0 ? advance : -advance);
                            firstX = startX - breadth;
                            firstZ = z;
                            secondX = startX + breadth;
                            secondZ = z;
                        } else {
                            int x = startX - (bedIndex == 0 ? advance : -advance);
                            firstX = x;
                            firstZ = startZ - breadth;
                            secondX = x;
                            secondZ = startZ + breadth;
                        }

                        // Treat each physical block position as belonging to the first shell that reaches it.
                        addOffset(offsets, seenAcrossLayers, firstX, firstY, firstZ);
                        addOffset(offsets, seenAcrossLayers, secondX, secondY, secondZ);

                        if (breadth > 0) {
                            yOffset++;
                        }
                    }
                }
            }

            layers[layer - 1] = new LayerOffsets(Collections.unmodifiableList(offsets));
        }

        return layers;
    }

    private static void addOffset(List<RelativeOffset> offsets, Set<Long> seen, int x, int y, int z) {
        long key = new BlockPos(x, y, z).toLong();
        if (seen.add(key)) {
            offsets.add(new RelativeOffset(x, y, z));
        }
    }

    private static EnumFacing getBedFacing(BlockPos foot, BlockPos head) {
        int dx = head.getX() - foot.getX();
        int dz = head.getZ() - foot.getZ();
        for (EnumFacing facing : EnumFacing.HORIZONTALS) {
            if (facing.getFrontOffsetX() == dx && facing.getFrontOffsetZ() == dz) {
                return facing;
            }
        }
        return null;
    }

    private void clearDefenseState() {
        defenseSnapshots.clear();
        defenseWatchRegions.clear();
        watchedBedsByDefensePos.clear();
        watchedBedsByChunk.clear();
        dirtyDefenseBeds.clear();
    }

    private void markBedsDirtyForDefensePos(BlockPos pos) {
        if (pos == null) {
            return;
        }

        Set<Long> feet = watchedBedsByDefensePos.get(pos.toLong());
        if (feet == null) {
            return;
        }

        dirtyDefenseBeds.addAll(feet);
    }

    private void markBedsDirtyForChunk(int chunkX, int chunkZ) {
        Set<Long> feet = watchedBedsByChunk.get(chunkKey(chunkX, chunkZ));
        if (feet == null) {
            return;
        }

        dirtyDefenseBeds.addAll(feet);
    }

    private void registerDefenseWatch(BlockPos foot, BlockPos head) {
        LayerOffsets[] layers = getLayerOffsets(foot, head);
        long footKey = foot.toLong();
        if (layers == null) {
            defenseWatchRegions.put(footKey, new DefenseWatchRegion(head.toLong(), Collections.<Long>emptySet(), Collections.<Long>emptySet()));
            return;
        }

        Set<Long> watchedPositions = new HashSet<>();
        Set<Long> watchedChunks = new HashSet<>();

        for (LayerOffsets layer : layers) {
            for (RelativeOffset offset : layer.positions) {
                BlockPos watchedPos = new BlockPos(foot.getX() + offset.x, foot.getY() + offset.y, foot.getZ() + offset.z);
                long posKey = watchedPos.toLong();
                if (!watchedPositions.add(posKey)) {
                    continue;
                }

                watchedBedsByDefensePos.computeIfAbsent(posKey, ignored -> new HashSet<>()).add(footKey);
                watchedChunks.add(chunkKey(watchedPos.getX() >> 4, watchedPos.getZ() >> 4));
            }
        }

        for (Long chunkKey : watchedChunks) {
            watchedBedsByChunk.computeIfAbsent(chunkKey, ignored -> new HashSet<>()).add(footKey);
        }

        defenseWatchRegions.put(footKey, new DefenseWatchRegion(
                head.toLong(),
                Collections.unmodifiableSet(watchedPositions),
                Collections.unmodifiableSet(watchedChunks)
        ));
    }

    private void unregisterDefenseWatch(long footKey) {
        DefenseWatchRegion region = defenseWatchRegions.remove(footKey);
        defenseSnapshots.remove(footKey);
        dirtyDefenseBeds.remove(footKey);

        if (region == null) {
            return;
        }

        for (Long posKey : region.watchedPositions) {
            Set<Long> feet = watchedBedsByDefensePos.get(posKey);
            if (feet == null) {
                continue;
            }
            feet.remove(footKey);
            if (feet.isEmpty()) {
                watchedBedsByDefensePos.remove(posKey);
            }
        }

        for (Long chunkKey : region.watchedChunks) {
            Set<Long> feet = watchedBedsByChunk.get(chunkKey);
            if (feet == null) {
                continue;
            }
            feet.remove(footKey);
            if (feet.isEmpty()) {
                watchedBedsByChunk.remove(chunkKey);
            }
        }
    }

    private static long chunkKey(int chunkX, int chunkZ) {
        return ((long) chunkX << 32) | (chunkZ & 0xFFFFFFFFL);
    }

    private float getBlockHeight() {
        return renderFullBlock.isToggled() ? 1 : 0.5625F;
    }

    private float computeDefenseBaseScaleValue() {
        return (float) defenseScale.getInput() * 0.02F;
    }

    private float computeDefenseScaleValue(float distance) {
        float baseScale = computeDefenseBaseScaleValue();
        float effectiveDistance = Math.max(1.0F, distance);
        float scaledValue = baseScale * (effectiveDistance / DEFENSE_AUTO_SCALE_THRESHOLD);
        return Math.max(baseScale, scaledValue);
    }

    private static final class BedBreakAnimation {
        private final BlockPos[] pair;
        private final long startedAt;
        private final DefenseOverlaySnapshot defenseSnapshot;

        private BedBreakAnimation(BlockPos[] pair, long startedAt, DefenseOverlaySnapshot defenseSnapshot) {
            this.pair = pair;
            this.startedAt = startedAt;
            this.defenseSnapshot = defenseSnapshot;
        }
    }

    private static final class DefenseOverlaySnapshot {
        private final long headKey;
        private final List<DefenseOverlayEntry> entries;

        private DefenseOverlaySnapshot(BlockPos head, List<DefenseOverlayEntry> entries) {
            this.headKey = head.toLong();
            this.entries = entries;
        }

        private boolean matches(BlockPos otherHead) {
            return otherHead != null && headKey == otherHead.toLong();
        }
    }

    private static final class DefenseOverlayEntry {
        private final ItemStack renderStack;
        private final TextureAtlasSprite blockSprite;
        private final int count;
        private final String sortName;

        private DefenseOverlayEntry(ItemStack renderStack, TextureAtlasSprite blockSprite, int count, String sortName) {
            this.renderStack = renderStack;
            this.blockSprite = blockSprite;
            this.count = count;
            this.sortName = sortName;
        }

        private boolean hasItemStack() {
            return renderStack != null && renderStack.getItem() != null;
        }

        private boolean hasBlockSprite() {
            return blockSprite != null;
        }

        private int getCount() {
            return count;
        }
    }

    private static final class DefenseWatchRegion {
        private final long headKey;
        private final Set<Long> watchedPositions;
        private final Set<Long> watchedChunks;

        private DefenseWatchRegion(long headKey, Set<Long> watchedPositions, Set<Long> watchedChunks) {
            this.headKey = headKey;
            this.watchedPositions = watchedPositions;
            this.watchedChunks = watchedChunks;
        }

        private boolean matches(BlockPos otherHead) {
            return otherHead != null && headKey == otherHead.toLong();
        }
    }

    private static final class DefenseBlockKey {
        private final IBlockState state;
        private final String identityKey;
        private final String sortName;
        private final int hashCode;
        private final ItemStack renderStack;
        private final TextureAtlasSprite blockSprite;

        private DefenseBlockKey(IBlockState state, String identityKey, String sortName, ItemStack renderStack, TextureAtlasSprite blockSprite) {
            this.state = state;
            this.identityKey = identityKey;
            this.sortName = sortName;
            this.renderStack = renderStack;
            this.blockSprite = blockSprite;
            this.hashCode = identityKey.hashCode();
        }

        private static DefenseBlockKey from(IBlockState state, BlockPos pos, World world) {
            String fallbackName = getFallbackStateName(state);
            ItemStack stack = resolveBlockItemStack(state, pos, world);
            String identityKey = resolveIdentityKey(state, stack);
            TextureAtlasSprite sprite = null;

            if (stack == null || stack.getItem() == null) {
                sprite = resolveBlockSprite(state);
                if (sprite == null) {
                    stack = fallbackRenderStack(state.getBlock());
                } else {
                    stack = null;
                }
            }

            String sortName = stack != null && stack.getItem() != null ? getSafeDisplayName(stack, fallbackName) : fallbackName;
            return new DefenseBlockKey(state, identityKey, sortName, stack, sprite);
        }

        private ItemStack createRenderStack() {
            return renderStack == null ? null : renderStack.copy();
        }

        private static String resolveIdentityKey(IBlockState state, ItemStack stack) {
            if (stack != null && stack.getItem() != null) {
                return Item.getIdFromItem(stack.getItem()) + ":" + stack.getMetadata();
            }

            Object registryName = Block.blockRegistry.getNameForObject(state.getBlock());
            return registryName != null ? registryName.toString() : Integer.toString(Block.getIdFromBlock(state.getBlock()));
        }

        private static String getSafeDisplayName(ItemStack stack, String fallback) {
            if (stack == null || stack.getItem() == null) {
                return fallback;
            }

            try {
                String displayName = stack.getDisplayName();
                return displayName != null && !displayName.isEmpty() ? displayName : fallback;
            } catch (Exception ignored) {
                return fallback;
            }
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof DefenseBlockKey)) {
                return false;
            }
            DefenseBlockKey other = (DefenseBlockKey) obj;
            return identityKey.equals(other.identityKey);
        }

        @Override
        public int hashCode() {
            return hashCode;
        }
    }

    private enum ToolOverlayType {
        DIAMOND_PICKAXE(Items.diamond_pickaxe, "Diamond Pickaxe"),
        IRON_AXE(Items.iron_axe, "Iron Axe"),
        IRON_HOE(Items.iron_hoe, "Iron Hoe"),
        IRON_PICKAXE(Items.iron_pickaxe, "Iron Pickaxe"),
        SHEARS(Items.shears, "Shears"),
        IRON_SHOVEL(Items.iron_shovel, "Iron Shovel"),
        IRON_SWORD(Items.iron_sword, "Iron Sword");

        private final Item item;
        private final String sortName;
        private final ItemStack renderStack;

        ToolOverlayType(Item item, String sortName) {
            this.item = item;
            this.sortName = sortName;
            this.renderStack = new ItemStack(item);
        }

        private ItemStack createRenderStack() {
            return renderStack.copy();
        }

        private static ToolOverlayType fromState(IBlockState state) {
            if (state == null) {
                return null;
            }

            Block block = state.getBlock();
            if (block == Blocks.obsidian) {
                return DIAMOND_PICKAXE;
            }

            ToolOverlayType bestTool = IRON_PICKAXE;
            float bestEfficiency = 1.0F;
            for (ToolOverlayType toolType : values()) {
                if (toolType == DIAMOND_PICKAXE) {
                    continue;
                }

                float efficiency = Utils.getEfficiency(toolType.renderStack, block);
                if (efficiency > bestEfficiency) {
                    bestEfficiency = efficiency;
                    bestTool = toolType;
                }
            }

            return bestTool;
        }
    }

    private static ItemStack resolveBlockItemStack(IBlockState state, BlockPos pos, World world) {
        Block block = state.getBlock();
        try {
            Item item = block.getItem(world, pos);
            if (item == null) {
                return null;
            }
            int meta = item.getHasSubtypes() ? block.getDamageValue(world, pos) : 0;
            return new ItemStack(item, 1, meta);
        } catch (Exception ignored) {
            return null;
        }
    }

    private static TextureAtlasSprite resolveBlockSprite(IBlockState state) {
        if (mc == null || mc.getBlockRendererDispatcher() == null || mc.getBlockRendererDispatcher().getBlockModelShapes() == null) {
            return null;
        }

        TextureAtlasSprite sprite = mc.getBlockRendererDispatcher().getBlockModelShapes().getTexture(state);
        if (sprite == null) {
            return null;
        }

        return sprite;
    }

    private static IBlockState normalizeDefenseState(IBlockState state) {
        if (state == null) {
            return null;
        }

        Block block = state.getBlock();
        if (block == Blocks.water || block == Blocks.flowing_water) {
            return Blocks.water.getDefaultState();
        }
        if (block == Blocks.lava || block == Blocks.flowing_lava) {
            return Blocks.lava.getDefaultState();
        }
        if (block == Blocks.fire) {
            return Blocks.fire.getDefaultState();
        }

        return state;
    }

    private static String getFallbackStateName(IBlockState state) {
        String localizedName = state.getBlock().getLocalizedName();
        if (localizedName != null && !localizedName.isEmpty()) {
            return localizedName;
        }

        Object registryName = Block.blockRegistry.getNameForObject(state.getBlock());
        if (registryName != null) {
            int meta = state.getBlock().getMetaFromState(state);
            return meta != 0 ? registryName + ":" + meta : registryName.toString();
        }

        return "unknown";
    }

    private static ItemStack fallbackRenderStack(Block block) {
        if (block == Blocks.bed) {
            return new ItemStack(Items.bed);
        }
        try {
            Item item = Item.getItemFromBlock(block);
            if (item != null) {
                int meta = block.getMetaFromState(block.getDefaultState());
                return new ItemStack(item, 1, meta);
            }
        } catch (Exception ignored) {
        }
        return new ItemStack(Blocks.barrier);
    }

    private static final class LayerOffsets {
        private final List<RelativeOffset> positions;

        private LayerOffsets(List<RelativeOffset> positions) {
            this.positions = positions;
        }
    }

    private static final class RelativeOffset {
        private final int x;
        private final int y;
        private final int z;

        private RelativeOffset(int x, int y, int z) {
            this.x = x;
            this.y = y;
            this.z = z;
        }
    }

    public int getCurrentColor() {
        int mode = colorMode == null ? 0 : (int) colorMode.getInput();

        switch (mode) {
            case 0:
                return color.getColor();

            case 1:
                double pct = Math.sin(
                        System.currentTimeMillis() * gradientSpeed.getInput() / 1000.0
                ) * 0.5 + 0.5;

                Color firstColor = new Color(
                        color.getRed(),
                        color.getGreen(),
                        color.getBlue(),
                        color.getAlpha()
                );

                Color secondColor = new Color(
                        color2.getRed(),
                        color2.getGreen(),
                        color2.getBlue(),
                        color2.getAlpha()
                );

                Color blended = Theme.convert(firstColor, secondColor, pct);
                int alpha = (int) (
                        color.getAlpha() * pct
                                + color2.getAlpha() * (1.0 - pct)
                );

                return Utils.mergeAlpha(blended.getRGB(), alpha);

            case 2:
                return Utils.mergeAlpha(
                        Utils.getChroma(2L, 0L),
                        color.getAlpha()
                );

            case THEME_COLOR_MODE:
                return Utils.mergeAlpha(
                        Theme.getGradient(getSelectedThemeIndex(), 0.0),
                        THEME_ALPHA
                );

            default:
                return color.getColor();
        }
    }

    private int getSelectedThemeIndex() {
        if (theme == null || theme.getOptions().length == 0) {
            return DEFAULT_THEME_INDEX;
        }

        return (int) Math.max(
                0,
                Math.min(theme.getOptions().length - 1, theme.getInput())
        );
    }
}
