package keystrokesmod.module.impl.player;

import keystrokesmod.event.ClientRotationEvent;
import keystrokesmod.event.GameTickEvent;
import keystrokesmod.event.PreInputEvent;
import keystrokesmod.event.PrePlayerInputEvent;
import keystrokesmod.event.PreAttackEvent;
import keystrokesmod.event.RightClickMouseEvent;
import keystrokesmod.helper.AutoLadderHelper;
import keystrokesmod.helper.RotationHelper;
import keystrokesmod.module.Module;
import keystrokesmod.module.ModuleManager;
import keystrokesmod.module.impl.movement.Timer;
import keystrokesmod.module.setting.impl.BlockListSetting;
import keystrokesmod.module.setting.impl.ButtonSetting;
import keystrokesmod.module.setting.impl.SliderSetting;
import keystrokesmod.script.model.Simulation;
import keystrokesmod.utility.BlockUtils;
import keystrokesmod.utility.RenderUtils;
import keystrokesmod.utility.RotationUtils;
import keystrokesmod.utility.Utils;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLadder;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Vec3;
import net.minecraft.util.Vec3i;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AutoLadder extends Module {
   private static final int LOOKAHEAD_TICKS = 20;
   private static final int GROUND_LOOKAHEAD_TICKS = 40;
   private static final int GUIDE_TIMEOUT_TICKS = 26;
   private static final int GUIDE_INVALID_LIMIT = 4;
   private static final int STAGE_INVALID_TICK_LIMIT = 2;
   private final AutoLadderHelper session = new AutoLadderHelper();
   private int retryAfterTick;
   private boolean fallQualified;
   private final java.util.List<Vec3> fallPath = new java.util.ArrayList<>();
   private boolean predictedLanding;
   private net.minecraft.world.World trackedWorld;
   private RotationHit stableHit;
   private ExecutionStage stableStage;
   private static final double MAX_PLACE_BELOW_PLAYER_Y = 3.0;
   private static final double MAX_PLACE_XZ_DELTA = 4.5;
   private static final double ENTRY_TICK_WEIGHT = 120.0;
   private static final double ENTRY_ALIGNMENT_WEIGHT = 90.0;
   private static final double TARGET_DISTANCE_WEIGHT = 10.0;
   private static final double[] HIT_OFFSETS = new double[]{0.5, 0.35, 0.65, 0.2, 0.8, 0.1, 0.9};
   private final SliderSetting minimumDropDistance;
   private final SliderSetting rotationSpeed;
   private final ButtonSetting onlyWhileHoldingLadder;
   private final ButtonSetting renderPlacements;
   private final ButtonSetting blockBlacklistToggle;
   private final BlockListSetting blockBlacklist;
   private AutoLadder.ExecutionStage stage = AutoLadder.ExecutionStage.IDLE;
   private AutoLadder.PlacementPlan activePlan;
   private int currentPlacementTick;
   private boolean placedThisTick;
   private int lastPlacementAttemptTick = Integer.MIN_VALUE;
   private int guideStartTick = Integer.MIN_VALUE;
   private int guideInvalidTicks;
   private int stageInvalidTicks;
   private float stickyYaw;
   private float stickyPitch;
   private boolean hasStickyRotation;
   private int stageStartTick;
   private int rotationTick = Integer.MIN_VALUE;
   private ExecutionStage rotationStage;
   private RotationHit placementHit;
   private EntityPlayerSP trackedPlayer;
   private boolean movementClaimed;

   public AutoLadder() {
      super("AutoLadder", category.player);
      this.registerSetting(minimumDropDistance = new SliderSetting("Minimum height", " blocks", 4.0, 0.0, 20.0, 0.5, "Minimum drop distance"));
      this.registerSetting(rotationSpeed = new SliderSetting("Rotation speed", "\u00B0", 90.0, 10.0, 180.0, 5.0));
      this.registerSetting(onlyWhileHoldingLadder = new ButtonSetting("Only while holding ladder", false));
      this.registerSetting(renderPlacements = new ButtonSetting("Render placements", false));
      this.registerSetting(blockBlacklistToggle = new ButtonSetting("Block blacklist", false));
      this.registerSetting(blockBlacklist = new BlockListSetting("Blacklisted blocks"));
      this.blockBlacklist.visible = false;
      this.closetModule = true;
      this.session.observe();
   }

   @Override
   public void guiUpdate() {
      this.blockBlacklist.setVisible(this.blockBlacklistToggle.isToggled(), this);
   }

   @Override
   public void onEnable() {
      this.fallQualified = false;
      this.session.start();
      this.trackedPlayer = mc.thePlayer;
      this.trackedWorld = mc.theWorld;
      this.retryAfterTick = 0;
      this.placedThisTick = false;
      this.resetExecutionState(true, "enabled");
      this.hasStickyRotation = false;
   }

   @Override
   public void onDisable() {
      this.releaseMovement();
      this.fallQualified = false;
      this.resetExecutionState(true, "disabled");
      this.session.finish();
      this.hasStickyRotation = false;
   }

   @SubscribeEvent(priority = EventPriority.HIGHEST)
   public void onGameTick(GameTickEvent e) {
      this.movementClaimed = false;
      this.placedThisTick = false;
      this.currentPlacementTick++;
      this.rotationTick = Integer.MIN_VALUE;
      this.placementHit = null;
      this.session.updatePlayer();
      if (this.trackedPlayer != mc.thePlayer || this.trackedWorld != mc.theWorld) {
         this.fallQualified = false;
         this.resetExecutionState(false, "player-changed");
         this.trackedWorld = mc.theWorld;
         this.hasStickyRotation = false;
         this.trackedPlayer = mc.thePlayer;
      }
      if (!this.isModuleReady()) {
         this.fallQualified = false;
         this.resetExecutionState(true, "module-not-ready");
         this.hasStickyRotation = false;
         return;
      }
      if (!this.isCurrentlyFalling()) this.fallQualified = false;
      if (this.shouldYieldToClutch()) {
         this.yieldToClutch();
         return;
      }
      if (this.session.changedManually() || this.hasIncompatibleModule()) {
         if (this.session.changedManually()) this.fallQualified = false;
         this.resetExecutionState(true, "control-conflict");
         this.session.clearManualChange();
         return;
      }
      if (!this.isCurrentlyFalling()) {
         this.fallQualified = false;
         this.resetExecutionState(true, "fall-ended");
         return;
      }
      if (!this.fallQualified && (this.minimumDropDistance.getInput() == 0
          || this.heightAboveGround() >= this.minimumDropDistance.getInput())) this.fallQualified = true;
      if (this.activePlan == null) {
         if (this.currentPlacementTick >= this.retryAfterTick && !this.session.restoring()
             && this.session.sent().rotationKnown && this.session.sent().positionKnown && this.shouldStartPlanningNow()) {
            this.startExecutionPlan();
         }
         return;
      }
      if (this.isInsideTargetLadder(this.activePlan.ladderPos)) {
         this.resetExecutionState(true, "ladder-occupied");
         return;
      }
      if (!this.isPlanWithinPlacementBounds(this.activePlan)) {
         this.resetExecutionState(true, "plan-out-of-bounds");
         return;
      }
      if (this.stage == ExecutionStage.PLACE_SUPPORT && this.isSolidLadderSupportBlock(this.activePlan.supportPlacePos)) {
         this.stage = ExecutionStage.PLACE_LADDER;
         this.stageStartTick = this.currentPlacementTick;
      }
      if (this.stage == ExecutionStage.PLACE_LADDER && this.isLadderBlock(this.activePlan.ladderPos)) {
         this.enterGuideState(this.currentPlacementTick);
      }
      if (this.stage == ExecutionStage.GUIDE_ENTRY) {
         this.tickGuideState();
      } else if (this.shouldAbortForMissingItems() || this.currentPlacementTick - this.stageStartTick > (this.activePlan.groundCatch ? GROUND_LOOKAHEAD_TICKS : 10)) {
         this.resetExecutionState(true, "placement-expired");
      } else {
         this.prepareHeldItemForStage();
      }
   }

   @SubscribeEvent(priority = EventPriority.LOWEST)
   public void onClientRotation(ClientRotationEvent e) {
      if (!this.isModuleReady()) {
         this.resetExecutionState(true, "module-not-ready");
         this.hasStickyRotation = false;
         return;
      }
      if (this.shouldYieldToClutch()) {
         this.yieldToClutch();
         return;
      }
      if (e.yaw != null || e.pitch != null || this.hasIncompatibleModule()) {
         this.resetExecutionState(true, "rotation-conflict");
         this.hasStickyRotation = false;
         return;
      }
      if (this.session.holdingAim()) {
         this.claimRotations(e, this.session.heldYaw(), this.session.heldPitch());
         return;
      }
      if (this.activePlan == null || this.stage == ExecutionStage.GUIDE_ENTRY) {
         this.restoreRotations(e);
         if (this.activePlan != null && e.yaw == null)
            this.claimRotations(e, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch);
         return;
      }
      if (!this.isPlanWithinPlacementBounds(this.activePlan)) {
         this.resetExecutionState(true, "plan-out-of-bounds");
         this.restoreRotations(e);
         return;
      }
      RotationHit hit = this.resolveStableHit();
      if (hit == null) {
         if (++this.stageInvalidTicks > STAGE_INVALID_TICK_LIMIT) {
            this.resetExecutionState(true, "no-placement-ray");
         }
         this.restoreRotations(e);
         return;
      }
      this.stageInvalidTicks = 0;
      this.applyRotations(e, hit.yaw, hit.pitch, (float) this.rotationSpeed.getInput());
      this.rotationTick = this.currentPlacementTick;
      this.rotationStage = this.stage;
      this.placementHit = hit;
   }

   private void applyRotations(ClientRotationEvent e, float yaw, float pitch, float limit) {
      float baseYaw = this.session.sent().yaw;
      float basePitch = this.session.sent().pitch;
      float yawStep = MathHelper.clamp_float(MathHelper.wrapAngleTo180_float(yaw - baseYaw), -limit, limit);
      float pitchStep = MathHelper.clamp_float(pitch - basePitch, -limit, limit);
      float[] fixed = RotationUtils.fixRotation(baseYaw + yawStep, basePitch + pitchStep, baseYaw, basePitch);
      this.stickyYaw = fixed[0];
      this.stickyPitch = fixed[1];
      this.hasStickyRotation = true;
      this.session.rememberAim();
      this.claimRotations(e, this.stickyYaw, this.stickyPitch);
   }

   private void claimRotations(ClientRotationEvent event, float yaw, float pitch) {
      this.movementClaimed = this.activePlan != null;
      event.claimExactRotations(yaw, pitch, this.movementClaimed);
   }

   private void releaseMovement() {
      if (this.movementClaimed) {
         RotationHelper.get().releaseServerRelativeMovement();
         this.movementClaimed = false;
      }
   }

   private void restoreRotations(ClientRotationEvent e) {
      if (!this.hasStickyRotation) {
         return;
      }
      if (e.yaw != null || e.pitch != null) {
         this.hasStickyRotation = false;
         return;
      }
      float yaw = mc.thePlayer.rotationYaw;
      float pitch = mc.thePlayer.rotationPitch;
      if (Math.abs(MathHelper.wrapAngleTo180_float(yaw - this.session.sent().yaw)) < 1.0F
         && Math.abs(pitch - this.session.sent().pitch) < 1.0F) {
         this.hasStickyRotation = false;
         return;
      }
      this.applyRotations(e, yaw, pitch, Math.min(45.0F, (float) this.rotationSpeed.getInput()));
   }

   @SubscribeEvent(priority = EventPriority.HIGHEST)
   public void onPreInput(PreInputEvent e) {
      if (this.shouldYieldToClutch()) { this.yieldToClutch(); return; }
      if (!this.isModuleReady() || !this.isCurrentlyFalling()) {
         this.resetExecutionState(true, "placement-interrupted");
         return;
      }
      if (!Timer.shouldProcessPlayerActions() || this.placedThisTick || this.activePlan == null
         || this.session.holdingAim() || this.session.changedManually() || !this.session.canSwitch()
         || this.lastPlacementAttemptTick == this.currentPlacementTick
         || this.rotationTick != this.currentPlacementTick || this.rotationStage != this.stage || this.placementHit == null
         || (this.stage != ExecutionStage.PLACE_SUPPORT && this.stage != ExecutionStage.PLACE_LADDER)) {
         return;
      }
      Float yaw = RotationHelper.get().getServerYaw();
      Float pitch = RotationHelper.get().getServerPitch();
      if (yaw == null || pitch == null || !RotationHelper.get().ownsServerRelativeMovement()) {
         return;
      }
      MovingObjectPosition hit = RotationUtils.rayCastBlock(this.getPlacementReach(), yaw, pitch);
      BlockPos placePos = this.stage == ExecutionStage.PLACE_SUPPORT ? this.activePlan.supportPlacePos : this.activePlan.ladderPos;
      BlockPos anchor = this.placementHit.mop.getBlockPos();
      EnumFacing face = this.placementHit.mop.sideHit;
      AutoLadderHelper.SentState sent = this.session.sent();
      Vec3 eye = new Vec3(sent.x, sent.y + mc.thePlayer.getEyeHeight(), sent.z);
      Vec3 look = RotationUtils.getVectorForRotation(sent.pitch, sent.yaw);
      MovingObjectPosition publishedHit = mc.theWorld.rayTraceBlocks(eye, eye.addVector(look.xCoord * this.getPlacementReach(),
          look.yCoord * this.getPlacementReach(), look.zCoord * this.getPlacementReach()), false, false, true);
      if (!sent.rotationKnown || !sent.positionKnown || !this.isValidPlacementRay(publishedHit, placePos, anchor, face)
          || !this.isValidPlacementRay(hit, placePos, anchor, face)) {
         return;
      }
      if (!this.isPlanStillValidForCurrentStage()) {
         this.resetExecutionState(true, "stage-invalid");
         return;
      }
      ItemStack heldStack = this.resolveHeldStackForCurrentStage();
      if (heldStack == null || this.session.sent().slot != mc.thePlayer.inventory.currentItem) return;
      this.lastPlacementAttemptTick = this.currentPlacementTick;
      net.minecraft.block.state.IBlockState previousState = mc.theWorld.getBlockState(placePos);
      int previousCount = heldStack.stackSize;
      net.minecraft.network.play.client.C08PacketPlayerBlockPlacement previousPlacement = this.session.lastPlacement();
      boolean accepted = mc.playerController.onPlayerRightClick(mc.thePlayer, mc.theWorld, heldStack, hit.getBlockPos(), hit.sideHit, hit.hitVec);
      net.minecraft.network.play.client.C08PacketPlayerBlockPlacement dispatched = this.session.lastPlacement();
      if (dispatched == previousPlacement || dispatched == null || !anchor.equals(dispatched.getPosition())
          || dispatched.getPlacedBlockDirection() != face.getIndex()) {
         mc.theWorld.setBlockState(placePos, previousState, 3);
         heldStack.stackSize = previousCount;
         this.resetExecutionState(true, "placement-not-dispatched");
         return;
      }
      this.session.pinAim(yaw, pitch);
      if (accepted) {
         this.placedThisTick = true;
         mc.thePlayer.swingItem();
         mc.getItemRenderer().resetEquippedProgress();
         if (this.stage == ExecutionStage.PLACE_SUPPORT && this.isSolidLadderSupportBlock(this.activePlan.supportPlacePos)) {
            this.stage = ExecutionStage.PLACE_LADDER;
            this.stageStartTick = this.currentPlacementTick;
         } else if (this.stage == ExecutionStage.PLACE_LADDER && this.isLadderBlock(this.activePlan.ladderPos)) {
            this.enterGuideState(this.currentPlacementTick);
         }
      }
   }

   @SubscribeEvent(priority = EventPriority.HIGH)
   public void onPrePlayerInput(PrePlayerInputEvent e) {
      if (this.isModuleReady() && this.isCurrentlyFalling() && this.activePlan != null && this.stage != AutoLadder.ExecutionStage.IDLE
          && RotationHelper.get().ownsServerRelativeMovement() && !this.session.changedManually() && !this.hasIncompatibleModule()) {
         if (this.shouldYieldToClutch()) {
            this.yieldToClutch();
         } else {
            this.prepareHeldItemForStage();
            Vec3 movementTarget = this.getLadderSteerTarget(this.activePlan.ladderPos);
            this.applyMovementOverride(e, movementTarget);
         }
      } else {
         this.releaseMovement();
      }
   }

   @SubscribeEvent(priority = EventPriority.HIGHEST)
   public void onRightClick(RightClickMouseEvent e) {
      if (this.placedThisTick) {
         e.setCanceled(true);
      }
   }

   @SubscribeEvent(priority = EventPriority.HIGHEST)
   public void onAttack(PreAttackEvent e) {
      if (this.placedThisTick) {
         e.setCanceled(true);
      }
   }

   @SubscribeEvent
   public void onRenderWorld(RenderWorldLastEvent e) {
      if (!this.renderPlacements.isToggled() || !this.isModuleReady() || this.activePlan == null
          || this.trackedWorld != mc.theWorld || this.trackedPlayer != mc.thePlayer
          || (this.stage != ExecutionStage.PLACE_SUPPORT && this.stage != ExecutionStage.PLACE_LADDER)) {
         return;
      }
      PlacementPlan plan = this.activePlan;
      if (this.stage == ExecutionStage.PLACE_SUPPORT && plan.supportPlacePos != null
          && !this.isSolidLadderSupportBlock(plan.supportPlacePos)) {
         RenderUtils.renderBlock(plan.supportPlacePos, 0xFFFF5555, false, true);
      }
      if (!this.isLadderBlock(plan.ladderPos)) {
         double x = plan.ladderPos.getX();
         double z = plan.ladderPos.getZ();
         double width = 1.0;
         double depth = 1.0;
         switch (plan.ladderFace) {
            case NORTH:
               z += 0.875;
               depth = 0.125;
               break;
            case SOUTH:
               depth = 0.125;
               break;
            case WEST:
               x += 0.875;
               width = 0.125;
               break;
            case EAST:
               width = 0.125;
               break;
            default:
               return;
         }
         RenderUtils.renderBox(x, plan.ladderPos.getY(), z, width, 1.0, depth, 0xFFFFAA55, false, true);
      }
   }

   private void startExecutionPlan() {
      AutoLadder.PlacementPlan plan = this.buildDeterministicPlan();
      if (plan == null) {
         this.resetExecutionState(true, "no-valid-plan");
      } else {
         this.activatePlan(plan);
      }
   }

   private void activatePlan(PlacementPlan plan) {
      this.activePlan = plan;
      this.stableHit = null;
      this.stage = plan.requiresSupportPlacement ? ExecutionStage.PLACE_SUPPORT : ExecutionStage.PLACE_LADDER;
      this.stageStartTick = this.currentPlacementTick;
      this.guideStartTick = this.currentPlacementTick;
      this.guideInvalidTicks = 0;
      this.stageInvalidTicks = 0;
      if (this.isLadderBlock(plan.ladderPos)) {
         this.enterGuideState(this.currentPlacementTick);
      } else {
         this.prepareHeldItemForStage();
      }
   }

   private void tickGuideState() {
      if (this.activePlan != null && this.stage == AutoLadder.ExecutionStage.GUIDE_ENTRY) {
         if (mc.thePlayer.isOnLadder() || this.isInsideTargetLadder(this.activePlan.ladderPos)) {
            this.resetExecutionState(true, "guide-success");
         } else if (mc.thePlayer.onGround) {
            this.resetExecutionState(true, "guide-grounded");
         } else if (!this.isPlanWithinPlacementBounds(this.activePlan)) {
            this.resetExecutionState(true, "guide-plan-out-of-bounds");
         } else if (!this.isLadderBlock(this.activePlan.ladderPos)) {
            this.resetExecutionState(true, "ladder-missing");
         } else {
            AutoLadder.EntryEstimate estimate = this.estimateLadderEntry(this.activePlan.ladderPos, this.activePlan.ladderFace, null, 0, 0);
            if (!estimate.valid()) {
               this.guideInvalidTicks++;
               if (this.guideInvalidTicks > GUIDE_INVALID_LIMIT) {
                  this.resetExecutionState(true, "guide-unreachable");
                  return;
               }
            } else {
               this.guideInvalidTicks = 0;
            }

            int playerTick = this.getPlacementPlayerTick();
            if (playerTick != Integer.MIN_VALUE && this.guideStartTick != Integer.MIN_VALUE && playerTick - this.guideStartTick > GUIDE_TIMEOUT_TICKS) {
               this.resetExecutionState(true, "guide-timeout");
            }
         }
      }
   }

   private void enterGuideState(int playerTick) {
      this.stage = AutoLadder.ExecutionStage.GUIDE_ENTRY;
      this.guideStartTick = playerTick;
      this.guideInvalidTicks = 0;
      this.stageInvalidTicks = 0;
      this.restoreOriginalSlotIfNeeded();
   }

   private RotationHit resolveStableHit() {
      float yaw = this.session.sent().yaw, pitch = this.session.sent().pitch;
      if (this.activePlan.groundCatch) {
         BlockPos anchor = this.stage == ExecutionStage.PLACE_SUPPORT ? this.activePlan.supportPlacePos.down() : this.activePlan.ladderSupportPos;
         EnumFacing face = this.stage == ExecutionStage.PLACE_SUPPORT ? EnumFacing.UP : this.activePlan.ladderFace;
         Vec3 point = this.buildFaceHitVec(anchor, face, 0.5, 0.5);
         float[] aim = this.getFixedRotationsForVec(point, yaw, pitch);
         return new RotationHit(aim[0], aim[1], new MovingObjectPosition(point, face, anchor), 0);
      }
      if (this.stableHit != null && this.stableStage == this.stage) {
         BlockPos anchor = this.stableHit.mop.getBlockPos();
         EnumFacing face = this.stableHit.mop.sideHit;
         BlockPos destination = this.stage == ExecutionStage.PLACE_SUPPORT ? this.activePlan.supportPlacePos : this.activePlan.ladderPos;
         float[] aim = this.getFixedRotationsForVec(this.stableHit.mop.hitVec, yaw, pitch);
         MovingObjectPosition hit = RotationUtils.rayCastBlock(this.getPlacementReach(), aim[0], aim[1]);
         if (this.isValidPlacementRay(hit, destination, anchor, face))
            return new RotationHit(aim[0], aim[1], this.stableHit.mop, 0);
      }
      this.stableStage = this.stage;
      return this.stableHit = this.resolveRotationForCurrentStage(yaw, pitch);
   }

   private AutoLadder.RotationHit resolveRotationForCurrentStage(float baseYaw, float basePitch) {
      return this.stage == ExecutionStage.PLACE_SUPPORT
         ? this.resolveSupportPlacementHit(this.activePlan, baseYaw, basePitch)
         : this.resolveLadderPlacementHit(this.activePlan, baseYaw, basePitch);
   }

   private AutoLadder.RotationHit resolveSupportPlacementHit(AutoLadder.PlacementPlan plan, float baseYaw, float basePitch) {
      return plan != null && plan.requiresSupportPlacement && plan.supportPlacePos != null && BlockUtils.replaceable(plan.supportPlacePos)
         ? this.findSupportBlockPlacementHit(plan.supportPlacePos, baseYaw, basePitch)
         : null;
   }

   private AutoLadder.RotationHit resolveLadderPlacementHit(AutoLadder.PlacementPlan plan, float baseYaw, float basePitch) {
      if (plan == null || plan.ladderPos == null || plan.ladderSupportPos == null || plan.ladderFace == null) {
         return null;
      } else if (!this.isReplaceableOrLadder(plan.ladderPos)) {
         return null;
      } else {
         return !this.canUseAsLadderSupport(plan.ladderPos, plan.ladderFace, plan.ladderSupportPos)
            ? null
            : this.findRotationHitForPlacement(plan.ladderPos, plan.ladderSupportPos, plan.ladderFace, baseYaw, basePitch);
      }
   }

   private AutoLadder.PlacementPlan buildDeterministicPlan() {
      if (this.findLadderSlot() == -1) {
         return null;
      }

      this.predictFallPath();

      PlacementPlan direct = this.findPlacementPlan(false);
      return direct != null ? direct : this.findSupportSlot() == -1 ? null : this.findGroundPlan();
   }

   private void predictFallPath() {
      this.fallPath.clear();
      this.predictedLanding = false;
      Simulation simulation = Simulation.create();
      simulation.setJump(false);
      for (int tick = 0; tick <= GROUND_LOOKAHEAD_TICKS; tick++) {
         keystrokesmod.script.model.Vec3 pos = simulation.getPosition();
         this.fallPath.add(new Vec3(pos.x, pos.y, pos.z));
         if (simulation.isInLiquid()) return;
         if (simulation.onGround()) { this.predictedLanding = true; return; }
         simulation.tick();
      }
   }

   private boolean fallPassesCell(BlockPos cell) {
      for (Vec3 pos : this.fallPath) {
         if (pos.yCoord < cell.getY()) break;
         if (pos.yCoord < cell.getY() + 1 && pos.xCoord >= cell.getX() && pos.xCoord < cell.getX() + 1
             && pos.zCoord >= cell.getZ() && pos.zCoord < cell.getZ() + 1) return true;
      }
      return false;
   }

   private PlacementPlan findGroundPlan() {
      if (!this.predictedLanding || this.fallPath.isEmpty()) return null;
      Vec3 landing = this.fallPath.get(this.fallPath.size() - 1);
      BlockPos center = new BlockPos(landing.xCoord, Math.ceil(landing.yCoord - 1.0E-7), landing.zCoord);
      PlacementPlan best = null;
      for (int x = -1; x <= 1; x++) for (int z = -1; z <= 1; z++) {
         BlockPos ladder = center.add(x, 0, z);
         if (!BlockUtils.replaceable(ladder)) continue;
         for (EnumFacing face : EnumFacing.Plane.HORIZONTAL) {
            BlockPos support = ladder.offset(face.getOpposite());
            if (!BlockUtils.replaceable(support) || !this.isSolidLadderSupportBlock(support.down())) continue;
            PlacementPlan candidate = new PlacementPlan(ladder, support, face, true, 0, true);
            EntryEstimate estimate = this.estimateGroundEntry(candidate);
            if (!estimate.valid()) continue;
            double dx = ladder.getX() + 0.5 - landing.xCoord, dz = ladder.getZ() + 0.5 - landing.zCoord;
            candidate = new PlacementPlan(ladder, support, face, true,
                this.computePlanCost(estimate.tickAhead, estimate.entryAlignmentErrorSq, dx * dx + dz * dz), true);
            best = this.pickBetterPlan(best, candidate);
         }
      }
      return best;
   }

   private EntryEstimate estimateGroundEntry(PlacementPlan plan) {
      Simulation simulation = Simulation.create();
      boolean supportPlaced = this.isSolidLadderSupportBlock(plan.supportPlacePos);
      boolean ladderPlaced = this.isLadderBlock(plan.ladderPos);
      if (!supportPlaced && (!BlockUtils.replaceable(plan.supportPlacePos) || !this.isSolidLadderSupportBlock(plan.supportPlacePos.down())))
         return EntryEstimate.invalid();
      if (!this.isReplaceableOrLadder(plan.ladderPos)) return EntryEstimate.invalid();
      AutoLadderHelper.SentState sent = this.session.sent();
      float yaw = sent.yaw, pitch = sent.pitch;
      Vec3 publishedEye = new Vec3(sent.x, sent.y + mc.thePlayer.getEyeHeight(), sent.z);
      Vec3 target = this.getLadderSteerTarget(plan.ladderPos);
      for (int tick = 0; tick <= GROUND_LOOKAHEAD_TICKS; tick++) {
         keystrokesmod.script.model.Vec3 pos = simulation.getPosition();
         if (simulation.onGround() || simulation.isInLiquid() || pos.y < plan.ladderPos.getY()) return EntryEstimate.invalid();
         if (ladderPlaced && simulation.isOnLadder() && this.feetOccupyLadderCell(pos.x, pos.y, pos.z, plan.ladderPos)) {
            double dx = pos.x - target.xCoord, dz = pos.z - target.zCoord;
            return new EntryEstimate(tick, dx * dx + dz * dz);
         }
         Vec3 eye = new Vec3(pos.x, pos.y + mc.thePlayer.getEyeHeight(), pos.z);
         float nextYaw, nextPitch;
         if (!ladderPlaced) {
            BlockPos anchor = supportPlaced ? plan.supportPlacePos : plan.supportPlacePos.down();
            EnumFacing face = supportPlaced ? plan.ladderFace : EnumFacing.UP;
            Vec3 point = this.buildFaceHitVec(anchor, face, 0.5, 0.5);
            double dx = point.xCoord - eye.xCoord, dy = point.yCoord - eye.yCoord, dz = point.zCoord - eye.zCoord;
            float[] aim = RotationUtils.fixRotation(yaw + MathHelper.wrapAngleTo180_float((float)Math.toDegrees(Math.atan2(dz, dx)) - 90 - yaw),
                (float)-Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz))), yaw, pitch);
            float speed = (float)this.rotationSpeed.getInput();
            float[] step = RotationUtils.fixRotation(yaw + MathHelper.clamp_float(MathHelper.wrapAngleTo180_float(aim[0] - yaw), -speed, speed),
                pitch + MathHelper.clamp_float(aim[1] - pitch, -speed, speed), yaw, pitch);
            nextYaw = step[0]; nextPitch = step[1];
            BlockPos hypothetical = supportPlaced ? plan.supportPlacePos : null;
            if ((tick > 0 || this.session.canSwitch())
                && this.groundRayReaches(publishedEye, yaw, pitch, anchor, face, hypothetical)
                && this.groundRayReaches(eye, nextYaw, nextPitch, anchor, face, hypothetical)) {
               if (!supportPlaced) {
                  double half = mc.thePlayer.width * 0.5;
                  AxisAlignedBB box = new AxisAlignedBB(pos.x - half, pos.y, pos.z - half, pos.x + half, pos.y + mc.thePlayer.height, pos.z + half);
                  if (box.intersectsWith(new AxisAlignedBB(plan.supportPlacePos, plan.supportPlacePos.add(1, 1, 1)))) return EntryEstimate.invalid();
                  simulation.setBlockState(plan.supportPlacePos, Blocks.stone.getDefaultState());
                  supportPlaced = true;
               } else {
                  simulation.setBlockState(plan.ladderPos, Blocks.ladder.getDefaultState().withProperty(BlockLadder.FACING, plan.ladderFace));
                  ladderPlaced = true;
               }
            }
         } else {
            float speed = Math.min(45, (float)this.rotationSpeed.getInput());
            float[] step = RotationUtils.fixRotation(yaw + MathHelper.clamp_float(MathHelper.wrapAngleTo180_float(mc.thePlayer.rotationYaw - yaw), -speed, speed),
                pitch + MathHelper.clamp_float(mc.thePlayer.rotationPitch - pitch, -speed, speed), yaw, pitch);
            nextYaw = step[0]; nextPitch = step[1];
         }
         if (ladderPlaced && simulation.isOnLadder() && this.feetOccupyLadderCell(pos.x, pos.y, pos.z, plan.ladderPos)) {
            double entryX = pos.x - target.xCoord;
            double entryZ = pos.z - target.zCoord;
            return new EntryEstimate(tick, entryX * entryX + entryZ * entryZ);
         }
         float[] input = chooseSteering(target, pos.x, pos.z, simulation.getMotion().x, simulation.getMotion().z, nextYaw, simulation.getAirAcceleration());
         simulation.setForward(input[0]); simulation.setStrafe(input[1]); simulation.setYaw(nextYaw);
         simulation.setJump(false); simulation.setSneak(false); simulation.setSprinting(mc.gameSettings.keyBindSprint.isKeyDown());
         simulation.tick();
         pos = simulation.getPosition();
         publishedEye = new Vec3(pos.x, pos.y + mc.thePlayer.getEyeHeight(), pos.z);
         yaw = nextYaw; pitch = nextPitch;
      }
      return EntryEstimate.invalid();
   }

   private boolean groundRayReaches(Vec3 eye, float yaw, float pitch, BlockPos anchor, EnumFacing face, BlockPos hypotheticalSupport) {
      Vec3 look = RotationUtils.getVectorForRotation(pitch, yaw);
      double reach = this.getPlacementReach();
      Vec3 end = eye.addVector(look.xCoord * reach, look.yCoord * reach, look.zCoord * reach);
      MovingObjectPosition hit = mc.theWorld.rayTraceBlocks(eye, end, false, false, true);
      if (hypotheticalSupport != null) {
         MovingObjectPosition supportHit = new AxisAlignedBB(hypotheticalSupport, hypotheticalSupport.add(1, 1, 1)).calculateIntercept(eye, end);
         if (supportHit != null && (hit == null || hit.typeOfHit != MovingObjectType.BLOCK
             || eye.squareDistanceTo(supportHit.hitVec) < eye.squareDistanceTo(hit.hitVec)))
            hit = new MovingObjectPosition(supportHit.hitVec, supportHit.sideHit, hypotheticalSupport);
      }
      return hit != null && hit.typeOfHit == MovingObjectType.BLOCK && anchor.equals(hit.getBlockPos()) && face == hit.sideHit;
   }

   private PlacementPlan findPlacementPlan(boolean requiresSupportPlacement) {
      int feetY = MathHelper.floor_double(this.getPlayerFeetY());
      int minX = MathHelper.floor_double(mc.thePlayer.posX - 4.5);
      int maxX = MathHelper.floor_double(mc.thePlayer.posX + 4.5);
      int minZ = MathHelper.floor_double(mc.thePlayer.posZ - 4.5);
      int maxZ = MathHelper.floor_double(mc.thePlayer.posZ + 4.5);
      AutoLadder.PlacementPlan best = null;

      for (int y = feetY; y >= feetY - (int) MAX_PLACE_BELOW_PLAYER_Y; y--) {
         for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
               BlockPos ladderPos = new BlockPos(x, y, z);
               if (this.isWithinPlacementBounds(ladderPos) && this.canReachCellBeforePassing(ladderPos) && this.isReplaceableOrLadder(ladderPos)
                   && this.fallPassesCell(ladderPos)) {
                  PlacementPlan plan = requiresSupportPlacement
                     ? this.buildSupportThenLadderPlanForCell(ladderPos) : this.buildDirectLadderPlanForCell(ladderPos);
                  best = this.pickBetterPlan(best, plan);
               }
            }
         }
      }

      return best;
   }

   private boolean canReachCellBeforePassing(BlockPos pos) {
      double y = this.getPlayerFeetY();
      double motionY = mc.thePlayer.motionY;
      double speed = Math.sqrt(mc.thePlayer.motionX * mc.thePlayer.motionX + mc.thePlayer.motionZ * mc.thePlayer.motionZ);
      double distance = mc.thePlayer.width;
      for (int tick = 0; tick < LOOKAHEAD_TICKS && y >= pos.getY(); tick++) {
         distance += speed + 0.026;
         speed = (speed + 0.026) * 0.91;
         y += motionY;
         motionY = (motionY - 0.08) * 0.98;
      }
      double dx = Math.max(0.0, Math.abs(pos.getX() + 0.5 - mc.thePlayer.posX) - 0.5);
      double dz = Math.max(0.0, Math.abs(pos.getZ() + 0.5 - mc.thePlayer.posZ) - 0.5);
      return dx * dx + dz * dz <= distance * distance;
   }

   private AutoLadder.PlacementPlan buildDirectLadderPlanForCell(BlockPos ladderPos) {
      AutoLadder.PlacementPlan best = null;

      for (EnumFacing ladderFace : EnumFacing.Plane.HORIZONTAL) {
         BlockPos ladderSupportPos = ladderPos.offset(ladderFace.getOpposite());
         if (this.isWithinPlacementBounds(ladderSupportPos) && this.canUseAsLadderSupport(ladderPos, ladderFace, ladderSupportPos)) {
            RotationHit hit = this.isLadderBlock(ladderPos) ? null
               : this.findRotationHitForPlacement(ladderPos, ladderSupportPos, ladderFace, this.getPlacementBaseYaw(), this.getPlacementBasePitch());
            if (hit == null && !this.isLadderBlock(ladderPos)) {
               continue;
            }
            int readyTick = hit == null ? 0 : this.rotationTicks(hit.yaw, hit.pitch, this.getPlacementBaseYaw(), this.getPlacementBasePitch());
            AutoLadder.EntryEstimate estimate = this.estimateLadderEntry(ladderPos, ladderFace, null, readyTick, 0);
            if (estimate.valid()) {
               double planCost = this.computePlanCost(estimate.tickAhead, estimate.entryAlignmentErrorSq, this.getHorizontalDistanceSq(ladderPos));
               AutoLadder.PlacementPlan candidate = new PlacementPlan(ladderPos, ladderSupportPos, ladderFace, false, planCost);
               best = this.pickBetterPlan(best, candidate);
            }
         }
      }

      return best;
   }

   private AutoLadder.PlacementPlan buildSupportThenLadderPlanForCell(BlockPos ladderPos) {
      AutoLadder.PlacementPlan best = null;

      for (EnumFacing ladderFace : EnumFacing.Plane.HORIZONTAL) {
         BlockPos supportPlacePos = ladderPos.offset(ladderFace.getOpposite());
         if (this.isWithinPlacementBounds(supportPlacePos)
            && BlockUtils.replaceable(supportPlacePos)
            && !this.doesPlayerIntersectPlacementNowOrNextTick(supportPlacePos)
            && this.hasSupportPlacementAnchor(supportPlacePos)) {
            RotationHit supportHit = this.findSupportBlockPlacementHit(supportPlacePos, this.getPlacementBaseYaw(), this.getPlacementBasePitch());
            if (supportHit == null) {
               continue;
            }
            float[] ladderAim = this.getFixedRotationsForVec(this.buildFaceHitVec(supportPlacePos, ladderFace, 0.5, 0.5), supportHit.yaw, supportHit.pitch);
            int supportReadyTick = this.rotationTicks(supportHit.yaw, supportHit.pitch, this.getPlacementBaseYaw(), this.getPlacementBasePitch());
            int readyTick = supportReadyTick + 1 + this.rotationTicks(ladderAim[0], ladderAim[1], supportHit.yaw, supportHit.pitch);
            AutoLadder.EntryEstimate estimate = this.estimateLadderEntry(ladderPos, ladderFace, supportPlacePos, readyTick, supportReadyTick);
            if (estimate.valid()) {
               double planCost = this.computePlanCost(estimate.tickAhead, estimate.entryAlignmentErrorSq, this.getHorizontalDistanceSq(ladderPos));
               AutoLadder.PlacementPlan candidate = new PlacementPlan(ladderPos, supportPlacePos, ladderFace, true, planCost);
               best = this.pickBetterPlan(best, candidate);
            }
         }
      }

      return best;
   }

   private AutoLadder.PlacementPlan pickBetterPlan(AutoLadder.PlacementPlan currentBest, AutoLadder.PlacementPlan candidate) {
      if (candidate == null) {
         return currentBest;
      } else if (currentBest == null) {
         return candidate;
      } else if (Math.abs(candidate.planCost - currentBest.planCost) > 1.0E-6) {
         return candidate.planCost < currentBest.planCost ? candidate : currentBest;
      } else {
         return candidate.ladderPos.toLong() < currentBest.ladderPos.toLong() ? candidate : currentBest;
      }
   }

   private double computePlanCost(int entryTick, double entryAlignmentErrorSq, double horizontalDistanceSq) {
      return entryTick * ENTRY_TICK_WEIGHT + entryAlignmentErrorSq * ENTRY_ALIGNMENT_WEIGHT + horizontalDistanceSq * TARGET_DISTANCE_WEIGHT;
   }

   private AutoLadder.RotationHit findSupportBlockPlacementHit(BlockPos placePos, float baseYaw, float basePitch) {
      AutoLadder.RotationHit best = null;

      for (EnumFacing placeFace : EnumFacing.values()) {
         if (placeFace != EnumFacing.DOWN) {
            BlockPos anchorPos = placePos.offset(placeFace.getOpposite());
            if (this.isAnchorBlockValid(anchorPos)) {
               AutoLadder.RotationHit hit = this.findRotationHitForPlacement(placePos, anchorPos, placeFace, baseYaw, basePitch);
               if (hit != null && (best == null || hit.score < best.score)) {
                  best = hit;
               }
            }
         }
      }

      return best;
   }

   private AutoLadder.RotationHit findRotationHitForPlacement(BlockPos placePos, BlockPos supportPos, EnumFacing supportFace, float baseYaw, float basePitch) {
      if (placePos != null && supportPos != null && supportFace != null && mc.thePlayer != null) {
         if (!this.isWithinReachBounds(placePos, supportPos)) {
            return null;
         }

         Vec3i faceDirection = supportFace.getDirectionVec();
         Vec3 supportFaceCenter = new Vec3(
            supportPos.getX() + 0.5 + faceDirection.getX() * 0.5,
            supportPos.getY() + 0.5 + faceDirection.getY() * 0.5,
            supportPos.getZ() + 0.5 + faceDirection.getZ() * 0.5
         );
         AutoLadder.RotationHit best = null;
         double reach = this.getPlacementReach();
         Vec3 eye = mc.thePlayer.getPositionEyes(1.0F);

         for (double u : HIT_OFFSETS) {
            for (double v : HIT_OFFSETS) {
               Vec3 hitVec = this.buildFaceHitVec(supportPos, supportFace, u, v);
               if (hitVec != null) {
                  float[] fixedRotations = this.getFixedRotationsForHitVec(hitVec, baseYaw, basePitch);
                  MovingObjectPosition traced = RotationUtils.rayCastBlock(reach, fixedRotations[0], fixedRotations[1]);
                  if (this.isValidPlacementRay(traced, placePos, supportPos, supportFace)) {
                     double yawDelta = Math.abs(MathHelper.wrapAngleTo180_float(fixedRotations[0] - baseYaw));
                     double pitchDelta = Math.abs(fixedRotations[1] - basePitch);
                     double centerPenalty = supportFaceCenter.squareDistanceTo(traced.hitVec);
                     double score = yawDelta + pitchDelta + centerPenalty * 4.0;
                     if (best == null || score < best.score) {
                        best = new AutoLadder.RotationHit(fixedRotations[0], fixedRotations[1], traced, score);
                     }
                  }
               }
            }
         }

         return best;
      } else {
         return null;
      }
   }

   private boolean isValidPlacementRay(MovingObjectPosition mop, BlockPos expectedPlacePos, BlockPos expectedSupportPos, EnumFacing expectedFace) {
      if (mop != null
         && mop.typeOfHit == MovingObjectType.BLOCK
         && mop.getBlockPos() != null
         && mop.sideHit != null
         && mop.hitVec != null
         && expectedPlacePos != null
         && expectedSupportPos != null
         && expectedFace != null
         && !this.isBlacklisted(expectedSupportPos)) {
         if (BlockUtils.isBlockPosEqual(mop.getBlockPos(), expectedSupportPos) && mop.sideHit == expectedFace) {
            BlockPos placePos = BlockUtils.offsetPos(mop);
            return placePos != null && BlockUtils.isBlockPosEqual(placePos, expectedPlacePos);
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean canUseAsLadderSupport(BlockPos ladderPos, EnumFacing ladderFace, BlockPos supportPos) {
      if (ladderPos == null || ladderFace == null || supportPos == null || mc.theWorld == null) {
         return false;
      } else if (!this.isSolidLadderSupportBlock(supportPos)) {
         return false;
      } else {
         return !this.isReplaceableOrLadder(ladderPos) ? false : Blocks.ladder.canPlaceBlockOnSide(mc.theWorld, ladderPos, ladderFace);
      }
   }

   private boolean isAnchorBlockValid(BlockPos pos) {
      if (pos != null && !BlockUtils.replaceable(pos) && !BlockUtils.isInteractable(BlockUtils.getBlock(pos))
         && !this.isBlacklisted(pos)) {
         Block block = BlockUtils.getBlock(pos);
         return block != null && block != Blocks.air;
      } else {
         return false;
      }
   }

   private boolean hasSupportPlacementAnchor(BlockPos placePos) {
      if (placePos == null) {
         return false;
      }

      for (EnumFacing placeFace : EnumFacing.values()) {
         if (placeFace != EnumFacing.DOWN) {
            BlockPos anchorPos = placePos.offset(placeFace.getOpposite());
            if (this.isAnchorBlockValid(anchorPos)) {
               return true;
            }
         }
      }

      return false;
   }

   private boolean isSolidLadderSupportBlock(BlockPos pos) {
      if (pos != null && !BlockUtils.replaceable(pos) && !BlockUtils.isInteractable(BlockUtils.getBlock(pos))
         && !this.isBlacklisted(pos)) {
         Block block = BlockUtils.getBlock(pos);
         return block != null && block != Blocks.air && block.isFullCube();
      } else {
         return false;
      }
   }

   private boolean isBlacklisted(BlockPos pos) {
      if (!this.blockBlacklistToggle.isToggled() || this.blockBlacklist.getBlocks().isEmpty() || pos == null || mc.theWorld == null) {
         return false;
      }
      IBlockState state = mc.theWorld.getBlockState(pos);
      Block block = state.getBlock();
      return this.isBlacklisted(block, block.getMetaFromState(state));
   }

   private boolean isBlacklisted(Block block, int metadata) {
      if (!this.blockBlacklistToggle.isToggled() || block == null) {
         return false;
      }
      ResourceLocation registryName = Block.blockRegistry.getNameForObject(block);
      if (registryName == null) {
         return false;
      }
      String registryId = registryName.toString();
      String storageId = metadata != 0 ? registryId + ":" + metadata : registryId;
      return this.blockBlacklist.contains(storageId) || this.blockBlacklist.contains(registryId);
   }

   private boolean isWithinReachBounds(BlockPos placePos, BlockPos supportPos) {
      if (mc.thePlayer == null) {
         return false;
      }

      Vec3 eye = mc.thePlayer.getPositionEyes(1.0F);
      Vec3 placeCenter = new Vec3(placePos.getX() + 0.5, placePos.getY() + 0.5, placePos.getZ() + 0.5);
      Vec3 supportCenter = new Vec3(supportPos.getX() + 0.5, supportPos.getY() + 0.5, supportPos.getZ() + 0.5);
      double reach = this.getPlacementReach() + 1.0;
      return eye.distanceTo(placeCenter) <= reach || eye.distanceTo(supportCenter) <= reach;
   }

   private float[] getFixedRotationsForHitVec(Vec3 hitVec, float baseYaw, float basePitch) {
      return this.getFixedRotationsForVec(hitVec, baseYaw, basePitch);
   }

   private float[] getFixedRotationsForVec(Vec3 targetVec, float baseYaw, float basePitch) {
      if (targetVec != null && mc.thePlayer != null) {
         double dx = targetVec.xCoord - mc.thePlayer.posX;
         double dy = targetVec.yCoord - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
         double dz = targetVec.zCoord - mc.thePlayer.posZ;
         double horizontalDistance = Math.sqrt(dx * dx + dz * dz);
         float yaw = horizontalDistance < 1.0E-6 ? baseYaw : (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
         float pitch = (float) -Math.toDegrees(Math.atan2(dy, horizontalDistance));
         yaw = baseYaw + MathHelper.wrapAngleTo180_float(yaw - baseYaw);
         pitch = MathHelper.clamp_float(basePitch + MathHelper.wrapAngleTo180_float(pitch - basePitch), -90.0F, 90.0F);
         return RotationUtils.fixRotation(yaw, pitch, baseYaw, basePitch);
      } else {
         return null;
      }
   }

   private Vec3 buildFaceHitVec(BlockPos blockPos, EnumFacing face, double u, double v) {
      if (blockPos != null && face != null) {
         double cu = MathHelper.clamp_double(u, 0.01, 0.99);
         double cv = MathHelper.clamp_double(v, 0.01, 0.99);
         double x;
         double y;
         double z;
         switch (face) {
            case DOWN:
               x = blockPos.getX() + cu;
               y = blockPos.getY() + 0.01;
               z = blockPos.getZ() + cv;
               break;
            case UP:
               x = blockPos.getX() + cu;
               y = blockPos.getY() + 0.99;
               z = blockPos.getZ() + cv;
               break;
            case NORTH:
               x = blockPos.getX() + cu;
               y = blockPos.getY() + cv;
               z = blockPos.getZ() + 0.01;
               break;
            case SOUTH:
               x = blockPos.getX() + cu;
               y = blockPos.getY() + cv;
               z = blockPos.getZ() + 0.99;
               break;
            case WEST:
               x = blockPos.getX() + 0.01;
               y = blockPos.getY() + cv;
               z = blockPos.getZ() + cu;
               break;
            case EAST:
               x = blockPos.getX() + 0.99;
               y = blockPos.getY() + cv;
               z = blockPos.getZ() + cu;
               break;
            default:
               return null;
         }

         return new Vec3(x, y, z);
      } else {
         return null;
      }
   }

   private int rotationTicks(float yaw, float pitch, float baseYaw, float basePitch) {
      double angle = Math.max(Math.abs(MathHelper.wrapAngleTo180_float(yaw - baseYaw)), Math.abs(pitch - basePitch));
      return Math.max(1, (int) Math.ceil(angle / this.rotationSpeed.getInput()));
   }

   private AutoLadder.EntryEstimate estimateLadderEntry(BlockPos ladderPos, EnumFacing ladderFace, BlockPos supportPlacementPos, int ladderReadyTick, int supportReadyTick) {
      Simulation simulation = Simulation.create();
      Vec3 target = this.getLadderSteerTarget(ladderPos);
      for (int tickAhead = 0; tickAhead <= LOOKAHEAD_TICKS; tickAhead++) {
         keystrokesmod.script.model.Vec3 pos = simulation.getPosition();
         if (simulation.onGround() || simulation.isInLiquid() || pos.y < ladderPos.getY()) {
            return EntryEstimate.invalid();
         }
         if (tickAhead >= ladderReadyTick && simulation.isOnLadder() && this.feetOccupyLadderCell(pos.x, pos.y, pos.z, ladderPos)) {
            double dx = target.xCoord - pos.x;
            double dz = target.zCoord - pos.z;
            return new EntryEstimate(tickAhead, dx * dx + dz * dz);
         }
         if (supportPlacementPos != null && tickAhead == supportReadyTick) {
            double halfWidth = mc.thePlayer.width * 0.5;
            AxisAlignedBB playerBox = new AxisAlignedBB(pos.x - halfWidth, pos.y, pos.z - halfWidth,
               pos.x + halfWidth, pos.y + mc.thePlayer.height, pos.z + halfWidth);
            if (playerBox.intersectsWith(new AxisAlignedBB(supportPlacementPos, supportPlacementPos.add(1, 1, 1)))) {
               return EntryEstimate.invalid();
            }
            simulation.setBlockState(supportPlacementPos, Blocks.stone.getDefaultState());
         }
         if (tickAhead == ladderReadyTick && !this.isLadderBlock(ladderPos)) {
            simulation.setBlockState(ladderPos, Blocks.ladder.getDefaultState().withProperty(BlockLadder.FACING, ladderFace));
         }
         if (tickAhead >= ladderReadyTick && simulation.isOnLadder() && this.feetOccupyLadderCell(pos.x, pos.y, pos.z, ladderPos)) {
            double dx = target.xCoord - pos.x;
            double dz = target.zCoord - pos.z;
            return new EntryEstimate(tickAhead, dx * dx + dz * dz);
         }
         float[] input = chooseSteering(target, pos.x, pos.z, simulation.getMotion().x, simulation.getMotion().z, this.getSteeringYaw(), simulation.getAirAcceleration());
         simulation.setForward(input[0]);
         simulation.setStrafe(input[1]);
         simulation.setYaw(this.getSteeringYaw());
         simulation.setJump(false);
         simulation.setSneak(false);
         simulation.setSprinting(mc.gameSettings.keyBindSprint.isKeyDown());
         simulation.tick();
      }
      return EntryEstimate.invalid();
   }

   private boolean feetOccupyLadderCell(double x, double y, double z, BlockPos pos) {
      return MathHelper.floor_double(x) == pos.getX() && MathHelper.floor_double(y) == pos.getY()
         && MathHelper.floor_double(z) == pos.getZ();
   }

   private boolean isPlanStillValidForCurrentStage() {
      if (this.activePlan == null || !this.isPlanWithinPlacementBounds(this.activePlan)) {
         return false;
      }
      if (this.activePlan.groundCatch) {
         return !this.shouldAbortForMissingItems() && this.estimateGroundEntry(this.activePlan).valid();
      }

      if (this.stage == AutoLadder.ExecutionStage.PLACE_SUPPORT) {
         if (this.activePlan.requiresSupportPlacement
            && this.activePlan.supportPlacePos != null
            && BlockUtils.replaceable(this.activePlan.supportPlacePos)
            && this.findSupportSlot() != -1
            && !this.doesPlayerIntersectPlacementNowOrNextTick(this.activePlan.supportPlacePos)
            && this.hasSupportPlacementAnchor(this.activePlan.supportPlacePos)) {
            float[] aim = this.getFixedRotationsForVec(this.buildFaceHitVec(this.activePlan.supportPlacePos,
               this.activePlan.ladderFace, 0.5, 0.5), this.placementHit.yaw, this.placementHit.pitch);
            int readyTick = this.rotationTicks(aim[0], aim[1], this.placementHit.yaw, this.placementHit.pitch);
            AutoLadder.EntryEstimate estimate = this.estimateLadderEntry(
               this.activePlan.ladderPos, this.activePlan.ladderFace, this.activePlan.supportPlacePos, readyTick, 0
            );
            return estimate.valid();
         } else {
            return false;
         }
      } else if (this.stage == AutoLadder.ExecutionStage.PLACE_LADDER) {
         if (this.findLadderSlot() != -1
            && this.isReplaceableOrLadder(this.activePlan.ladderPos)
            && this.canUseAsLadderSupport(this.activePlan.ladderPos, this.activePlan.ladderFace, this.activePlan.ladderSupportPos)) {
            AutoLadder.EntryEstimate estimate = this.estimateLadderEntry(this.activePlan.ladderPos, this.activePlan.ladderFace, null, 0, 0);
            return estimate.valid();
         } else {
            return false;
         }
      } else {
         return true;
      }
   }

   private boolean shouldAbortForMissingItems() {
      if (this.activePlan == null) {
         return false;
      } else if (this.stage == AutoLadder.ExecutionStage.PLACE_SUPPORT) {
         return this.findSupportSlot() == -1 || this.findLadderSlot() == -1;
      } else {
         return this.stage == AutoLadder.ExecutionStage.PLACE_LADDER && this.findLadderSlot() == -1;
      }
   }

   private void prepareHeldItemForStage() {
      if (mc.thePlayer != null && this.activePlan != null) {
         if (this.stage == AutoLadder.ExecutionStage.PLACE_SUPPORT) {
            int supportSlot = this.findSupportSlot();
            if (supportSlot != -1) {
               this.switchToSlot(supportSlot);
            }
         } else {
            if (this.stage == AutoLadder.ExecutionStage.PLACE_LADDER) {
               int ladderSlot = this.findLadderSlot();
               if (ladderSlot != -1) {
                  this.switchToSlot(ladderSlot);
               }
            }
         }
      }
   }

   private ItemStack resolveHeldStackForCurrentStage() {
      if (mc.thePlayer == null) {
         return null;
      }

      ItemStack held = mc.thePlayer.getHeldItem();
      if (this.stage == AutoLadder.ExecutionStage.PLACE_SUPPORT) {
         if (this.isSupportBlockStack(held)) {
            return held;
         }

         int slot = this.findSupportSlot();
         if (slot == -1) {
            return null;
         }

         this.switchToSlot(slot);
         held = mc.thePlayer.getHeldItem();
         return this.isSupportBlockStack(held) ? held : null;
      } else {
         if (this.isLadderStack(held)) {
            return held;
         }

         int ladderSlot = this.findLadderSlot();
         if (ladderSlot == -1) {
            return null;
         }

         this.switchToSlot(ladderSlot);
         held = mc.thePlayer.getHeldItem();
         return this.isLadderStack(held) ? held : null;
      }
   }

   private void switchToSlot(int slot) {
      this.session.select(slot);
   }

   private void restoreOriginalSlotIfNeeded() {
      this.session.restore();
   }

   private int findLadderSlot() {
      if (mc.thePlayer == null) {
         return -1;
      }

      for (int slot = 0; slot < 9; slot++) {
         if (this.isLadderStack(mc.thePlayer.inventory.getStackInSlot(slot))) {
            return slot;
         }
      }

      return -1;
   }

   private int findSupportSlot() {
      if (mc.thePlayer == null) {
         return -1;
      }

      for (int slot = 0; slot < 9; slot++) {
         if (this.isSupportBlockStack(mc.thePlayer.inventory.getStackInSlot(slot))) {
            return slot;
         }
      }

      return -1;
   }

   private boolean isLadderStack(ItemStack stack) {
      if (stack != null && stack.stackSize > 0 && stack.getItem() instanceof ItemBlock) {
         Block block = ((ItemBlock)stack.getItem()).getBlock();
         return block == Blocks.ladder;
      } else {
         return false;
      }
   }

   private boolean isSupportBlockStack(ItemStack stack) {
      if (stack != null && stack.stackSize > 0 && stack.getItem() instanceof ItemBlock) {
         ItemBlock itemBlock = (ItemBlock)stack.getItem();
         Block block = itemBlock.getBlock();
         return block != Blocks.ladder && block != null && block.isFullCube() && Utils.canBePlaced(itemBlock)
            && !this.isBlacklisted(block, itemBlock.getMetadata(stack.getMetadata()));
      } else {
         return false;
      }
   }

   private float[] steeringInput(Vec3 target, double x, double z, double motionX, double motionZ, float yaw) {
      return this.chooseSteering(target, x, z, motionX, motionZ, yaw, mc.thePlayer.jumpMovementFactor);
   }

   private float[] chooseSteering(Vec3 target, double x, double z, double motionX, double motionZ, float yaw, float acceleration) {
      double dx = target.xCoord - x;
      double dz = target.zCoord - z;
      double best = Double.POSITIVE_INFINITY;
      int bestForward = 0;
      int bestStrafe = 0;
      float sin = MathHelper.sin(yaw * (float) Math.PI / 180.0F);
      float cos = MathHelper.cos(yaw * (float) Math.PI / 180.0F);

      for (int forward = -1; forward <= 1; forward++) {
         for (int strafe = -1; strafe <= 1; strafe++) {
            float forwardInput = forward * 0.98F;
            float strafeInput = strafe * 0.98F;
            float scale = acceleration / Math.max(1.0F, MathHelper.sqrt_float(forwardInput * forwardInput + strafeInput * strafeInput));
            double velocityX = motionX + (strafeInput * cos - forwardInput * sin) * scale;
            double velocityZ = motionZ + (forwardInput * cos + strafeInput * sin) * scale;
            double errorX = dx - velocityX * 5.0;
            double errorZ = dz - velocityZ * 5.0;
            double cost = errorX * errorX + errorZ * errorZ + (forward * forward + strafe * strafe) * 1.0E-6;

            if (cost < best) {
               best = cost;
               bestForward = forward;
               bestStrafe = strafe;
            }
         }
      }

      return new float[]{bestForward, bestStrafe};
   }

   private void applyMovementOverride(PrePlayerInputEvent e, Vec3 target) {
      float[] input = this.steeringInput(target, mc.thePlayer.posX, mc.thePlayer.posZ, mc.thePlayer.motionX, mc.thePlayer.motionZ, this.getSteeringYaw());
      e.setForward(input[0]);
      e.setStrafe(input[1]);
      e.setJump(false);
      e.setSneak(false);
   }

   private Vec3 getLadderSteerTarget(BlockPos ladderPos) {
      return new Vec3(ladderPos.getX() + 0.5, ladderPos.getY() + 0.5, ladderPos.getZ() + 0.5);
   }

   private double getHorizontalDistanceSq(BlockPos pos) {
      if (pos != null && mc.thePlayer != null) {
         double dx = pos.getX() + 0.5 - mc.thePlayer.posX;
         double dz = pos.getZ() + 0.5 - mc.thePlayer.posZ;
         return dx * dx + dz * dz;
      } else {
         return Double.MAX_VALUE;
      }
   }

   private float getSteeringYaw() {
      Float yaw = RotationHelper.get().getServerYaw();
      return yaw == null ? this.session.sent().yaw : yaw;
   }

   private float getPlacementBaseYaw() {
      return this.session.sent().yaw;
   }

   private float getPlacementBasePitch() {
      return this.session.sent().pitch;
   }

   private boolean shouldYieldToClutch() {
      Module clutchModule = ModuleManager.getModule(Clutch.class);
      return clutchModule instanceof Clutch && ((Clutch) clutchModule).isActiveWindow();
   }

   int yieldToClutch() {
      int original = this.session.transferSlot();
      Module clutch = ModuleManager.getModule(Clutch.class);
      if (original >= 0 && clutch instanceof Clutch) ((Clutch) clutch).adoptLadderSlot(original);
      this.resetExecutionState(false, "yield-clutch");
      this.hasStickyRotation = false;
      return original;
   }

   private boolean hasIncompatibleModule() {
      return this.getBlockingModule() != null;
   }

   private String getBlockingModule() {
      if (keystrokesmod.Raven.lagHandler != null && keystrokesmod.Raven.lagHandler.isBuffering()) return "Buffered packets";
      return null;
   }

   private boolean shouldStartPlanningNow() {
      return this.isCurrentlyFalling() && (!this.onlyWhileHoldingLadder.isToggled() || this.isLadderStack(mc.thePlayer.getHeldItem()))
         && this.findLadderSlot() != -1
         && (this.fallQualified || this.minimumDropDistance.getInput() == 0 || this.heightAboveGround() >= this.minimumDropDistance.getInput());
   }

   private double heightAboveGround() {
      AxisAlignedBB feet = mc.thePlayer.getEntityBoundingBox();
      AxisAlignedBB column = new AxisAlignedBB(feet.minX + 1.0E-7, -1, feet.minZ + 1.0E-7,
         feet.maxX - 1.0E-7, feet.minY + 1.0E-7, feet.maxZ - 1.0E-7);
      double surface = Double.NEGATIVE_INFINITY;
      java.util.List<AxisAlignedBB> boxes = new java.util.ArrayList<>();
      for (int x = MathHelper.floor_double(column.minX); x <= MathHelper.floor_double(column.maxX); x++) {
         for (int z = MathHelper.floor_double(column.minZ); z <= MathHelper.floor_double(column.maxZ); z++) {
            for (int y = MathHelper.floor_double(feet.minY); y >= 0 && y + 1.5 > surface; y--) {
               BlockPos pos = new BlockPos(x, y, z);
               net.minecraft.block.state.IBlockState state = mc.theWorld.getBlockState(pos);
               boxes.clear();
               state.getBlock().addCollisionBoxesToList(mc.theWorld, pos, state, column, boxes, mc.thePlayer);
               for (AxisAlignedBB box : boxes) {
                  if (box.maxY <= feet.minY + 1.0E-7) surface = Math.max(surface, box.maxY);
               }
            }
         }
      }
      return feet.minY - surface;
   }

   private boolean isCurrentlyFalling() {
      return mc.thePlayer != null && !mc.thePlayer.onGround && !mc.thePlayer.isOnLadder() && mc.thePlayer.motionY < 0.0
         && !mc.thePlayer.isInWater() && !mc.thePlayer.isInLava() && !mc.thePlayer.capabilities.isFlying
         && !mc.thePlayer.isSpectator() && !mc.thePlayer.noClip && mc.thePlayer.isEntityAlive()
         && !mc.thePlayer.isRiding() && !mc.thePlayer.isUsingItem();
   }

   private boolean isPlanWithinPlacementBounds(AutoLadder.PlacementPlan plan) {
      if (plan == null || plan.ladderPos == null) {
         return false;
      } else if (plan.groundCatch && this.stage != ExecutionStage.GUIDE_ENTRY) {
         return this.getPlayerFeetY() >= plan.ladderPos.getY()
            && this.getHorizontalDistanceSq(plan.ladderPos) <= MAX_PLACE_XZ_DELTA * MAX_PLACE_XZ_DELTA;
      } else if (this.stage == AutoLadder.ExecutionStage.GUIDE_ENTRY) {
         double belowDelta = this.getPlayerFeetY() - plan.ladderPos.getY();
         return mc.thePlayer != null
            && Math.abs(plan.ladderPos.getX() + 0.5 - mc.thePlayer.posX) <= MAX_PLACE_XZ_DELTA
            && Math.abs(plan.ladderPos.getZ() + 0.5 - mc.thePlayer.posZ) <= MAX_PLACE_XZ_DELTA
            && belowDelta >= -1.0 && belowDelta <= MAX_PLACE_BELOW_PLAYER_Y;
      } else if (!this.isWithinPlacementBounds(plan.ladderPos)) {
         return false;
      } else {
         return plan.ladderSupportPos != null && !this.isWithinPlacementBounds(plan.ladderSupportPos)
            ? false
            : plan.supportPlacePos == null || this.isWithinPlacementBounds(plan.supportPlacePos);
      }
   }

   private boolean isWithinPlacementBounds(BlockPos pos) {
      if (pos != null && mc.thePlayer != null) {
         double dx = Math.abs(pos.getX() + 0.5 - mc.thePlayer.posX);
         double dz = Math.abs(pos.getZ() + 0.5 - mc.thePlayer.posZ);
         if (dx <= MAX_PLACE_XZ_DELTA && dz <= MAX_PLACE_XZ_DELTA) {
            double belowDelta = this.getPlayerFeetY() - pos.getY();
            return belowDelta > -1.0 && belowDelta <= MAX_PLACE_BELOW_PLAYER_Y;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private double getPlayerFeetY() {
      if (mc.thePlayer == null) {
         return 0.0;
      } else {
         return mc.thePlayer.getEntityBoundingBox() != null ? mc.thePlayer.getEntityBoundingBox().minY : mc.thePlayer.posY;
      }
   }

   private boolean isReplaceableOrLadder(BlockPos pos) {
      if (pos == null) {
         return false;
      }

      Block block = BlockUtils.getBlock(pos);
      return block == Blocks.ladder || BlockUtils.replaceable(pos);
   }

   private boolean isInsideTargetLadder(BlockPos ladderPos) {
      return ladderPos != null && mc.thePlayer != null && mc.thePlayer.isOnLadder() && this.isLadderBlock(ladderPos)
         && this.feetOccupyLadderCell(mc.thePlayer.posX, this.getPlayerFeetY(), mc.thePlayer.posZ, ladderPos);
   }

   private boolean doesPlayerIntersectPlacementNowOrNextTick(BlockPos pos) {
      if (mc.thePlayer == null || pos == null) {
         return false;
      }
      AxisAlignedBB placementBox = new AxisAlignedBB(pos, pos.add(1, 1, 1));
      AxisAlignedBB playerBox = mc.thePlayer.getEntityBoundingBox();
      return playerBox.intersectsWith(placementBox)
         || playerBox.offset(mc.thePlayer.motionX, mc.thePlayer.motionY, mc.thePlayer.motionZ).intersectsWith(placementBox);
   }

   private boolean isLadderBlock(BlockPos pos) {
      return pos != null && BlockUtils.getBlock(pos) == Blocks.ladder;
   }

   private boolean isModuleReady() {
      if (this.isEnabled() && Utils.nullCheck() && mc.playerController != null && !mc.isGamePaused()) {
         EntityPlayerSP player = mc.thePlayer;
         return player != null && player.movementInput != null && mc.currentScreen == null;
      } else {
         return false;
      }
   }

   private int getPlacementPlayerTick() {
      return Utils.nullCheck() && mc.thePlayer != null ? this.currentPlacementTick : Integer.MIN_VALUE;
   }

   private double getPlacementReach() {
      return mc.playerController == null ? 4.5 : mc.playerController.getBlockReachDistance();
   }

   private void resetExecutionState(boolean restoreOriginalSlot, String reason) {
      this.releaseMovement();
      if (this.activePlan != null || "no-valid-plan".equals(reason) || "control-conflict".equals(reason))
         this.retryAfterTick = this.currentPlacementTick + 3;
      this.stableHit = null;
      this.stage = AutoLadder.ExecutionStage.IDLE;
      this.activePlan = null;
      this.placementHit = null;
      this.rotationTick = Integer.MIN_VALUE;
      this.lastPlacementAttemptTick = Integer.MIN_VALUE;
      this.guideStartTick = Integer.MIN_VALUE;
      this.guideInvalidTicks = 0;
      this.stageInvalidTicks = 0;
      if (restoreOriginalSlot) {
         this.restoreOriginalSlotIfNeeded();
      }
   }

   private static final class EntryEstimate {
      private final int tickAhead;
      private final double entryAlignmentErrorSq;

      private EntryEstimate(int tickAhead, double entryAlignmentErrorSq) {
         this.tickAhead = tickAhead;
         this.entryAlignmentErrorSq = entryAlignmentErrorSq;
      }

      private static AutoLadder.EntryEstimate invalid() {
         return new AutoLadder.EntryEstimate(-1, Double.MAX_VALUE);
      }

      private boolean valid() {
         return this.tickAhead >= 0;
      }
   }

   private enum ExecutionStage {
      IDLE,
      PLACE_SUPPORT,
      PLACE_LADDER,
      GUIDE_ENTRY;
   }

   private static final class PlacementPlan {
      private final BlockPos ladderPos;
      private final BlockPos ladderSupportPos;
      private final EnumFacing ladderFace;
      private final boolean requiresSupportPlacement;
      private final BlockPos supportPlacePos;
      private final double planCost;
      private final boolean groundCatch;

      private PlacementPlan(BlockPos ladderPos, BlockPos supportPos, EnumFacing ladderFace, boolean requiresSupportPlacement, double planCost) {
         this(ladderPos, supportPos, ladderFace, requiresSupportPlacement, planCost, false);
      }

      private PlacementPlan(BlockPos ladderPos, BlockPos supportPos, EnumFacing ladderFace, boolean requiresSupportPlacement, double planCost, boolean groundCatch) {
         this.ladderPos = ladderPos;
         this.ladderSupportPos = supportPos;
         this.ladderFace = ladderFace;
         this.requiresSupportPlacement = requiresSupportPlacement;
         this.supportPlacePos = requiresSupportPlacement ? supportPos : null;
         this.planCost = planCost;
         this.groundCatch = groundCatch;
      }
   }

   private static final class RotationHit {
      private final float yaw;
      private final float pitch;
      private final MovingObjectPosition mop;
      private final double score;

      private RotationHit(float yaw, float pitch, MovingObjectPosition mop, double score) {
         this.yaw = yaw;
         this.pitch = pitch;
         this.mop = mop;
         this.score = score;
      }
   }
}

