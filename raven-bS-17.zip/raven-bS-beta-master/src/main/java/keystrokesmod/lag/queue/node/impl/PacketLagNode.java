package keystrokesmod.lag.queue.node.impl;

import keystrokesmod.lag.api.EnumLagDirection;
import keystrokesmod.lag.handler.AbstractFastTrackProvider;
import keystrokesmod.lag.queue.node.api.AbstractLagNode;
import keystrokesmod.utility.PacketUtils;
import net.minecraft.network.Packet;
import org.jetbrains.annotations.NotNull;

public final class PacketLagNode extends AbstractLagNode {

    private final @NotNull Packet<?> packet;
    private final @NotNull EnumLagDirection direction;
    private final boolean sendWithoutEvent;
    private final long queuedAtMs;

    public PacketLagNode(final @NotNull Packet<?> packet, final @NotNull EnumLagDirection direction) {
        this(packet, direction, false);
    }

    public PacketLagNode(final @NotNull Packet<?> packet, final @NotNull EnumLagDirection direction, boolean sendWithoutEvent) {
        this.packet = packet;
        this.direction = direction;
        this.sendWithoutEvent = sendWithoutEvent;
        this.queuedAtMs = System.currentTimeMillis();
    }

    public long getQueuedAtMs() {
        return queuedAtMs;
    }

    public void goThrough(final @NotNull AbstractFastTrackProvider fastTrack) {
        if (direction == EnumLagDirection.OUTBOUND) {
            if (sendWithoutEvent) {
                PacketUtils.sendPacketNoEvent(packet);
                return;
            }
            fastTrack.forPacket(packet);
        }
        direction.passThroughChannel(packet);
    }

}
