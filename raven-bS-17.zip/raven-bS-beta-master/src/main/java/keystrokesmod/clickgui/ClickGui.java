package keystrokesmod.clickgui;

import keystrokesmod.Raven;
import keystrokesmod.clickgui.components.Component;
import keystrokesmod.clickgui.components.FocusableTextComponent;
import keystrokesmod.clickgui.components.impl.BindComponent;
import keystrokesmod.clickgui.components.impl.CategoryComponent;
import keystrokesmod.clickgui.components.impl.ModuleComponent;
import keystrokesmod.clickgui.components.impl.SliderComponent;
import keystrokesmod.module.Module;
import keystrokesmod.module.impl.client.CommandLine;
import keystrokesmod.module.impl.client.Gui;
import keystrokesmod.module.setting.impl.SliderSetting;
import keystrokesmod.utility.CommandHandler;
import keystrokesmod.utility.RenderUtils;
import keystrokesmod.utility.Timer;
import keystrokesmod.utility.Utils;
import keystrokesmod.utility.shader.BlurUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.*;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.MathHelper;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.config.GuiButtonExt;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ClickGui extends GuiScreen {
    private Timer logoSmoothWidth;
    private Timer smoothEntity;
    private Timer backgroundFade;
    private long openedAt;
    private ScaledResolution sr;
    private GuiButtonExt commandLineSend;
    private GuiTextField commandLineInput;
    public static ArrayList<CategoryComponent> categories;
    private int actualScreenWidth;
    private int actualScreenHeight;
    private double previousScale;
    private static boolean isNotFirstOpen;
    private boolean pendingScaleRefresh;
    private SliderSetting heldArrowSlider;
    private int heldArrowDirection;
    private long arrowHoldStartedAt;
    private long lastArrowAdjustmentAt;

    private static final long ARROW_HOLD_DELAY_MS = 300L;
    private static final double ARROW_INITIAL_REPEAT_MS = 180.0D;
    private static final double ARROW_ACCELERATION_HALF_LIFE_MS = 750.0D;
    private static final long ARROW_MIN_REPEAT_MS = 20L;

    public ClickGui() {
        categories = new ArrayList();
        int y = 5;
        Module.category[] values;
        int length = (values = Module.category.values()).length;

        for (int i = 0; i < length; ++i) {
            Module.category c = values[i];
            CategoryComponent categoryComponent = new CategoryComponent(c);
            categoryComponent.setY(y, false);
            categories.add(categoryComponent);
            y += 20;
        }
    }

    public void initMain() {
        this.openedAt = System.currentTimeMillis();
        (this.logoSmoothWidth = this.smoothEntity = this.backgroundFade = new Timer(500.0F)).start();
    }

    public void resetPositions() {
        int y = 5;
        for (CategoryComponent categoryComponent : categories) {
            categoryComponent.applySavedState(5, y, false, false);
            y += 20;
        }
    }

    @Override
    public void initGui() {
        super.initGui();
        if (this.backgroundFade == null) {
            initMain();
        }
        double configuredScale = getConfiguredGuiScale();
        if (!isNotFirstOpen) {
            isNotFirstOpen = true;
            this.previousScale = configuredScale;
        }
        for (CategoryComponent categoryComponent : categories) {
            categoryComponent.setScreenSize(this.width, this.height);
        }
        if (Double.compare(this.previousScale, configuredScale) != 0) {
            for (CategoryComponent categoryComponent : categories) {
                categoryComponent.limitPositions();
            }
        }
        reloadModulesForCurrentMode();
        (this.commandLineInput = new GuiTextField(1, this.mc.fontRendererObj, 22, this.height - 100, 150, 20)).setMaxStringLength(256);
        this.buttonList.add(this.commandLineSend = new GuiButtonExt(2, 22, this.height - 70, 150, 20, "Send"));
        this.commandLineSend.visible = CommandLine.opened;
        this.previousScale = configuredScale;
    }

    public void reloadModulesForCurrentMode() {
        for (CategoryComponent categoryComponent : categories) {
            if (categoryComponent.category == Module.category.profiles) {
                categoryComponent.reloadModules(true);
            } else if (categoryComponent.category == Module.category.scripts) {
                categoryComponent.reloadModules(false);
            } else {
                categoryComponent.reloadModules();
            }
        }
    }

    /** Categories in render order: least recently interacted first (so most recent drawn on top). */
    private List<CategoryComponent> getCategoriesInRenderOrder() {
        List<CategoryComponent> renderOrder = new ArrayList<>(categories);
        renderOrder.sort(Comparator.comparingLong(c -> c.lastInteractedTime));
        return renderOrder;
    }

    /** Returns the topmost CategoryComponent under the cursor, or null. */
    private CategoryComponent getTopmostUnderCursor(List<CategoryComponent> renderOrder, int x, int y) {
        for (int i = renderOrder.size() - 1; i >= 0; i--) {
            if (renderOrder.get(i).overRect(x, y)) {
                return renderOrder.get(i);
            }
        }
        return null;
    }

    public void drawScreen(int x, int y, float p) {
        if (pendingScaleRefresh) {
            pendingScaleRefresh = false;
            refreshLayoutForConfiguredScale();
        }

        int logicalMouseX = toLogicalCoordinate(x);
        int logicalMouseY = toLogicalCoordinate(y);

        int backgroundAlpha = (int) (this.backgroundFade.getValueFloat(0.0F, 0.75F, 2) * 255.0F);
        if (Gui.darkBackground.isToggled()) {
            drawRect(0, 0, this.actualScreenWidth, this.actualScreenHeight, 0x101010 | backgroundAlpha << 24);
        }
        if (Gui.backgroundBlur.getInput() > 0) {
            BlurUtils.prepareBlur();
            drawRect(0, 0, this.actualScreenWidth, this.actualScreenHeight, -1);
            float strength = (float) (3.4 * Gui.backgroundBlur.getInput() / 100.0);
            BlurUtils.blurEnd(2, strength * backgroundAlpha / 191.0f);
        }

        GlStateManager.pushMatrix();
        GlStateManager.scale(getRenderScale(), getRenderScale(), 1.0D);

        int r;
        if (!Gui.hideWatermark.isToggled()) {
            this.drawTitle(this.width / 2.0f, this.height / 4.0f);
        }
        this.renderClientInfo(this.height + 8 - this.logoSmoothWidth.getValueInt(0, 30, 2), this.fontRendererObj);

        List<CategoryComponent> renderOrder = getCategoriesInRenderOrder();
        CategoryComponent topmostUnderCursor = getTopmostUnderCursor(renderOrder, logicalMouseX, logicalMouseY);
        for (CategoryComponent c : renderOrder) {
            c.render(this.fontRendererObj);
            c.mousePosition(logicalMouseX, logicalMouseY, c == topmostUnderCursor);

            for (Component m : c.getModules()) {
                m.drawScreen(logicalMouseX, logicalMouseY);
            }
        }

        updateHeldSliderAdjustment(logicalMouseX, logicalMouseY);

        GL11.glColor3f(1.0f, 1.0f, 1.0f);
        if (!Gui.hidePlayerModel.isToggled()) {
            GlStateManager.pushMatrix();
            GlStateManager.disableBlend();
            GuiInventory.drawEntityOnScreen(this.width + 15 - this.smoothEntity.getValueInt(0, 40, 2), this.height - 10, 40, (float) (this.width - 25 - logicalMouseX), (float) (this.height - 50 - logicalMouseY), this.mc.thePlayer);
            GlStateManager.enableBlend();
            GlStateManager.popMatrix();
        }


        if (CommandLine.opened) {
            if (!this.commandLineSend.visible) {
                this.commandLineSend.visible = true;
            }

            r = CommandLine.animate.isToggled() ? CommandLine.animation.getValueInt(0, 200, 2) : 200;
            if (CommandLine.closed) {
                r = 200 - r;
                if (r == 0) {
                    CommandLine.closed = false;
                    CommandLine.opened = false;
                    this.commandLineSend.visible = false;
                }
            }
            drawRect(0, 0, r, this.height, -1089466352);
            this.drawHorizontalLine(0, r - 1, (this.height - 345), -1);
            this.drawHorizontalLine(0, r - 1, (this.height - 115), -1);
            drawRect(r - 1, 0, r, this.height, -1);
            CommandHandler.renderCommandOutput(this.fontRendererObj, this.height, r, this.sr.getScaleFactor());
            int x2 = r - 178;
            this.commandLineInput.xPosition = x2;
            this.commandLineSend.xPosition = x2;
            this.commandLineInput.drawTextBox();
            super.drawScreen(logicalMouseX, logicalMouseY, p);
        }
        else if (CommandLine.closed) {
            CommandLine.closed = false;
        }
        GlStateManager.popMatrix();
    }

    public void drawTitle(float cx, float cy) {
        long now = System.currentTimeMillis();
        float since = now - openedAt;
        String title = "raven";
        String tag = "bs";
        float intro = this.clamp(since / 950.0f);
        float base = 2.5f;
        float pulse = 1.0f + (float) Math.sin((double) now * 0.0017) * 0.012f;
        float scale = base * pulse;
        float spacing = 0.8f;
        float width = 0.0f;
        for (int i = 0; i < title.length(); ++i) {
            width += ((float) this.fontRendererObj.getCharWidth(title.charAt(i)) + spacing) * scale;
        }
        float startX = cx - (width -= spacing * scale) / 2.0f;
        float bob = (float) Math.sin((double) now * 0.0021) * 1.2f;
        GL11.glEnable(3042);
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        this.drawSparkles(cx, cy + 3.0f, width * 0.58f, 20.0f, intro, now);
        float px = startX;
        for (int i = 0; i < title.length(); ++i) {
            char c = title.charAt(i);
            float cw = this.fontRendererObj.getCharWidth(c);
            float t = this.clamp((since - (float) i * 70.0f) / 760.0f);
            if (t <= 0.0f) {
                px += (cw + spacing) * scale;
                continue;
            }
            float e = this.easeOutBack(t);
            float ang = -1.3f + (float) i * 0.48f;
            float dist = (1.0f - e) * (36.0f + (float) i * 3.5f);
            float bx = px + cw * scale / 2.0f;
            float by = cy + bob;
            float lx = bx + (float) Math.cos(ang) * dist;
            float ly = by + (float) Math.sin(ang) * dist * 0.55f + (1.0f - e) * 14.0f;
            float rot = (1.0f - e) * ((i & 1) == 0 ? -86.0f : 86.0f);
            float s = scale * (0.72f + 0.28f * e);
            int color = RenderUtils.rainbow(2L, (long) (-i) * 320L);
            this.drawGlowText(String.valueOf(c), lx, ly, s, rot, color, (int) (255.0f * t));
            px += (cw + spacing) * scale;
        }
        float tagT = this.clamp((since - 420.0f) / 850.0f);
        if (tagT > 0.0f) {
            float e = this.easeOutCubic(tagT);
            float s = 1.05f * (0.82f + 0.18f * e);
            float tw = (float) this.fontRendererObj.getStringWidth(tag) * s;
            float sway = (float) Math.sin((double) now * 0.00115) * 2.2f;
            float tbob = (float) Math.sin((double) now * 0.0021) * 0.9f;
            float phase = (float) (now % 4200L) / 4200.0f;
            float rock = (float) Math.sin((double) phase * Math.PI * 2.0) * 7.0f;
            float tx = cx + width * 0.28f + sway + 6.0f;
            float ty = cy + 17.0f + (1.0f - e) * 10.0f + tbob;
            float rot = (1.0f - e) * 8.0f + rock;
            this.drawGlowText(tag, tx + tw / 2.0f, ty, s, rot, RenderUtils.rainbow(2L, -1700L), (int) (235.0f * tagT));
        }
        RenderUtils.resetColor();
        GL11.glDisable(3042);
    }

    public void drawSparkles(float cx, float cy, float rx, float ry, float intro, long now) {
        char[] chars = new char[]{'.', '+', 'x', '*', '.', '+'};
        for (int i = 0; i < chars.length; ++i) {
            float scale;
            boolean even = (i & 1) == 0;
            double ang = (double) i * (Math.PI * 2 / (double) chars.length) + (even ? 0.0 : Math.PI / (double) chars.length);
            double speed = even ? 4.2E-4 : -3.1E-4;
            double a = ang + (double) now * speed;
            float ex = rx * (even ? 1.02f : 0.78f);
            float ey = ry * (even ? 1.0f : 0.72f);
            float sx = cx + (float) Math.cos(a) * ex;
            float sy = cy + (float) Math.sin(a) * ey;
            float twinkle = 0.65f + 0.35f * (float) Math.sin((double) now * 0.0042 + (double) i * 1.37);
            int alpha = (int) (120.0f * intro * twinkle);
            if (alpha <= 3) continue;
            alpha = RenderUtils.clampAlpha(alpha);
            int color = RenderUtils.withAlpha(RenderUtils.rainbow(2L, (long) i * 430L), alpha);
            char c = chars[i];
            float rot = 0.0f;
            switch (c) {
                case '.':
                    scale = 0.85f;
                    break;
                case '+':
                    scale = 0.72f;
                    rot = (float) (((double) now * 0.045 + (double) (i * 37)) % 360.0);
                    break;
                case 'x':
                    scale = 0.72f;
                    rot = (float) (((double) now * 0.04 + (double) (i * 53)) % 360.0);
                    break;
                default:
                    scale = 0.78f;
                    rot = (float) (((double) now * 0.03 + (double) (i * 29)) % 360.0);
            }
            GlStateManager.pushMatrix();
            GlStateManager.translate(sx, sy, 0.0f);
            if (rot != 0.0f) {
                GlStateManager.rotate(rot, 0.0f, 0.0f, 1.0f);
            }
            GlStateManager.scale(scale, scale, 1.0f);
            String s = String.valueOf(c);
            this.fontRendererObj.drawString(s, (float) (-this.fontRendererObj.getStringWidth(s)) / 2.0f, (float) (-this.fontRendererObj.FONT_HEIGHT) / 2.0f, color, true);
            GlStateManager.popMatrix();
        }
    }

    public void drawGlowText(String s, float x, float y, float scale, float rot, int color, int alpha) {
        if (alpha <= 3) {
            return;
        }
        alpha = RenderUtils.clampAlpha(alpha);
        int w = this.fontRendererObj.getStringWidth(s);
        int h = this.fontRendererObj.FONT_HEIGHT;
        float ox = (float) (-w) / 2.0f;
        float oy = (float) (-h) / 2.0f;
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, 0.0f);
        GlStateManager.rotate(rot, 0.0f, 0.0f, 1.0f);
        GlStateManager.scale(scale, scale, 1.0f);
        for (int i = 2; i >= 1; --i) {
            float gs = 1.0f + (float) i * 0.055f;
            int ga = (int) ((float) alpha * (0.1f + (float) i * 0.035f));
            if (ga < 4) continue;
            ga = RenderUtils.clampAlpha(ga);
            GlStateManager.pushMatrix();
            GlStateManager.scale(gs, gs, 1.0f);
            this.fontRendererObj.drawString(s, ox, oy, RenderUtils.withAlpha(color, ga), false);
            GlStateManager.popMatrix();
        }
        this.fontRendererObj.drawString(s, ox, oy, RenderUtils.withAlpha(color, alpha), true);
        GlStateManager.popMatrix();
    }

    public float easeOutCubic(float f) {
        float t = 1.0f - f;
        return 1.0f - t * t * t;
    }

    public float clamp(float f) {
        return f < 0.0f ? 0.0f : (f > 1.0f ? 1.0f : f);
    }

    public float easeOutBack(float f) {
        float c1 = 1.70158f;
        float c3 = c1 + 1.0f;
        float t = f - 1.0f;
        return 1.0f + c3 * t * t * t + c1 * t * t;
    }

    public void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        List<CategoryComponent> inputOrder = new ArrayList<>(categories);
        inputOrder.sort((a, b) -> Long.compare(b.lastInteractedTime, a.lastInteractedTime));
        CategoryComponent topmostCategory = null;
        for (CategoryComponent category : inputOrder) {
            if (category.overRect(mouseX, mouseY)) {
                topmostCategory = category;
                break;
            }
        }

        if (topmostCategory != null) {
            topmostCategory.markInteracted();
        }

        if (mouseButton == 0) {
            for (CategoryComponent category : categories) {
                category.overTitle(false);
            }
            if (topmostCategory != null && topmostCategory.draggable(mouseX, mouseY)) {
                topmostCategory.overTitle(true);
                topmostCategory.xx = mouseX - topmostCategory.getX();
                topmostCategory.yy = mouseY - topmostCategory.getY();
                topmostCategory.dragging = true;
            }
        }

        if (mouseButton == 1 && topmostCategory != null && topmostCategory.overTitle(mouseX, mouseY)) {
            topmostCategory.mouseClicked(!topmostCategory.isOpened());
        }

        if (topmostCategory != null && topmostCategory.isOpened() && !topmostCategory.getModules().isEmpty() && !topmostCategory.overTitle(mouseX, mouseY)) {
            for (ModuleComponent component : topmostCategory.getModules()) {
                if (component.onClick(mouseX, mouseY, mouseButton)) {
                    break;
                }
            }
        }

        if (CommandLine.opened) {
            this.commandLineInput.mouseClicked(mouseX, mouseY, mouseButton);
            super.mouseClicked(mouseX, mouseY, mouseButton);
        }

        if (mouseButton == 0 || mouseButton == 1) {
            FocusableTextComponent focusedComponent = findFocusedTextComponentAt(mouseX, mouseY);
            enforceSingleFocusedTextInput(focusedComponent);
        }
    }


    public void mouseReleased(int x, int y, int button) {
        if (button == 0) {
            for (CategoryComponent category : categories) {
                category.overTitle(false);
                if (category.isOpened() && !category.getModules().isEmpty()) {
                    for (Component module : category.getModules()) {
                        module.mouseReleased(x, y, button);
                    }
                }
            }
        }
        if (pendingScaleRefresh) {
            pendingScaleRefresh = false;
            refreshLayoutForConfiguredScale();
        }
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int wheelInput = Mouse.getDWheel();
        if (wheelInput != 0) {
            int mouseX = Mouse.getEventX() * this.width / mc.displayWidth;
            int mouseY = this.height - Mouse.getEventY() * this.height / mc.displayHeight - 1;
            for (CategoryComponent category : categories) {
                category.onScroll(wheelInput, mouseX, mouseY);
            }
        }
    }

    /**
     * Refreshes the ClickGui for the newly loaded profile's Gui scale. Call after
     * all module settings (including Gui.guiScale) are loaded. Recomputes the
     * ClickGui layout using the profile's configured internal scale.
     */
    public void refreshAfterProfileLoad() {
        if (mc == null) {
            mc = Minecraft.getMinecraft();
        }
        reloadModulesForCurrentMode();
        refreshLayoutForConfiguredScale();
    }

    @Override
    public void setWorldAndResolution(Minecraft p_setWorldAndResolution_1_, final int p_setWorldAndResolution_2_, final int p_setWorldAndResolution_3_) {
        this.mc = p_setWorldAndResolution_1_;
        this.itemRender = p_setWorldAndResolution_1_.getRenderItem();
        this.fontRendererObj = p_setWorldAndResolution_1_.fontRendererObj;
        refreshScaledResolution();
        if (!MinecraftForge.EVENT_BUS.post(new GuiScreenEvent.InitGuiEvent.Pre(this, this.buttonList))) {
            this.buttonList.clear();
            this.initGui();
        }
        MinecraftForge.EVENT_BUS.post(new GuiScreenEvent.InitGuiEvent.Post(this, this.buttonList));
    }

    @Override
    public void keyTyped(char t, int k) {
        FocusableTextComponent activeTextInput = getActiveFocusedTextInput();
        if (k == Keyboard.KEY_ESCAPE) {
            if (activeTextInput != null) {
                activeTextInput.unfocusTextInput();
                return;
            }
            if (!binding()) {
                this.mc.displayGuiScreen(null);
                return;
            }
        }

        if (activeTextInput != null) {
            for (CategoryComponent category : categories) {
                if (!category.isOpened() || category.getModules().isEmpty()) {
                    continue;
                }
                for (Component module : category.getModules()) {
                    module.keyTyped(t, k);
                }
            }
            return;
        }

        if (!binding() && adjustHoveredSlider(k)) {
            if (pendingScaleRefresh) {
                pendingScaleRefresh = false;
                refreshLayoutForConfiguredScale();
            }
            return;
        }

        for (CategoryComponent category : categories) {
            if (category.isOpened() && !category.getModules().isEmpty()) {
                for (Component module : category.getModules()) {
                    module.keyTyped(t, k);
                }
            }
        }
        if (CommandLine.opened) {
            String cm = this.commandLineInput.getText();
            if (k == 28 && !cm.isEmpty()) {
                CommandHandler.runCommand(this.commandLineInput.getText());
                this.commandLineInput.setText("");
                return;
            }
            this.commandLineInput.textboxKeyTyped(t, k);
        }
    }

    private boolean adjustHoveredSlider(int keyCode) {
        if (keyCode != Keyboard.KEY_LEFT && keyCode != Keyboard.KEY_RIGHT) {
            return false;
        }
        if (CommandLine.opened && this.commandLineInput.isFocused()) {
            return false;
        }

        int mouseX = Mouse.getX() * this.width / this.mc.displayWidth;
        int mouseY = this.height - Mouse.getY() * this.height / this.mc.displayHeight - 1;
        SliderComponent slider = getHoveredSlider(mouseX, mouseY);
        if (slider == null) {
            return false;
        }

        int direction = keyCode == Keyboard.KEY_RIGHT ? 1 : -1;
        if (this.heldArrowSlider != slider.sliderSetting || this.heldArrowDirection != direction) {
            long now = System.currentTimeMillis();
            this.heldArrowSlider = slider.sliderSetting;
            this.heldArrowDirection = direction;
            this.arrowHoldStartedAt = now;
            this.lastArrowAdjustmentAt = now;
            slider.adjustValue(direction);
        }
        return true;
    }

    private void renderClientInfo(int y, FontRenderer fontRenderer) {
        fontRenderer.drawStringWithShadow("raven bs " + Raven.VERSION, 4.0f, (float)y + 10, Gui.INFO_COLOR);
    }

    private SliderComponent getHoveredSlider(int mouseX, int mouseY) {
        CategoryComponent category = getTopmostUnderCursor(getCategoriesInRenderOrder(), mouseX, mouseY);
        if (category == null || !category.isOpened() || category.overTitle(mouseX, mouseY)) {
            return null;
        }

        for (ModuleComponent module : category.getModules()) {
            for (Component component : module.settings) {
                if (component instanceof SliderComponent) {
                    SliderComponent slider = (SliderComponent) component;
                    if (slider.isHovered(mouseX, mouseY)) {
                        return slider;
                    }
                }
            }
        }
        return null;
    }

    private void updateHeldSliderAdjustment(int mouseX, int mouseY) {
        if (this.heldArrowSlider == null) {
            return;
        }

        int heldKey = this.heldArrowDirection > 0 ? Keyboard.KEY_RIGHT : Keyboard.KEY_LEFT;
        SliderComponent hoveredSlider = getHoveredSlider(mouseX, mouseY);
        if (!Keyboard.isKeyDown(heldKey)
            || binding()
            || (CommandLine.opened && this.commandLineInput.isFocused())
            || hoveredSlider == null
            || hoveredSlider.sliderSetting != this.heldArrowSlider) {
            clearHeldSliderAdjustment();
            return;
        }

        long now = System.currentTimeMillis();
        long heldDuration = now - this.arrowHoldStartedAt;
        if (heldDuration < ARROW_HOLD_DELAY_MS) {
            return;
        }

        long acceleratingDuration = heldDuration - ARROW_HOLD_DELAY_MS;
        long repeatDelay = Math.max(
            ARROW_MIN_REPEAT_MS,
            Math.round(ARROW_INITIAL_REPEAT_MS
                * Math.pow(0.5D, acceleratingDuration / ARROW_ACCELERATION_HALF_LIFE_MS))
        );
        if (now - this.lastArrowAdjustmentAt >= repeatDelay) {
            hoveredSlider.adjustValue(this.heldArrowDirection);
            this.lastArrowAdjustmentAt = now;
        }
    }

    private void clearHeldSliderAdjustment() {
        this.heldArrowSlider = null;
        this.heldArrowDirection = 0;
        this.arrowHoldStartedAt = 0L;
        this.lastArrowAdjustmentAt = 0L;
    }

    public void actionPerformed(GuiButton b) {
        if (b == this.commandLineSend) {
            CommandHandler.runCommand(this.commandLineInput.getText());
            this.commandLineInput.setText("");
        }
    }

    @Override
    public void onGuiClosed() {
        for (CategoryComponent c : categories) {
            c.dragging = false;
            c.onGuiClosed();
            for (Component m : c.getModules()) {
                m.onGuiClosed();
            }
        }
        clearHeldSliderAdjustment();
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    private boolean binding() {
        for (CategoryComponent c : categories) {
            for (ModuleComponent m : c.getModules()) {
                for (Component component : m.settings) {
                    if (component instanceof BindComponent && ((BindComponent) component).isBinding) {
                        return true;
                    }
                    if (component instanceof FocusableTextComponent && ((FocusableTextComponent) component).isTextInputFocused()) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private boolean unfocusFocusedTextInput() {
        for (CategoryComponent category : categories) {
            for (ModuleComponent module : category.getModules()) {
                for (Component component : module.settings) {
                    if (component instanceof FocusableTextComponent) {
                        FocusableTextComponent textComponent = (FocusableTextComponent) component;
                        if (textComponent.isTextInputFocused()) {
                            textComponent.unfocusTextInput();
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    private FocusableTextComponent getActiveFocusedTextInput() {
        FocusableTextComponent activeComponent = null;
        for (CategoryComponent category : categories) {
            for (ModuleComponent module : category.getModules()) {
                for (Component component : module.settings) {
                    if (component instanceof FocusableTextComponent) {
                        FocusableTextComponent textComponent = (FocusableTextComponent) component;
                        if (textComponent.isTextInputFocused()) {
                            if (activeComponent == null) {
                                activeComponent = textComponent;
                            }
                            else {
                                textComponent.unfocusTextInput();
                            }
                        }
                    }
                }
            }
        }
        return activeComponent;
    }

    private FocusableTextComponent findFocusedTextComponentAt(int mouseX, int mouseY) {
        List<CategoryComponent> inputOrder = new ArrayList<>(categories);
        inputOrder.sort((a, b) -> Long.compare(b.lastInteractedTime, a.lastInteractedTime));

        for (CategoryComponent category : inputOrder) {
            if (!category.isOpened() || !category.overRect(mouseX, mouseY)) {
                continue;
            }

            for (ModuleComponent module : category.getModules()) {
                for (Component component : module.settings) {
                    if (component instanceof FocusableTextComponent) {
                        FocusableTextComponent textComponent = (FocusableTextComponent) component;
                        if (textComponent.isTextInputFocused() && textComponent.containsClick(mouseX, mouseY)) {
                            return textComponent;
                        }
                    }
                }
            }
        }

        return null;
    }

    private void enforceSingleFocusedTextInput(FocusableTextComponent focusedComponentToKeep) {
        for (CategoryComponent category : categories) {
            for (ModuleComponent module : category.getModules()) {
                for (Component component : module.settings) {
                    if (component instanceof FocusableTextComponent) {
                        FocusableTextComponent textComponent = (FocusableTextComponent) component;
                        if (textComponent != focusedComponentToKeep && textComponent.isTextInputFocused()) {
                            textComponent.unfocusTextInput();
                        }
                    }
                }
            }
        }
    }

    public void onSliderChange() {
        for (CategoryComponent c : categories) {
            for (ModuleComponent m : c.getModules()) {
                m.onSliderChange();
            }
        }
    }

    public void requestScaleRefresh() {
        this.pendingScaleRefresh = true;
    }

    private void refreshLayoutForConfiguredScale() {
        refreshScaledResolution();
        for (CategoryComponent categoryComponent : categories) {
            categoryComponent.setScreenSize(this.width, this.height);
            categoryComponent.limitPositions();
        }
        this.buttonList.clear();
        initGui();
    }

    private void refreshScaledResolution() {
        this.sr = new ScaledResolution(mc);
        this.actualScreenWidth = this.sr.getScaledWidth();
        this.actualScreenHeight = this.sr.getScaledHeight();

        double targetScaleFactor = getTargetGuiScaleFactor();
        this.width = Math.max(1, MathHelper.ceiling_double_int((double) mc.displayWidth / targetScaleFactor));
        this.height = Math.max(1, MathHelper.ceiling_double_int((double) mc.displayHeight / targetScaleFactor));
    }

    private int getMaximumGuiScaleFactor() {
        int scaleFactor = 1;
        while (mc.displayWidth / (scaleFactor + 1) >= 320 && mc.displayHeight / (scaleFactor + 1) >= 240) {
            ++scaleFactor;
        }

        if (mc.isUnicode() && scaleFactor % 2 != 0 && scaleFactor != 1) {
            --scaleFactor;
        }

        return scaleFactor;
    }

    private double getTargetGuiScaleFactor() {
        // Old "Normal" mode forced Minecraft guiScale=2, so treat 1.0x as that baseline.
        return Math.max(1.0D, Math.min(getMaximumGuiScaleFactor(), getConfiguredGuiScale() * 2.0D));
    }

    private int toLogicalCoordinate(int coordinate) {
        return (int) Math.floor(coordinate / getRenderScale());
    }

    private double getRenderScale() {
        return actualScreenWidth <= 0 || width <= 0 ? 1.0D : (double) actualScreenWidth / (double) width;
    }

    public static double getActiveRenderScale() {
        Minecraft minecraft = Minecraft.getMinecraft();
        return minecraft.currentScreen instanceof ClickGui ? ((ClickGui) minecraft.currentScreen).getRenderScale() : 1.0D;
    }

    private double getConfiguredGuiScale() {
        return Gui.getClickGuiScale();
    }
}
