package keystrokesmod.helper;

import keystrokesmod.event.ClientRotationEvent;
import keystrokesmod.event.DispatchPacketEvent;
import keystrokesmod.event.GameTickEvent;
import keystrokesmod.utility.RotationUtils;
import keystrokesmod.utility.Utils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.*;
import net.minecraft.util.MathHelper;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public final class AutoLadderHelper {
    private final Minecraft mc = Minecraft.getMinecraft();
    private EntityPlayerSP player;
    private NetworkManager network;
    private net.minecraft.world.World world;
    private final java.util.Map<Packet<?>, Boolean> dispatched = new java.util.WeakHashMap<>();
    private volatile SentState sent = SentState.empty();
    private volatile C08PacketPlayerBlockPlacement lastPlacement;
    private boolean registered;
    private boolean closing;
    private boolean restorePending;
    private int originalSlot = -1;
    private int selectedSlot = -1;
    private boolean manualChange;
    private long holdAfterMovement = -1;
    private float holdYaw, holdPitch;
    private boolean aimed;
    private long slotRequestSequence = -1;

    public void observe() {
        if (!registered) {
            MinecraftForge.EVENT_BUS.register(this);
            registered = true;
        }
        updatePlayer();
    }

    public void start() {
        observe();
        closing = false;
    }

    public synchronized void updatePlayer() {
        if (player != mc.thePlayer || world != mc.theWorld
            || (player != null && network != player.sendQueue.getNetworkManager())) {
            player = mc.thePlayer;
            world = mc.theWorld;
            network = player == null ? null : player.sendQueue.getNetworkManager();
            sent = SentState.empty();
            lastPlacement = null;
            originalSlot = selectedSlot = -1;
            restorePending = manualChange = aimed = false;
            holdAfterMovement = slotRequestSequence = -1;
            dispatched.clear();
        }
    }

    public SentState sent() { return sent; }
    public C08PacketPlayerBlockPlacement lastPlacement() { return lastPlacement; }

    @SubscribeEvent
    public synchronized void onDispatch(DispatchPacketEvent event) {
        updatePlayer();
        if (network == null || event.getNetworkManager() != network) return;
        Packet<?> packet = event.getPacket();
        if (dispatched.put(packet, Boolean.TRUE) != null) return;
        SentState old = sent;
        if (packet instanceof C08PacketPlayerBlockPlacement) lastPlacement = (C08PacketPlayerBlockPlacement) packet;
        if (packet instanceof C03PacketPlayer) {
            C03PacketPlayer movement = (C03PacketPlayer) packet;
            sent = new SentState(old.sequence + 1, -1,
                movement.isMoving() ? movement.getPositionX() : old.x,
                movement.isMoving() ? movement.getPositionY() : old.y,
                movement.isMoving() ? movement.getPositionZ() : old.z,
                movement.getRotating() ? movement.getYaw() : old.yaw,
                movement.getRotating() ? movement.getPitch() : old.pitch,
                old.positionKnown || movement.isMoving(), old.rotationKnown || movement.getRotating(), old.slot);
        } else if (packet instanceof C09PacketHeldItemChange) {
            sent = new SentState(old.sequence, old.actionSequence, old.x, old.y, old.z, old.yaw, old.pitch,
                old.positionKnown, old.rotationKnown, ((C09PacketHeldItemChange) packet).getSlotId());
        } else if (packet instanceof C08PacketPlayerBlockPlacement || packet instanceof C02PacketUseEntity
            || packet instanceof C07PacketPlayerDigging || packet instanceof C0BPacketEntityAction
            || packet instanceof C16PacketClientStatus) {
            sent = new SentState(old.sequence, old.sequence, old.x, old.y, old.z, old.yaw, old.pitch,
                old.positionKnown, old.rotationKnown, old.slot);
        }
    }

    public boolean canSwitch() {
        SentState state = sent;
        return player != null && mc.playerController != null && state.sequence > 0 && state.actionSequence != state.sequence
            && (keystrokesmod.Raven.lagHandler == null || !keystrokesmod.Raven.lagHandler.isBuffering());
    }

    public boolean select(int slot) {
        if (slot < 0 || slot > 8 || player == null || manualChange || restorePending) return false;
        if (selectedSlot >= 0 && player.inventory.currentItem != selectedSlot) {
            abandonManualSelection();
            return false;
        }
        if (!canSwitch()) return false;
        if (originalSlot < 0) originalSlot = player.inventory.currentItem;
        if (!requestSlot(slot)) return false;
        selectedSlot = slot;
        return sent.slot == slot;
    }

    private boolean requestSlot(int slot) {
        if (sent.slot == slot && player.inventory.currentItem == slot) return true;
        if (slotRequestSequence == sent.sequence) return false;
        slotRequestSequence = sent.sequence;
        if (player.inventory.currentItem != slot) Utils.switchSlot(slot, true);
        else player.sendQueue.addToSendQueue(new C09PacketHeldItemChange(slot));
        return player.inventory.currentItem == slot;
    }

    public boolean changedManually() {
        if (player != null && selectedSlot >= 0 && player.inventory.currentItem != selectedSlot) abandonManualSelection();
        return manualChange;
    }

    private void abandonManualSelection() {
        originalSlot = selectedSlot = -1;
        restorePending = false;
        manualChange = true;
    }

    public void clearManualChange() { manualChange = false; }
    public boolean restoring() { return restorePending; }

    public void restore() { restorePending = originalSlot >= 0; }

    public int transferSlot() {
        updatePlayer();
        changedManually();
        int slot = originalSlot;
        originalSlot = selectedSlot = -1;
        restorePending = false;
        aimed = false;
        holdAfterMovement = -1;
        return slot;
    }

    public void pinAim(float yaw, float pitch) {
        holdAfterMovement = sent.sequence;
        holdYaw = yaw;
        holdPitch = pitch;
        aimed = true;
    }

    public boolean holdingAim() { return holdAfterMovement >= 0 && sent.sequence <= holdAfterMovement; }
    public float heldYaw() { return holdYaw; }
    public float heldPitch() { return holdPitch; }
    public void rememberAim() { aimed = true; }

    public void finish() {
        restore();
        closing = true;
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onTick(GameTickEvent event) {
        updatePlayer();
        if (player != null && restorePending && !changedManually() && canSwitch() && requestSlot(originalSlot)) {
            selectedSlot = originalSlot;
            if (sent.slot == originalSlot) {
                originalSlot = selectedSlot = -1;
                restorePending = false;
            }
        }

    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onRotation(ClientRotationEvent event) {
        if (!closing || player == null || !aimed) return;
        if (event.yaw != null || event.pitch != null) { aimed = false; return; }
        if (holdingAim()) {
            event.claimExactRotations(holdYaw, holdPitch, false);
            return;
        }
        SentState state = sent;
        float dy = MathHelper.wrapAngleTo180_float(player.rotationYaw - state.yaw);
        float dp = player.rotationPitch - state.pitch;
        if (Math.abs(dy) < 1 && Math.abs(dp) < 1) { aimed = false; return; }
        float[] fixed = RotationUtils.fixRotation(state.yaw + MathHelper.clamp_float(dy, -45, 45),
            state.pitch + MathHelper.clamp_float(dp, -45, 45), state.yaw, state.pitch);
        event.claimExactRotations(fixed[0], fixed[1], false);
    }

    public static final class SentState {
        public final long sequence, actionSequence;
        public final double x, y, z;
        public final float yaw, pitch;
        public final boolean positionKnown, rotationKnown;
        public final int slot;
        SentState(long sequence, long actionSequence, double x, double y, double z, float yaw, float pitch,
                  boolean positionKnown, boolean rotationKnown, int slot) {
            this.sequence = sequence; this.actionSequence = actionSequence;
            this.x = x; this.y = y; this.z = z; this.yaw = yaw; this.pitch = pitch;
            this.positionKnown = positionKnown; this.rotationKnown = rotationKnown; this.slot = slot;
        }
        static SentState empty() { return new SentState(0, -1, 0, 0, 0, 0, 0, false, false, 0); }
    }
}

