package keystrokesmod.mixin.impl.entity;

import com.mojang.authlib.GameProfile;
import keystrokesmod.event.PostMotionEvent;
import keystrokesmod.event.PostUpdateEvent;
import keystrokesmod.event.PreMovementPacketEvent;
import keystrokesmod.event.PreMotionEvent;
import keystrokesmod.event.PreUpdateEvent;
import keystrokesmod.module.ModuleManager;
import keystrokesmod.module.impl.combat.WTap;
import keystrokesmod.module.impl.movement.NoSlow;
import keystrokesmod.module.impl.movement.Sprint;
import keystrokesmod.module.impl.movement.Timer;
import keystrokesmod.module.impl.player.Freecam;
import keystrokesmod.module.impl.player.Scaffold;
import keystrokesmod.utility.ModuleUtils;
import keystrokesmod.utility.RotationUtils;
import keystrokesmod.utility.Utils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.potion.Potion;
import net.minecraft.util.*;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityPlayerSP.class)
public abstract class MixinEntityPlayerSP extends AbstractClientPlayer {
    @Shadow
    public int sprintingTicksLeft;

    public MixinEntityPlayerSP(World p_i45074_1_, GameProfile p_i45074_2_) {
        super(p_i45074_1_, p_i45074_2_);
    }

    @Override
    @Shadow
    public abstract void setSprinting(boolean p_setSprinting_1_);
    @Shadow
    protected int sprintToggleTimer;
    @Shadow
    public float prevTimeInPortal;
    @Shadow
    public float timeInPortal;
    @Shadow
    protected Minecraft mc;
    @Shadow
    public MovementInput movementInput;
    @Override
    @Shadow
    public abstract void sendPlayerAbilities();
    @Shadow
    protected abstract boolean isCurrentViewEntity();
    @Shadow
    public abstract boolean isRidingHorse();
    @Shadow
    private int horseJumpPowerCounter;
    @Shadow
    private float horseJumpPower;
    @Shadow
    protected abstract void sendHorseJump();
    @Shadow
    private boolean serverSprintState;
    @Shadow
    @Final
    public NetHandlerPlayClient sendQueue;
    @Override
    @Shadow
    public abstract boolean isSneaking();
    @Shadow
    private boolean serverSneakState;
    @Shadow
    private double lastReportedPosX;
    @Shadow
    private double lastReportedPosY;
    @Shadow
    private double lastReportedPosZ;
    @Shadow
    private float lastReportedYaw;
    @Shadow
    private float lastReportedPitch;
    @Shadow
    private int positionUpdateTicks;

    @Inject(method = "onUpdate", at = @At("HEAD"), cancellable = true)
    private void onUpdatePre(CallbackInfo c) {
        if (!Utils.isLocalPlayerSubUpdate() && Timer.shouldSkipBaseLocalUpdate()) {
            syncPrevRenderStateToCurrent();
            c.cancel();
            return;
        }

        if (Utils.isLocalPlayerSubUpdate()) {
            return;
        }

        if (this.worldObj.isBlockLoaded(new BlockPos(this.posX, 0.0, this.posZ))) {
            RotationUtils.prevRenderPitch = RotationUtils.renderPitch;
            RotationUtils.prevRenderYaw = RotationUtils.renderYaw;

            net.minecraftforge.common.MinecraftForge.EVENT_BUS.post(new PreUpdateEvent());
        }
    }

    @Inject(method = "onUpdate", at = @At("RETURN"))
    private void onUpdatePost(CallbackInfo c) {
        if (Utils.isLocalPlayerSubUpdate()) {
            return;
        }

        if (this.worldObj.isBlockLoaded(new BlockPos(this.posX, 0.0, this.posZ))) {
            net.minecraftforge.common.MinecraftForge.EVENT_BUS.post(new PostUpdateEvent());
        }

        int extraUpdates = Timer.consumeExtraLocalUpdatesForBaseTick();
        if (extraUpdates <= 0) {
            return;
        }

        InterpolationState interpolationState = captureInterpolationState();
        for (int i = 0; i < extraUpdates; ++i) {
            Utils.beginLocalPlayerSubUpdate();
            try {
                this.onUpdate();
            }
            finally {
                Utils.endLocalPlayerSubUpdate();
            }
        }
        restoreInterpolationState(interpolationState);
    }

    @Overwrite
    public void onUpdateWalkingPlayer() {
        PreMotionEvent.setRotations = false;
        PreMotionEvent.setRenderYaw(false);
        RotationUtils.setFakeRotations = false;
        PreMotionEvent preMotionEvent = new PreMotionEvent(
                this.posX,
                this.getEntityBoundingBox().minY,
                this.posZ,
                this.rotationYaw,
                this.rotationPitch,
                this.onGround,
                this.isSprinting(),
                this.isSneaking()
        );

        net.minecraftforge.common.MinecraftForge.EVENT_BUS.post(preMotionEvent);

        RotationUtils.serverRotations = new float[] { preMotionEvent.getYaw(), preMotionEvent.getPitch() };

        boolean flag = preMotionEvent.isSprinting();
        if (flag != this.serverSprintState) {
            if (flag) {
                this.sendQueue.addToSendQueue(new C0BPacketEntityAction(this, C0BPacketEntityAction.Action.START_SPRINTING));
            } else {
                this.sendQueue.addToSendQueue(new C0BPacketEntityAction(this, C0BPacketEntityAction.Action.STOP_SPRINTING));
            }

            this.serverSprintState = flag;
        }

        boolean flag1 = preMotionEvent.isSneaking();
        if (flag1 != this.serverSneakState) {
            if (flag1) {
                this.sendQueue.addToSendQueue(new C0BPacketEntityAction(this, C0BPacketEntityAction.Action.START_SNEAKING));
            } else {
                this.sendQueue.addToSendQueue(new C0BPacketEntityAction(this, C0BPacketEntityAction.Action.STOP_SNEAKING));
            }

            this.serverSneakState = flag1;
        }

        net.minecraftforge.common.MinecraftForge.EVENT_BUS.post(new PreMovementPacketEvent());

        // Freecam changes the render-view entity, but the real local player must
        // still perform its normal once-per-tick walking-player network update.
        if (this.isCurrentViewEntity() || Freecam.freeEntity != null) {
            if (PreMotionEvent.setRenderYaw()) {
                RotationUtils.setRenderYaw(preMotionEvent.getYaw());
            }

            RotationUtils.renderPitch = preMotionEvent.getPitch();
            RotationUtils.renderYaw = preMotionEvent.getYaw();

            if (RotationUtils.setFakeRotations) {
                RotationUtils.renderPitch = RotationUtils.fakeRotations[1];
                RotationUtils.renderYaw = RotationUtils.fakeRotations[0];
                RotationUtils.setRenderYaw(RotationUtils.renderYaw);
            }
            RotationUtils.setFakeRotations = false;

            double d0 = preMotionEvent.getPosX() - this.lastReportedPosX;
            double d1 = preMotionEvent.getPosY() - this.lastReportedPosY;
            double d2 = preMotionEvent.getPosZ() - this.lastReportedPosZ;
            double d3 = preMotionEvent.getYaw() - this.lastReportedYaw;
            double d4 = preMotionEvent.getPitch() - this.lastReportedPitch;
            boolean flag2 = d0 * d0 + d1 * d1 + d2 * d2 > 9.0E-4 || this.positionUpdateTicks >= 20;
            boolean flag3 = d3 != 0.0 || d4 != 0.0;
            if (this.ridingEntity == null) {
                if (flag2 && flag3) {
                    this.sendQueue.addToSendQueue(new C03PacketPlayer.C06PacketPlayerPosLook(preMotionEvent.getPosX(), preMotionEvent.getPosY(), preMotionEvent.getPosZ(), preMotionEvent.getYaw(), preMotionEvent.getPitch(), preMotionEvent.isOnGround()));
                } else if (flag2) {
                    this.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(preMotionEvent.getPosX(), preMotionEvent.getPosY(), preMotionEvent.getPosZ(), preMotionEvent.isOnGround()));
                } else if (flag3) {
                    this.sendQueue.addToSendQueue(new C03PacketPlayer.C05PacketPlayerLook(preMotionEvent.getYaw(), preMotionEvent.getPitch(), preMotionEvent.isOnGround()));
                } else {
                    this.sendQueue.addToSendQueue(new C03PacketPlayer(preMotionEvent.isOnGround()));
                }
            } else {
                this.sendQueue.addToSendQueue(new C03PacketPlayer.C06PacketPlayerPosLook(this.motionX, -999.0D, this.motionZ, preMotionEvent.getYaw(), preMotionEvent.getPitch(), preMotionEvent.isOnGround()));
                flag2 = false;
            }

            ++this.positionUpdateTicks;

            if (flag2) {
                this.lastReportedPosX = preMotionEvent.getPosX();
                this.lastReportedPosY = preMotionEvent.getPosY();
                this.lastReportedPosZ = preMotionEvent.getPosZ();
                this.positionUpdateTicks = 0;
            }

            if (flag3) {
                this.lastReportedYaw = preMotionEvent.getYaw();
                this.lastReportedPitch = preMotionEvent.getPitch();
            }
        }
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.post(new PostMotionEvent());
    }

    @Overwrite
    public void onLivingUpdate() {
        if (this.sprintingTicksLeft > 0) {
            --this.sprintingTicksLeft;
            if (this.sprintingTicksLeft == 0) {
                this.setSprinting(false);
            }
        }

        if (this.sprintToggleTimer > 0) {
            --this.sprintToggleTimer;
        }

        this.prevTimeInPortal = this.timeInPortal;
        if (this.inPortal) {
            if (this.mc.currentScreen != null && !this.mc.currentScreen.doesGuiPauseGame()) {
                this.mc.displayGuiScreen(null);
            }

            if (this.timeInPortal == 0.0F) {
                this.mc.getSoundHandler().playSound(PositionedSoundRecord.create(new ResourceLocation("portal.trigger"), this.rand.nextFloat() * 0.4F + 0.8F));
            }

            this.timeInPortal += 0.0125F;
            if (this.timeInPortal >= 1.0F) {
                this.timeInPortal = 1.0F;
            }

            this.inPortal = false;
        }
        else if (this.isPotionActive(Potion.confusion) && this.getActivePotionEffect(Potion.confusion).getDuration() > 60 && (ModuleManager.antiDebuff == null || !ModuleManager.antiDebuff.canRemoveNausea(Potion.confusion))) {
            this.timeInPortal += 0.006666667F;
            if (this.timeInPortal > 1.0F) {
                this.timeInPortal = 1.0F;
            }
        }
        else {
            if (this.timeInPortal > 0.0F) {
                this.timeInPortal -= 0.05F;
            }

            if (this.timeInPortal < 0.0F) {
                this.timeInPortal = 0.0F;
            }
        }

        if (this.timeUntilPortal > 0) {
            --this.timeUntilPortal;
        }

        boolean flag = this.movementInput.jump;
        boolean flag1 = this.movementInput.sneak;
        float f = 0.8F;
        boolean flag2 = this.movementInput.moveForward >= f;
        this.movementInput.updatePlayerMoveState();
        boolean stopSprint = ModuleManager.noSlow == null || !ModuleManager.noSlow.isEnabled() || NoSlow.slowed.getInput() == 80;
        if (this.isUsingItem() && !this.isRiding()) {
            MovementInput var10000 = this.movementInput;
            float slowed = NoSlow.getSlowed();
            var10000.moveStrafe *= slowed;
            var10000 = this.movementInput;
            var10000.moveForward *= slowed;
            if (stopSprint) {
                this.sprintToggleTimer = 0;
            }
        }

        this.pushOutOfBlocks(this.posX - (double) this.width * 0.35, this.getEntityBoundingBox().minY + 0.5, this.posZ + (double) this.width * 0.35);
        this.pushOutOfBlocks(this.posX - (double) this.width * 0.35, this.getEntityBoundingBox().minY + 0.5, this.posZ - (double) this.width * 0.35);
        this.pushOutOfBlocks(this.posX + (double) this.width * 0.35, this.getEntityBoundingBox().minY + 0.5, this.posZ - (double) this.width * 0.35);
        this.pushOutOfBlocks(this.posX + (double) this.width * 0.35, this.getEntityBoundingBox().minY + 0.5, this.posZ + (double) this.width * 0.35);
        boolean flag3 = (float) this.getFoodStats().getFoodLevel() > 6.0F || this.capabilities.allowFlying;
        Scaffold scaffold = (Scaffold) ModuleManager.getModule(Scaffold.class);
        boolean scaffoldSprint = scaffold != null && scaffold.isAlwaysSprinting()
                && !this.movementInput.sneak
                && (this.movementInput.moveForward != 0 || this.movementInput.moveStrafe != 0);
        boolean scaffoldAllowsSprint = scaffold == null || scaffold.canSprint();
        boolean sprintDirectionAllowed = scaffoldAllowsSprint && (this.movementInput.moveForward >= f || scaffoldSprint);
        boolean effectiveSprintKeyDown = this.mc.gameSettings.keyBindSprint.isKeyDown() || scaffoldSprint;
        if (scaffoldAllowsSprint && this.onGround && !flag1 && !flag2 && this.movementInput.moveForward >= f && !this.isSprinting() && flag3 && (!this.isUsingItem() || !stopSprint) && !this.isPotionActive(Potion.blindness)) {
            if (this.sprintToggleTimer <= 0 && !effectiveSprintKeyDown) {
                this.sprintToggleTimer = 7;
            } else {
                this.setSprinting(true);
            }
        }

        if (!this.isSprinting() && effectiveSprintKeyDown && (this.movementInput.moveForward != 0 || this.movementInput.moveStrafe != 0)  && (sprintDirectionAllowed && flag3) && (!(this.isUsingItem() || mc.thePlayer.isBlocking()) || !stopSprint) && !this.isPotionActive(Potion.blindness)) {
            this.setSprinting(true);
        }

        if (this.isSprinting() && (((!sprintDirectionAllowed || !flag3)) || this.isCollidedHorizontally || ModuleUtils.setSlow || (this.movementInput.moveForward == 0 && this.movementInput.moveStrafe == 0) || this.mc.gameSettings.keyBindSneak.isKeyDown() || (ModuleManager.wTap.isEnabled() && WTap.stopSprint))) {
            this.setSprinting(false);
            WTap.stopSprint = false;
        }

        Sprint sprintMod = ModuleManager.sprint;
        if (scaffoldAllowsSprint && !keystrokesmod.helper.RotationHelper.get().ownsServerRelativeMovement() && !this.isSprinting() && sprintMod != null && sprintMod.isEnabled()
                && !this.isCollidedHorizontally
                && (this.movementInput.moveForward != 0 || this.movementInput.moveStrafe != 0)
                && !this.mc.gameSettings.keyBindSneak.isKeyDown() && !this.isPotionActive(Potion.blindness)) {
            boolean movingBackwards = this.movementInput.moveForward < 0;
            boolean movingSideways = this.movementInput.moveForward == 0 && this.movementInput.moveStrafe != 0;
            boolean directionAllowed = (!movingBackwards && !movingSideways)
                    || (movingBackwards && sprintMod.allowWhileBackwards())
                    || (movingSideways && sprintMod.allowWhileSideways());
            boolean usingItemAllowed = !this.isUsingItem() || sprintMod.allowWhileUsingItem();
            boolean needsOverride = movingBackwards || movingSideways || this.isUsingItem();

            if (directionAllowed && usingItemAllowed && needsOverride) {
                this.setSprinting(true);
            }
        }

        if (this.capabilities.allowFlying) {
            if (this.mc.playerController.isSpectatorMode()) {
                if (!this.capabilities.isFlying) {
                    this.capabilities.isFlying = true;
                    this.sendPlayerAbilities();
                }
            } else if (!flag && this.movementInput.jump) {
                if (this.flyToggleTimer == 0) {
                    this.flyToggleTimer = 7;
                } else {
                    this.capabilities.isFlying = !this.capabilities.isFlying;
                    this.sendPlayerAbilities();
                    this.flyToggleTimer = 0;
                }
            }
        }

        if (this.capabilities.isFlying && this.isCurrentViewEntity()) {
            if (this.movementInput.sneak) {
                this.motionY -= (double) (this.capabilities.getFlySpeed() * 3.0F);
            }

            if (this.movementInput.jump) {
                this.motionY += (double) (this.capabilities.getFlySpeed() * 3.0F);
            }
        }

        if (this.isRidingHorse()) {
            if (this.horseJumpPowerCounter < 0) {
                ++this.horseJumpPowerCounter;
                if (this.horseJumpPowerCounter == 0) {
                    this.horseJumpPower = 0.0F;
                }
            }

            if (flag && !this.movementInput.jump) {
                this.horseJumpPowerCounter = -10;
                this.sendHorseJump();
            } else if (!flag && this.movementInput.jump) {
                this.horseJumpPowerCounter = 0;
                this.horseJumpPower = 0.0F;
            } else if (flag) {
                ++this.horseJumpPowerCounter;
                if (this.horseJumpPowerCounter < 10) {
                    this.horseJumpPower = (float) this.horseJumpPowerCounter * 0.1F;
                } else {
                    this.horseJumpPower = 0.8F + 2.0F / (float) (this.horseJumpPowerCounter - 9) * 0.1F;
                }
            }
        } else {
            this.horseJumpPower = 0.0F;
        }

        super.onLivingUpdate();
        if (this.onGround && this.capabilities.isFlying && !this.mc.playerController.isSpectatorMode()) {
            this.capabilities.isFlying = false;
            this.sendPlayerAbilities();
        }
    }

    private InterpolationState captureInterpolationState() {
        return new InterpolationState(
                prevPosX, prevPosY, prevPosZ,
                lastTickPosX, lastTickPosY, lastTickPosZ,
                prevRotationYaw, prevRotationPitch,
                prevRotationYawHead, prevRenderYawOffset,
                prevCameraYaw, prevCameraPitch,
                prevDistanceWalkedModified, prevLimbSwingAmount,
                prevSwingProgress, prevChasingPosX,
                prevChasingPosY, prevChasingPosZ
        );
    }

    private void restoreInterpolationState(InterpolationState state) {
        if (state == null) {
            return;
        }

        prevPosX = state.prevPosX;
        prevPosY = state.prevPosY;
        prevPosZ = state.prevPosZ;
        lastTickPosX = state.lastTickPosX;
        lastTickPosY = state.lastTickPosY;
        lastTickPosZ = state.lastTickPosZ;
        prevRotationYaw = state.prevRotationYaw;
        prevRotationPitch = state.prevRotationPitch;
        prevRotationYawHead = state.prevRotationYawHead;
        prevRenderYawOffset = state.prevRenderYawOffset;
        prevCameraYaw = state.prevCameraYaw;
        prevCameraPitch = state.prevCameraPitch;
        prevDistanceWalkedModified = state.prevDistanceWalkedModified;
        prevLimbSwingAmount = state.prevLimbSwingAmount;
        prevSwingProgress = state.prevSwingProgress;
        prevChasingPosX = state.prevChasingPosX;
        prevChasingPosY = state.prevChasingPosY;
        prevChasingPosZ = state.prevChasingPosZ;
    }

    private void syncPrevRenderStateToCurrent() {
        prevPosX = posX;
        prevPosY = posY;
        prevPosZ = posZ;
        lastTickPosX = posX;
        lastTickPosY = posY;
        lastTickPosZ = posZ;
        prevRotationYaw = rotationYaw;
        prevRotationPitch = rotationPitch;
        prevRotationYawHead = rotationYawHead;
        prevRenderYawOffset = renderYawOffset;
        prevCameraYaw = cameraYaw;
        prevCameraPitch = cameraPitch;
        prevDistanceWalkedModified = distanceWalkedModified;
        prevLimbSwingAmount = limbSwingAmount;
        prevSwingProgress = swingProgress;
        prevChasingPosX = chasingPosX;
        prevChasingPosY = chasingPosY;
        prevChasingPosZ = chasingPosZ;
        prevTimeInPortal = timeInPortal;
    }

    private static class InterpolationState {
        private final double prevPosX;
        private final double prevPosY;
        private final double prevPosZ;
        private final double lastTickPosX;
        private final double lastTickPosY;
        private final double lastTickPosZ;
        private final float prevRotationYaw;
        private final float prevRotationPitch;
        private final float prevRotationYawHead;
        private final float prevRenderYawOffset;
        private final float prevCameraYaw;
        private final float prevCameraPitch;
        private final float prevDistanceWalkedModified;
        private final float prevLimbSwingAmount;
        private final float prevSwingProgress;
        private final double prevChasingPosX;
        private final double prevChasingPosY;
        private final double prevChasingPosZ;

        private InterpolationState(double prevPosX, double prevPosY, double prevPosZ, double lastTickPosX, double lastTickPosY, double lastTickPosZ, float prevRotationYaw, float prevRotationPitch, float prevRotationYawHead, float prevRenderYawOffset, float prevCameraYaw, float prevCameraPitch, float prevDistanceWalkedModified, float prevLimbSwingAmount, float prevSwingProgress, double prevChasingPosX, double prevChasingPosY, double prevChasingPosZ) {
            this.prevPosX = prevPosX;
            this.prevPosY = prevPosY;
            this.prevPosZ = prevPosZ;
            this.lastTickPosX = lastTickPosX;
            this.lastTickPosY = lastTickPosY;
            this.lastTickPosZ = lastTickPosZ;
            this.prevRotationYaw = prevRotationYaw;
            this.prevRotationPitch = prevRotationPitch;
            this.prevRotationYawHead = prevRotationYawHead;
            this.prevRenderYawOffset = prevRenderYawOffset;
            this.prevCameraYaw = prevCameraYaw;
            this.prevCameraPitch = prevCameraPitch;
            this.prevDistanceWalkedModified = prevDistanceWalkedModified;
            this.prevLimbSwingAmount = prevLimbSwingAmount;
            this.prevSwingProgress = prevSwingProgress;
            this.prevChasingPosX = prevChasingPosX;
            this.prevChasingPosY = prevChasingPosY;
            this.prevChasingPosZ = prevChasingPosZ;
        }
    }
}
