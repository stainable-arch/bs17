package keystrokesmod.mixin.impl.render;

import keystrokesmod.utility.GhostHandRenderState;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GlStateManager.class)
public abstract class MixinGlStateManager {
    @Inject(method = "disableCull", at = @At("HEAD"), cancellable = true)
    private static void ghostHand$keepBackFacesHidden(CallbackInfo ci) {
        if (GhostHandRenderState.isActive()) {
            ci.cancel();
        }
    }

    @Inject(method = "disableBlend", at = @At("HEAD"), cancellable = true)
    private static void ghostHand$keepBlendEnabled(CallbackInfo ci) {
        if (GhostHandRenderState.isActive()) {
            GlStateManager.tryBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ZERO);
            ci.cancel();
        }
    }

    @Inject(method = "blendFunc", at = @At("HEAD"), cancellable = true)
    private static void ghostHand$blendSeparate(int source, int destination, CallbackInfo ci) {
        if (GhostHandRenderState.isActive()) {
            GlStateManager.tryBlendFuncSeparate(source, destination, GL11.GL_ONE, GL11.GL_ZERO);
            ci.cancel();
        }
    }

    @ModifyVariable(method = "tryBlendFuncSeparate", at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private static int ghostHand$sourceFactor(int factor) {
        return GhostHandRenderState.isActive() ? GL11.GL_CONSTANT_ALPHA : factor;
    }

    @ModifyVariable(method = "tryBlendFuncSeparate", at = @At("HEAD"), argsOnly = true, ordinal = 1)
    private static int ghostHand$destinationFactor(int factor) {
        return GhostHandRenderState.isActive() && factor != GL11.GL_ONE ? GL11.GL_ONE_MINUS_CONSTANT_ALPHA : factor;
    }

    @ModifyVariable(method = "tryBlendFuncSeparate", at = @At("HEAD"), argsOnly = true, ordinal = 2)
    private static int ghostHand$sourceAlphaFactor(int factor) {
        return GhostHandRenderState.isActive() ? GL11.GL_CONSTANT_ALPHA : factor;
    }

    @ModifyVariable(method = "tryBlendFuncSeparate", at = @At("HEAD"), argsOnly = true, ordinal = 3)
    private static int ghostHand$destinationAlphaFactor(int factor) {
        return GhostHandRenderState.isActive() ? GL11.GL_ONE_MINUS_CONSTANT_ALPHA : factor;
    }

    @ModifyVariable(method = "depthMask", at = @At("HEAD"), argsOnly = true)
    private static boolean ghostHand$disableDepthWrites(boolean enabled) {
        return enabled && !GhostHandRenderState.isActive();
    }

    @Inject(method = "color(FFFF)V", at = @At("HEAD"))
    private static void ghostHand$colorAlpha(float red, float green, float blue, float alpha, CallbackInfo ci) {
        GhostHandRenderState.setColorAlpha(alpha);
    }
}
