package keystrokesmod.event;

import net.minecraftforge.fml.common.eventhandler.Event;

public class ClientRotationEvent extends Event {
    public Float yaw;
    public Float pitch;
    public boolean scriptRotations;
    private Float exactYaw, exactPitch;
    private boolean serverRelativeMovement;

    public void claimExactRotations(float yaw, float pitch, boolean serverRelativeMovement) {
        this.yaw = this.exactYaw = yaw;
        this.pitch = this.exactPitch = pitch;
        this.serverRelativeMovement = serverRelativeMovement;
    }

    public boolean hasExactRotations() {
        return exactYaw != null && exactYaw.equals(yaw) && exactPitch.equals(pitch);
    }

    public boolean hasServerRelativeMovement() {
        return hasExactRotations() && serverRelativeMovement;
    }

    public ClientRotationEvent(Float yaw, Float pitch) {
        this.yaw = yaw;
        this.pitch = pitch;
    }

    public void setYaw(Float yaw) {
        exactYaw = null;
        this.yaw = yaw;
    }

    public void setPitch(Float pitch) {
        exactYaw = null;
        this.pitch = pitch;
    }
}
