# Project Instructions

- Do not create, modify, or run automated tests unless explicitly requested.
- Do not add testing libraries, dependencies, or configuration.
- Do not run test commands as part of verification.
- Do not run tests such as launching the game or etc. unless explicitly requested.
- Do not create comments.
- When adding button settings, always add them below slider settings, and not in the middle, unless explicitly requested.
- Minecraft source code is stored in C:\Users\ThatC\Documents\raven bs dev, use the source code to help you understand the game and how to implement features.